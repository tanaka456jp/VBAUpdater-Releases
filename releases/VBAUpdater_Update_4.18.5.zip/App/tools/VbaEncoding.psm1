Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Get-VbaAnsiEncoding {
    [CmdletBinding()]
    param([int]$CodePage=0)

    if($CodePage-le0){$CodePage = [System.Globalization.CultureInfo]::CurrentCulture.TextInfo.ANSICodePage}
    return [System.Text.Encoding]::GetEncoding(
        $CodePage,
        [System.Text.EncoderFallback]::ExceptionFallback,
        [System.Text.DecoderFallback]::ExceptionFallback)
}

function Get-UnicodeCodePointLabel {
    param([Parameter(Mandatory=$true)][string]$Text)

    if ($Text.Length -eq 2 -and [char]::IsSurrogatePair($Text[0],$Text[1])) {
        $value = [char]::ConvertToUtf32($Text[0],$Text[1])
        return ('U+{0:X6}' -f $value)
    }
    return ('U+{0:X4}' -f [int][char]$Text[0])
}

function Test-VbaSourceEncodingRoundTrip {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$ComponentName,
        [Parameter(Mandatory=$true)][ValidateSet('standard','class','document','userform')][string]$ComponentType,
        [int]$CodePage=0
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "VBA source file not found: $Path"
    }
    $extension = [System.IO.Path]::GetExtension($Path).ToLowerInvariant()
    if ($extension -notin @('.bas','.cls','.frm')) {
        throw "Unsupported VBA text source extension: $extension"
    }

    $normalizer = Get-Command Read-VbaTextFile -ErrorAction SilentlyContinue
    if ($null -ne $normalizer) {
        $text = Read-VbaTextFile -Path $Path
    }
    else {
        $bytes = [System.IO.File]::ReadAllBytes($Path)
        if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
            $text = [System.Text.Encoding]::UTF8.GetString($bytes, 3, $bytes.Length - 3)
        }
        elseif ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
            $text = [System.Text.Encoding]::Unicode.GetString($bytes, 2, $bytes.Length - 2)
        }
        elseif ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFE -and $bytes[1] -eq 0xFF) {
            $text = [System.Text.Encoding]::BigEndianUnicode.GetString($bytes, 2, $bytes.Length - 2)
        }
        else {
            $strictUtf8 = New-Object System.Text.UTF8Encoding($false,$true)
            try { $text = $strictUtf8.GetString($bytes) }
            catch { $text = [System.Text.Encoding]::Default.GetString($bytes) }
        }
    }

    $encoding = Get-VbaAnsiEncoding -CodePage $CodePage
    $diagnostics = New-Object 'System.Collections.Generic.List[object]'
    $lines = @(([string]$text -replace "`r`n","`n" -replace "`r","`n").Split([string[]]@("`n"),[System.StringSplitOptions]::None))
    for ($lineIndex = 0; $lineIndex -lt $lines.Count; $lineIndex++) {
        $line = [string]$lines[$lineIndex]
        for ($column = 0; $column -lt $line.Length; $column++) {
            $character = [string]$line[$column]
            if ([char]::IsHighSurrogate($line[$column]) -and ($column + 1) -lt $line.Length -and [char]::IsLowSurrogate($line[$column + 1])) {
                $character = $line.Substring($column,2)
                $column++
            }

            $roundTripped = $null
            $reason = ''
            try {
                $encoded = $encoding.GetBytes($character)
                $roundTripped = $encoding.GetString($encoded)
                if (-not [string]::Equals($character,$roundTripped,[System.StringComparison]::Ordinal)) {
                    $reason = ('ANSI code page {0} maps the character to {1}' -f $encoding.CodePage,(Get-UnicodeCodePointLabel -Text $roundTripped))
                }
            }
            catch {
                $reason = ('ANSI code page {0} cannot encode the character' -f $encoding.CodePage)
            }

            if (-not [string]::IsNullOrWhiteSpace($reason)) {
                [void]$diagnostics.Add([PSCustomObject]@{
                    Component=$ComponentName
                    ComponentType=$ComponentType
                    SourceFile=[System.IO.Path]::GetFullPath($Path)
                    Line=($lineIndex + 1)
                    Column=($column - $character.Length + 2)
                    Character=$character
                    CodePoint=Get-UnicodeCodePointLabel -Text $character
                    Reason=$reason
                })
            }
        }
    }

    return [PSCustomObject]@{
        IsSafe=($diagnostics.Count -eq 0)
        CodePage=$encoding.CodePage
        EncodingName=$encoding.EncodingName
        Component=$ComponentName
        ComponentType=$ComponentType
        SourceFile=[System.IO.Path]::GetFullPath($Path)
        Diagnostics=[object[]]$diagnostics.ToArray()
    }
}

function Assert-VbaSourceEncodingSafe {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$ComponentName,
        [Parameter(Mandatory=$true)][ValidateSet('standard','class','document','userform')][string]$ComponentType
    )

    $result = Test-VbaSourceEncodingRoundTrip -Path $Path -ComponentName $ComponentName -ComponentType $ComponentType
    if ($result.IsSafe) { return $result }

    $first = $result.Diagnostics[0]
    throw ("[ENC1001] VBA source contains a character that cannot round-trip through Excel VBE. Component={0}; SourceFile={1}; Line={2}; Column={3}; Character={4}; CodePoint={5}; Reason={6}; Total={7}" -f
        $first.Component,$first.SourceFile,$first.Line,$first.Column,$first.Character,$first.CodePoint,$first.Reason,$result.Diagnostics.Count)
}

Export-ModuleMember -Function Get-VbaAnsiEncoding,Test-VbaSourceEncodingRoundTrip,Assert-VbaSourceEncodingSafe
