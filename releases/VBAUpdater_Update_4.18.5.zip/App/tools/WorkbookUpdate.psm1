﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$script:WorkbookSchemaVersion = '1.0'
$script:AllowedWorkbookExtensions = @('.xlsm', '.xlsb', '.xlam')
$script:AllowedImageExtensions = @('.png', '.jpg', '.jpeg', '.gif', '.bmp')
$script:KnownRootFields = @('schemaVersion','workbookId','worksheets','ranges','rows','columns','names','validations','conditionalFormats','tables','shapes','pageSetups','migrations')
$script:WorkbookOpenAuditHook = $null
$script:OwnedWorkbookExcelApplications = @{}

if ($null -eq ('VBAUpdater.ExcelRangeWriter' -as [type])) {
    Add-Type -ReferencedAssemblies Microsoft.CSharp -TypeDefinition @'
namespace VBAUpdater {
    public static class ExcelRangeWriter {
        public static void SetValue2(object range, object value) { dynamic target = range; target.Value2 = value; }
        public static void SetFormula(object range, object value) { dynamic target = range; target.Formula = value; }
        public static void SetFormula2(object range, object value) { dynamic target = range; target.Formula2 = value; }
    }
}
'@
}

function Get-ObjectProperty {
    param([AllowNull()]$Object,[Parameter(Mandatory=$true)][string]$Name,[AllowNull()]$Default=$null)
    if ($null -eq $Object -or $null -eq $Object.PSObject.Properties[$Name]) { return $Default }
    return $Object.$Name
}

function Set-WorkbookOpenAuditHook {
    [CmdletBinding()]
    param([AllowNull()][scriptblock]$Hook)
    $script:WorkbookOpenAuditHook=$Hook
}

function Invoke-WorkbookOpenAuditHook {
    param([Parameter(Mandatory=$true)][string]$Path,[Parameter(Mandatory=$true)][string]$ProjectDir)
    if($null-ne$script:WorkbookOpenAuditHook){& $script:WorkbookOpenAuditHook $Path $ProjectDir}
}

function Test-JsonObject {
    param([AllowNull()]$Value)
    return ($null -ne $Value -and -not ($Value -is [string]) -and -not ($Value -is [System.Array]) -and -not ($Value -is [System.ValueType]))
}

function Resolve-SafeProjectPath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$ProjectDir,
        [Parameter(Mandatory=$true)][string]$RelativePath,
        [switch]$MustExist,
        [ValidateSet('Any','File','Directory')][string]$PathType='Any'
    )
    if ([string]::IsNullOrWhiteSpace($RelativePath)) { throw '[WB1001] 相対パスが空です。' }
    if ([System.IO.Path]::IsPathRooted($RelativePath)) { throw "[WB1002] 絶対パスは禁止されています: $RelativePath" }
    if ($RelativePath.IndexOfAny([System.IO.Path]::GetInvalidPathChars()) -ge 0) { throw "[WB1003] パスに使用できない文字があります: $RelativePath" }
    $root = [System.IO.Path]::GetFullPath($ProjectDir).TrimEnd([System.IO.Path]::DirectorySeparatorChar,[System.IO.Path]::AltDirectorySeparatorChar)
    $candidate = [System.IO.Path]::GetFullPath((Join-Path $root $RelativePath))
    $prefix = $root + [System.IO.Path]::DirectorySeparatorChar
    if (-not $candidate.StartsWith($prefix,[System.StringComparison]::OrdinalIgnoreCase)) { throw "[WB1004] プロジェクト外への参照は禁止されています: $RelativePath" }
    if ($MustExist) {
        $type = switch($PathType){'File'{'Leaf'};'Directory'{'Container'};default{$null}}
        $exists = if($null -eq $type){Test-Path -LiteralPath $candidate}else{Test-Path -LiteralPath $candidate -PathType $type}
        if(-not $exists){throw "[WB1005] 参照先が見つかりません: $RelativePath"}
    }
    return $candidate
}

function Get-WorkbookProjectConfiguration {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$ProjectDir,[Parameter(Mandatory=$true)]$ProjectManifest)
    if ($null -eq $ProjectManifest.PSObject.Properties['workbook'] -or $null -eq $ProjectManifest.workbook) {
        return [PSCustomObject]@{Enabled=$false;DefinitionPath='';RelativeDefinitionPath='';Reason='NotConfigured'}
    }
    $config=$ProjectManifest.workbook
    if(-not (Test-JsonObject $config)){throw '[WB1010] project.json の workbook はJSONオブジェクトで指定してください。'}
    foreach($p in $config.PSObject.Properties.Name){if($p -notin @('enabled','definition')){throw "[WB1011] workbook に未知のフィールドがあります: $p"}}
    $enabled=$true
    if($config.PSObject.Properties['enabled']){
        if(-not ($config.enabled -is [bool])){throw '[WB1012] workbook.enabled はtrueまたはfalseで指定してください。'}
        $enabled=[bool]$config.enabled
    }
    if(-not $enabled){return [PSCustomObject]@{Enabled=$false;DefinitionPath='';RelativeDefinitionPath='';Reason='Disabled'}}
    $relative=[string](Get-ObjectProperty $config 'definition' '')
    if([string]::IsNullOrWhiteSpace($relative)){throw '[WB1013] workbook.enabled=true の場合は workbook.definition が必要です。'}
    $path=Resolve-SafeProjectPath -ProjectDir $ProjectDir -RelativePath $relative -MustExist -PathType File
    if([System.IO.Path]::GetExtension($path) -ine '.json'){throw '[WB1014] Workbook定義は.jsonファイルで指定してください。'}
    return [PSCustomObject]@{Enabled=$true;DefinitionPath=$path;RelativeDefinitionPath=$relative;Reason='Configured'}
}

function Read-WorkbookDefinition {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Path)
    try{$definition=Get-Content -LiteralPath $Path -Raw -Encoding UTF8|ConvertFrom-Json}
    catch{throw "[WB1100] Workbook定義JSONを読み込めません: $($_.Exception.Message)"}
    if(-not (Test-JsonObject $definition)){throw '[WB1101] Workbook定義のルートはJSONオブジェクトである必要があります。'}
    return $definition
}

function Test-WorksheetName {
    param([Parameter(Mandatory=$true)][string]$Name)
    if([string]::IsNullOrWhiteSpace($Name)-or$Name.Length -gt 31){return $false}
    if($Name.IndexOfAny([char[]]'[]:*?/\') -ge 0){return $false}
    if($Name.StartsWith("'")-or$Name.EndsWith("'")){return $false}
    return $true
}

function Test-A1Address {
    param([Parameter(Mandatory=$true)][string]$Address)
    return $Address -match '^\$?[A-Z]{1,3}\$?[1-9][0-9]{0,6}(:\$?[A-Z]{1,3}\$?[1-9][0-9]{0,6})?$'
}

function ConvertTo-ColumnNumber {param([string]$Letters)$number=0;foreach($ch in $Letters.ToUpperInvariant().ToCharArray()){$number=($number*26)+([int]$ch-[int][char]'A'+1)};return $number}

function Get-A1Bounds {
    param([string]$Address)
    $parts=$Address.Replace('$','').ToUpperInvariant().Split(':');$first=$parts[0];$last=if($parts.Count-gt1){$parts[1]}else{$first};[void]($first-match'^([A-Z]+)([0-9]+)$');$c1=ConvertTo-ColumnNumber $matches[1];$r1=[int]$matches[2];[void]($last-match'^([A-Z]+)([0-9]+)$');$c2=ConvertTo-ColumnNumber $matches[1];$r2=[int]$matches[2];return [pscustomobject]@{Row1=[math]::Min($r1,$r2);Row2=[math]::Max($r1,$r2);Column1=[math]::Min($c1,$c2);Column2=[math]::Max($c1,$c2)}
}

function Test-A1Overlap {param([string]$First,[string]$Second)$a=Get-A1Bounds $First;$b=Get-A1Bounds $Second;return -not($a.Row2-lt$b.Row1-or$b.Row2-lt$a.Row1-or$a.Column2-lt$b.Column1-or$b.Column2-lt$a.Column1)}

function Test-ExternalWorkbookReference {
    param([AllowNull()]$Value)
    if($null-eq$Value){return $false}
    if($Value-is[System.Array]){foreach($item in $Value){if(Test-ExternalWorkbookReference $item){return $true}};return $false}
    return ([string]$Value -match '(?i)\[[^\]]+\.(xls|xlsx|xlsm|xlsb|xla|xlam|csv)\]')
}

function Assert-UniqueIdAndTarget {
    param([object[]]$Items,[string]$Section,[scriptblock]$TargetSelector)
    $ids=@{};$targets=@{}
    foreach($item in @($Items)){
        if(-not(Test-JsonObject $item)){throw "[WB1110] $Section の各要素はJSONオブジェクトで指定してください。"}
        $id=[string](Get-ObjectProperty $item 'id' '')
        if([string]::IsNullOrWhiteSpace($id)){throw "[WB1111] $Section のidがありません。"}
        $idKey=$id.ToLowerInvariant()
        if($ids.ContainsKey($idKey)){throw "[WB1112] $Section のidが重複しています: $id"};$ids[$idKey]=$true
        $target=[string](& $TargetSelector $item)
        if(-not[string]::IsNullOrWhiteSpace($target)){
            $targetKey=$target.ToLowerInvariant()
            if($targets.ContainsKey($targetKey)){throw "[WB1113] $Section の更新対象が重複しています: $target"};$targets[$targetKey]=$true
        }
    }
}

function Test-WorkbookDefinition {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)]$Definition,[Parameter(Mandatory=$true)][string]$ProjectDir)
    foreach($p in $Definition.PSObject.Properties.Name){if($p -notin $script:KnownRootFields){throw "[WB1102] Workbook定義に未知のフィールドがあります: $p"}}
    if($null -eq $Definition.PSObject.Properties['schemaVersion']){throw '[WB1103] schemaVersionがありません。'}
    if([string]$Definition.schemaVersion -ne $script:WorkbookSchemaVersion){throw "[WB1104] 未対応のWorkbook schemaVersionです: $($Definition.schemaVersion)"}
    if($Definition.PSObject.Properties['workbookId'] -and [string]::IsNullOrWhiteSpace([string]$Definition.workbookId)){throw '[WB1105] workbookIdは空にできません。'}

    $worksheets=@(Get-ObjectProperty $Definition 'worksheets' @())
    Assert-UniqueIdAndTarget -Items $worksheets -Section 'worksheets' -TargetSelector {param($x) [string](Get-ObjectProperty $x 'name' '')}
    $knownSheetIds=@{}
    foreach($sheet in $worksheets){
        foreach($p in $sheet.PSObject.Properties.Name){if($p -notin @('id','action','name','from','position','visible','tabColor','allowDelete','protection','view')){throw "[WB1120] worksheetsに未知のフィールドがあります: $p"}}
        $action=[string](Get-ObjectProperty $sheet 'action' 'ensure')
        if($action -notin @('ensure','rename','delete')){throw "[WB1121] 不正なWorksheet actionです: $action"}
        $name=[string](Get-ObjectProperty $sheet 'name' '')
        if(-not(Test-WorksheetName $name)){throw "[WB1122] 不正なシート名です: $name"}
        if($action -eq 'rename'){$from=[string](Get-ObjectProperty $sheet 'from' '');if(-not(Test-WorksheetName $from)){throw "[WB1123] rename元シート名が不正です: $from"};if($from -ieq $name){throw '[WB1124] rename元とrename先が同じです。'}}
        if($action -eq 'delete' -and -not [bool](Get-ObjectProperty $sheet 'allowDelete' $false)){throw "[WB1125] シート削除にはallowDelete=trueが必要です: $name"}
        $position=Get-ObjectProperty $sheet 'position' $null;if($null-ne$position -and (-not($position-is[int])-or[int]$position-lt 1)){throw "[WB1126] positionは1以上の整数です: $name"}
        $visible=[string](Get-ObjectProperty $sheet 'visible' 'visible');if($visible -notin @('visible','hidden','veryHidden')){throw "[WB1127] 不正なvisible値です: $visible"}
        $protection=Get-ObjectProperty $sheet 'protection' $null
        if($null-ne$protection){if(-not(Test-JsonObject $protection)){throw '[WB1128] protectionはJSONオブジェクトです。'};if([string](Get-ObjectProperty $protection 'mode' 'preserve') -ne 'preserve'){throw '[WB1129] パスワード管理基盤がないためWorksheet保護の変更は未対応です。mode=preserveのみ指定できます。'}}
        $view=Get-ObjectProperty $sheet 'view' $null;if($null-ne$view){foreach($p in $view.PSObject.Properties.Name){if($p-notin@('freezeAt','zoom','showGridlines','showHeadings')){throw "[WB112A] viewに未知のフィールドがあります: $p"}};if($view.PSObject.Properties['freezeAt']-and-not(Test-A1Address (([string]$view.freezeAt).ToUpperInvariant()))){throw '[WB112B] view.freezeAtはA1形式のセルです。'}}
        $knownSheetIds[[string]$sheet.id]=$name
    }

    $ranges=@(Get-ObjectProperty $Definition 'ranges' @())
    Assert-UniqueIdAndTarget -Items $ranges -Section 'ranges' -TargetSelector {param($x) ([string](Get-ObjectProperty $x 'sheet' ''))+'!'+([string](Get-ObjectProperty $x 'address' ''))}
    foreach($range in $ranges){
        foreach($p in $range.PSObject.Properties.Name){if($p -notin @('id','sheet','address','policy','value','values','formula','formulas','note','hyperlink','merge','allowDataLoss','style')){throw "[WB1130] rangesに未知のフィールドがあります: $p"}}
        $sheet=[string](Get-ObjectProperty $range 'sheet' '');if(-not(Test-WorksheetName $sheet)){throw "[WB1131] ranges.sheetが不正です: $sheet"}
        $address=([string](Get-ObjectProperty $range 'address' '')).ToUpperInvariant();if(-not(Test-A1Address $address)){throw "[WB1132] 不正なセル範囲です: $address"}
        $policy=[string](Get-ObjectProperty $range 'policy' 'managed');if($policy -notin @('managed','preserve','setIfBlank','clear','formulaOnly','valueOnly')){throw "[WB1133] 不正な更新policyです: $policy"}
        $payloadCount=0;foreach($p in @('value','values','formula','formulas')){if($range.PSObject.Properties[$p]){$payloadCount++}}
        if($policy -notin @('preserve','clear') -and $payloadCount -ne 1){throw "[WB1134] $policy はvalue/values/formula/formulasのいずれか1つを必要とします: $($range.id)"}
        if($policy -in @('preserve','clear') -and $payloadCount -gt 0){throw "[WB1135] $policy には値または数式を指定できません: $($range.id)"}
        if($policy -eq 'formulaOnly' -and -not($range.PSObject.Properties['formula']-or$range.PSObject.Properties['formulas'])){throw '[WB1136] formulaOnlyにはformulaまたはformulasが必要です。'}
        if($policy -eq 'valueOnly' -and -not($range.PSObject.Properties['value']-or$range.PSObject.Properties['values'])){throw '[WB1137] valueOnlyにはvalueまたはvaluesが必要です。'}
        foreach($formulaField in @('formula','formulas')){if($range.PSObject.Properties[$formulaField]-and(Test-ExternalWorkbookReference $range.$formulaField)){throw "[WB113D] 外部Workbook参照を含む数式は安全に解決できないため拒否します: $($range.id)"}}
        if($range.PSObject.Properties['merge'] -and -not($range.merge-is[bool])){throw '[WB1138] mergeはtrueまたはfalseです。'}
        if($range.PSObject.Properties['hyperlink']){$link=$range.hyperlink;if(-not(Test-JsonObject $link)-or[string]::IsNullOrWhiteSpace([string](Get-ObjectProperty $link 'address' ''))){throw '[WB1139] hyperlink.addressが必要です。'}}
        if($range.PSObject.Properties['style']){$style=$range.style;if(-not(Test-JsonObject $style)){throw '[WB113A] styleはJSONオブジェクトです。'};foreach($p in $style.PSObject.Properties.Name){if($p-notin@('font','fillColor','horizontalAlignment','verticalAlignment','wrapText','shrinkToFit','indentLevel','orientation','numberFormat','borders')){throw "[WB113B] styleに未知のフィールドがあります: $p"}};foreach($cp in @('fillColor')){if($style.PSObject.Properties[$cp]){[void](ConvertTo-ExcelColor ([string]$style.$cp))}};if($style.PSObject.Properties['font']){foreach($p in $style.font.PSObject.Properties.Name){if($p-notin@('name','size','bold','italic','underline','color')){throw "[WB113C] style.fontに未知のフィールドがあります: $p"}};if($style.font.PSObject.Properties['color']){[void](ConvertTo-ExcelColor ([string]$style.font.color))}}}
    }
    for($i=0;$i-lt$ranges.Count;$i++){for($j=$i+1;$j-lt$ranges.Count;$j++){if(([string]$ranges[$i].sheet-ieq[string]$ranges[$j].sheet)-and(Test-A1Overlap -First ([string]$ranges[$i].address) -Second ([string]$ranges[$j].address))){throw "[WB1144] 管理範囲が重複しています: $($ranges[$i].id), $($ranges[$j].id)"}}}

    foreach($section in @('rows','columns')){
        $items=@(Get-ObjectProperty $Definition $section @())
        Assert-UniqueIdAndTarget -Items $items -Section $section -TargetSelector {param($x) ([string](Get-ObjectProperty $x 'sheet' ''))+'!'+([string](Get-ObjectProperty $x 'index' ''))}
        foreach($item in $items){
            foreach($p in $item.PSObject.Properties.Name){if($p -notin @('id','sheet','index','size','hidden','autoFit')){throw "[WB1140] $section に未知のフィールドがあります: $p"}}
            if(-not(Test-WorksheetName ([string](Get-ObjectProperty $item 'sheet' '')))){throw "[WB1141] $section.sheetが不正です。"}
            $index=Get-ObjectProperty $item 'index' $null;if(-not($index-is[int])-or[int]$index-lt 1){throw "[WB1142] $section.indexは1以上の整数です。"}
            if($item.PSObject.Properties['autoFit'] -and [bool]$item.autoFit){throw '[WB1143] AutoFitは環境依存で冪等性を保証できないため正式適用では未対応です。'}
        }
    }

    $names=@(Get-ObjectProperty $Definition 'names' @())
    Assert-UniqueIdAndTarget -Items $names -Section 'names' -TargetSelector {param($x) ([string](Get-ObjectProperty $x 'scope' 'workbook'))+'|'+([string](Get-ObjectProperty $x 'name' ''))}
    foreach($name in $names){if([string]::IsNullOrWhiteSpace([string](Get-ObjectProperty $name 'name' ''))-or[string]::IsNullOrWhiteSpace([string](Get-ObjectProperty $name 'refersTo' ''))){throw '[WB1150] 名前定義にはnameとrefersToが必要です。'};if(([string]$name.name).StartsWith('_xlnm.',[System.StringComparison]::OrdinalIgnoreCase)){throw '[WB1151] Excel組込み名はnamesでは管理できません。'};if(Test-ExternalWorkbookReference $name.refersTo){throw "[WB1153] 外部Workbook参照を含む名前定義は安全に解決できないため拒否します: $($name.name)"}}
    foreach($name in $names){foreach($p in $name.PSObject.Properties.Name){if($p-notin@('id','scope','name','refersTo','visible')){throw "[WB1152] namesに未知のフィールドがあります: $p"}}}

    $validations=@(Get-ObjectProperty $Definition 'validations' @())
    Assert-UniqueIdAndTarget -Items $validations -Section 'validations' -TargetSelector {param($x) ([string](Get-ObjectProperty $x 'sheet' ''))+'!'+([string](Get-ObjectProperty $x 'address' ''))}
    foreach($v in $validations){foreach($p in $v.PSObject.Properties.Name){if($p-notin@('id','sheet','address','mode','type','operator','formula1','formula2','ignoreBlank','inCellDropdown','showInput','showError','inputTitle','inputMessage','errorTitle','errorMessage')){throw "[WB1159] validationsに未知のフィールドがあります: $p"}};$type=[string](Get-ObjectProperty $v 'type' '');if($type -notin @('list','whole','decimal','date','time','textLength','custom')){throw "[WB1160] 未対応の入力規則typeです: $type"};if([string](Get-ObjectProperty $v 'mode' 'replaceManagedRange') -ne 'replaceManagedRange'){throw '[WB1161] 入力規則modeはreplaceManagedRangeのみ対応します。'};if(-not(Test-A1Address (([string](Get-ObjectProperty $v 'address' '')).ToUpperInvariant()))){throw '[WB1162] 入力規則addressが不正です。'}}

    $conditional=@(Get-ObjectProperty $Definition 'conditionalFormats' @())
    if($conditional.Count -gt 0){throw '[WB1170] 条件付き書式は安全なルール識別を保証できないため、今回のApply対象外です。定義から除外してください。'}

    $tables=@(Get-ObjectProperty $Definition 'tables' @())
    Assert-UniqueIdAndTarget -Items $tables -Section 'tables' -TargetSelector {param($x) [string](Get-ObjectProperty $x 'name' '')}
    foreach($t in $tables){foreach($p in $t.PSObject.Properties.Name){if($p-notin@('id','sheet','name','address','mode','style','showTotals','showHeaders')){throw "[WB1179] tablesに未知のフィールドがあります: $p"}};if([string]::IsNullOrWhiteSpace([string](Get-ObjectProperty $t 'name' ''))-or-not(Test-A1Address (([string](Get-ObjectProperty $t 'address' '')).ToUpperInvariant()))){throw '[WB1180] tableには一意なnameと有効なaddressが必要です。'};if([string](Get-ObjectProperty $t 'mode' 'createOrExpand') -ne 'createOrExpand'){throw '[WB1181] データ損失防止のためtable.modeはcreateOrExpandのみ対応します。'}}
    foreach($t in $tables){foreach($r in $ranges){if(([string]$t.sheet-ieq[string]$r.sheet)-and(Test-A1Overlap -First ([string]$t.address) -Second ([string]$r.address))){throw "[WB1182] Table範囲とCell管理範囲の重複は禁止です: $($t.id), $($r.id)"}}}

    $deletedSheets=@($worksheets|Where-Object{[string](Get-ObjectProperty $_ 'action' 'ensure')-eq'delete'}|ForEach-Object{[string]$_.name})
    foreach($section in @('ranges','rows','columns','validations','tables','shapes','pageSetups')){foreach($item in @(Get-ObjectProperty $Definition $section @())){if([string](Get-ObjectProperty $item 'sheet' '')-in$deletedSheets){throw "[WB1183] 削除対象シートに別の更新定義があります: $section / $($item.id)"}}}

    $shapes=@(Get-ObjectProperty $Definition 'shapes' @())
    Assert-UniqueIdAndTarget -Items $shapes -Section 'shapes' -TargetSelector {param($x) ([string](Get-ObjectProperty $x 'sheet' ''))+'!'+([string](Get-ObjectProperty $x 'name' ''))}
    foreach($shape in $shapes){
        foreach($p in $shape.PSObject.Properties.Name){if($p-notin@('id','sheet','name','kind','asset','text','shapeType','left','top','width','height','visible','lockAspectRatio','placement','alternativeText','onAction')){throw "[WB1189] shapesに未知のフィールドがあります: $p"}}
        $kind=[string](Get-ObjectProperty $shape 'kind' '');if($kind -notin @('picture','textBox','shape','chartObject')){throw "[WB1190] 未対応のshape kindです: $kind"}
        if($kind -eq 'picture'){$asset=[string](Get-ObjectProperty $shape 'asset' '');$normalizedAsset=$asset.Replace('/','\');if($normalizedAsset-notmatch'(?i)^(source|assets)\\'){throw "[WB1193] 画像はsourceまたはassets配下で管理してください: $asset"};$assetPath=Resolve-SafeProjectPath -ProjectDir $ProjectDir -RelativePath $asset -MustExist -PathType File;if([System.IO.Path]::GetExtension($assetPath).ToLowerInvariant() -notin $script:AllowedImageExtensions){throw "[WB1191] 許可されていない画像拡張子です: $asset"}}
        if($shape.PSObject.Properties['onAction']){throw '[WB1192] OnActionの変更は今回の正式適用対象外です。既存割当は常に保持します。'}
    }

    $pageSetups=@(Get-ObjectProperty $Definition 'pageSetups' @())
    Assert-UniqueIdAndTarget -Items $pageSetups -Section 'pageSetups' -TargetSelector {param($x) [string](Get-ObjectProperty $x 'sheet' '')}
    $pageFields=@('id','sheet','printArea','printTitleRows','printTitleColumns','paperSize','orientation','zoom','fitToPagesWide','fitToPagesTall','leftMargin','rightMargin','topMargin','bottomMargin','headerMargin','footerMargin','centerHorizontally','centerVertically','leftHeader','centerHeader','rightHeader','leftFooter','centerFooter','rightFooter','blackAndWhite','draft','printComments','printErrors','printGridlines','printHeadings','order','manualRowBreaks','manualColumnBreaks','resetManualBreaks')
    foreach($page in $pageSetups){foreach($p in $page.PSObject.Properties.Name){if($p-notin$pageFields){throw "[WB1199] pageSetupsに未知のフィールドがあります: $p"}};if($page.PSObject.Properties['zoom'] -and ($page.PSObject.Properties['fitToPagesWide']-or$page.PSObject.Properties['fitToPagesTall'])){throw '[WB1200] zoomとFitToPagesは同時に指定できません。'};if($page.PSObject.Properties['resetManualBreaks']-and[bool]$page.resetManualBreaks){throw '[WB1201] 管理対象外の手動改ページを保護するためresetManualBreaksは未対応です。'};if($page.PSObject.Properties['orientation']-and[string]$page.orientation-notin@('portrait','landscape')){throw '[WB1202] orientationが不正です。'};if($page.PSObject.Properties['order']-and[string]$page.order-notin@('downThenOver','overThenDown')){throw '[WB1203] 印刷順序が不正です。'}}

    $migrations=@(Get-ObjectProperty $Definition 'migrations' @())
    if($migrations.Count -gt 0){throw '[WB1210] Migration実行は基盤設計のみです。migrationsを空配列にしてください。'}
    $globalIds=@{}
    foreach($section in @('worksheets','ranges','rows','columns','names','validations','tables','shapes','pageSetups')){foreach($item in @(Get-ObjectProperty $Definition $section @())){$idKey=([string]$item.id).ToLowerInvariant();if($globalIds.ContainsKey($idKey)){throw "[WB1211] 操作idは全Sectionで一意にしてください: $($item.id)"};$globalIds[$idKey]=$true}}
    $positions=@{};$renameSources=@{}
    foreach($sheet in $worksheets){if($sheet.PSObject.Properties['position']){$key=[string]$sheet.position;if($positions.ContainsKey($key)){throw "[WB1212] Worksheet positionが重複しています: $key"};$positions[$key]=$true};if([string](Get-ObjectProperty $sheet 'action' 'ensure')-eq'rename'){$key=([string]$sheet.from).ToLowerInvariant();if($renameSources.ContainsKey($key)){throw "[WB1213] rename元シートが重複しています: $($sheet.from)"};$renameSources[$key]=$true}}
    return [PSCustomObject]@{Valid=$true;SchemaVersion=$script:WorkbookSchemaVersion;WorksheetCount=$worksheets.Count;RangeCount=$ranges.Count;WarningCount=0}
}

function Set-WorksheetDefinition {
    param($Workbook,$Excel,$Definition)
    $action=[string](Get-ObjectProperty $Definition 'action' 'ensure');$name=[string]$Definition.name;$sheet=$null;$sheets=$null
    try{
        if($action-eq'rename'){$sheet=Get-WorksheetByName $Workbook ([string]$Definition.from);if($null-eq$sheet){throw "[WB2400] rename元シートがありません: $($Definition.from)"};$sheet.Name=$name}
        elseif($action-eq'delete'){$sheet=Get-WorksheetByName $Workbook $name;if($null-ne$sheet){Test-SheetDeleteSafety -Workbook $Workbook -Sheet $sheet -Name $name;$sheet.Delete()};return}
        else{$sheet=Get-WorksheetByName $Workbook $name;if($null-eq$sheet){$sheets=$Workbook.Worksheets;$sheet=$sheets.Add();$sheet.Name=$name}}
        if($Definition.PSObject.Properties['position']){$sheets=$Workbook.Worksheets;$position=[int]$Definition.position;if($position-gt[int]$sheets.Count){$position=[int]$sheets.Count};if([int]$sheet.Index-ne$position){$anchor=$null;try{$anchor=$sheets.Item($position);if([int]$sheet.Index-lt$position){$sheet.Move([Type]::Missing,$anchor)}else{$sheet.Move($anchor)}}finally{Release-WorkbookComObject $anchor}}}
        $vis=@{visible=-1;hidden=0;veryHidden=2};$sheet.Visible=$vis[[string](Get-ObjectProperty $Definition 'visible' 'visible')]
        if($Definition.PSObject.Properties['tabColor']){$tab=$null;try{$tab=$sheet.Tab;$tab.Color=ConvertTo-ExcelColor ([string]$Definition.tabColor)}finally{Release-WorkbookComObject $tab}}
        if($Definition.PSObject.Properties['view']){$view=$Definition.view;$sheet.Activate();$window=$null;$cell=$null;try{$window=$Excel.ActiveWindow
                if($view.PSObject.Properties['freezeAt']){$window.FreezePanes=$false;$cell=$sheet.Range([string]$view.freezeAt);$cell.Select();$window.FreezePanes=$true}
                if($view.PSObject.Properties['zoom']){$window.Zoom=[int]$view.zoom};if($view.PSObject.Properties['showGridlines']){$window.DisplayGridlines=[bool]$view.showGridlines};if($view.PSObject.Properties['showHeadings']){$window.DisplayHeadings=[bool]$view.showHeadings}
            }finally{Release-WorkbookComObject $cell;Release-WorkbookComObject $window}}
    }finally{Release-WorkbookComObject $sheets;Release-WorkbookComObject $sheet}
}

function Set-RangeDefinition {
    param($Workbook,$Definition)
    $sheet=Get-WorksheetByName $Workbook ([string]$Definition.sheet);if($null-eq$sheet){throw "[WB2500] 対象シートがありません: $($Definition.sheet)"};$range=$null;$comment=$null;$links=$null
    try{
        if([bool]$sheet.ProtectContents){throw "[WB2501] 保護されたシートのセルは更新できません: $($Definition.sheet)"}
        $range=$sheet.Range([string]$Definition.address);$policy=[string](Get-ObjectProperty $Definition 'policy' 'managed')
        $blank=$true;$cells=$null;try{$cells=$range.Cells;for($i=1;$i-le[int]$cells.Count;$i++){$cell=$null;try{$cell=$cells.Item($i);if($null-ne$cell.Value2-and[string]$cell.Value2-ne''){$blank=$false;break}}finally{Release-WorkbookComObject $cell}}}finally{Release-WorkbookComObject $cells}
        if($policy-eq'preserve'){return};if($policy-eq'setIfBlank'-and-not$blank){return}
        if($policy-eq'clear'){$range.ClearContents()}
        elseif($Definition.PSObject.Properties['value']){$scalar=$Definition.value;if($null-ne$scalar){$scalar=$scalar.PSObject.BaseObject};[VBAUpdater.ExcelRangeWriter]::SetValue2($range,$scalar)}
        elseif($Definition.PSObject.Properties['values']){$matrix=Get-MatrixFromJson -Value $Definition.values -Rows ([int]$range.Rows.Count) -Columns ([int]$range.Columns.Count) -Id ([string]$Definition.id);$matrix=$matrix.PSObject.BaseObject;[VBAUpdater.ExcelRangeWriter]::SetValue2($range,$matrix)}
        elseif($Definition.PSObject.Properties['formula']){try{[VBAUpdater.ExcelRangeWriter]::SetFormula2($range,[string]$Definition.formula)}catch{[VBAUpdater.ExcelRangeWriter]::SetFormula($range,[string]$Definition.formula)}}
        elseif($Definition.PSObject.Properties['formulas']){$matrix=Get-MatrixFromJson -Value $Definition.formulas -Rows ([int]$range.Rows.Count) -Columns ([int]$range.Columns.Count) -Id ([string]$Definition.id);$matrix=$matrix.PSObject.BaseObject;try{[VBAUpdater.ExcelRangeWriter]::SetFormula2($range,$matrix)}catch{[VBAUpdater.ExcelRangeWriter]::SetFormula($range,$matrix)}}
        if($Definition.PSObject.Properties['merge']){if([bool]$Definition.merge){if(-not[bool]$range.MergeCells){if(-not[bool](Get-ObjectProperty $Definition 'allowDataLoss' $false)){Test-RangeMergeSafety -Range $range -Target (($Definition.sheet)+'!'+$Definition.address)};$range.Merge()}}elseif([bool]$range.MergeCells){$range.UnMerge()}}
        if($Definition.PSObject.Properties['note']){try{$comment=$range.Comment}catch{Write-Verbose "既存ノートはありません: $($Definition.sheet)!$($Definition.address)"};if($null-ne$comment){$comment.Delete();Release-WorkbookComObject $comment;$comment=$null};if($null-ne$Definition.note-and-not[string]::IsNullOrWhiteSpace([string]$Definition.note)){$comment=$range.AddComment([string]$Definition.note)}}
        if($Definition.PSObject.Properties['hyperlink']){$links=$range.Hyperlinks;if([int]$links.Count-gt0){$links.Delete()};$h=$Definition.hyperlink;$display=[string](Get-ObjectProperty $h 'displayText' '');if([string]::IsNullOrWhiteSpace($display)){$display=[string]$range.Text};[void]$sheet.Hyperlinks.Add($range,[string]$h.address,[string](Get-ObjectProperty $h 'subAddress' ''),'',$display)}
        Set-RangeStyle -Range $range -Style (Get-ObjectProperty $Definition 'style' $null)
    }finally{Release-WorkbookComObject $links;Release-WorkbookComObject $comment;Release-WorkbookComObject $range;Release-WorkbookComObject $sheet}
}

function Set-RowColumnDefinition {
    param($Workbook,[string]$Section,$Definition)
    $sheet=Get-WorksheetByName $Workbook ([string]$Definition.sheet);if($null-eq$sheet){throw "[WB2550] 対象シートがありません: $($Definition.sheet)"};$obj=$null
    try{$obj=if($Section-eq'rows'){$sheet.Rows.Item([int]$Definition.index)}else{$sheet.Columns.Item([int]$Definition.index)};if($Definition.PSObject.Properties['size']){if($Section-eq'rows'){$obj.RowHeight=[double]$Definition.size}else{$obj.ColumnWidth=[double]$Definition.size}};if($Definition.PSObject.Properties['hidden']){$obj.Hidden=[bool]$Definition.hidden}}
    finally{Release-WorkbookComObject $obj;Release-WorkbookComObject $sheet}
}

function Set-NameDefinition {
    param($Workbook,$Definition)
    $scope=[string](Get-ObjectProperty $Definition 'scope' 'workbook');$name=$null;$sheet=$null
    try{try{if($scope-eq'workbook'){$name=$Workbook.Names.Item([string]$Definition.name)}else{$sheet=Get-WorksheetByName $Workbook $scope;if($null-eq$sheet){throw "[WB2560] 名前定義のscopeシートがありません: $scope"};$name=$sheet.Names.Item([string]$Definition.name)}}catch{$name=$null}
        if($null-ne$name){$name.RefersTo=[string]$Definition.refersTo;if($Definition.PSObject.Properties['visible']){$name.Visible=[bool]$Definition.visible}}
        elseif($scope-eq'workbook'){$name=$Workbook.Names.Add([string]$Definition.name,[string]$Definition.refersTo);$name.Visible=[bool](Get-ObjectProperty $Definition 'visible' $true)}
        else{$name=$sheet.Names.Add([string]$Definition.name,[string]$Definition.refersTo)}
    }finally{Release-WorkbookComObject $name;Release-WorkbookComObject $sheet}
}

function Set-ValidationDefinition {
    param($Workbook,$Definition)
    $sheet=Get-WorksheetByName $Workbook ([string]$Definition.sheet);if($null-eq$sheet){throw "[WB2570] 対象シートがありません: $($Definition.sheet)"};$range=$null;$validation=$null
    try{$range=$sheet.Range([string]$Definition.address);$validation=$range.Validation;try{$validation.Delete()}catch{Write-Verbose "既存の入力規則はありません: $($Definition.sheet)!$($Definition.address)"};$types=@{whole=1;decimal=2;list=3;date=4;time=5;textLength=6;custom=7};$operators=@{between=1;notBetween=2;equal=3;notEqual=4;greater=5;less=6;greaterOrEqual=7;lessOrEqual=8};$op=$operators[[string](Get-ObjectProperty $Definition 'operator' 'between')];$validation.Add($types[[string]$Definition.type],1,$op,[string](Get-ObjectProperty $Definition 'formula1' ''),[string](Get-ObjectProperty $Definition 'formula2' ''));foreach($pair in @(@('ignoreBlank','IgnoreBlank'),@('inCellDropdown','InCellDropdown'),@('showInput','ShowInput'),@('showError','ShowError'),@('inputTitle','InputTitle'),@('inputMessage','InputMessage'),@('errorTitle','ErrorTitle'),@('errorMessage','ErrorMessage'))){if($Definition.PSObject.Properties[$pair[0]]){$validation.($pair[1])=$Definition.($pair[0])}}}
    finally{Release-WorkbookComObject $validation;Release-WorkbookComObject $range;Release-WorkbookComObject $sheet}
}

function Set-TableDefinition {
    param($Workbook,$Definition)
    $sheet=Get-WorksheetByName $Workbook ([string]$Definition.sheet);if($null-eq$sheet){throw "[WB2580] 対象シートがありません: $($Definition.sheet)"};$table=$null;$range=$null;$oldRange=$null
    try{$range=$sheet.Range([string]$Definition.address);try{$table=$sheet.ListObjects.Item([string]$Definition.name)}catch{$table=$null};if($null-eq$table){$table=$sheet.ListObjects.Add(1,$range,$null,1);$table.Name=[string]$Definition.name}else{$oldRange=$table.Range;if([int]$range.Rows.Count-lt[int]$oldRange.Rows.Count-or[int]$range.Columns.Count-lt[int]$oldRange.Columns.Count){throw "[WB2581] データ損失防止のため既存テーブルの縮小は禁止されています: $($Definition.name)"};$table.Resize($range)};if($Definition.PSObject.Properties['style']){$table.TableStyle=[string]$Definition.style};if($Definition.PSObject.Properties['showTotals']){$table.ShowTotals=[bool]$Definition.showTotals};if($Definition.PSObject.Properties['showHeaders']){$table.ShowHeaders=[bool]$Definition.showHeaders}}
    finally{Release-WorkbookComObject $oldRange;Release-WorkbookComObject $range;Release-WorkbookComObject $table;Release-WorkbookComObject $sheet}
}

function Set-ShapeDefinition {
    param($Workbook,[string]$ProjectDir,$Definition)
    $sheet=Get-WorksheetByName $Workbook ([string]$Definition.sheet);if($null-eq$sheet){throw "[WB2590] 対象シートがありません: $($Definition.sheet)"};$shape=$null;$frame=$null;$chars=$null
    try{try{$shape=$sheet.Shapes.Item([string]$Definition.name)}catch{$shape=$null};$left=[double](Get-ObjectProperty $Definition 'left' 0);$top=[double](Get-ObjectProperty $Definition 'top' 0);$width=[double](Get-ObjectProperty $Definition 'width' 100);$height=[double](Get-ObjectProperty $Definition 'height' 100);$kind=[string]$Definition.kind
        if($kind-eq'picture'){$asset=Resolve-SafeProjectPath -ProjectDir $ProjectDir -RelativePath ([string]$Definition.asset)-MustExist -PathType File;$hash=(Get-FileHash -LiteralPath $asset -Algorithm SHA256).Hash;$marker=Get-ShapeMarker $hash ([string](Get-ObjectProperty $Definition 'alternativeText' ''));if($null-eq$shape){$shape=$sheet.Shapes.AddPicture($asset,$false,$true,$left,$top,$width,$height);$shape.Name=[string]$Definition.name}elseif([string]$shape.AlternativeText-cne$marker){$picture=$null;try{$picture=$shape.PictureFormat;$picture.Replace($asset)}catch{throw "[WB2591] 既存画像を参照を保ったまま置換できません: $($Definition.name) / $($_.Exception.Message)"}finally{Release-WorkbookComObject $picture}};$shape.AlternativeText=$marker}
        elseif($kind-eq'textBox'){if($null-eq$shape){$shape=$sheet.Shapes.AddTextbox(1,$left,$top,$width,$height);$shape.Name=[string]$Definition.name};if($Definition.PSObject.Properties['text']){$frame=$shape.TextFrame;$chars=$frame.Characters();$chars.Text=[string]$Definition.text}}
        elseif($kind-eq'shape'){if($null-eq$shape){$shape=$sheet.Shapes.AddShape([int](Get-ObjectProperty $Definition 'shapeType' 1),$left,$top,$width,$height);$shape.Name=[string]$Definition.name}}
        elseif($kind-eq'chartObject'){if($null-eq$shape){$chartObj=$null;try{$chartObj=$sheet.ChartObjects().Add($left,$top,$width,$height);$shape=$chartObj.ShapeRange.Item(1);$shape.Name=[string]$Definition.name}finally{Release-WorkbookComObject $chartObj}}}
        foreach($p in @('left','top','width','height')){if($Definition.PSObject.Properties[$p]){$shape.$p=[double]$Definition.$p}};if($Definition.PSObject.Properties['visible']){$shape.Visible=if([bool]$Definition.visible){-1}else{0}};if($Definition.PSObject.Properties['lockAspectRatio']){$shape.LockAspectRatio=if([bool]$Definition.lockAspectRatio){-1}else{0}};if($Definition.PSObject.Properties['placement']){$shape.Placement=[int]$Definition.placement}
    }finally{Release-WorkbookComObject $chars;Release-WorkbookComObject $frame;Release-WorkbookComObject $shape;Release-WorkbookComObject $sheet}
}

function Set-PageSetupDefinition {
    param($Workbook,$Definition)
    $sheet=Get-WorksheetByName $Workbook ([string]$Definition.sheet);if($null-eq$sheet){throw "[WB2600] 対象シートがありません: $($Definition.sheet)"};$page=$null
    try{$page=$sheet.PageSetup;if($Definition.PSObject.Properties['fitToPagesWide']-or$Definition.PSObject.Properties['fitToPagesTall']){$page.Zoom=$false};$map=@{printArea='PrintArea';printTitleRows='PrintTitleRows';printTitleColumns='PrintTitleColumns';paperSize='PaperSize';zoom='Zoom';fitToPagesWide='FitToPagesWide';fitToPagesTall='FitToPagesTall';leftMargin='LeftMargin';rightMargin='RightMargin';topMargin='TopMargin';bottomMargin='BottomMargin';headerMargin='HeaderMargin';footerMargin='FooterMargin';centerHorizontally='CenterHorizontally';centerVertically='CenterVertically';leftHeader='LeftHeader';centerHeader='CenterHeader';rightHeader='RightHeader';leftFooter='LeftFooter';centerFooter='CenterFooter';rightFooter='RightFooter';blackAndWhite='BlackAndWhite';draft='Draft';printGridlines='PrintGridlines';printHeadings='PrintHeadings';printComments='PrintComments';printErrors='PrintErrors'};foreach($p in $map.Keys){if($Definition.PSObject.Properties[$p]){$page.($map[$p])=$Definition.$p}};if($Definition.PSObject.Properties['orientation']){$page.Orientation=@{portrait=1;landscape=2}[[string]$Definition.orientation]};if($Definition.PSObject.Properties['order']){$page.Order=@{downThenOver=1;overThenDown=2}[[string]$Definition.order]}
        foreach($b in @(Get-ObjectProperty $Definition 'manualRowBreaks' @())){$range=$null;try{$range=$sheet.Rows.Item([int]$b);$sheet.HPageBreaks.Add($range)|Out-Null}finally{Release-WorkbookComObject $range}};foreach($b in @(Get-ObjectProperty $Definition 'manualColumnBreaks' @())){$range=$null;try{$range=$sheet.Columns.Item([int]$b);$sheet.VPageBreaks.Add($range)|Out-Null}finally{Release-WorkbookComObject $range}}
    }finally{Release-WorkbookComObject $page;Release-WorkbookComObject $sheet}
}

function Write-WorkbookResultLog {
    param([string]$LogDirectory,$Result)
    if([string]::IsNullOrWhiteSpace($LogDirectory)){return ''};New-Item -ItemType Directory -Path $LogDirectory -Force|Out-Null;$path=Join-Path $LogDirectory ('workbook_update_'+[DateTime]::Now.ToString('yyyyMMdd_HHmmss_fff')+'.json');[IO.File]::WriteAllText($path,($Result|ConvertTo-Json -Depth 10),(New-Object Text.UTF8Encoding($false)));return $path
}

function Invoke-WorkbookUpdate {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$ProjectDir,[Parameter(Mandatory=$true)]$ProjectManifest,[Parameter(Mandatory=$true)][string]$TargetPath,[ValidateSet('Validate','Diff','Apply','Verify')][string]$Mode='Validate',[string]$LogDirectory,[string]$BackupDirectory,[ValidateSet('None','AfterOpen','AfterWorksheet','BeforeSave','AfterSave','AfterSaveRestoreFailure')][string]$FailureInjection='None')
    $started=Get-Date;$context=Get-WorkbookDefinitionContext -ProjectDir $ProjectDir -ProjectManifest $ProjectManifest
    if(-not$context.Enabled){return [PSCustomObject]@{success=$true;code='WB0001';mode=$Mode;enabled=$false;changedCount=0;message='Workbook更新定義はありません。'}}
    if($Mode-eq'Validate'){$result=[PSCustomObject]@{success=$true;code='WB0000';mode=$Mode;enabled=$true;schemaVersion=[string]$context.Definition.schemaVersion;changedCount=0;backupPath='';restoreAttempted=$false;restoreSucceeded=$null;excelCloseErrors=@();elapsedSeconds=[math]::Round(((Get-Date)-$started).TotalSeconds,3)};[void](Write-WorkbookResultLog $LogDirectory $result);return $result}
    $plan=Get-WorkbookUpdatePlan -ProjectDir $ProjectDir -ProjectManifest $ProjectManifest -TargetPath $TargetPath
    if($Mode-eq'Diff'){$result=[PSCustomObject]@{success=$true;code='WB0000';mode=$Mode;enabled=$true;schemaVersion=$plan.SchemaVersion;changedCount=$plan.ChangedCount;unchangedCount=$plan.UnchangedCount;operations=@($plan.Operations|Select-Object id,category,target,action,changed);backupPath='';restoreAttempted=$false;restoreSucceeded=$null;excelCloseErrors=@();elapsedSeconds=[math]::Round(((Get-Date)-$started).TotalSeconds,3)};[void](Write-WorkbookResultLog $LogDirectory $result);return $result}
    if($Mode-eq'Verify'){$ok=$plan.ChangedCount-eq0;$result=[PSCustomObject]@{success=$ok;code=if($ok){'WB0000'}else{'WB3001'};mode=$Mode;enabled=$true;schemaVersion=$plan.SchemaVersion;changedCount=$plan.ChangedCount;operations=@($plan.Operations|Where-Object changed|Select-Object id,category,target,action);backupPath='';restoreAttempted=$false;restoreSucceeded=$null;excelCloseErrors=@();elapsedSeconds=[math]::Round(((Get-Date)-$started).TotalSeconds,3)};[void](Write-WorkbookResultLog $LogDirectory $result);if(-not$ok){throw "[WB3001] Workbook更新後検証で差分が$($plan.ChangedCount)件残っています。"};return $result}
    if($plan.ChangedCount-eq0){$result=[PSCustomObject]@{success=$true;code='WB0002';mode=$Mode;enabled=$true;schemaVersion=$plan.SchemaVersion;changedCount=0;appliedCount=0;backupPath='';restoreAttempted=$false;restoreSucceeded=$null;excelCloseErrors=@();elapsedSeconds=[math]::Round(((Get-Date)-$started).TotalSeconds,3)};[void](Write-WorkbookResultLog $LogDirectory $result);return $result}
    $unsupportedPictureReplacement=@($plan.Operations|Where-Object{$_.changed-and$_.category-eq'shapes'-and[string]$_.definition.kind-eq'picture'-and[string]$_.comparison-like'MarkerLength:*'})
    if($unsupportedPictureReplacement.Count-gt0){throw "[WB2592] このExcel環境では既存画像を参照保持したまま置換できません。削除・再挿入は安全上実行しません: $((@($unsupportedPictureReplacement|ForEach-Object target))-join', ')"}
    $changedIds=@{};foreach($operation in @($plan.Operations|Where-Object changed)){$changedIds[[string]$operation.id]=$true}

    Assert-WorkbookFileAvailableForWrite -Path $TargetPath
    if([string]::IsNullOrWhiteSpace($BackupDirectory)){$BackupDirectory=Join-Path $ProjectDir 'backups\workbook'};New-Item -ItemType Directory -Path $BackupDirectory -Force|Out-Null;$backupPath=Join-Path $BackupDirectory (([IO.Path]::GetFileNameWithoutExtension($TargetPath))+'_before_workbook_'+[DateTime]::Now.ToString('yyyyMMdd_HHmmss_fff')+[IO.Path]::GetExtension($TargetPath));Copy-Item -LiteralPath $TargetPath -Destination $backupPath -Force;$backupHash=(Get-FileHash -LiteralPath $backupPath -Algorithm SHA256).Hash
    $excel=$null;$book=$null;$closeErrors=@();$saved=$false;$phase='Open'
    try{
        $excel=New-WorkbookExcel;Invoke-WorkbookOpenAuditHook -Path $TargetPath -ProjectDir $ProjectDir;$book=$excel.Workbooks.Open($TargetPath,0,$false);$originalCalculation=$excel.Calculation;$excel.Calculation=-4135;Assert-WorkbookOpenState -Workbook $book -TargetPath $TargetPath
        if($FailureInjection-eq'AfterOpen'){throw '[WB3999] テスト用障害: AfterOpen'}
        foreach($d in @(Get-ObjectProperty $context.Definition 'worksheets' @())){if($changedIds.ContainsKey([string]$d.id)){$phase='Worksheet:'+[string]$d.id;[void](Set-WorksheetDefinition -Workbook $book -Excel $excel -Definition $d)}};if($FailureInjection-eq'AfterWorksheet'){throw '[WB3999] テスト用障害: AfterWorksheet'}
        foreach($d in @(Get-ObjectProperty $context.Definition 'ranges' @())){if($changedIds.ContainsKey([string]$d.id)){$phase='Range:'+[string]$d.id;[void](Set-RangeDefinition -Workbook $book -Definition $d)}};foreach($s in @('rows','columns')){foreach($d in @(Get-ObjectProperty $context.Definition $s @())){if($changedIds.ContainsKey([string]$d.id)){$phase=$s+':'+[string]$d.id;[void](Set-RowColumnDefinition -Workbook $book -Section $s -Definition $d)}}};foreach($d in @(Get-ObjectProperty $context.Definition 'names' @())){if($changedIds.ContainsKey([string]$d.id)){$phase='Name:'+[string]$d.id;[void](Set-NameDefinition $book $d)}};foreach($d in @(Get-ObjectProperty $context.Definition 'validations' @())){if($changedIds.ContainsKey([string]$d.id)){$phase='Validation:'+[string]$d.id;[void](Set-ValidationDefinition $book $d)}};foreach($d in @(Get-ObjectProperty $context.Definition 'tables' @())){if($changedIds.ContainsKey([string]$d.id)){$phase='Table:'+[string]$d.id;[void](Set-TableDefinition $book $d)}};foreach($d in @(Get-ObjectProperty $context.Definition 'shapes' @())){if($changedIds.ContainsKey([string]$d.id)){$phase='Shape:'+[string]$d.id;[void](Set-ShapeDefinition -Workbook $book -ProjectDir $ProjectDir -Definition $d)}};foreach($d in @(Get-ObjectProperty $context.Definition 'pageSetups' @())){if($changedIds.ContainsKey([string]$d.id)){$phase='PageSetup:'+[string]$d.id;[void](Set-PageSetupDefinition $book $d)}}
        $phase='Save';if($FailureInjection-eq'BeforeSave'){throw '[WB3999] テスト用障害: BeforeSave'};$excel.Calculation=$originalCalculation;$book.Save();$saved=$true;if($FailureInjection-in@('AfterSave','AfterSaveRestoreFailure')){throw "[WB3999] テスト用障害: $FailureInjection"}
        $closeErrors=@(Close-WorkbookExcel -Excel $excel -Workbook $book);$excel=$null;$book=$null;if($closeErrors.Count-gt0){throw "[WB3002] Excel終了処理に失敗しました: $($closeErrors -join '; ')"}
        $verify=Get-WorkbookUpdatePlan -ProjectDir $ProjectDir -ProjectManifest $ProjectManifest -TargetPath $TargetPath;if($verify.ChangedCount-ne0){$remaining=(@($verify.Operations|Where-Object changed|ForEach-Object{"$($_.category):$($_.id)$(if($_.PSObject.Properties['comparison']-and$_.comparison){'['+$_.comparison+']'})"})-join',');throw "[WB3001] 保存後検証で差分が$($verify.ChangedCount)件残っています: $remaining"}
        $result=[PSCustomObject]@{success=$true;code='WB0000';mode=$Mode;enabled=$true;schemaVersion=$plan.SchemaVersion;changedCount=$plan.ChangedCount;appliedCount=$plan.ChangedCount;backupPath=$backupPath;restoreAttempted=$false;restoreSucceeded=$null;excelCloseErrors=$closeErrors;elapsedSeconds=[math]::Round(((Get-Date)-$started).TotalSeconds,3)};[void](Write-WorkbookResultLog $LogDirectory $result);return $result
    }catch{
        $failure="Phase=$phase / $($_.Exception.Message) / Position=$($_.InvocationInfo.PositionMessage) / Stack=$($_.ScriptStackTrace)";$closeErrors=@(Close-WorkbookExcel -Excel $excel -Workbook $book);$excel=$null;$book=$null;$restore=$false;$restoreError='';$restoreSource=if($FailureInjection-eq'AfterSaveRestoreFailure'){$backupPath+'.missing-for-test'}else{$backupPath};try{Copy-Item -LiteralPath $restoreSource -Destination $TargetPath -Force;$restoreHash=(Get-FileHash -LiteralPath $TargetPath -Algorithm SHA256).Hash;if($restoreHash-ne$backupHash){throw '復元後ハッシュが一致しません。'};$restore=$true}catch{$restoreError=$_.Exception.Message}
        $code=if($restore){'WB3003'}else{'WB3004'};$result=[PSCustomObject]@{success=$false;code=$code;mode=$Mode;enabled=$true;schemaVersion=$plan.SchemaVersion;changedCount=$plan.ChangedCount;appliedCount=0;backupPath=$backupPath;restoreAttempted=$true;restoreSucceeded=$restore;restoreError=$restoreError;excelCloseErrors=$closeErrors;error=$failure;elapsedSeconds=[math]::Round(((Get-Date)-$started).TotalSeconds,3)};[void](Write-WorkbookResultLog $LogDirectory $result);throw "[$code] Workbook更新に失敗しました。Restore=$restore / Backup=$backupPath / 詳細: $failure $(if($restoreError){'/ 復元エラー: '+$restoreError})"
    }
}

function Invoke-WorkbookDefinitionTest {
    [CmdletBinding()]param()
    $root=Join-Path ([IO.Path]::GetTempPath()) ('VBAUpdaterWorkbookUnit_'+[guid]::NewGuid().ToString('N'))
    try{New-Item -ItemType Directory -Path (Join-Path $root 'source\workbook') -Force|Out-Null;$valid=[pscustomobject]@{schemaVersion='1.0';workbookId='unit';worksheets=@([pscustomobject]@{id='s1';action='ensure';name='Sheet1'});ranges=@([pscustomobject]@{id='r1';sheet='Sheet1';address='A1';policy='managed';value='x'});migrations=@()};[void](Test-WorkbookDefinition -Definition $valid -ProjectDir $root)
        $assertRejected={param($Definition,[string]$Name,[string]$Pattern)$rejected=$false;try{Test-WorkbookDefinition $Definition $root|Out-Null}catch{if([string]::IsNullOrWhiteSpace($Pattern)-or$_.Exception.Message-match$Pattern){$rejected=$true}else{throw}};if(-not$rejected){throw "$Name 拒否テストに失敗しました。"}}
        $badPath=$false;try{Resolve-SafeProjectPath -ProjectDir $root -RelativePath '..\outside.json'|Out-Null}catch{$badPath=$true};if(-not$badPath){throw 'パストラバーサル拒否テストに失敗しました。'}
        & $assertRejected ([pscustomobject]@{schemaVersion='1.0';worksheets=@();ranges=@([pscustomobject]@{id='x';sheet='Sheet1';address='A1';policy='clear'},[pscustomobject]@{id='x';sheet='Sheet1';address='A2';policy='clear'})}) '重複ID' 'WB1112'
        & $assertRejected ([pscustomobject]@{schemaVersion='9.0';worksheets=@();ranges=@()}) '未知schema' 'WB1104'
        & $assertRejected ([pscustomobject]@{schemaVersion='0.9';worksheets=@();ranges=@()}) '旧schema' 'WB1104'
        & $assertRejected ([pscustomobject]@{worksheets=@();ranges=@()}) 'schema不足' 'WB1103'
        & $assertRejected ([pscustomobject]@{schemaVersion='1.0';unknownMajorField=$true;worksheets=@();ranges=@()}) '未知フィールド' 'WB1102'
        & $assertRejected ([pscustomobject]@{schemaVersion='1.0';worksheets=@();ranges=@([pscustomobject]@{id='r';sheet='Sheet1';address='BAD';policy='clear'})}) '不正範囲' 'WB1132'
        & $assertRejected ([pscustomobject]@{schemaVersion='1.0';worksheets=@();ranges=@([pscustomobject]@{id='a';sheet='Sheet1';address='A1:B2';policy='clear'},[pscustomobject]@{id='b';sheet='Sheet1';address='B2:C3';policy='clear'})}) '重複範囲' 'WB1144'
        & $assertRejected ([pscustomobject]@{schemaVersion='1.0';worksheets=@();ranges=@();conditionalFormats=@([pscustomobject]@{id='cf'})}) '条件付き書式未対応' 'WB1170'
        & $assertRejected ([pscustomobject]@{schemaVersion='1.0';worksheets=@();ranges=@();pageSetups=@([pscustomobject]@{id='p';sheet='Sheet1';zoom=100;fitToPagesWide=1})}) 'PageSetup矛盾' 'WB1200'
        & $assertRejected ([pscustomobject]@{schemaVersion='1.0';worksheets=@([pscustomobject]@{id='same';name='Sheet1'});ranges=@([pscustomobject]@{id='same';sheet='Sheet1';address='A1';policy='clear'})}) '全Section ID重複' 'WB1211'
        & $assertRejected ([pscustomobject]@{schemaVersion='1.0';worksheets=@();ranges=@();migrations=@([pscustomobject]@{id='m1'})}) 'Migration未対応' 'WB1210'
        & $assertRejected ([pscustomobject]@{schemaVersion='1.0';worksheets=@();ranges=@([pscustomobject]@{id='external';sheet='Sheet1';address='A1';policy='formulaOnly';formula='=[Other.xlsx]Sheet1!A1'})}) '外部Workbook数式' 'WB113D'
        & $assertRejected ([pscustomobject]@{schemaVersion='1.0';worksheets=@();ranges=@();names=@([pscustomobject]@{id='external-name';scope='workbook';name='ExternalName';refersTo='=[Other.xlsm]Sheet1!$A$1'})}) '外部Workbook名前定義' 'WB1153'
        return [PSCustomObject]@{success=$true;count=15;message='Workbook定義・安全性単体テストに成功しました。'}
    }finally{Remove-Item -LiteralPath $root -Recurse -Force -ErrorAction SilentlyContinue}
}

function Get-WorkbookDefinitionContext {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$ProjectDir,[Parameter(Mandatory=$true)]$ProjectManifest)
    $config=Get-WorkbookProjectConfiguration -ProjectDir $ProjectDir -ProjectManifest $ProjectManifest
    if(-not$config.Enabled){return [PSCustomObject]@{Enabled=$false;Configuration=$config;Definition=$null;Validation=$null}}
    $definition=Read-WorkbookDefinition -Path $config.DefinitionPath
    $validation=Test-WorkbookDefinition -Definition $definition -ProjectDir $ProjectDir
    return [PSCustomObject]@{Enabled=$true;Configuration=$config;Definition=$definition;Validation=$validation}
}

function Release-WorkbookComObject {
    param([AllowNull()]$Object)
    if($null-ne$Object-and[System.Runtime.InteropServices.Marshal]::IsComObject($Object)){try{[void][System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($Object)}catch{Write-Verbose "COM解放失敗: $($_.Exception.Message)"}}
}

function Get-WorkbookExcelOwnershipKey {
    param([AllowNull()]$Excel)
    if($null-eq$Excel){return ''}
    try{return ('HWND:{0}' -f [int64]$Excel.Hwnd)}catch{return ('RCW:{0}' -f [Runtime.CompilerServices.RuntimeHelpers]::GetHashCode($Excel))}
}

function Close-WorkbookExcel {
    param([AllowNull()]$Excel,[AllowNull()]$Workbook,[bool]$SaveChanges=$false)
    $errors=New-Object System.Collections.Generic.List[string]
    $key=Get-WorkbookExcelOwnershipKey $Excel
    $owned=(-not[string]::IsNullOrWhiteSpace($key)-and$script:OwnedWorkbookExcelApplications.ContainsKey($key))
    if($null-ne$Workbook){if($owned){try{$Workbook.Close($SaveChanges)}catch{[void]$errors.Add("Workbook.Close: $($_.Exception.Message)")}};Release-WorkbookComObject $Workbook}
    if($null-ne$Excel){if($owned){try{$Excel.Quit()}catch{[void]$errors.Add("Excel.Quit: $($_.Exception.Message)")}};Release-WorkbookComObject $Excel}
    if($owned){[void]$script:OwnedWorkbookExcelApplications.Remove($key)}
    [GC]::Collect();[GC]::WaitForPendingFinalizers();[GC]::Collect();[GC]::WaitForPendingFinalizers()
    return @($errors)
}

function New-WorkbookExcel {
    $excel=New-Object -ComObject Excel.Application
    $key=Get-WorkbookExcelOwnershipKey $excel
    $script:OwnedWorkbookExcelApplications[$key]=[PSCustomObject]@{CreatedAt=[DateTime]::Now;ProcessId=$PID}
    $excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.EnableEvents=$false;$excel.ScreenUpdating=$false;$excel.AskToUpdateLinks=$false
    try{$excel.AutomationSecurity=3}catch{try{$excel.Quit()}catch{};Release-WorkbookComObject $excel;[void]$script:OwnedWorkbookExcelApplications.Remove($key);throw}
    return $excel
}

function Assert-WorkbookFileAvailableForWrite {
    param([Parameter(Mandatory=$true)][string]$Path)
    for($attempt=1;$attempt-le3;$attempt++){
        $stream=$null
        try{$stream=New-Object IO.FileStream($Path,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None);return}
        catch{if($attempt-ge3){throw "[WB2001] 対象ブックは読み取り専用または別のExcel/処理で使用中です: $Path"};[GC]::Collect();[GC]::WaitForPendingFinalizers();Start-Sleep -Milliseconds 150}
        finally{if($null-ne$stream){$stream.Dispose()}}
    }
}

function Get-WorksheetByName {
    param($Workbook,[string]$Name)
    $sheets=$null;$sheet=$null
    try{$sheets=$Workbook.Worksheets;for($i=1;$i-le[int]$sheets.Count;$i++){$candidate=$null;try{$candidate=$sheets.Item($i);if([string]$candidate.Name -ieq $Name){$sheet=$candidate;$candidate=$null;break}}finally{Release-WorkbookComObject $candidate}};return $sheet}
    finally{Release-WorkbookComObject $sheets}
}

function ConvertTo-CanonicalValue {
    param([AllowNull()]$Value)
    if($null-eq$Value){return '<null>'}
    if($Value-is[datetime]){return $Value.ToUniversalTime().ToString('o')}
    if($Value-is[double]-or$Value-is[single]-or$Value-is[decimal]){return ([decimal]$Value).ToString([Globalization.CultureInfo]::InvariantCulture)}
    if($Value-is[bool]){return $Value.ToString().ToLowerInvariant()}
    return ([string]$Value).Replace("`r`n","`n")
}

function Test-CanonicalEqual {param($Left,$Right) return (ConvertTo-CanonicalValue $Left) -ceq (ConvertTo-CanonicalValue $Right)}

function Test-RangePayloadEqual {
    param($Range,$Definition,[bool]$Formula=$false)
    $script:LastRangeComparisonDetail=''
    $rows=[int]$Range.Rows.Count;$columns=[int]$Range.Columns.Count
    $actual=if($Formula){try{$Range.Formula2}catch{$Range.Formula}}else{$Range.Value2}
    if($Definition.PSObject.Properties['value']-or$Definition.PSObject.Properties['formula']){
        $desired=if($Formula){[string]$Definition.formula}else{$Definition.value}
        if($rows-eq1-and$columns-eq1){return Test-CanonicalEqual $actual $desired}
        if(-not($actual-is[System.Array])-or$actual.Rank-ne2){return $false};$ar=$actual.GetLowerBound(0);$ac=$actual.GetLowerBound(1);for($r=0;$r-lt$rows;$r++){for($c=0;$c-lt$columns;$c++){if(-not(Test-CanonicalEqual $actual.GetValue($ar+$r,$ac+$c) $desired)){return $false}}};return $true
    }
    $source=if($Formula){$Definition.formulas}else{$Definition.values};$desiredMatrix=Get-MatrixFromJson -Value $source -Rows $rows -Columns $columns -Id ([string]$Definition.id)
    $dr=$desiredMatrix.GetLowerBound(0);$dc=$desiredMatrix.GetLowerBound(1)
    if($actual-is[System.Array]-and$actual.Rank-eq1-and$actual.Count-eq($rows*$columns)){$lower=$actual.GetLowerBound(0);for($r=0;$r-lt$rows;$r++){for($c=0;$c-lt$columns;$c++){$av=$actual.GetValue($lower+($r*$columns)+$c);$dv=$desiredMatrix.GetValue($dr+$r,$dc+$c);if(-not(Test-CanonicalEqual $av $dv)){$script:LastRangeComparisonDetail="FlatMismatch[$r,$c]";return $false}}};return $true}
    if(-not($actual-is[System.Array])-or$actual.Rank-ne2){$actualType=if($null-eq$actual){'<null>'}else{$actual.GetType().FullName};$rank=if($actual-is[System.Array]){$actual.Rank}else{0};$count=if($actual-is[System.Array]){$actual.Count}else{1};$script:LastRangeComparisonDetail="ActualNot2DArray Type=$actualType Rank=$rank Count=$count";return $false};$ar=$actual.GetLowerBound(0);$ac=$actual.GetLowerBound(1);for($r=0;$r-lt$rows;$r++){for($c=0;$c-lt$columns;$c++){$av=$actual.GetValue($ar+$r,$ac+$c);$dv=$desiredMatrix.GetValue($dr+$r,$dc+$c);if(-not(Test-CanonicalEqual $av $dv)){$at=if($null-eq$av){'<null>'}else{$av.GetType().FullName};$dt=if($null-eq$dv){'<null>'}else{$dv.GetType().FullName};$script:LastRangeComparisonDetail="Mismatch[$r,$c] ActualType=$at DesiredType=$dt ActualLength=$(([string]$av).Length) DesiredLength=$(([string]$dv).Length)";return $false}}};return $true
}

function Test-RangeDefinitionChanged {
    param($Range,$Definition)
    $policy=[string](Get-ObjectProperty $Definition 'policy' 'managed')
    $cells=$null;$blank=$true
    try{$cells=$Range.Cells;for($i=1;$i-le[int]$cells.Count;$i++){$cell=$null;try{$cell=$cells.Item($i);if(($null-ne$cell.Value2-and[string]$cell.Value2-ne'')-or[bool]$cell.HasFormula){$blank=$false;break}}finally{Release-WorkbookComObject $cell}}}finally{Release-WorkbookComObject $cells}
    if($policy-eq'preserve'){return $false};if($policy-eq'setIfBlank'-and-not$blank){return $false};if($policy-eq'clear'){return -not$blank}
    $formula=$Definition.PSObject.Properties['formula']-or$Definition.PSObject.Properties['formulas'];if(-not(Test-RangePayloadEqual -Range $Range -Definition $Definition -Formula:$formula)){return $true}
    if($Definition.PSObject.Properties['merge']-and[bool]$Range.MergeCells-ne[bool]$Definition.merge){return $true}
    if($Definition.PSObject.Properties['note']){$comment=$null;$text='';try{try{$comment=$Range.Comment;if($null-ne$comment){$text=[string]$comment.Text()}}catch{Write-Verbose '比較対象の既存ノートはありません。'};if($text-cne[string]$Definition.note){return $true}}finally{Release-WorkbookComObject $comment}}
    if($Definition.PSObject.Properties['hyperlink']){$links=$null;$link=$null;try{$links=$Range.Hyperlinks;if([int]$links.Count-ne1){return $true};$link=$links.Item(1);$h=$Definition.hyperlink;if([string]$link.Address-cne[string]$h.address-or[string]$link.SubAddress-cne[string](Get-ObjectProperty $h 'subAddress' '')){return $true}}finally{Release-WorkbookComObject $link;Release-WorkbookComObject $links}}
    if(-not(Test-RangeStyleMatch -Range $Range -Style (Get-ObjectProperty $Definition 'style' $null))){return $true}
    return $false
}

function Test-WorksheetDefinitionChanged {
    param($Workbook,$Excel,$Sheet,$Definition)
    $action=[string](Get-ObjectProperty $Definition 'action' 'ensure')
    if($action-eq'delete'){if($null-ne$Sheet){Test-SheetDeleteSafety -Workbook $Workbook -Sheet $Sheet -Name ([string]$Definition.name);return $true};return $false}
    if($null-eq$Sheet){return $true}
    if($Definition.PSObject.Properties['position']-and[int]$Sheet.Index-ne[int]$Definition.position){return $true}
    $vis=@{visible=-1;hidden=0;veryHidden=2};if([int]$Sheet.Visible-ne[int]$vis[[string](Get-ObjectProperty $Definition 'visible' 'visible')]){return $true}
    if($Definition.PSObject.Properties['tabColor']){$tab=$null;try{$tab=$Sheet.Tab;if([int]$tab.Color-ne[int](ConvertTo-ExcelColor ([string]$Definition.tabColor))){return $true}}finally{Release-WorkbookComObject $tab}}
    if($Definition.PSObject.Properties['view']){$Sheet.Activate();$window=$null;$cell=$null;try{$window=$Excel.ActiveWindow;$view=$Definition.view;if($view.PSObject.Properties['zoom']-and[int]$window.Zoom-ne[int]$view.zoom){return $true};if($view.PSObject.Properties['showGridlines']-and[bool]$window.DisplayGridlines-ne[bool]$view.showGridlines){return $true};if($view.PSObject.Properties['showHeadings']-and[bool]$window.DisplayHeadings-ne[bool]$view.showHeadings){return $true};if($view.PSObject.Properties['freezeAt']){$cell=$Sheet.Range([string]$view.freezeAt);$expectedRow=[int]$cell.Row-1;$expectedColumn=[int]$cell.Column-1;if(-not[bool]$window.FreezePanes-or[int]$window.SplitRow-ne$expectedRow-or[int]$window.SplitColumn-ne$expectedColumn){return $true}}}finally{Release-WorkbookComObject $cell;Release-WorkbookComObject $window}}
    return $false
}

function New-WorkbookOperation {param([string]$Id,[string]$Category,[string]$Target,[string]$Action,[bool]$Changed,[AllowNull()]$Current,[AllowNull()]$Desired,[AllowNull()]$Definition)
    return [PSCustomObject]@{id=$Id;category=$Category;target=$Target;action=$Action;changed=$Changed;current=$Current;desired=$Desired;definition=$Definition}
}

function Assert-WorkbookOpenState {
    param($Workbook,[string]$TargetPath)
    if([bool]$Workbook.ReadOnly){throw "[WB2001] 対象ブックは読み取り専用です: $TargetPath"}
    if([bool]$Workbook.ProtectStructure){throw '[WB2002] ブック構造が保護されているためWorksheet構造更新を開始できません。'}
}

function ConvertTo-ExcelColor {
    param([Parameter(Mandatory=$true)][string]$Color)
    if($Color -notmatch '^#[0-9A-Fa-f]{6}$'){throw "[WB1300] 色は#RRGGBBで指定してください: $Color"}
    $r=[Convert]::ToInt32($Color.Substring(1,2),16);$g=[Convert]::ToInt32($Color.Substring(3,2),16);$b=[Convert]::ToInt32($Color.Substring(5,2),16)
    return ($r+($g*256)+($b*65536))
}

function Normalize-ExcelAddress {param([AllowNull()][string]$Address) return ([string]$Address).Replace('$','').ToUpperInvariant()}

function Get-MatrixFromJson {
    param([Parameter(Mandatory=$true)]$Value,[Parameter(Mandatory=$true)][int]$Rows,[Parameter(Mandatory=$true)][int]$Columns,[string]$Id)
    $outer=@($Value)
    if($outer.Count-ne$Rows){throw "[WB2200] 2次元配列の行数が範囲と一致しません: $Id Expected=$Rows Actual=$($outer.Count)"}
    $matrix=[Array]::CreateInstance([object],[int[]]@($Rows,$Columns),[int[]]@(1,1))
    for($r=0;$r-lt$Rows;$r++){$inner=@($outer[$r]);if($inner.Count-ne$Columns){throw "[WB2201] 2次元配列の列数が範囲と一致しません: $Id Row=$($r+1) Expected=$Columns Actual=$($inner.Count)"};for($c=0;$c-lt$Columns;$c++){$cellValue=$inner[$c];if($null-ne$cellValue){$cellValue=$cellValue.PSObject.BaseObject};$matrix.SetValue($cellValue,$r+1,$c+1)}}
    return ,$matrix
}

function Test-SheetDeleteSafety {
    param($Workbook,$Sheet,[string]$Name)
    $worksheets=$null;$names=$null;$used=$null;$cells=$null;$tables=$null;$shapes=$null
    try{
        $worksheets=$Workbook.Worksheets
        if([int]$worksheets.Count-le1){throw "[WB2102] 最後のWorksheetは削除できません: $Name"}
        $used=$Sheet.UsedRange;$cells=$used.Cells
        $hasData=$false
        for($i=1;$i-le[int]$cells.Count;$i++){$cell=$null;try{$cell=$cells.Item($i);if($null-ne$cell.Value2-and[string]$cell.Value2-ne''){$hasData=$true;break};if([bool]$cell.HasFormula){$hasData=$true;break}}finally{Release-WorkbookComObject $cell}}
        $tables=$Sheet.ListObjects;$shapes=$Sheet.Shapes
        if($hasData-or[int]$tables.Count-gt0-or[int]$shapes.Count-gt0){throw "[WB2103] データ、数式、テーブルまたは図形があるシートは自動削除できません: $Name"}
        $names=$Workbook.Names
        for($nameIndex=1;$nameIndex-le[int]$names.Count;$nameIndex++){$n=$null;try{$n=$names.Item($nameIndex);$ref='';try{$ref=[string]$n.RefersTo}catch{throw "[WB2108] Worksheet削除前に名前定義の参照を確認できません: $Name"};if($ref-match("(?i)'?"+[regex]::Escape($Name)+"'?!")){throw "[WB2104] 名前定義から参照されるシートは削除できません: $Name"}}finally{Release-WorkbookComObject $n}}
        $targetSheetIndex=[int]$Sheet.Index
        for($sheetIndex=1;$sheetIndex-le[int]$worksheets.Count;$sheetIndex++){if($sheetIndex-eq$targetSheetIndex){continue};$other=$null;$otherUsed=$null;$otherCells=$null;try{$other=$worksheets.Item($sheetIndex);$otherUsed=$other.UsedRange;$otherCells=$otherUsed.Cells;for($i=1;$i-le[int]$otherCells.Count;$i++){$cell=$null;try{$cell=$otherCells.Item($i);if([bool]$cell.HasFormula-and[string]$cell.Formula-match("(?i)'?"+[regex]::Escape($Name)+"'?!")){throw "[WB2105] 他シートの数式から参照されるシートは削除できません: $Name"}}finally{Release-WorkbookComObject $cell}}}finally{Release-WorkbookComObject $otherCells;Release-WorkbookComObject $otherUsed;Release-WorkbookComObject $other}}
        $vbProject=$null;$vbComponents=$null;$component=$null;$code=$null;try{$vbProject=$Workbook.VBProject;$vbComponents=$vbProject.VBComponents;$component=$vbComponents.Item([string]$Sheet.CodeName);$code=$component.CodeModule;if([int]$code.CountOfLines-gt0){throw "[WB2106] VBAコードを持つWorksheetは削除できません: $Name"}}catch{if($_.Exception.Message-match'^\[WB2106\]'){throw};throw "[WB2107] Worksheet削除前にVBAコード有無を確認できません。VBAプロジェクトアクセスを確認してください: $Name"}finally{Release-WorkbookComObject $code;Release-WorkbookComObject $component;Release-WorkbookComObject $vbComponents;Release-WorkbookComObject $vbProject}
    }finally{Release-WorkbookComObject $shapes;Release-WorkbookComObject $tables;Release-WorkbookComObject $cells;Release-WorkbookComObject $used;Release-WorkbookComObject $names;Release-WorkbookComObject $worksheets}
}

function Test-RangeMergeSafety {
    param($Range,[string]$Target)
    $cells=$null;try{$cells=$Range.Cells;$nonBlank=0;for($i=1;$i-le[int]$cells.Count;$i++){$cell=$null;try{$cell=$cells.Item($i);if(($null-ne$cell.Value2-and[string]$cell.Value2-ne'')-or[bool]$cell.HasFormula){$nonBlank++}}finally{Release-WorkbookComObject $cell}};if($nonBlank-gt1){throw "[WB2202] 複数の値または数式を含む範囲は結合できません: $Target"}}finally{Release-WorkbookComObject $cells}
}

function Test-RangeStyleMatch {
    param($Range,$Style)
    if($null-eq$Style){return $true}
    $font=$null;$interior=$null
    try{
        if($Style.PSObject.Properties['font']){$font=$Range.Font;$f=$Style.font
            if($f.PSObject.Properties['name']-and[string]$font.Name-cne[string]$f.name){return $false}
            if($f.PSObject.Properties['size']-and[double]$font.Size-ne[double]$f.size){return $false}
            foreach($p in @('bold','italic')){if($f.PSObject.Properties[$p]-and[bool]$font.$p-ne[bool]$f.$p){return $false}}
            if($f.PSObject.Properties['color']-and[int]$font.Color-ne[int](ConvertTo-ExcelColor ([string]$f.color))){return $false}
        }
        if($Style.PSObject.Properties['fillColor']){$interior=$Range.Interior;if([int]$interior.Color-ne[int](ConvertTo-ExcelColor ([string]$Style.fillColor))){return $false}}
        foreach($p in @('WrapText','ShrinkToFit','NumberFormat')){$json=([char]::ToLowerInvariant($p[0])+$p.Substring(1));if($Style.PSObject.Properties[$json]-and[string]$Range.$p-cne[string]$Style.$json){return $false}}
        return $true
    }finally{Release-WorkbookComObject $interior;Release-WorkbookComObject $font}
}

function Set-RangeStyle {
    param($Range,$Style)
    if($null-eq$Style){return}
    foreach($p in $Style.PSObject.Properties.Name){if($p-notin@('font','fillColor','horizontalAlignment','verticalAlignment','wrapText','shrinkToFit','indentLevel','orientation','numberFormat','borders')){throw "[WB1301] styleに未知のフィールドがあります: $p"}}
    $font=$null;$interior=$null
    try{
        if($Style.PSObject.Properties['font']){$font=$Range.Font;$f=$Style.font;foreach($p in $f.PSObject.Properties.Name){if($p-notin@('name','size','bold','italic','underline','color')){throw "[WB1302] style.fontに未知のフィールドがあります: $p"}}
            if($f.PSObject.Properties['name']){$font.Name=[string]$f.name};if($f.PSObject.Properties['size']){$font.Size=[double]$f.size};if($f.PSObject.Properties['bold']){$font.Bold=[bool]$f.bold};if($f.PSObject.Properties['italic']){$font.Italic=[bool]$f.italic};if($f.PSObject.Properties['underline']){$font.Underline=if([bool]$f.underline){2}else{-4142}};if($f.PSObject.Properties['color']){$font.Color=ConvertTo-ExcelColor ([string]$f.color)}
        }
        if($Style.PSObject.Properties['fillColor']){$interior=$Range.Interior;$interior.Color=ConvertTo-ExcelColor ([string]$Style.fillColor)}
        $h=@{general=1;left=-4131;center=-4108;right=-4152;fill=5;justify=-4130;centerAcross=7;distributed=-4117};$v=@{top=-4160;center=-4108;bottom=-4107;justify=-4130;distributed=-4117}
        if($Style.PSObject.Properties['horizontalAlignment']){$key=([string]$Style.horizontalAlignment);if(-not$h.ContainsKey($key)){throw "[WB1303] horizontalAlignmentが不正です: $key"};$Range.HorizontalAlignment=$h[$key]}
        if($Style.PSObject.Properties['verticalAlignment']){$key=([string]$Style.verticalAlignment);if(-not$v.ContainsKey($key)){throw "[WB1304] verticalAlignmentが不正です: $key"};$Range.VerticalAlignment=$v[$key]}
        if($Style.PSObject.Properties['wrapText']){$Range.WrapText=[bool]$Style.wrapText};if($Style.PSObject.Properties['shrinkToFit']){$Range.ShrinkToFit=[bool]$Style.shrinkToFit};if($Style.PSObject.Properties['indentLevel']){$Range.IndentLevel=[int]$Style.indentLevel};if($Style.PSObject.Properties['orientation']){$Range.Orientation=[int]$Style.orientation};if($Style.PSObject.Properties['numberFormat']){$Range.NumberFormat=[string]$Style.numberFormat}
        if($Style.PSObject.Properties['borders']){foreach($b in @($Style.borders)){$edgeMap=@{left=7;top=8;bottom=9;right=10;insideVertical=11;insideHorizontal=12};$edge=[string](Get-ObjectProperty $b 'edge' '');if(-not$edgeMap.ContainsKey($edge)){throw "[WB1305] border.edgeが不正です: $edge"};$border=$null;try{$border=$Range.Borders.Item($edgeMap[$edge]);if($b.PSObject.Properties['lineStyle']){$border.LineStyle=[int]$b.lineStyle};if($b.PSObject.Properties['weight']){$border.Weight=[int]$b.weight};if($b.PSObject.Properties['color']){$border.Color=ConvertTo-ExcelColor ([string]$b.color)}}finally{Release-WorkbookComObject $border}}}
    }finally{Release-WorkbookComObject $interior;Release-WorkbookComObject $font}
}

function Get-ShapeMarker {param([string]$Hash,[AllowNull()][string]$AltText) return "VBAUpdaterHash=$Hash`n$([string]$AltText)"}

function Test-ManualBreakExists {
    param($Breaks,[int]$Index,[ValidateSet('row','column')][string]$Axis)
    for($i=1;$i-le[int]$Breaks.Count;$i++){$break=$null;$location=$null;try{$break=$Breaks.Item($i);$location=$break.Location;$actual=if($Axis-eq'row'){[int]$location.Row}else{[int]$location.Column};if($actual-eq$Index){return $true}}finally{Release-WorkbookComObject $location;Release-WorkbookComObject $break}}
    return $false
}

function Test-AdvancedOperationChanged {
    param($Workbook,[string]$ProjectDir,[string]$Section,$Definition)
    $script:LastAdvancedComparisonDetail=''
    $sheet=$null;$range=$null;$obj=$null
    try{
        switch($Section){
            'rows'{$sheet=Get-WorksheetByName $Workbook ([string]$Definition.sheet);if($null-eq$sheet){throw "[WB2300] 対象シートがありません: $($Definition.sheet)"};$obj=$sheet.Rows.Item([int]$Definition.index);if($Definition.PSObject.Properties['size']-and[math]::Abs([double]$obj.RowHeight-[double]$Definition.size)-gt0.25){return $true};if($Definition.PSObject.Properties['hidden']-and[bool]$obj.Hidden-ne[bool]$Definition.hidden){return $true};return $false}
            'columns'{$sheet=Get-WorksheetByName $Workbook ([string]$Definition.sheet);if($null-eq$sheet){throw "[WB2301] 対象シートがありません: $($Definition.sheet)"};$obj=$sheet.Columns.Item([int]$Definition.index);if($Definition.PSObject.Properties['size']-and[math]::Abs([double]$obj.ColumnWidth-[double]$Definition.size)-gt0.01){return $true};if($Definition.PSObject.Properties['hidden']-and[bool]$obj.Hidden-ne[bool]$Definition.hidden){return $true};return $false}
            'names'{$scope=[string](Get-ObjectProperty $Definition 'scope' 'workbook');try{if($scope-eq'workbook'){$obj=$Workbook.Names.Item([string]$Definition.name)}else{$sheet=Get-WorksheetByName $Workbook $scope;if($null-eq$sheet){return $true};$obj=$sheet.Names.Item([string]$Definition.name)}}catch{return $true};return ([string]$obj.RefersTo-cne[string]$Definition.refersTo)}
            'validations'{$sheet=Get-WorksheetByName $Workbook ([string]$Definition.sheet);if($null-eq$sheet){throw "[WB2302] 対象シートがありません: $($Definition.sheet)"};$range=$sheet.Range([string]$Definition.address);$obj=$range.Validation;$map=@{whole=1;decimal=2;list=3;date=4;time=5;textLength=6;custom=7};try{if([int]$obj.Type-ne[int]$map[[string]$Definition.type]){return $true}}catch{return $true};if($Definition.PSObject.Properties['formula1']-and[string]$obj.Formula1-cne[string]$Definition.formula1){return $true};return $false}
            'tables'{$sheet=Get-WorksheetByName $Workbook ([string]$Definition.sheet);if($null-eq$sheet){throw "[WB2303] 対象シートがありません: $($Definition.sheet)"};try{$obj=$sheet.ListObjects.Item([string]$Definition.name)}catch{return $true};$range=$obj.Range;if((Normalize-ExcelAddress ([string]$range.Address()))-cne(Normalize-ExcelAddress ([string]$Definition.address))){return $true};if($Definition.PSObject.Properties['style']){$style=$null;try{$style=$obj.TableStyle;if([string]$style.Name-cne[string]$Definition.style){return $true}}finally{Release-WorkbookComObject $style}};return $false}
            'shapes'{$sheet=Get-WorksheetByName $Workbook ([string]$Definition.sheet);if($null-eq$sheet){throw "[WB2304] 対象シートがありません: $($Definition.sheet)"};try{$obj=$sheet.Shapes.Item([string]$Definition.name)}catch{$script:LastAdvancedComparisonDetail='Missing';return $true};$shapeType=[int]$obj.Type;if($shapeType-in@(6,7,12,14,24)){throw "[WB2306] Group/OLE/ActiveX/SmartArtは検出のみ対応で、自動更新しません: $($Definition.name) Type=$shapeType"};$expectedTypes=switch([string]$Definition.kind){'picture'{@(11,13)};'textBox'{@(17)};'chartObject'{@(3)};default{@(1)}};if($shapeType-notin$expectedTypes){throw "[WB2307] 同名の異なる種類のShapeが既に存在します: $($Definition.name) Type=$shapeType"};foreach($p in @('left','top','width','height')){if($Definition.PSObject.Properties[$p]-and[math]::Abs([double]$obj.$p-[double]$Definition.$p)-gt0.75){$script:LastAdvancedComparisonDetail="Position:$p";return $true}};if([string]$Definition.kind-eq'picture'){$asset=Resolve-SafeProjectPath -ProjectDir $ProjectDir -RelativePath ([string]$Definition.asset)-MustExist -PathType File;$hash=(Get-FileHash -LiteralPath $asset -Algorithm SHA256).Hash;$marker=Get-ShapeMarker $hash ([string](Get-ObjectProperty $Definition 'alternativeText' ''));$actualMarker=([string]$obj.AlternativeText).Replace("`r`n","`n");if($actualMarker-cne$marker.Replace("`r`n","`n")){$script:LastAdvancedComparisonDetail="MarkerLength:$($actualMarker.Length)/$($marker.Length)";return $true}};if([string]$Definition.kind-eq'textBox' -and $Definition.PSObject.Properties['text']){$frame=$null;$chars=$null;try{$frame=$obj.TextFrame;$chars=$frame.Characters();if([string]$chars.Text-cne[string]$Definition.text){$script:LastAdvancedComparisonDetail="TextLength:$(([string]$chars.Text).Length)/$(([string]$Definition.text).Length)";return $true}}finally{Release-WorkbookComObject $chars;Release-WorkbookComObject $frame}};return $false}
            'pageSetups'{$sheet=Get-WorksheetByName $Workbook ([string]$Definition.sheet);if($null-eq$sheet){throw "[WB2305] 対象シートがありません: $($Definition.sheet)"};$obj=$sheet.PageSetup;$map=@{printArea='PrintArea';printTitleRows='PrintTitleRows';printTitleColumns='PrintTitleColumns';paperSize='PaperSize';zoom='Zoom';fitToPagesWide='FitToPagesWide';fitToPagesTall='FitToPagesTall';leftMargin='LeftMargin';rightMargin='RightMargin';topMargin='TopMargin';bottomMargin='BottomMargin';headerMargin='HeaderMargin';footerMargin='FooterMargin';centerHorizontally='CenterHorizontally';centerVertically='CenterVertically';leftHeader='LeftHeader';centerHeader='CenterHeader';rightHeader='RightHeader';leftFooter='LeftFooter';centerFooter='CenterFooter';rightFooter='RightFooter';blackAndWhite='BlackAndWhite';draft='Draft';printGridlines='PrintGridlines';printHeadings='PrintHeadings';printComments='PrintComments';printErrors='PrintErrors'};foreach($p in $map.Keys){if($Definition.PSObject.Properties[$p]-and[string]$obj.($map[$p])-cne[string]$Definition.$p){return $true}};if($Definition.PSObject.Properties['orientation']-and[int]$obj.Orientation-ne[int]@{portrait=1;landscape=2}[[string]$Definition.orientation]){return $true};if($Definition.PSObject.Properties['order']-and[int]$obj.Order-ne[int]@{downThenOver=1;overThenDown=2}[[string]$Definition.order]){return $true};if($Definition.PSObject.Properties['fitToPagesWide']-or$Definition.PSObject.Properties['fitToPagesTall']){if([bool]$obj.Zoom){return $true}};$breaks=$null;try{if($Definition.PSObject.Properties['manualRowBreaks']){$breaks=$sheet.HPageBreaks;foreach($index in @($Definition.manualRowBreaks)){if(-not(Test-ManualBreakExists $breaks ([int]$index) row)){return $true}};Release-WorkbookComObject $breaks;$breaks=$null};if($Definition.PSObject.Properties['manualColumnBreaks']){$breaks=$sheet.VPageBreaks;foreach($index in @($Definition.manualColumnBreaks)){if(-not(Test-ManualBreakExists $breaks ([int]$index) column)){return $true}}}}finally{Release-WorkbookComObject $breaks};return $false}
        }
    }finally{Release-WorkbookComObject $obj;Release-WorkbookComObject $range;Release-WorkbookComObject $sheet}
    return $true
}

function Get-WorkbookUpdatePlan {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$ProjectDir,[Parameter(Mandatory=$true)]$ProjectManifest,[Parameter(Mandatory=$true)][string]$TargetPath)
    $context=Get-WorkbookDefinitionContext -ProjectDir $ProjectDir -ProjectManifest $ProjectManifest
    if(-not$context.Enabled){return [PSCustomObject]@{Enabled=$false;SchemaVersion='';Operations=@();ChangedCount=0;UnchangedCount=0;Warnings=@()}}
    if(-not(Test-Path -LiteralPath $TargetPath -PathType Leaf)){throw "[WB2000] 対象ブックが見つかりません: $TargetPath"}
    if([System.IO.Path]::GetExtension($TargetPath).ToLowerInvariant() -notin $script:AllowedWorkbookExtensions){throw "[WB2003] 未対応のブック形式です: $TargetPath"}
    $excel=$null;$book=$null;$ops=New-Object System.Collections.Generic.List[object]
    try{
        $excel=New-WorkbookExcel;Invoke-WorkbookOpenAuditHook -Path $TargetPath -ProjectDir $ProjectDir;$book=$excel.Workbooks.Open($TargetPath,0,$true)
        foreach($d in @(Get-ObjectProperty $context.Definition 'worksheets' @())){
            $action=[string](Get-ObjectProperty $d 'action' 'ensure');$name=[string]$d.name;$sheet=$null
            try{
                if($action-eq'rename'){$from=[string]$d.from;$sheet=Get-WorksheetByName $book $from;$targetSheet=Get-WorksheetByName $book $name;try{if($null-ne$targetSheet-and$null-ne$sheet){throw "[WB2100] rename先シートが既に存在します: $name"};if($null-ne$targetSheet-and$null-eq$sheet){$sheet=$targetSheet;$targetSheet=$null}}finally{Release-WorkbookComObject $targetSheet};$changed=if($null-ne$sheet-and[string]$sheet.Name-ieq$name){Test-WorksheetDefinitionChanged $book $excel $sheet $d}else{$true};$current=if($null-ne$sheet){[string]$sheet.Name}else{'<missing>'}}
                else{$sheet=Get-WorksheetByName $book $name;$changed=Test-WorksheetDefinitionChanged $book $excel $sheet $d;$current=if($null-ne$sheet){$name}else{'<missing>'}}
                [void]$ops.Add((New-WorkbookOperation ([string]$d.id) 'worksheet' $name $action $changed $current $name $d))
            }finally{Release-WorkbookComObject $sheet}
        }
        foreach($d in @(Get-ObjectProperty $context.Definition 'ranges' @())){
            $sheet=Get-WorksheetByName $book ([string]$d.sheet);$plannedSheet=@($context.Definition.worksheets|Where-Object{[string]$_.name-ieq[string]$d.sheet-and[string](Get-ObjectProperty $_ 'action' 'ensure')-in@('ensure','rename')}).Count-gt0;if($null-eq$sheet-and-not$plannedSheet){throw "[WB2101] range対象シートがありません: $($d.sheet)"};$range=$null
            try{if($null-eq$sheet){$policy=[string](Get-ObjectProperty $d 'policy' 'managed');$changed=$true}else{$range=$sheet.Range([string]$d.address);if($d.PSObject.Properties['merge']-and[bool]$d.merge-and-not[bool]$range.MergeCells-and-not[bool](Get-ObjectProperty $d 'allowDataLoss' $false)){Test-RangeMergeSafety -Range $range -Target (([string]$d.sheet)+'!'+[string]$d.address)};$policy=[string](Get-ObjectProperty $d 'policy' 'managed');$changed=Test-RangeDefinitionChanged -Range $range -Definition $d}
                $operation=New-WorkbookOperation ([string]$d.id) 'range' (([string]$d.sheet)+'!'+[string]$d.address) $policy $changed '<redacted>' '<redacted>' $d;$operation|Add-Member -NotePropertyName comparison -NotePropertyValue ([string]$script:LastRangeComparisonDetail);[void]$ops.Add($operation)
            }finally{Release-WorkbookComObject $range;Release-WorkbookComObject $sheet}
        }
        foreach($section in @('rows','columns','names','validations','tables','shapes','pageSetups')){foreach($d in @(Get-ObjectProperty $context.Definition $section @())){$targetSheet=[string](Get-ObjectProperty $d 'sheet' '');$plannedSheet=-not[string]::IsNullOrWhiteSpace($targetSheet)-and@($context.Definition.worksheets|Where-Object{[string]$_.name-ieq$targetSheet-and[string](Get-ObjectProperty $_ 'action' 'ensure')-in@('ensure','rename')}).Count-gt0;$actualSheet=$null;if(-not[string]::IsNullOrWhiteSpace($targetSheet)){$actualSheet=Get-WorksheetByName $book $targetSheet};try{$changed=if($plannedSheet-and$null-eq$actualSheet){$script:LastAdvancedComparisonDetail='PlannedSheet';$true}else{Test-AdvancedOperationChanged -Workbook $book -ProjectDir $ProjectDir -Section $section -Definition $d}}finally{Release-WorkbookComObject $actualSheet};$operation=New-WorkbookOperation ([string]$d.id) $section ([string](Get-ObjectProperty $d 'sheet' (Get-ObjectProperty $d 'name' ''))) 'ensure' $changed '<redacted>' '<definition>' $d;$operation|Add-Member -NotePropertyName comparison -NotePropertyValue ([string]$script:LastAdvancedComparisonDetail);[void]$ops.Add($operation)}}
    }finally{$closeErrors=@(Close-WorkbookExcel -Excel $excel -Workbook $book);if($closeErrors.Count-gt 0){throw "[WB2099] Excel終了処理に失敗しました: $($closeErrors -join '; ')"}}
    $array=@($ops.ToArray());return [PSCustomObject]@{Enabled=$true;SchemaVersion=[string]$context.Definition.schemaVersion;Operations=$array;ChangedCount=@($array|Where-Object{$_.changed}).Count;UnchangedCount=@($array|Where-Object{-not$_.changed}).Count;Warnings=@()}
}

function Invoke-WorkbookIntegrationTest {
    [CmdletBinding()]param([AllowEmptyString()][string]$TestRoot='')
    $baseRoot=if([string]::IsNullOrWhiteSpace($TestRoot)){[IO.Path]::GetTempPath()}else{[IO.Path]::GetFullPath($TestRoot)}
    if(-not[IO.Path]::IsPathRooted($baseRoot)-or-not(Test-Path -LiteralPath $baseRoot -PathType Container)){throw "Workbook Integration Test Rootが無効です: $baseRoot"}
    $root=Join-Path $baseRoot ('WorkbookIntegration_'+[guid]::NewGuid().ToString('N'))
    $excel=$null;$book=$null;$beforePids=@(Get-Process EXCEL -ErrorAction SilentlyContinue|ForEach-Object Id)
    try{
        $definitionDir=Join-Path $root 'source\workbook';$sourceCodeDir=Join-Path $root 'source\standard';$targetDir=Join-Path $root 'target';$logDir=Join-Path $root 'logs';$backupDir=Join-Path $root 'backups';$restoreDir=Join-Path $root 'restore_points';New-Item -ItemType Directory -Path $definitionDir,$sourceCodeDir,$targetDir,$logDir,$backupDir,$restoreDir -Force|Out-Null
        $definitionPath=Join-Path $definitionDir 'workbook.json';$targetPath=Join-Path $targetDir 'WorkbookIntegration.xlsm'
        $json=@'
{
  "schemaVersion": "1.0",
  "workbookId": "integration",
  "worksheets": [
    { "id": "main", "action": "ensure", "name": "Main", "position": 1, "visible": "visible", "tabColor": "#336699", "view": { "freezeAt": "B2", "zoom": 90, "showGridlines": true, "showHeadings": true } },
    { "id": "added", "action": "ensure", "name": "Added", "position": 2, "visible": "visible" },
    { "id": "renamed", "action": "rename", "from": "RenameOld", "name": "Renamed", "position": 3, "visible": "hidden" },
    { "id": "deleted", "action": "delete", "name": "DeleteMe", "allowDelete": true }
  ],
  "ranges": [
    { "id": "value", "sheet": "Main", "address": "A1", "policy": "managed", "value": "managed" },
    { "id": "formula", "sheet": "Main", "address": "A2", "policy": "formulaOnly", "formula": "=1+1" },
    { "id": "matrix", "sheet": "Main", "address": "G10:H12", "policy": "managed", "values": [["H1","H2"],["a","b"],["c","d"]] },
    { "id": "styled", "sheet": "Main", "address": "C1", "policy": "managed", "value": 7, "style": { "font": { "bold": true, "color": "#112233" }, "fillColor": "#DDEEFF", "numberFormat": "0" } },
    { "id": "preserve", "sheet": "Main", "address": "D1", "policy": "preserve" },
    { "id": "blank", "sheet": "Main", "address": "E1", "policy": "setIfBlank", "value": "default" }
    ,{ "id": "added-value", "sheet": "Added", "address": "A1", "policy": "managed", "value": "new sheet" }
  ],
  "rows": [{ "id": "row1", "sheet": "Main", "index": 1, "size": 22, "hidden": false }],
  "columns": [{ "id": "col1", "sheet": "Main", "index": 1, "size": 18, "hidden": false }],
  "names": [{ "id": "name1", "scope": "workbook", "name": "ManagedValue", "refersTo": "=Main!$A$1", "visible": true }],
  "validations": [{ "id": "validation1", "sheet": "Main", "address": "F1", "mode": "replaceManagedRange", "type": "list", "formula1": "one,two", "ignoreBlank": true, "inCellDropdown": true }],
  "tables": [{ "id": "table1", "sheet": "Main", "name": "ManagedTable", "address": "A10:B12", "mode": "createOrExpand", "style": "TableStyleMedium2", "showTotals": false, "showHeaders": true }],
  "shapes": [
    { "id": "text1", "sheet": "Main", "name": "ManagedText", "kind": "textBox", "text": "hello", "left": 120, "top": 20, "width": 100, "height": 30 },
    { "id": "picture1", "sheet": "Main", "name": "ManagedPicture", "kind": "picture", "asset": "source/assets/pixel.png", "alternativeText": "test image", "left": 240, "top": 20, "width": 24, "height": 24, "lockAspectRatio": false, "placement": 1 }
  ],
  "pageSetups": [{ "id": "page1", "sheet": "Main", "printArea": "$A$1:$F$12", "orientation": "landscape", "centerHeader": "Workbook test", "printGridlines": false }],
  "migrations": []
}
'@
        $assetDir=Join-Path $root 'source\assets';New-Item -ItemType Directory -Path $assetDir -Force|Out-Null;$assetPath=Join-Path $assetDir 'pixel.png';Add-Type -AssemblyName System.Drawing;$bitmap=New-Object Drawing.Bitmap 2,2;try{$bitmap.SetPixel(0,0,[Drawing.Color]::Red);$bitmap.SetPixel(1,0,[Drawing.Color]::Red);$bitmap.SetPixel(0,1,[Drawing.Color]::Red);$bitmap.SetPixel(1,1,[Drawing.Color]::Red);$bitmap.Save($assetPath,[Drawing.Imaging.ImageFormat]::Png)}finally{$bitmap.Dispose()}
        [IO.File]::WriteAllText($definitionPath,$json,(New-Object Text.UTF8Encoding($false)))
        $sourceCodePath=Join-Path $sourceCodeDir 'modWorkbookIntegration.bas';[IO.File]::WriteAllText($sourceCodePath,"Attribute VB_Name = `"modWorkbookIntegration`"`r`nOption Explicit`r`n",(New-Object Text.UTF8Encoding($false)))
        $projectManifest=[ordered]@{schemaVersion='1.0';projectName='WorkbookIntegrationTest';target=[ordered]@{directory='target';file='WorkbookIntegration.xlsm';autoDetectWhenMissing=$false};source=[ordered]@{root='source';encoding='utf-8'};components=@([ordered]@{type='standard';name='modWorkbookIntegration';file='standard/modWorkbookIntegration.bas'});validation=[ordered]@{compileAfterPush=$false;requireBackup=$true};workbook=[ordered]@{enabled=$true;definition='source/workbook/workbook.json'}}
        $projectPath=Join-Path $root 'project.json';[IO.File]::WriteAllText($projectPath,($projectManifest|ConvertTo-Json -Depth 10),(New-Object Text.UTF8Encoding($false)))
        $excel=New-WorkbookExcel;$book=$excel.Workbooks.Add();$main=$null;$user=$null;$old=$null;$delete=$null
        try{$main=$book.Worksheets.Item(1);$main.Name='Main';$main.Range('D1').Value2='keep';$user=$book.Worksheets.Add();$user.Name='UserData';$user.Range('A1').Value2='user';$old=$book.Worksheets.Add();$old.Name='RenameOld';Release-WorkbookComObject $old;$old=$null;$delete=$book.Worksheets.Add();$delete.Name='DeleteMe';Release-WorkbookComObject $delete;$delete=$null;$book.SaveAs($targetPath,52)}finally{Release-WorkbookComObject $delete;Release-WorkbookComObject $old;Release-WorkbookComObject $user;Release-WorkbookComObject $main}
        $close=@(Close-WorkbookExcel $excel $book);$excel=$null;$book=$null;if($close.Count){throw "初期Excel終了失敗: $($close-join'; ')"}
        $manifest=Get-Content -LiteralPath $projectPath -Raw -Encoding UTF8|ConvertFrom-Json
        $diff=Get-WorkbookUpdatePlan -ProjectDir $root -ProjectManifest $manifest -TargetPath $targetPath;if($diff.ChangedCount-lt8){throw "初回差分件数が少なすぎます: $($diff.ChangedCount)"}
        $apply=Invoke-WorkbookUpdate -ProjectDir $root -ProjectManifest $manifest -TargetPath $targetPath -Mode Apply -LogDirectory $logDir -BackupDirectory $backupDir;if(-not$apply.success){throw 'Applyが失敗しました。'};if(-not$apply.PSObject.Properties['backupPath']-or-not(Test-Path -LiteralPath ([string]$apply.backupPath) -PathType Leaf)){throw 'Apply前Backupが作成されていません。'}
        $second=Get-WorkbookUpdatePlan -ProjectDir $root -ProjectManifest $manifest -TargetPath $targetPath;if($second.ChangedCount-ne0){$remaining=(@($second.Operations|Where-Object changed|ForEach-Object{"$($_.category):$($_.id)"})-join',');throw "再Diffが0件ではありません: $remaining"}
        $verify=Invoke-WorkbookUpdate -ProjectDir $root -ProjectManifest $manifest -TargetPath $targetPath -Mode Verify -LogDirectory $logDir -BackupDirectory $backupDir;if(-not$verify.success-or$verify.ChangedCount-ne0){throw "Verify後の差分が0件ではありません: $($verify.ChangedCount)"}
        $bitmap=New-Object Drawing.Bitmap 2,2;try{$bitmap.SetPixel(0,0,[Drawing.Color]::Blue);$bitmap.SetPixel(1,0,[Drawing.Color]::Blue);$bitmap.SetPixel(0,1,[Drawing.Color]::Blue);$bitmap.SetPixel(1,1,[Drawing.Color]::Blue);$bitmap.Save($assetPath,[Drawing.Imaging.ImageFormat]::Png)}finally{$bitmap.Dispose()};$pictureDiff=Get-WorkbookUpdatePlan -ProjectDir $root -ProjectManifest $manifest -TargetPath $targetPath;if(@($pictureDiff.Operations|Where-Object{$_.id-eq'picture1'-and$_.changed}).Count-ne1){throw '画像内容差分を検出できませんでした。'};$beforeRejectedImage=(Get-FileHash -LiteralPath $targetPath -Algorithm SHA256).Hash;$replacementRejected=$false;try{Invoke-WorkbookUpdate -ProjectDir $root -ProjectManifest $manifest -TargetPath $targetPath -Mode Apply -LogDirectory $logDir -BackupDirectory $backupDir|Out-Null}catch{if($_.Exception.Message-notmatch'WB2592'){throw};$replacementRejected=$true};if(-not$replacementRejected-or(Get-FileHash -LiteralPath $targetPath -Algorithm SHA256).Hash-ne$beforeRejectedImage){throw '安全でない画像置換が正しく拒否されませんでした。'};$bitmap=New-Object Drawing.Bitmap 2,2;try{$bitmap.SetPixel(0,0,[Drawing.Color]::Red);$bitmap.SetPixel(1,0,[Drawing.Color]::Red);$bitmap.SetPixel(0,1,[Drawing.Color]::Red);$bitmap.SetPixel(1,1,[Drawing.Color]::Red);$bitmap.Save($assetPath,[Drawing.Imaging.ImageFormat]::Png)}finally{$bitmap.Dispose()};$pictureVerify=Get-WorkbookUpdatePlan -ProjectDir $root -ProjectManifest $manifest -TargetPath $targetPath;if($pictureVerify.ChangedCount-ne0){throw '画像置換拒否後に元Assetへ戻したDiffが0件ではありません。'}
        $excel=New-WorkbookExcel;Invoke-WorkbookOpenAuditHook -Path $targetPath -ProjectDir $root;$book=$excel.Workbooks.Open($targetPath,0,$true);$user=$null;$main=$null;try{$user=Get-WorksheetByName $book 'UserData';$main=Get-WorksheetByName $book 'Main';if([string]$user.Range('A1').Value2-cne'user'){throw '管理対象外シートの値が変化しました。'};if([string]$main.Range('D1').Value2-cne'keep'){throw 'Preserveセルが変化しました。'}}finally{Release-WorkbookComObject $main;Release-WorkbookComObject $user};$close=@(Close-WorkbookExcel $excel $book);$excel=$null;$book=$null;if($close.Count){throw "確認Excel終了失敗: $($close-join'; ')"}
        $stableHash=(Get-FileHash -LiteralPath $targetPath -Algorithm SHA256).Hash
        $safetyCopy=Join-Path $root 'stable-safety-copy.xlsm'
        Copy-Item -LiteralPath $targetPath -Destination $safetyCopy -Force
        $json2=$json.Replace('"value": "managed"','"value": "managed-rollback"')
        [IO.File]::WriteAllText($definitionPath,$json2,(New-Object Text.UTF8Encoding($false)))
        $rollbackPhases=@('AfterOpen','AfterWorksheet','BeforeSave','AfterSave')
        foreach($failurePhase in $rollbackPhases){
            $failed=$false
            try{Invoke-WorkbookUpdate -ProjectDir $root -ProjectManifest $manifest -TargetPath $targetPath -Mode Apply -LogDirectory $logDir -BackupDirectory $backupDir -FailureInjection $failurePhase|Out-Null}
            catch{if($_.Exception.Message-notmatch'WB3003'){throw};$failed=$true}
            if(-not$failed){throw "意図的障害が失敗として報告されませんでした: $failurePhase"}
            $restoredHash=(Get-FileHash -LiteralPath $targetPath -Algorithm SHA256).Hash
            if($restoredHash-ne$stableHash){throw "障害からの復元ハッシュが一致しません: $failurePhase"}
        }
        $restoreFailureReported=$false
        try{Invoke-WorkbookUpdate -ProjectDir $root -ProjectManifest $manifest -TargetPath $targetPath -Mode Apply -LogDirectory $logDir -BackupDirectory $backupDir -FailureInjection AfterSaveRestoreFailure|Out-Null}
        catch{if($_.Exception.Message-notmatch'WB3004'){throw};$restoreFailureReported=$true}
        if(-not$restoreFailureReported){throw '復元失敗がWB3004として報告されませんでした。'}
        Copy-Item -LiteralPath $safetyCopy -Destination $targetPath -Force
        if((Get-FileHash -LiteralPath $targetPath -Algorithm SHA256).Hash-ne$stableHash){throw '復元失敗試験後の安全コピー復旧に失敗しました。'}
        return [PSCustomObject]@{success=$true;projectStructureVerified=$true;initialChanges=$diff.ChangedCount;appliedChanges=$apply.appliedCount;verifyChanges=$verify.ChangedCount;secondChanges=$second.ChangedCount;backupCreated=$true;pictureAddVerified=$true;pictureReplacementRejected=$true;rollbackHashMatched=$true;rollbackPhases=$rollbackPhases;restoreFailureDistinct=$restoreFailureReported;unmanagedDataPreserved=$true;message='Workbook実ブック統合テストに成功しました。'}
    }
    finally{
        if($null-ne$excel-or$null-ne$book){[void](Close-WorkbookExcel $excel $book)}
        $after=@()
        for($attempt=0;$attempt-lt60;$attempt++){Start-Sleep -Milliseconds 250;$after=@(Get-Process EXCEL -ErrorAction SilentlyContinue|Where-Object{$_.Id-notin$beforePids});if($after.Count-eq0){break}}
        if($after.Count-gt0){Write-Error ("テストが開始したExcelプロセスが残留しています: "+(($after|ForEach-Object Id)-join','))}
        Remove-Item -LiteralPath $root -Recurse -Force -ErrorAction SilentlyContinue
    }
}

Export-ModuleMember -Function Resolve-SafeProjectPath,Get-WorkbookProjectConfiguration,Read-WorkbookDefinition,Test-WorkbookDefinition,Get-WorkbookDefinitionContext,Get-WorkbookUpdatePlan,Invoke-WorkbookUpdate,Invoke-WorkbookDefinitionTest,Invoke-WorkbookIntegrationTest,Set-WorkbookOpenAuditHook
