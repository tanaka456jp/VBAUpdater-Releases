﻿param(
    [Parameter(Mandatory=$true)][string]$PackagePath,
    [Parameter(Mandatory=$true)][string]$InstallRoot,
    [Parameter(Mandatory=$true)][string]$ExpectedSha256,
    [string]$RestartPath=''
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2.0


function Start-VBAUpdaterAfterUpdate {
  param([string]$RestartPath,[string]$InstallRoot)

  try {
    if($RestartPath -and (Test-Path -LiteralPath $RestartPath -PathType Leaf)){
      Start-VBAUpdaterAfterUpdate -RestartPath $RestartPath -InstallRoot $InstallRoot
      return
    }

    $guiPs1=Join-Path $InstallRoot 'gui.ps1'
    if(Test-Path -LiteralPath $guiPs1 -PathType Leaf){
      $ps="$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
      Start-Process -FilePath $ps -ArgumentList @(
        '-NoProfile','-STA','-ExecutionPolicy','Bypass','-File',$guiPs1
      ) -WorkingDirectory $InstallRoot | Out-Null
      return
    }

    throw "更新後の再起動先が見つかりません。"
  } catch {
    Write-Warning ("更新は完了しましたが、自動再起動に失敗しました: " + $_.Exception.Message)
  }
}


function Assert-SafeInstallRoot([string]$Path){
    $full=[IO.Path]::GetFullPath($Path).TrimEnd('\')
    if([string]::IsNullOrWhiteSpace($full)){throw 'インストール先が不正です。'}
    $userData=[IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'VBAUpdater')).TrimEnd('\')
    if($full.StartsWith($userData,[StringComparison]::OrdinalIgnoreCase)){
        throw 'ユーザーデータ領域を更新先には指定できません。'
    }
    return $full
}

if(-not(Test-Path -LiteralPath $PackagePath -PathType Leaf)){throw '更新パッケージが見つかりません。'}
$actual=(Get-FileHash -LiteralPath $PackagePath -Algorithm SHA256).Hash
if($actual -ine $ExpectedSha256.Trim()){throw '更新パッケージのSHA-256検証に失敗しました。'}

$install=Assert-SafeInstallRoot $InstallRoot
$stage=Join-Path $env:TEMP ('VBAUpdater_SelfUpdate_'+[guid]::NewGuid().ToString('N'))
$backup=Join-Path $env:LOCALAPPDATA ('VBAUpdater\UpdateBackup\'+(Get-Date -Format 'yyyyMMdd_HHmmss'))
New-Item -ItemType Directory -Path $stage -Force | Out-Null
New-Item -ItemType Directory -Path $backup -Force | Out-Null

try{
    Expand-Archive -LiteralPath $PackagePath -DestinationPath $stage -Force
    $payload=Join-Path $stage 'App'
    if(-not(Test-Path -LiteralPath $payload -PathType Container)){
        throw '更新パッケージにAppフォルダがありません。'
    }

    # Back up application files only. User data is stored outside InstallRoot and is never copied/deleted here.
    if(Test-Path -LiteralPath $install -PathType Container){
        Copy-Item -LiteralPath $install -Destination $backup -Recurse -Force
    }

    # Replace application payload. Never touch LOCALAPPDATA\VBAUpdater user data.
    New-Item -ItemType Directory -Path $install -Force | Out-Null
    Get-ChildItem -LiteralPath $payload -Force | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $install -Recurse -Force
    }

    $result=[ordered]@{
        status='UPDATED'
        updatedAt=(Get-Date).ToString('o')
        installRoot=$install
        backupRoot=$backup
        userDataPreserved=(Join-Path $env:LOCALAPPDATA 'VBAUpdater')
    }
    $result | ConvertTo-Json -Depth 4

    if(-not[string]::IsNullOrWhiteSpace($RestartPath) -and (Test-Path -LiteralPath $RestartPath -PathType Leaf)){
        Start-Process -FilePath $RestartPath
    }
}
catch{
    # Best-effort rollback of application files only.
    try{
        $saved=Join-Path $backup ([IO.Path]::GetFileName($install))
        if(Test-Path -LiteralPath $saved -PathType Container){
            Get-ChildItem -LiteralPath $saved -Force | ForEach-Object {
                Copy-Item -LiteralPath $_.FullName -Destination $install -Recurse -Force
            }
        }
    }catch{}
    throw
}
finally{
    Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
}
