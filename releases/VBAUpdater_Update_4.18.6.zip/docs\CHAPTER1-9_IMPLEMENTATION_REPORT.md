﻿# Chapter1～Chapter9 実装・品質報告

## 1. 結論

Ver4.18.0 の既存VBA更新処理を置き換えず、任意の `project.json.workbook` がある場合だけ `tools/WorkbookUpdate.psm1` を経由するWorkbook更新基盤を追加した。Workbook定義がないProjectは従来の `project-push` 本体へそのまま分岐するため、設定追加は不要である。

Chapter1～9A Safety HotFixで、前回選択ProjectをCLIが暗黙利用できる重大な安全問題を修正した。Chapter1～9BではSAFE1023を緩和せず、Workbook Integration Fixtureを親Test Root配下の正式Projectへ修正した。2026-08-09に `test-isolation-test`、26件の非COM回帰、23工程の隔離Excel統合回帰がすべて成功したため、Workbook＋VBA統合Pushおよび正式対応範囲のExcel COM ApplyをAへ戻す。Migration実行、CodeName、秘密情報を要する保護、SmartArt/OLE/ActiveX、グラフ系列等の既存B/C分類は維持する。

現在の表示バージョンは `4.18.0` のままとした。本HotFixの実機受入後は修正版 `4.18.1` が候補であり、受入前に `4.19.0` へ上げない。

## 2. 現状調査結果

| 責務 | 実装位置・実際の流れ |
|---|---|
| CLI | `vba.cmd` → `vba.ps1` のコマンドルーター |
| GUI | `gui.cmd` → `gui.ps1`。重い処理はCLI子プロセスを起動 |
| Project登録 | `tools/ProjectRegistration.psm1` と `Invoke-ProjectCreateCore`。開発フォルダを直接登録 |
| Project設定 | `%LOCALAPPDATA%\VBAUpdater\settings.json` / `projects.json` |
| Project検出 | 明示 `-ProjectRoot`、明示 `-Project`、通常CLIの現在directory/親 `project.json`。保存済み最終ProjectのCLI暗黙利用は禁止 |
| Manifest | `Read-ProjectManifest` → `Test-ProjectManifest` → `Resolve-ManifestTarget` |
| Export/Pull | `Invoke-ProjectPull` → 一時ステージへ全対象Export → Sourceバックアップ → Source差替え |
| Import/Push | `Invoke-ManifestComponentPush` → `push-*` → Add-in macro。変更/追加だけ処理 |
| Diff | `Get-ProjectDiff`。対象ブックをReadOnlyで開き、正規化コードを比較 |
| Preflight | `Invoke-Preflight` / `Invoke-ProjectPreflight` |
| Compile | `Invoke-ProjectCompileGate`。設定時だけ別Excelで実行 |
| Backup | Component単位バックアップと `New-ProjectRestorePoint` |
| 復元 | 既存は `rollback-list` / `rollback -Apply`。新規Workbook経路は自動復元 |
| COM | `New-ExcelApplication` / `Close-ExcelApplication`、各COM member helper |
| ログ | `logs` 配下の操作別JSON・診断ログ |
| バージョン | `vba.ps1` の `$script:ToolVersion` とGUI表示・テスト期待値 |

既存VBA-only Pushは、PrepareSource、Manifest/target検証、復元ポイント、ReadOnly Diff、変更ComponentのAdd-in更新、Compile Gate、post hook、再Diffの順である。失敗時の自動rollbackは元実装にはなく、手動rollbackが正式手段だった。Workbook統合Pushでは、Workbook Preflight/Diff、外側の統合復元ポイント、Workbook Apply、既存VBA Push、Workbook Verifyの順にし、どの段階の失敗でもExcelを閉じてから外側の復元ポイントへ戻す。

主な既存リスクは、終了例外を隠す空catch、VBA-only失敗時の自動復元なし、保存失敗、ReadOnly/保護ビュー、VBProject access拒否、外部リンク、イベント・計算の副作用、登録済みProjectを暗黙選択するテスト経路である。最後のリスクは実際にJournalConverter業務Projectの誤更新を発生させたため、HotFixで最終Project fallbackを削除し、Test Mode、Denied Root、Open監査、Canary hashを追加した。Workbook経路では専用Excel、macro無効、`UpdateLinks=0`、events/alerts/screen updating無効、manual calculation、Close/Quit結果収集、更新後再Open Diff、ハッシュ復元を採用する。

## 3. Chapter別結果

### Chapter1

- A: 現行アーキテクチャ、Push、Backup/復元、COM、ログ、エラー、テスト、バージョン位置を実コードから整理。
- A: `ARCHITECTURE_AND_SAFETY.md` にリスク、互換性、Chapter計画を記録。
- 既存説明との差: 復元ポイント作成はあるが、従来VBA-only Pushは失敗時に自動復元しない。

### Chapter2

- A: 定義読込、schema/path検証、Operation plan、Excel不要のDiff model、結果、隔離log設計を専用moduleへ分離。
- A: Apply前backup、保存後Verify、`WB3003`（更新失敗・復元成功）と `WB3004`（更新失敗・復元失敗）。正式一時Projectによる障害注入4段階と復元失敗識別を確認。
- A: `project-push` のWorkbook/VBA外側transaction。HotFix後の隔離Excel回帰で初回適用、Verify、再実行差分0、Canary、Open監査、Excel PID終了を確認。

### Chapter3

- A: `project.json.workbook` は任意。未指定/disabledはVBA-only。
- A: Workbook schema `1.0`、未知field、型、ID/target/position/rename元重複、range競合、delete競合、外部Workbook数式、path traversalを拒否。
- A: 画像はProject内の `source` または `assets` 配下だけを許可。
- C: Migration実行とブック側適用履歴。`migrations` は空配列だけ許可。

### Chapter4

- A: Worksheet追加、Rename、順序、visible/hidden/veryHidden、tab color。
- A: `allowDelete=true` の空で無参照・無VBAコードのシートだけ削除。未定義シートは触らない。
- B: 保護は `mode=preserve` のみ。
- C: CodeName変更、平文passwordを使う保護変更。

### Chapter5

- A: scalar value、formula、2D values/formulas、COM一括書込、Managed/Preserve/SetIfBlank/FormulaOnly/ValueOnly。
- A: 管理範囲だけを差分更新し、管理外シートとPreserveセルを実機で保全確認。
- B: Clear、note、hyperlink、mergeは実装経路と安全検査があるが、今回の実機統合ケースで全組合せを網羅していない。
- B: Formula2を優先しFormulaへfallback。spill範囲の破壊を完全には保証しない。

### Chapter6

- A: font bold/color、fill、number format、row height、column width、hidden、Freeze Panes、zoom、gridline、headingを実機確認。
- B: font name/size/italic/underline、alignment、wrap、shrink、indent、orientation、bordersは実装済みだが実機網羅未完了。
- C: AutoFit。環境差で冪等性を保証できないため定義を拒否。
- B: ThemeColor/ColorIndexはRGBへ暗黙変換せず、正式定義は `#RRGGBB` に限定。

### Chapter7

- A: List入力規則、Workbook scope Name、Table新規作成を実機確認。
- B: その他の入力規則、Worksheet scope Name、Table拡張はコード経路あり・網羅試験未完了。Table縮小は禁止。
- B: 条件付き書式はschema sectionを予約したが、安全なrule identityを保証できず非空定義を `WB1170` で拒否。
- C: AutoFilter、Outline、group、管理対象条件付き書式の高度な再構築。

### Chapter8

- A: Picture新規追加、asset hash、同一画像再実行0件、位置/size/aspect/placement/alt text/name、TextBoxを実機確認。
- B: 既存画像の内容差分は検出するが、安全なReplace APIがない環境ではApply前に `WB2592` で停止。削除・再挿入しない。
- B: basic Shape / ChartObjectの作成・位置・sizeはコード基盤のみ。
- C: chart series/title/axis/legend/type、group再構築、SmartArt、OLE、ActiveX、slicer、timeline、3D。
- A: `OnAction` 未指定時は既存値を保持。定義による変更は拒否。

### Chapter9

- A: print area、orientation、header、print gridlinesを実機確認。
- B: title rows/columns、paper、zoom/Fit、margins、centering、footer、B/W、draft、comments/errors、headings、order、manual break追加はコード経路あり。printer/driver差を網羅していない。
- A: ZoomとFitの同時指定を事前拒否。
- B: 既存manual breakを消すreset操作は拒否。
- C: 改ページプレビューの完全再現。

## 4. 機能マトリクス

| 機能 | 区分 | 根拠 |
|---|---:|---|
| Workbook Validate/Diff/Apply/Verify | A | CLI実機成功 |
| Workbook backup/save/reopen/verify/restore | A | 4障害点とSHA-256復元成功 |
| 復元失敗の別報告 | A | `WB3004` injection成功 |
| Workbookなしの従来分岐 | A | 同じVBA coreへ直接分岐 |
| Workbook+VBA統合Push | A | 専用sampleでDiff→Push→Diff 0→Pull成功 |
| Worksheet基本構造 | A | 専用一時ブックで実機確認 |
| Password保護 / CodeName | C | 秘密管理・参照影響の安全性不足 |
| Cell主要policy・2D bulk | A | 実機確認、再Diff 0 |
| Clear/note/hyperlink/merge | B | 経路あり、実機網羅未完了 |
| 主要Style/View | A | 代表項目の実機確認 |
| 高度Style / Theme / AutoFit | B / C | 網羅不足 / 冪等性不足 |
| Validation list / Name / Table create | A | 実機確認 |
| 高度Validation / Table expand | B | 経路あり、網羅不足 |
| Conditional Format | B | schema/拒否基盤。Applyなし |
| AutoFilter / Outline / Group | C | 未実装 |
| Picture add/hash/idempotency / TextBox | A | 実機確認 |
| Picture replacement | B | 差分検出、Apply前安全停止 |
| Basic Shape / ChartObject | B | code基盤、統合未完了 |
| SmartArt等高度object | C | 検出・拒否方針のみ |
| 主要Page Setup | A | 代表項目実機確認 |
| Printer依存設定 / manual break | B | code基盤、環境網羅不足 |
| Migration | C | 将来schema設計のみ |

## 5. 変更ファイル

変更: `vba.ps1`、`gui.ps1`。

追加: `tools/WorkbookUpdate.psm1`、`docs/ARCHITECTURE_AND_SAFETY.md`、`docs/WORKBOOK_UPDATE_SPEC.md`、本報告書、`tests/workbook/fixtures/*`、`samples/workbook-minimal/*`。

削除: なし。既存VBA engine、Add-in、Manifest fixtureは置換していない。`addin/installed-addin.json` はテスト後に元の内容へ戻した。

## 6. CLI・GUI

追加CLI: `workbook-validate`、`workbook-diff`、`workbook-apply`、`workbook-verify`、`workbook-test`、`workbook-integration-test`。既存CLI名は変更していない。`project-push` はWorkbook定義がある場合だけ統合経路、ない場合は従来経路である。成功はexit 0、失敗はexit 1。詳細理由は `WBxxxx` をJSONまたはmessageに含める。

GUIはProject情報へ「Workbook定義」行だけを追加した。なし、無効、あり、fileなし、設定errorを表示する。既存Push buttonとCLI output logを流用し、大規模layout変更はしていない。

## 7. 最小定義例

`samples/workbook-minimal` は専用xlsm、Project manifest、VBA source、Workbook definitionを含む。次で確認できる。

```powershell
$sample = (Resolve-Path '.\samples\workbook-minimal').Path
.\vba.cmd workbook-validate -ProjectRoot $sample
.\vba.cmd workbook-diff -ProjectRoot $sample
.\vba.cmd workbook-apply -ProjectRoot $sample
.\vba.cmd workbook-verify -ProjectRoot $sample
```

## 8. テスト結果

| テスト | 結果 | 概要 |
|---|---|---|
| PowerShell parser | 成功 | `vba.ps1`、`gui.ps1`、Workbook module |
| Workbook非COM単体 | 成功 | 15件。schema、path、重複、range、未対応、外部参照等 |
| Workbook専用一時ブック統合 | 成功 | 初回18差分、Apply、再Diff 0、管理外data保全、画像、Excel cleanup |
| Workbook CLI sample | 成功 | Validate 0 / Diff 1 / Apply 1 / Verify 0 / 再Diff 0 |
| 既存VBA + 統合Push sample | 成功 | VBA added 1 → Push → unchanged 1 → Pull exported 1 |
| 既存の安全な回帰群 | 成功17 / 環境失敗2 | `cli-core-test` と `gui-usability-test` はsandbox内 `logs` access denied。実装前も同じ |
| 再一括回帰 | 未実行 | 登録済み業務Projectを暗黙選択する危険が判明したため安全審査で停止 |
| SmartArt/高度Chart/CF | 未実行 | CまたはBとしてApplyしない |

## 9. ロールバック検証

専用一時ブックを変更対象にし、`AfterOpen`、`AfterWorksheet`、`BeforeSave`、`AfterSave` で意図的に例外を発生させた。全て `WB3003` となり、更新前backupから復元後のtarget SHA-256が開始前と一致した。さらにrestore sourceを意図的に解決不能にし、`WB3004` として復元失敗を別報告することを確認した。試験が開始したExcel PIDは0件まで待機し、残留時はtest failureにする。

## 10. 回帰と作業中インシデント

既存の包括回帰を最初に実行した際、保存済みの直接参照設定を使う既存試験経路が `JournalConverter` を選択し、外部業務ブックへVBA更新を行った。直ちに停止し、既存restore pointのbackup hashを確認して元ブックへcopy復元した。復元後SHA-256は `040E34B5149C9C445B55180C0EB9B92EBE9D2F26C9F059DFC5A29D9F22A1799D` と一致した。更新後状態は `backups/codex_recovery/JournalConverter_after_unintended_regression_20260801_140725.xlsm` に保全した。以後、外部Projectを使う回帰は実行せず、専用sampleまたはtemp workbookだけを使用した。

このインシデントで残った `/automation -Embedding` Excel PID 4件は、開始時刻・command line・テスト用VBE titleを確認後、対象PIDだけを終了し、最終的にExcel process 0件を確認した。

## 11. 残課題

- 条件付き書式の安定したmanaged identityとuser rule保全。
- Pictureを削除せず内容だけreplaceできるOffice version横断API。
- Dynamic array spill、array formula、locale/version差の統合matrix。
- Tableの列削除・縮小、formula column、data retention policy。
- Printer driver差を含むPage Setup/改ページの統合matrix。
- SmartArt、group、OLE、ActiveX、slicer、timeline、高度chart。
- Migration適用履歴の格納方式とrollback contract。
- 登録済みProjectを一切暗黙選択しない隔離回帰harness。

## 12. 実機確認手順

### 既存機能

業務ブックではなくcopyまたは専用Projectを使う。

```powershell
.\vba.cmd version
.\vba.cmd help
$project = 'C:\Development\YourTestProject'
.\vba.cmd project-preflight -ProjectRoot $project
.\vba.cmd project-diff -ProjectRoot $project
.\vba.cmd project-push -ProjectRoot $project
.\vba.cmd project-diff -ProjectRoot $project
.\vba.cmd project-pull -ProjectRoot $project
```

### 新機能

```powershell
$sample = (Resolve-Path '.\samples\workbook-minimal').Path
.\vba.cmd workbook-test
.\vba.cmd workbook-validate -ProjectRoot $sample
.\vba.cmd workbook-diff -ProjectRoot $sample
.\vba.cmd workbook-apply -ProjectRoot $sample
.\vba.cmd workbook-verify -ProjectRoot $sample
.\vba.cmd workbook-diff -ProjectRoot $sample
.\vba.cmd workbook-integration-test
Get-Process EXCEL -ErrorAction SilentlyContinue
```

最後の `Get-Process` が無出力であること、2回目Diffが0であること、`WB3003`/`WB3004` testが成功することを確認する。

## 13. 納品

納品ZIPはProject folderの内容をZIP直下へ格納し、`.git`、既存/生成済みZIP、`logs`、`backups`、Excel lock、一時fileを除外する。Git commit、push、branch、tagは実行していない。ZIP名とSHA-256は作成後の最終報告に記載する。
