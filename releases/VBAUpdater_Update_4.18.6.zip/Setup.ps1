﻿$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
Add-Type -AssemblyName System.Windows.Forms

$productName = 'VBAUpdater'
$buildVersionFile = Join-Path $PSScriptRoot 'BUILD_VERSION.txt'
if (-not (Test-Path -LiteralPath $buildVersionFile -PathType Leaf)) { throw "BUILD_VERSION.txtが見つかりません: $buildVersionFile" }
$buildVersion = ([System.IO.File]::ReadAllText($buildVersionFile)).Trim()
if ([string]::IsNullOrWhiteSpace($buildVersion)) { throw 'BUILD_VERSION.txtが空です。' }
$productVersionFile = Join-Path $PSScriptRoot 'App\VERSION.txt'
if (-not (Test-Path -LiteralPath $productVersionFile -PathType Leaf)) { throw "App VERSION.txtが見つかりません: $productVersionFile" }
$version = ([System.IO.File]::ReadAllText($productVersionFile)).Trim()
if ($version -notmatch '^\d+\.\d+\.\d+$') { throw "ProductVersionが不正です: $version" }
$publisher = 'VBAUpdater'
$sourceApp = Join-Path $PSScriptRoot 'App'
$sourceUninstaller = Join-Path $PSScriptRoot 'Uninstall.ps1'
$installRoot = Join-Path $env:LOCALAPPDATA 'Programs\VBAUpdater'
$desktop = [Environment]::GetFolderPath('Desktop')
$startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\VBAUpdater'
$uninstallKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\VBAUpdater'
$logDirectory = Join-Path $env:LOCALAPPDATA 'VBAUpdater\installer-logs'
$timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$logPath = Join-Path $logDirectory ("Setup_{0}.log" -f $timestamp)
$backupDirectory = Join-Path $env:LOCALAPPDATA 'VBAUpdater\installer-backups'
$historyDirectory = Join-Path $env:LOCALAPPDATA 'VBAUpdater\installer-history'
$historyPath = Join-Path $historyDirectory 'InstallHistory.tsv'
$userDataRoot = Join-Path $env:LOCALAPPDATA 'VBAUpdater'
$configBackupDirectory = Join-Path $userDataRoot 'config-backups'
$transactionBackup = $null
$transcriptStarted = $false

function Show-Info([string]$message) {
    [System.Windows.Forms.MessageBox]::Show($message, 'VBAUpdater Setup', 'OK', 'Information') | Out-Null
}

function Show-Error([string]$message) {
    [System.Windows.Forms.MessageBox]::Show($message, 'VBAUpdater Setup', 'OK', 'Error') | Out-Null
}


function Get-InstalledBuildVersion {
    $installedBuildFile = Join-Path $installRoot 'BUILD_VERSION.txt'
    if (-not (Test-Path -LiteralPath $installedBuildFile -PathType Leaf)) { return $null }
    try {
        $value = ([System.IO.File]::ReadAllText($installedBuildFile)).Trim()
        if ([string]::IsNullOrWhiteSpace($value)) { return $null }
        return $value
    }
    catch {
        Write-Host ("Installed version read failed: " + $_.Exception.Message)
        return $null
    }
}

function Get-BuildRank([string]$value) {
    if ([string]::IsNullOrWhiteSpace($value)) { return $null }

    # Supported examples:
    # Chapter3-8_Final_HotFix1 -> 3.8.900.1
    # Chapter3-9_01           -> 3.9.1.0
    # Chapter3-9_02_HotFix1   -> 3.9.2.1
    # This comparison is used by installers from Chapter3-9 onward.
    $match = [regex]::Match($value, '^Chapter(?<major>\d+)-(?<minor>\d+)(?:_(?<stage>Final|\d+))?(?:_HotFix(?<hotfix>\d+))?$', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    if (-not $match.Success) { return $null }

    $major = [int64]$match.Groups['major'].Value
    $minor = [int64]$match.Groups['minor'].Value
    $stageText = $match.Groups['stage'].Value
    $stage = 0L
    if (-not [string]::IsNullOrWhiteSpace($stageText)) {
        if ($stageText -ieq 'Final') { $stage = 900L } else { $stage = [int64]$stageText }
    }
    $hotfix = 0L
    if ($match.Groups['hotfix'].Success) { $hotfix = [int64]$match.Groups['hotfix'].Value }

    # Keep each component in its own numeric range so 3-10 > 3-9 and 02 > 01.
    return ($major * 1000000000000L) + ($minor * 1000000000L) + ($stage * 1000000L) + $hotfix
}

function Write-InstallHistory([string]$result, [string]$mode, [string]$fromBuild, [string]$toBuild, [string]$detail) {
    try {
        New-Item -ItemType Directory -Path $historyDirectory -Force | Out-Null
        $safeDetail = ([string]$detail) -replace "[\r\n\t]+", ' '
        $safeFrom = if ([string]::IsNullOrWhiteSpace($fromBuild)) { '-' } else { $fromBuild }
        $line = @(
            (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),
            $result,
            $mode,
            $safeFrom,
            $toBuild,
            $safeDetail
        ) -join "`t"
        [System.IO.File]::AppendAllText($historyPath, $line + [Environment]::NewLine, (New-Object System.Text.UTF8Encoding($false)))
    }
    catch {
        Write-Host ('Install history write skipped: ' + $_.Exception.Message)
    }
}

function Test-InstalledApplication {
    $required = @('gui.ps1','vba.ps1','BUILD_VERSION.txt','tools\\WorkbookUpdate.psm1')
    foreach ($relative in $required) {
        $path = Join-Path $installRoot $relative
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            throw "インストール後検証に失敗しました。必須ファイルがありません: $relative"
        }
    }
    $installedValue = ([System.IO.File]::ReadAllText((Join-Path $installRoot 'BUILD_VERSION.txt'))).Trim()
    if ($installedValue -ne $buildVersion) {
        throw "インストール後検証に失敗しました。BUILD_VERSIONが一致しません。期待=$buildVersion / 実際=$installedValue"
    }
}

function Remove-OldInstallerBackups {
    if (-not (Test-Path -LiteralPath $backupDirectory -PathType Container)) { return }
    try {
        $items = @(Get-ChildItem -LiteralPath $backupDirectory -Directory -ErrorAction Stop | Sort-Object LastWriteTime -Descending)
        if ($items.Count -gt 3) {
            $items | Select-Object -Skip 3 | ForEach-Object {
                Write-Host ("Removing old installer backup: " + $_.FullName)
                Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
            }
        }
    }
    catch {
        Write-Host ("Backup cleanup skipped: " + $_.Exception.Message)
    }
}


function Remove-OldConfigBackups {
    if (-not (Test-Path -LiteralPath $configBackupDirectory -PathType Container)) { return }
    try {
        $items = @(Get-ChildItem -LiteralPath $configBackupDirectory -Directory -ErrorAction Stop | Sort-Object LastWriteTime -Descending)
        if ($items.Count -gt 5) {
            $items | Select-Object -Skip 5 | ForEach-Object {
                Write-Host ("Removing old config backup: " + $_.FullName)
                Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
            }
        }
    }
    catch {
        Write-Host ("Config backup cleanup skipped: " + $_.Exception.Message)
    }
}

function New-PreInstallConfigBackup {
    $files = @('settings.json','projects.json')
    $existing = @($files | Where-Object { Test-Path -LiteralPath (Join-Path $userDataRoot $_) -PathType Leaf })
    if ($existing.Count -eq 0) {
        Write-Host 'No user configuration files found. Pre-install configuration backup skipped.'
        return $null
    }

    New-Item -ItemType Directory -Path $configBackupDirectory -Force | Out-Null
    $destination = Join-Path $configBackupDirectory ("BeforeInstall_{0}" -f $timestamp)
    New-Item -ItemType Directory -Path $destination -Force | Out-Null
    foreach ($name in $existing) {
        Copy-Item -LiteralPath (Join-Path $userDataRoot $name) -Destination (Join-Path $destination $name) -Force -ErrorAction Stop
    }
    $info = @(
        ('Created=' + (Get-Date -Format 'o')),
        ('Reason=BeforeInstall'),
        ('FromBuild=' + $(if ([string]::IsNullOrWhiteSpace($installedBuild)) { '-' } else { $installedBuild })),
        ('ToBuild=' + $buildVersion),
        ('Files=' + $existing.Count)
    ) -join [Environment]::NewLine
    [System.IO.File]::WriteAllText((Join-Path $destination 'backup-info.txt'), $info + [Environment]::NewLine, (New-Object System.Text.UTF8Encoding($false)))
    Write-Host ("Created pre-install configuration backup: $destination")
    Remove-OldConfigBackups
    return $destination
}

function New-Shortcut(
    [string]$path,
    [string]$target,
    [string]$arguments,
    [string]$workingDirectory,
    [string]$description
) {
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($path)
    $shortcut.TargetPath = $target
    $shortcut.Arguments = $arguments
    $shortcut.WorkingDirectory = $workingDirectory
    $shortcut.Description = $description
    $shortcut.IconLocation = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe,0"
    $shortcut.Save()
}

try {
    New-Item -ItemType Directory -Path $logDirectory -Force | Out-Null
    Start-Transcript -LiteralPath $logPath -Force | Out-Null
    $transcriptStarted = $true

    Write-Host ("VBAUpdater Setup {0}" -f $buildVersion)
    Write-Host "Source: $PSScriptRoot"
    Write-Host "Install: $installRoot"
    Write-Host "Log: $logPath"

    if (-not (Test-Path -LiteralPath $sourceApp -PathType Container)) {
        throw "Appフォルダーが見つかりません: $sourceApp"
    }
    if (-not (Test-Path -LiteralPath (Join-Path $sourceApp 'gui.ps1') -PathType Leaf)) {
        throw "gui.ps1が見つかりません: $(Join-Path $sourceApp 'gui.ps1')"
    }
    if (-not (Test-Path -LiteralPath $sourceUninstaller -PathType Leaf)) {
        throw "Uninstall.ps1が見つかりません: $sourceUninstaller"
    }

    # Do not replace application files while VBAUpdater itself is running.
    # User settings/projects/logs live outside installRoot and are intentionally preserved.
    $runningVBAUpdater = @()
    try {
        $runningVBAUpdater = @(Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe' OR Name = 'pwsh.exe'" -ErrorAction Stop |
            Where-Object {
                -not [string]::IsNullOrWhiteSpace([string]$_.CommandLine) -and
                ([string]$_.CommandLine).IndexOf((Join-Path $installRoot 'gui.ps1'), [System.StringComparison]::OrdinalIgnoreCase) -ge 0
            })
    }
    catch {
        Write-Host ("Running-process check skipped: " + $_.Exception.Message)
    }
    if ($runningVBAUpdater.Count -gt 0) {
        throw "VBAUpdaterが起動しています。VBAUpdaterを終了してから、もう一度インストーラーを実行してください。"
    }

    $installedBuild = Get-InstalledBuildVersion
    $installMode = if ($null -eq $installedBuild) { '新規インストール' } elseif ($installedBuild -eq $buildVersion) { '再インストール' } else { 'アップデート' }
    Write-Host ("Installed build: " + $(if ($null -eq $installedBuild) { '(none)' } else { $installedBuild }))
    Write-Host ("Target build: $buildVersion")
    Write-Host ("Install mode: $installMode")

    $installedRank = Get-BuildRank $installedBuild
    $targetRank = Get-BuildRank $buildVersion
    if ($null -ne $installedRank -and $null -ne $targetRank -and $targetRank -lt $installedRank) {
        $downgradeAnswer = [System.Windows.Forms.MessageBox]::Show(
            "現在より古いChapterをインストールしようとしています。`r`n`r`n現在: $installedBuild`r`n今回: $buildVersion`r`n`r`n通常はキャンセルしてください。意図的に旧版へ戻す場合のみ［はい］を選択してください。",
            'VBAUpdater Setup - 旧版の確認',
            'YesNo',
            'Warning',
            [System.Windows.Forms.MessageBoxDefaultButton]::Button2
        )
        if ($downgradeAnswer -ne [System.Windows.Forms.DialogResult]::Yes) {
            Write-Host 'Downgrade cancelled by user.'
            Write-InstallHistory 'CANCEL' 'ダウングレード確認' $installedBuild $buildVersion 'ユーザーが旧版インストールを中止しました。'
            exit 0
        }
        $installMode = '旧版への切り戻し'
    }

    $currentText = if ($null -eq $installedBuild) { '未インストール' } else { $installedBuild }
    $answer = [System.Windows.Forms.MessageBox]::Show(
        "$installMode を実行します。`r`n`r`n現在: $currentText`r`n今回: $buildVersion`r`n`r`nインストール先:`r`n$installRoot`r`n`r`n登録Project・設定・ログは保持されます。",
        'VBAUpdater Setup',
        'OKCancel',
        'Information'
    )
    if ($answer -ne [System.Windows.Forms.DialogResult]::OK) {
        Write-Host 'Installation cancelled by user.'
        Write-InstallHistory 'CANCEL' $installMode $installedBuild $buildVersion 'ユーザーがインストールを中止しました。'
        exit 0
    }

    # Back up registration/settings separately before replacing application files.
    # This gives the user a recoverable copy even though user data normally lives outside installRoot.
    [void](New-PreInstallConfigBackup)

    # Transactional replacement: move the previous app aside first. If any later
    # installation step fails, the catch block restores this exact installed copy.
    New-Item -ItemType Directory -Path $backupDirectory -Force | Out-Null
    if (Test-Path -LiteralPath $installRoot) {
        $safeInstalledBuild = if ([string]::IsNullOrWhiteSpace($installedBuild)) { 'unknown' } else { ($installedBuild -replace '[^A-Za-z0-9._-]','_') }
        $transactionBackup = Join-Path $backupDirectory ("PreInstall_{0}_{1}" -f $timestamp,$safeInstalledBuild)
        Write-Host ("Creating transactional backup: $transactionBackup")
        Move-Item -LiteralPath $installRoot -Destination $transactionBackup -Force
    }
    New-Item -ItemType Directory -Path $installRoot -Force | Out-Null

    Write-Host 'Copying application files.'
    Copy-Item -Path (Join-Path $sourceApp '*') -Destination $installRoot -Recurse -Force
    Copy-Item -LiteralPath $sourceUninstaller -Destination (Join-Path $installRoot 'Uninstall.ps1') -Force
    [System.IO.File]::WriteAllText((Join-Path $installRoot 'BUILD_VERSION.txt'), $buildVersion + [Environment]::NewLine, (New-Object System.Text.UTF8Encoding($false)))

    $powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $gui = Join-Path $installRoot 'gui.ps1'
    $uninstaller = Join-Path $installRoot 'Uninstall.ps1'
    $guiArguments = '-NoProfile -STA -ExecutionPolicy Bypass -File "' + $gui + '"'
    $uninstallArguments = '-NoProfile -STA -ExecutionPolicy Bypass -File "' + $uninstaller + '"'

    Write-Host 'Creating shortcuts.'
    New-Shortcut -path (Join-Path $desktop 'VBAUpdater.lnk') -target $powershell -arguments $guiArguments -workingDirectory $installRoot -description 'VBAUpdaterを起動します'

    New-Item -ItemType Directory -Path $startMenu -Force | Out-Null
    New-Shortcut -path (Join-Path $startMenu 'VBAUpdater.lnk') -target $powershell -arguments $guiArguments -workingDirectory $installRoot -description 'VBAUpdaterを起動します'
    New-Shortcut -path (Join-Path $startMenu 'VBAUpdater をアンインストール.lnk') -target $powershell -arguments $uninstallArguments -workingDirectory $installRoot -description 'VBAUpdaterをアンインストールします'

    Write-Host 'Registering uninstall information.'
    New-Item -Path $uninstallKey -Force | Out-Null
    New-ItemProperty -Path $uninstallKey -Name DisplayName -Value $productName -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $uninstallKey -Name DisplayVersion -Value $version -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $uninstallKey -Name Publisher -Value $publisher -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $uninstallKey -Name InstallLocation -Value $installRoot -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $uninstallKey -Name UninstallString -Value ('"' + $powershell + '" ' + $uninstallArguments) -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $uninstallKey -Name NoModify -Value 1 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $uninstallKey -Name NoRepair -Value 1 -PropertyType DWord -Force | Out-Null

    Write-Host 'Validating installed application.'
    Test-InstalledApplication
    Write-InstallHistory 'SUCCESS' $installMode $installedBuild $buildVersion 'インストール後検証に成功しました。'
    Remove-OldInstallerBackups
    Write-Host 'Installation completed successfully.'
    if ($transcriptStarted) {
        Stop-Transcript | Out-Null
        $transcriptStarted = $false
    }

    # Final launch confirmation is owned by the EXE bootstrap.
    # Keeping it outside this PowerShell process prevents the prompt from being hidden
    # behind another window or skipped during installer teardown.
    Write-Host 'Installation finished. Returning control to installer bootstrap.'
    exit 0
}
catch {
    $errorMessage = $_.Exception.Message
    Write-Host "ERROR: $errorMessage"

    if ($null -ne $transactionBackup -and (Test-Path -LiteralPath $transactionBackup -PathType Container)) {
        Write-Host 'Installation failed after previous version was backed up. Starting automatic rollback.'
        try {
            if (Test-Path -LiteralPath $installRoot) {
                Remove-Item -LiteralPath $installRoot -Recurse -Force -ErrorAction Stop
            }
            Move-Item -LiteralPath $transactionBackup -Destination $installRoot -Force -ErrorAction Stop
            Write-Host 'Automatic rollback completed successfully.'
            $errorMessage += "`r`n`r`n旧バージョンは自動的に復元されました。"
            $transactionBackup = $null
        }
        catch {
            $rollbackError = $_.Exception.Message
            Write-Host ("ROLLBACK ERROR: " + $rollbackError)
            $errorMessage += "`r`n`r`n旧バージョンの自動復元にも失敗しました。`r`n$rollbackError`r`n`r`nバックアップ: $transactionBackup"
        }
    }
    Write-InstallHistory 'FAILED' $(if ($null -ne $installMode) { $installMode } else { '不明' }) $(if ($null -ne $installedBuild) { $installedBuild } else { $null }) $buildVersion $errorMessage
    if ($transcriptStarted) {
        try { Stop-Transcript | Out-Null } catch {}
        $transcriptStarted = $false
    }

    $desktopErrorLog = Join-Path $desktop ("VBAUpdater_Setup_Error_{0}.log" -f $timestamp)
    try {
        if (Test-Path -LiteralPath $logPath) {
            Copy-Item -LiteralPath $logPath -Destination $desktopErrorLog -Force
        }
    } catch {}

    Show-Error "インストールに失敗しました。`r`n`r`n$errorMessage`r`n`r`n診断ログをデスクトップへ保存しました。`r`n$desktopErrorLog"
    exit 1
}
finally {
    # Do not write a FAILED history entry here. The catch block records real failures.
    # PowerShell executes finally even after a successful exit, so recording FAILED here
    # would create a false failure immediately after every SUCCESS entry.
    if ($transcriptStarted) {
        try { Stop-Transcript | Out-Null } catch {}
    }
}
