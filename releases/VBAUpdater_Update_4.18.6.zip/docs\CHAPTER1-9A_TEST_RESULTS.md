# Chapter1～9A/9B Safety HotFix テスト結果

最終実行日: 2026-08-09（Asia/Tokyo）
表示version: 4.18.0

## 構文・静的検証

- `vba.ps1`: PowerShell parser error 0
- `gui.ps1`: PowerShell parser error 0
- `tools/WorkbookUpdate.psm1`: PowerShell parser error 0
- SAFE1023の定義が残っていることを確認
- `git diff --check`: whitespace error 0（改行形式warningのみ）

## test-isolation-test

```powershell
.\vba.cmd test-isolation-test
```

結果: 成功。

- dummy登録、Denied外部Project、前回選択Projectを参照しない。
- Test ModeでProject Root省略、current directory自動検出、同名複数Projectを拒否する。
- Project Root外target、junction、read-only原本をOpen前に拒否する。
- Canary SHA-256: `BA1EF6D875EBF0E35AD8F3A974D76CE02573CAB81673AB0F21B1D037A4B5DD35`（前後一致）。
- 隔離log 2fileの同時排他Openとhandle解放後再書込に成功。

## regression-test

```powershell
.\vba.cmd regression-test
```

結果: 26件成功、0件失敗。

Canary SHA-256: `33FBFBB149B740839DAB32CCD1B43379602AA02BCDDA88722C74CD57CE911317`（前後一致）。CanaryのWorkbook Open監査記録0件。

## isolated-excel-regression-test

```powershell
.\vba.cmd isolated-excel-regression-test
```

結果: 全23工程成功。

- `test-create`
- `push-standard`
- `test-run`
- `class-test-create`
- `push-class`
- `class-test-run`
- `document-test-create`
- `document-test-push`
- `document-test-run`
- `userform-test-create`
- `userform-test-push`
- `userform-test-run`
- `workbook-integration-test`
- `workbook-validate`
- `workbook-diff`
- `workbook-apply`
- `workbook-verify`
- 再`workbook-diff`
- 統合`project-push`
- 再統合`project-push`
- VBA-only `project-diff`
- VBA-only `project-push`
- VBA-only `project-pull`

Workbook Integrationの確認結果:

- 親Test Root配下へ正式schemaの一時Projectを生成。
- 初回Diffは8件以上を確認し、固定値への完全一致には依存しない。
- Apply成功、Apply前Backup file存在確認。
- Worksheet、Cell、Style、Validation、Table、Picture、TextBox、Page Setupを適用。
- Verify差分0、再Diff 0で冪等性を確認。
- 管理対象外`UserData!A1`とPreserve対象`Main!D1`を保全。
- 画像内容変更を検出し、安全でない置換をWB2592で拒否。
- `AfterOpen`、`AfterWorksheet`、`BeforeSave`、`AfterSave`の障害注入後に更新前SHA-256へ復元。
- 復元失敗をWB3004として通常の更新失敗と区別。

全体Canary SHA-256: `33FBFBB149B740839DAB32CCD1B43379602AA02BCDDA88722C74CD57CE911317`（前後一致）。
Workbook Open監査: 47件、Denied/外部Workbook 0件。
終了後: 新規Excel process 0、`VU_*` Test Root 0、旧`VBAUpdaterWorkbookIntegration_*` root 0。

## 判定

Chapter1～9Aで暫定Bへ下げた安全関連のExcel実ブック経路は、最終隔離統合回帰の成功によりAへ復帰可能。Chapter1～9で既にB/Cとした高度機能・環境依存機能は変更しない。
