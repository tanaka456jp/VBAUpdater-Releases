$ErrorActionPreference='Stop'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$baselineFile=Join-Path $root 'RUNTIME_BASELINE.sha256'

$runtimeFiles=@(
 'App\gui.ps1',
 'App\vba.ps1',
 'App\vba.cmd',
 'App\addin\VBAUpdater.xlam',
 'App\engine\modVBAUpdaterEngine.bas',
 'App\tools\CodeNormalizer.psm1',
 'App\tools\PrepareSource.psm1',
 'App\tools\ProjectRegistration.psm1',
 'App\tools\VbaEncoding.psm1',
 'App\tools\WorkbookUpdate.psm1',
 'Setup.ps1',
 'Uninstall.ps1',
 'BuildInstaller.ps1',
 'VBAUpdaterSetupBootstrap.cs',
 'vba.ps1',
 'App\tools\OperationalSafety.psm1'
)
$textExtensions=@('.ps1','.psm1','.cmd','.bat','.cs','.json','.md','.txt','.bas','.cls','.frm')

function Get-NormalizedSha256([string]$Path){
 $extension=[IO.Path]::GetExtension($Path).ToLowerInvariant()
 if($textExtensions -notcontains $extension){
  return (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToUpperInvariant()
 }
 $raw=[IO.File]::ReadAllBytes($Path)
 $normalized=New-Object 'System.Collections.Generic.List[byte]'
 for($i=0;$i -lt $raw.Length;$i++){
  $b=$raw[$i]
  if($b -eq 13){
   if(($i+1) -lt $raw.Length -and $raw[$i+1] -eq 10){$i++}
   [void]$normalized.Add([byte]10)
  } else {
   [void]$normalized.Add([byte]$b)
  }
 }
 $sha=[Security.Cryptography.SHA256]::Create()
 try { return ([BitConverter]::ToString($sha.ComputeHash($normalized.ToArray()))).Replace('-','').ToUpperInvariant() }
 finally { $sha.Dispose() }
}

$lines=foreach($rel in $runtimeFiles){
 $path=Join-Path $root $rel
 if(-not (Test-Path -LiteralPath $path -PathType Leaf)){throw ("Runtime file missing: {0}" -f $rel)}
 $hash=Get-NormalizedSha256 $path
 '{0} *{1}' -f $hash,$rel
}

# UTF-8 without BOM keeps the baseline deterministic on Windows PowerShell 5.1.
$utf8NoBom=New-Object Text.UTF8Encoding($false)
[IO.File]::WriteAllText($baselineFile,($lines -join "`n")+"`n",$utf8NoBom)
Write-Host ("Runtime baseline regenerated: {0} files" -f $runtimeFiles.Count) -ForegroundColor Green
