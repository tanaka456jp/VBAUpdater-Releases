@echo off
setlocal
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Setup.ps1"
set "EXITCODE=%ERRORLEVEL%"
if not "%EXITCODE%"=="0" (
  echo.
  echo VBAUpdater Setup failed. Please check the log shown by the installer.
  pause
)
exit /b %EXITCODE%
