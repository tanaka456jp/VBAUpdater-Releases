Set-StrictMode -Version Latest

$script:SchemaVersion = 1
$script:ClassificationExpected = 'EXPECTED'
$script:ClassificationKnownUserChange = 'KNOWN_USER_CHANGE'
$script:ClassificationUnknown = 'UNKNOWN'

function Get-VBAUpdaterFileSha256 {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToUpperInvariant()
}

function New-VBAUpdaterGeneratedDifferenceRecord {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$SessionId,
        [Parameter(Mandatory)][string]$Operation,
        [Parameter(Mandatory)][string]$Path,
        [AllowNull()][string]$BeforeSha256,
        [AllowNull()][string]$AfterSha256,
        [Parameter(Mandatory)][ValidateSet('SUCCESS','FAILED','CANCELLED')][string]$Result,
        [datetime]$TimestampUtc = [datetime]::UtcNow
    )

    [pscustomobject][ordered]@{
        schemaVersion = $script:SchemaVersion
        sessionId = $SessionId
        operation = $Operation
        path = [IO.Path]::GetFullPath($Path)
        beforeSha256 = if ($BeforeSha256) { $BeforeSha256.ToUpperInvariant() } else { $null }
        afterSha256 = if ($AfterSha256) { $AfterSha256.ToUpperInvariant() } else { $null }
        result = $Result
        timestampUtc = $TimestampUtc.ToUniversalTime().ToString('o')
    }
}

function Save-VBAUpdaterGeneratedDifferenceRecord {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]$Record,
        [Parameter(Mandatory)][string]$LedgerPath
    )

    $directory = Split-Path -Parent $LedgerPath
    if ($directory -and -not (Test-Path -LiteralPath $directory)) {
        New-Item -ItemType Directory -Path $directory -Force | Out-Null
    }
    $line = $Record | ConvertTo-Json -Compress -Depth 5
    Add-Content -LiteralPath $LedgerPath -Value $line -Encoding UTF8
}

function Get-VBAUpdaterGeneratedDifferenceRecords {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$LedgerPath)

    if (-not (Test-Path -LiteralPath $LedgerPath -PathType Leaf)) { return @() }
    $records = @()
    foreach ($line in Get-Content -LiteralPath $LedgerPath -Encoding UTF8) {
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        try { $records += ($line | ConvertFrom-Json -ErrorAction Stop) }
        catch { throw "Generated difference provenance ledger is invalid: $LedgerPath" }
    }
    return @($records)
}

function Get-VBAUpdaterDifferenceClassification {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [AllowNull()][string]$CurrentSha256,
        [object[]]$Records = @(),
        [switch]$KnownUserChange
    )

    if ($KnownUserChange) {
        return [pscustomobject]@{ Classification=$script:ClassificationKnownUserChange; Reason='Explicitly marked as a known user change.'; Record=$null }
    }

    $fullPath = [IO.Path]::GetFullPath($Path)
    $hash = if ($CurrentSha256) { $CurrentSha256.ToUpperInvariant() } else { $null }
    $match = @($Records | Where-Object {
        $_.result -eq 'SUCCESS' -and
        ([IO.Path]::GetFullPath([string]$_.path) -ieq $fullPath) -and
        $hash -and $_.afterSha256 -and ([string]$_.afterSha256).ToUpperInvariant() -eq $hash
    } | Sort-Object { [datetime]$_.timestampUtc } -Descending | Select-Object -First 1)

    if ($match.Count -eq 1) {
        return [pscustomobject]@{ Classification=$script:ClassificationExpected; Reason='Current file hash matches a successful VBAUpdater-generated result.'; Record=$match[0] }
    }

    return [pscustomobject]@{ Classification=$script:ClassificationUnknown; Reason='No successful provenance record matches the current path and hash.'; Record=$null }
}

function Write-VBAUpdaterUtf8JsonLine {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Line
    )

    $directory = Split-Path -Parent $Path
    if ($directory -and -not (Test-Path -LiteralPath $directory)) {
        New-Item -ItemType Directory -Path $directory -Force | Out-Null
    }

    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    $writer = $null
    try {
        $writer = New-Object System.IO.StreamWriter($Path, $true, $utf8NoBom)
        $writer.WriteLine($Line)
        $writer.Flush()
    }
    finally {
        if ($null -ne $writer) { $writer.Dispose() }
    }
}

function Observe-VBAUpdaterDifference {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$LedgerPath,
        [string]$ObservationLogPath,
        [switch]$KnownUserChange,
        [datetime]$TimestampUtc = [datetime]::UtcNow
    )

    $currentHash = Get-VBAUpdaterFileSha256 -Path $Path
    $records = @(Get-VBAUpdaterGeneratedDifferenceRecords -LedgerPath $LedgerPath)
    $classification = Get-VBAUpdaterDifferenceClassification -Path $Path -CurrentSha256 $currentHash -Records $records -KnownUserChange:$KnownUserChange
    $observation = [pscustomobject][ordered]@{
        schemaVersion = $script:SchemaVersion
        timestampUtc = $TimestampUtc.ToUniversalTime().ToString('o')
        path = [IO.Path]::GetFullPath($Path)
        currentSha256 = $currentHash
        classification = $classification.Classification
        reason = $classification.Reason
        action = 'OBSERVE_ONLY'
        matchedSessionId = if ($classification.Record) { [string]$classification.Record.sessionId } else { $null }
        matchedOperation = if ($classification.Record) { [string]$classification.Record.operation } else { $null }
    }

    if (-not [string]::IsNullOrWhiteSpace($ObservationLogPath)) {
        Write-VBAUpdaterUtf8JsonLine -Path $ObservationLogPath -Line ($observation | ConvertTo-Json -Compress -Depth 5)
    }

    return [pscustomobject]@{
        Classification = $classification.Classification
        Reason = $classification.Reason
        Action = 'OBSERVE_ONLY'
        CurrentSha256 = $currentHash
        Record = $classification.Record
        Observation = $observation
    }
}

Export-ModuleMember -Function Get-VBAUpdaterFileSha256,New-VBAUpdaterGeneratedDifferenceRecord,Save-VBAUpdaterGeneratedDifferenceRecord,Get-VBAUpdaterGeneratedDifferenceRecords,Get-VBAUpdaterDifferenceClassification,Observe-VBAUpdaterDifference
