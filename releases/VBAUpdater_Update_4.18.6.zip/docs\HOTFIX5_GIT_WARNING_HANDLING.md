
Test script encoding HotFix: TestGitWarningHandling.ps1 was changed to ASCII-only source to remain parser-safe on Windows PowerShell 5.1 regardless of system ANSI code page. Production Git handling logic is unchanged.
