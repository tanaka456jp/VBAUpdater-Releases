VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmUpdaterTest 
   Caption         =   "USERFORM_NEW_CAPTION"
   ClientHeight    =   3636
   ClientLeft      =   108
   ClientTop       =   456
   ClientWidth     =   6984
   OleObjectBlob   =   "frmUpdaterTest.frx":0000
   StartUpPosition =   1  '�I�[�i�[ �t�H�[���̒���
End
Attribute VB_Name = "frmUpdaterTest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Public Function GetValue() As String
    GetValue = "USERFORM_NEW_VALUE"
End Function
