﻿Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'

function Invoke-VBAUpdaterWorkbookSafetyGate {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [int]$WaitMilliseconds=250
    )
    if(-not(Test-Path -LiteralPath $Path -PathType Leaf)){throw "対象ブックが見つかりません: $Path"}
    $initial=Get-WorkbookExclusiveAccessDiagnostic -Path $Path
    if($initial.Available){
        return [PSCustomObject][ordered]@{Allowed=$true;RecoveryAttempted=$false;RecoveryAction='NONE';Initial=$initial;Final=$initial;Message='対象ブックは排他アクセス可能です。'}
    }
    $recovery=Invoke-VBAUpdaterSafeWorkbookLockRecovery -Path $Path -WaitMilliseconds $WaitMilliseconds
    $final=$recovery.After
    if(-not $final.Available){
        return [PSCustomObject][ordered]@{Allowed=$false;RecoveryAttempted=$true;RecoveryAction=[string]$recovery.Action;Initial=$initial;Final=$final;Message='対象ブックの安全な自己回復後も排他アクセスできません。外部Excel/プロセスには触れず更新を停止します。'}
    }
    return [PSCustomObject][ordered]@{Allowed=$true;RecoveryAttempted=$true;RecoveryAction=[string]$recovery.Action;Initial=$initial;Final=$final;Message='安全な自己回復後に対象ブックの排他アクセスを確認しました。'}
}

Export-ModuleMember -Function Invoke-VBAUpdaterWorkbookSafetyGate
