param(
    [string]$RepositoryRoot = (Split-Path -Parent $PSScriptRoot)
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$gui=Join-Path $RepositoryRoot 'App\gui.ps1'
$workbook=Join-Path $RepositoryRoot 'App\tools\WorkbookUpdate.psm1'
if(-not(Test-Path -LiteralPath $gui -PathType Leaf)){throw "gui.ps1 not found: $gui"}
if(-not(Test-Path -LiteralPath $workbook -PathType Leaf)){throw "WorkbookUpdate.psm1 not found: $workbook"}

$wb=[IO.File]::ReadAllText($workbook,[Text.Encoding]::UTF8)
$oldImport="Import-Module `$script:GeneratedDifferenceProvenanceModulePath -Force -ErrorAction Stop"
$newImport="Import-Module `$script:GeneratedDifferenceProvenanceModulePath -Force -DisableNameChecking -ErrorAction Stop"
if($wb.Contains($newImport)){Write-Host ('[OK] Already applied: '+$workbook)}
elseif($wb.Contains($oldImport)){
    [IO.File]::WriteAllText($workbook,$wb.Replace($oldImport,$newImport),(New-Object Text.UTF8Encoding($true)))
    Write-Host ('[OK] Updated: '+$workbook)
}else{throw 'GeneratedDifferenceProvenance import guard was not found in the expected state.'}

$guiText=[IO.File]::ReadAllText($gui,[Text.Encoding]::UTF8)
$startMatches=[regex]::Matches($guiText,'(?m)^function\s+Get-ProjectNames\s*\{')
# The next function is parameterized in the RC2 source: function Quote-ProcessArgument([string]$Value) {
$endMatches=[regex]::Matches($guiText,'(?m)^function\s+Quote-ProcessArgument(?:\s*\([^\r\n]*\))?\s*\{')
if($startMatches.Count-ne 1){throw "Expected exactly one Get-ProjectNames function but found $($startMatches.Count)"}
if($endMatches.Count-ne 1){throw "Expected exactly one Quote-ProcessArgument function but found $($endMatches.Count)"}
$start=$startMatches[0].Index
$end=$endMatches[0].Index
if($end-le $start){throw 'Get-ProjectNames function boundary is invalid.'}
$current=$guiText.Substring($start,$end-$start)
if($current -notmatch "'projects'\s*,\s*'-Json'"){throw 'Get-ProjectNames no longer calls projects -Json; refusing to patch.'}
if($current -match 'VBAUpdater_projects_json_'){
    Write-Host ('[OK] Already applied: '+$gui)
}else{
$newFunction=@'
function Get-ProjectNames {
    $script:settingsInfo=Get-SettingsInfoFromCli
    if($script:settingsInfo.PSObject.Properties['Logging'] -and $script:settingsInfo.Logging.PSObject.Properties['retentionCount']){
        $script:GuiLogRetentionCount=[Math]::Max(1,[int]$script:settingsInfo.Logging.retentionCount)
    }
    $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',$cliPath,'projects','-Json')+@(Get-GuiTestPropagationArguments)
    $stderrPath=Join-Path ([IO.Path]::GetTempPath()) ('VBAUpdater_projects_json_'+[guid]::NewGuid().ToString('N')+'.stderr')
    try {
        $outputLines=@(& powershell.exe @arguments 2> $stderrPath)
        $exitCode=$LASTEXITCODE
        $output=$outputLines -join [Environment]::NewLine
        $stderr=if(Test-Path -LiteralPath $stderrPath -PathType Leaf){[IO.File]::ReadAllText($stderrPath)}else{''}
        if($exitCode-ne 0){throw "登録プロジェクト一覧をCLIから取得できません。ExitCode=$exitCode / 詳細: $output / STDERR: $stderr"}
        if([string]::IsNullOrWhiteSpace($output)){throw "登録プロジェクト一覧のCLI応答が空です。STDERR: $stderr"}
        try{$projects=@($output|ConvertFrom-Json -ErrorAction Stop)}
        catch{throw "登録プロジェクト一覧のCLI応答を解析できません: $($_.Exception.Message) / 応答: $output / STDERR: $stderr"}
    }
    finally { Remove-Item -LiteralPath $stderrPath -Force -ErrorAction SilentlyContinue }
    $script:registeredProjectFolders=@{}
    $names=New-Object 'System.Collections.Generic.List[string]'
    foreach($entry in @($projects|Sort-Object Name,ProjectFolder)){
        if($null-eq$entry){continue}
        $name=[string]$entry.Name
        if([string]::IsNullOrWhiteSpace($name)){continue}
        $script:registeredProjectFolders[$name]=[string]$entry.ProjectFolder
        if(-not $names.Contains($name)){$names.Add($name)}
    }
    return @($names.ToArray())
}

'@
    $newline=if($current.Contains("`r`n")){"`r`n"}else{"`n"}
    $newFunction=$newFunction -replace "`r?`n",$newline
    $updated=$guiText.Substring(0,$start)+$newFunction+$guiText.Substring($end)
    [IO.File]::WriteAllText($gui,$updated,(New-Object Text.UTF8Encoding($true)))
    Write-Host ('[OK] Updated: '+$gui)
}

$testPath=Join-Path $RepositoryRoot 'tests\test-v4186-json-cli-warning-isolation.ps1'
$test=@'
Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$gui=[IO.File]::ReadAllText((Join-Path $root 'App\gui.ps1'),[Text.Encoding]::UTF8)
$wb=[IO.File]::ReadAllText((Join-Path $root 'App\tools\WorkbookUpdate.psm1'),[Text.Encoding]::UTF8)
if($wb -notmatch 'GeneratedDifferenceProvenanceModulePath\s+-Force\s+-DisableNameChecking\s+-ErrorAction\s+Stop'){throw 'GeneratedDifferenceProvenance import does not suppress unapproved-verb warnings.'}
$start=[regex]::Matches($gui,'(?m)^function\s+Get-ProjectNames\s*\{')
$next=[regex]::Matches($gui,'(?m)^function\s+Quote-ProcessArgument(?:\s*\([^\r\n]*\))?\s*\{')
if($start.Count-ne 1 -or $next.Count-ne 1 -or $next[0].Index-le$start[0].Index){throw 'Get-ProjectNames boundary validation failed.'}
$body=$gui.Substring($start[0].Index,$next[0].Index-$start[0].Index)
if($body -match 'powershell\.exe\s+@arguments\s+2>&1'){throw 'Get-ProjectNames still merges stderr into JSON stdout.'}
foreach($required in @('2> $stderrPath','ConvertFrom-Json -ErrorAction Stop','STDERR: $stderr',"'projects','-Json'")){if($body.IndexOf($required,[StringComparison]::Ordinal)-lt 0){throw "Missing JSON isolation guard: $required"}}
Write-Host '[PASS] V4.18.6 JSON CLI warning isolation regression guard.'
'@
[IO.File]::WriteAllText($testPath,$test,(New-Object Text.UTF8Encoding($true)))

Write-Host '[PASS] Applied V4.18.6 JSON CLI warning isolation HotFix.'
Write-Host ('  Verified: '+$workbook)
Write-Host ('  Verified: '+$gui)
Write-Host ('  Added   : '+$testPath)
