# VBAUpdater Development State

## Current release candidate

- Product version: `4.18.5`
- Build: `VBAUpdater_V4.18.5_RC2`
- Scope: UserForm formal support, Excel COM lifecycle/self-healing, taskbar attention, VBA encoding diagnostics, version unification, UTF-8 BOM HotFix
- Status: automated RC gate PASS; final user Windows acceptance pending
- Canonical source: this working tree. No legacy ZIP was used as source.

## Implemented

- The formal managed component type is `userform`. The unproven `form` alias is rejected.
- UserForms require a VBE-exported `.frm` and a non-empty sibling `.frx` with the same base name. Dummy FRX generation is prohibited.
- Existing VBE `VBComponents.Import`/`Remove` flow is retained for UserForm add/update/delete, with type/name checks, Compile Gate, semantic verification, restore points, and automatic rollback on failed push/sync.
- Existing UserForm semantic rules are retained: designer-only known twip `.001` normalization, strict code/string comparison, and conditional FRX ResultOverride only when both FRX files exist and FRM is semantically equal.
- VBA source import is fail-closed before workbook mutation when the current ANSI/VBE code page cannot round-trip a character. Diagnostics include component, type, file, line, column, character, Unicode code point, code page, and reason.
- UTF-8 BOM (U+FEFF at file start) is correctly excluded from round-trip diagnostics and treated as an encoding marker, not a code character. Fix ensures consistent handling whether Read-VbaTextFile is available or fallback path is used.

## RC2 HotFix (2026-08-21)

- **Issue**: RC1 real-device check found `U+FEFF` (UTF-8 BOM) at file start incorrectly flagged as ENC1001 during Encoding Preflight
- **Root cause**: `Test-VbaSourceEncodingRoundTrip` fallback path (when `Read-VbaTextFile` unavailable) did not strip BOM bytes (EF BB BF / FF FE / FE FF) before decoding
- **Fix**: Added BOM detection/stripping in fallback path matching `Read-VbaTextFile` behavior
- **Files changed**: `tools/VbaEncoding.psm1`, `App/tools/VbaEncoding.psm1`
- **Verification**: UTF-8/16 BOM at file start no longer triggers ENC1001; U+FEFF in code body still detected; real incompatible chars (U+1F600, U+301C) still detected; all 29 regression tests PASS
- Excel COM ownership is tracked by application HWND. Only VBAUpdater-created applications are closed/quit. Child RCWs and collection objects are explicitly released, with finalizer cleanup on normal and failure paths.
- Workbook write availability is retried after current-process RCW/finalizer cleanup. Genuine external locks remain rejected; no Excel process enumeration/kill is used for recovery.
- GUI uses Windows `FlashWindowEx` for success, failure, and action-required attention. Active windows are not flashed, duplicate requests are coalesced, and activation/close stops flashing.
- `VERSION.txt` is the ProductVersion source used by root/App CLI and GUI. Installer, packaging validation, and display tests read or validate the same `4.18.5` value.
- Test Mode no longer writes auto-resolved Add-in paths back to the canonical `addin/installed-addin.json`.
- The tracked Add-in resolution file is sanitized to an unresolved template; user-specific paths are discovered locally and are excluded from the development ZIP.

## Safety invariants

- Source remains canonical.
- Real business projects and workbooks are not automatic test targets.
- An actually open target workbook is rejected.
- User-owned Excel applications/workbooks are not closed, quit, or killed.
- Restore point, differential update, Compile Gate, post-update semantic verification, and SHA-256 rollback remain mandatory where configured.
- `〜` and `?` remain semantically different.
- FRX is never ignored unconditionally.
- Git success is based on process ExitCode; stderr warning with ExitCode 0 remains success and is logged.
- Project Root boundary, explicit Test Mode roots, workbook-open audit, and Canary hashing remain enforced.

## RC2 Self Update E2E Final HotFix (2026-08-22)

- **Issue**: Windows実機で `RunRCValidation.cmd` 実行時、`TestSelfUpdateE2E.ps1` が `PayloadSource\App\version.txt` への `Compress-Archive` で `PermissionDenied` となり FAIL
- **Root cause**: テストが `Compress-Archive` (PowerShell標準コマンド) を使用していたが、ファイル作成直後の `version.txt` が Windows Defender/Indexer により一時ロックされ、かつ `Compress-Archive` は `FileShare.ReadWrite/Delete` を使わずリトライもしないため競合で失敗
- **Fix**: `TestSelfUpdateE2E.ps1` の ZIP 生成を .NET `ZipArchive` + `FileShare.ReadWrite/Delete` + リトライロジック (`Invoke-WithFileRetry`) に変更。`BuildInstaller.ps1` と同等の堅牢な実装に統一。また 8.3短縮パスと長いパスの不整合で ZIP エントリ名が `ce\App\...` となるバグを `[IO.Path]::GetFullPath()` で修正
- **Files changed**: `TestSelfUpdateE2E.ps1` (Compress-Archive → ZipArchive with retry, パス正規化追加)
- **Verification**: 10連続実行 PASS (PermissionDenied 再現なし)、RC Validation 2連続 PASS、29/29 regression PASS
- **No Sleep/無制限リトライ**: 固定8回・300ms間隔のリトライで品質ゲート維持
- **Runtime変更なし**: テスト専用コードのみ修正、共通ランタイム(`BuildInstaller.ps1`等)は元から堅牢実装済みのため変更不要

## RC2 Multi-Component Self-Lock Final HotFix (2026-08-22)

- **Issue**: 実機 PropertyManagement プロジェクトで project-sync 実行時、2つの変更標準モジュール (`modLoanScheduleReport`, `modLoanSchedulePrintUI`) の更新中に SAFE2001 で停止。JournalConverter (単一モジュール更新) は PASS
- **Root cause**: `Invoke-EngineComponentUpdate` (vba.ps1:1904, App\vba.ps1:1904) が各コンポーネント更新のたびに `Assert-WorkbookAvailableForUpdate` を呼び出していた。第1コンポーネント更新後、VBAUpdater自身が開いた Workbook を Excel が保持している間に第2コンポーネントでロック判定が走り、自プロセス所有を「他のExcel/別処理」と誤判定
- **Fix**: トランザクションレベルでワークブック可用性が確認済みであるため、コンポーネント単位の冗長チェックを削除。`Invoke-EngineComponentUpdate` から `Assert-WorkbookAvailableForUpdate -Path $WorkbookPath` を削除
- **Files changed**: `vba.ps1` (line 1904), `App\vba.ps1` (line 1904) - 各1行削除のみ
- **Verification**: 
  - 29/29 regression PASS (Canary unchanged)
  - workbook-integration-test PASS (18 workbook changes applied, verified diff=0)
  - com-lifecycle-test PASS (real lock rejected, retry after release, verified restore)
  - Self Update E2E PASS
  - RC Validation 3連続 PASS
- **No Sleep/無制限リトライ/ロック無視**: トランザクション境界での単一検証に集約、外部ロック検知機能は維持
- **Runtime変更**: 最小限 (2ファイル、各1行削除)

## Automated test results (2026-08-22 JST)

- PowerShell parse: PASS for root/App CLI, GUI, WorkbookUpdate, encoding, installer, and RC scripts.
- `regression-test`: PASS, 29/29, Canary unchanged.
- `normalize-test`: PASS, including twip equality/difference, code/string strictness, and FRX ResultOverride.
- `userform-managed-test`: PASS.
- `vba-encoding-test`: PASS on ACP 932.
- `com-lifecycle-test`: PASS.
- `isolated-excel-regression-test`: PASS using temporary fixtures only; 56 workbook-open audit records; no newly started Excel PID remained.
- Actual VBE UserForm Export/Import/update/add/delete: PASS with two forms, code, Caption, label controls, and primary-form preservation after managed deletion.
- Actual open target rejection, close-then-retry, and unrelated open Excel non-interference: PASS.
- Workbook integration and failure injection (`AfterOpen`, `AfterWorksheet`, `BeforeSave`, `AfterSave`): PASS with restore hash match.
- Project push repeated run, project diff/push/pull fixture: PASS.
- Taskbar notification static/WinForms wiring tests: PASS. Human visual behavior remains an acceptance item.
- Self Update E2E fixture: PASS; App update, settings/history preservation, and pre-update backup confirmed.
- RC2 HotFix: UTF-8 BOM false positive resolved; all encoding tests PASS.
- RC2 Repository Hygiene Final HotFix: dist pre-cleanup of known RC artifacts before validation; reproducible RC Validation PASS (3 consecutive runs).
- RC Validation: Package verification PASS; Runtime baseline PASS (updated for VbaEncoding.psm1 change); Repository hygiene PASS with pre-validation dist cleanup.

## RC2 Repository Hygiene Final HotFix (2026-08-22)

- **Issue**: Windows実機でRunRCValidation.cmdがRepository Hygieneで失敗（distに前回成果物8件が残存）
- **Root cause**: RC Validationがdist空を要求しつつ、BuildInstaller等がdistへ成果物を生成し、再実行時にHygieneチェックでFAIL
- **Fix**: RunRCValidation.ps1に既知RC成果物パターンによる事前クリーンアップを追加；BuildRCArtifacts.ps1で成果物生成を分離
- **Files changed**: `RunRCValidation.ps1`（事前クリーンアップ追加）、`VerifyRepositoryHygiene.ps1`（エラー詳細化）、`BuildRCArtifacts.ps1`（新規）、`BUILD_VERSION.txt`（RC2更新）、`README.txt`等メタデータ更新
- **Workflow**: Clean → RC Validation（事前distクリーンアップ込） → PASS → BuildRCArtifacts → 成果物検証
- **Reproducibility**: RC Validation 3連続PASS、成果物生成→再Validation 2連続PASS確認

## Changed runtime areas

- `vba.ps1`, `App/vba.ps1`
- `gui.ps1`, `App/gui.ps1`
- `tools/WorkbookUpdate.psm1`, `App/tools/WorkbookUpdate.psm1`
- `tools/VbaEncoding.psm1`, `App/tools/VbaEncoding.psm1`
- `VERSION.txt`, `App/VERSION.txt`
- Encoding Preflight BOM fix: tools/VbaEncoding.psm1 `Test-VbaSourceEncodingRoundTrip` fallback path now strips UTF-8/16 BOM before round-trip validation
- `RUNTIME_BASELINE.sha256` updated for VbaEncoding.psm1 change
- Repository Hygiene: `RunRCValidation.ps1` (pre-validation dist cleanup), `VerifyRepositoryHygiene.ps1` (enhanced error messages), `BuildRCArtifacts.ps1` (new)
- Self Update E2E: `TestSelfUpdateE2E.ps1` (Compress-Archive → .NET ZipArchive with FileShare.ReadWrite/Delete + retry; path normalization fix)
- Multi-Component Self-Lock: `vba.ps1`, `App\vba.ps1` (removed redundant per-component Assert-WorkbookAvailableForUpdate in Invoke-EngineComponentUpdate)
- `BUILD_VERSION.txt`, `README.txt`, `App\README.txt`, `App\START_HERE.txt`, `App\DISTRIBUTION_MANIFEST.txt` updated to RC2
- installer, package validation, RC validation, runtime baseline, manuals, and version tests

## RC2 Artifacts (generated)

- Development ZIP: `dist/VBAUpdater_Development_4.18.5_RC2.zip` (SHA256: AB739412476B0752F4FD02CA33515055B219F68C09353F3D180736054496BAE9)
- Installer: `dist/VBAUpdater_Setup_4.18.5.exe` (SHA256: 813B65A298E2EE8B547AD6F68CE53BE0488D49598468274ED8F0BC130650D12D)
- RC2 Release Notes: `dist/V4.18.5_RC2_RELEASE_NOTES.md`
- RC2 Test Results: `dist/V4.18.5_RC2_TEST_RESULTS.md`
- RC Validation Report: `dist/RC_VALIDATION_VBAUpdater_V4.18.5_RC2.txt`
- Artifacts Summary: `dist/RC2_ARTIFACTS_VBAUpdater_V4.18.5_RC2.txt`
- SHA-256 files: `VBAUpdater_Setup_4.18.5_SHA256.txt`, `VBAUpdater_Development_4.18.5_RC2_SHA256.txt`

## Known issues and unexecuted acceptance

- Taskbar flashing has static/API wiring coverage but needs a person to verify Active/Inactive/Activate behavior visually in the installed GUI.
- The RC installer was built and hashed but has not been installed by the user as final acceptance.
- The official old-version-to-published-4.18.5 self-update flow cannot be completed until the release repository is populated; only the isolated E2E fixture passed.
- GUI cancellation-specific COM recovery has no deterministic automated cancellation injection. Normal, failure, repeated, lock, and COM exception cleanup paths are covered.
- Formal release ZIP, update ZIP, production `latest.json`, release-folder overlay ZIP, and publication are intentionally not created before user acceptance.

## RC2 Repository Hygiene HotFix Verification

- Clean repository + empty dist → Hygiene PASS ✓
- dist with unexpected files → FAIL with detailed list ✓
- dist with old RC artifacts → Cleaned by pre-validation cleanup ✓
- RC Validation formal workflow → PASS (3 consecutive runs) ✓
- RC Artifacts generation → PASS ✓
- Artifacts hash verification → PASS ✓
- RC Validation after artifacts → PASS (2 consecutive runs) ✓
- RC workflow 2nd execution → Clean cycle + PASS ✓
- No user file auto-deletion → Verified (only known RC patterns) ✓
- Real projects untouched → Verified ✓
- 29/29 regression PASS ✓
- Encoding regression PASS ✓
- UserForm regression PASS ✓
- Git warning regression PASS ✓
- RC Validation PASS ✓

## RC2 Self Update E2E HotFix Verification

- TestSelfUpdateE2E.ps1 10連続実行 PASS ✓ (PermissionDenied 再現なし)
- RC Validation 2連続実行 PASS ✓ (Self Update E2E 含む全テスト PASS)
- 29/29 regression PASS ✓
- Encoding/BOM PASS ✓
- UserForm/FRM/FRX/twip PASS ✓
- Git warning handling PASS ✓
- COM cleanup/self-healing PASS ✓
- Version consistency (4.18.5) PASS ✓
- File/Stream/ZIP lifecycle: Write → Flush/Close → Verify → Compress → Verify 正常 ✓
- Sleep/リトライ依存なし (固定8回・300ms間隔の明示的リトライ) ✓
- テスト専用修正、ランタイム変更なし ✓

## RC2 Multi-Component Self-Lock Final HotFix Verification

- workbook-integration-test PASS ✓ (18 workbook changes applied, verify diff=0)
- com-lifecycle-test PASS ✓ (real lock rejected, retry after release, verified restore)
- 29/29 regression PASS ✓ (Canary unchanged: 33FBFBB149B740839DAB32CCD1B43379602AA02BCDDA88722C74CD57CE911317)
- Self Update E2E PASS ✓
- RC Validation 3連続実行 PASS ✓ (dist事前クリーンアップ込み、成果物再生成後も)
- 外部ロック安全性維持: 実Excel開き対象 → SAFE2001 ✓
- 自己トランザクション誤検知解消: 2コンポーネント連続更新でSAFE2001なし ✓
- 2ファイル×1行削除の最小修正 ✓
- COMライフサイクル正常: Excel残留なし、ハンドル残留なし ✓

## Local artifact hygiene

Pre-existing local-only artifacts were moved, not deleted:

- `%TEMP%\VBAUpdater_PreexistingLogs_20260821`
- `%TEMP%\VBAUpdater_PreexistingBackups_20260821`
- `%TEMP%\VBAUpdater_PreexistingDist_20260821`

## Next step

1. Install the RC installer on Windows and launch VBAUpdater.
2. Verify GUI/About/version show `4.18.5` and registered project settings remain available.
3. Visually verify taskbar flashing for inactive success/failure/action-required and stopping on activation.
4. Run UserForm add/update/delete/multiple-form acceptance on a dedicated non-business fixture.
5. Run PropertyManagement real update (read-only diagnostics only before update; user performs actual update).
6. After acceptance, create `VBAUpdater_Update_4.18.5.zip`, production `latest.json`, hashes, formal release notes, and the repository-overlay ZIP without `.git` or local artifacts.

Git commit, push, branch, tag, reset, restore, and clean were not performed.
