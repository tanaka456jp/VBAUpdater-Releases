﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Get-VBAUpdaterSessionMarkerPath {
    param([Parameter(Mandatory=$true)][string]$UserDataRoot)
    return (Join-Path $UserDataRoot 'runtime\gui-session.json')
}

function Start-VBAUpdaterOperationalSession {
    param([Parameter(Mandatory=$true)][string]$UserDataRoot,[string]$Build='')
    $path=Get-VBAUpdaterSessionMarkerPath -UserDataRoot $UserDataRoot
    $dir=Split-Path -Parent $path
    if(-not(Test-Path -LiteralPath $dir -PathType Container)){[void](New-Item -ItemType Directory -Path $dir -Force)}
    $previousUnclean=Test-Path -LiteralPath $path -PathType Leaf
    $previous=$null
    if($previousUnclean){try{$previous=[IO.File]::ReadAllText($path)|ConvertFrom-Json}catch{$previous=$null}}
    $record=[ordered]@{build=$Build;processId=$PID;startedAt=(Get-Date).ToString('o');machine=[Environment]::MachineName;powershell=$PSVersionTable.PSVersion.ToString()}
    [IO.File]::WriteAllText($path,($record|ConvertTo-Json -Depth 4),(New-Object Text.UTF8Encoding($false)))
    return [PSCustomObject]@{Path=$path;PreviousUnclean=$previousUnclean;Previous=$previous}
}

function Stop-VBAUpdaterOperationalSession {
    param([Parameter(Mandatory=$true)][string]$UserDataRoot)
    $path=Get-VBAUpdaterSessionMarkerPath -UserDataRoot $UserDataRoot
    if(Test-Path -LiteralPath $path -PathType Leaf){Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue}
}

function Get-WorkbookExclusiveAccessDiagnostic {
    param([Parameter(Mandatory=$true)][string]$Path)
    $stream=$null
    try{
        $stream=[IO.File]::Open($Path,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
        return [PSCustomObject][ordered]@{Available=$true;ExceptionType='';HResult='';Message=''}
    } catch {
        $exception=$_.Exception;$hresult=''
        try{$hresultValue=[int64]$exception.HResult;if($hresultValue -lt 0){$hresultValue += 0x100000000L};$hresult=('0x{0:X8}' -f $hresultValue)}catch{$hresult=''}
        return [PSCustomObject][ordered]@{Available=$false;ExceptionType=$exception.GetType().FullName;HResult=$hresult;Message=[string]$exception.Message}
    } finally {if($null-ne$stream){$stream.Dispose()}}
}

function Invoke-VBAUpdaterSafeWorkbookLockRecovery {
    param([Parameter(Mandatory=$true)][string]$Path,[int]$WaitMilliseconds=250)
    $before=Get-WorkbookExclusiveAccessDiagnostic -Path $Path
    if($before.Available){
        return [PSCustomObject][ordered]@{Attempted=$false;Recovered=$true;Action='NONE';Before=$before;After=$before;Message='対象ブックは既に排他アクセス可能です。'}
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
    if($WaitMilliseconds -gt 0){Start-Sleep -Milliseconds ([Math]::Min($WaitMilliseconds,2000))}
    $after=Get-WorkbookExclusiveAccessDiagnostic -Path $Path
    return [PSCustomObject][ordered]@{Attempted=$true;Recovered=[bool]$after.Available;Action='GC_FINALIZER_RETRY';Before=$before;After=$after;Message=if($after.Available){'VBAUpdaterプロセス内の解放待ち参照を整理した後、排他アクセスが回復しました。'}else{'安全なプロセス内整理では排他アクセスは回復しませんでした。外部Excel/プロセスには触れずFail Closedを維持します。'}}
}

function Assert-VBAUpdaterWorkbookExclusiveSafe {
    param([Parameter(Mandatory=$true)][string]$Path,[int]$WaitMilliseconds=250)
    if(-not(Test-Path -LiteralPath $Path -PathType Leaf)){throw "対象ブックが見つかりません: $Path"}
    $initial=Get-WorkbookExclusiveAccessDiagnostic -Path $Path
    if($initial.Available){return}
    $recovery=Invoke-VBAUpdaterSafeWorkbookLockRecovery -Path $Path -WaitMilliseconds $WaitMilliseconds
    if(-not [bool]$recovery.After.Available){
        throw ("対象ブックを安全に排他利用できません。VBAUpdater内の安全な自己回復後もロックされています。外部Excel/プロセスには触れず更新を停止します。HResult={0} / {1}" -f $recovery.After.HResult,$recovery.After.Message)
    }
}

function Get-VBAUpdaterOperationalSafetySnapshot {
    param([Parameter(Mandatory=$true)][string]$UserDataRoot,[Parameter(Mandatory=$true)][string]$InstallRoot,[string]$ProjectDirectory='',[string]$TargetPath='',[bool]$PreviousSessionUnclean=$false)
    $ok=New-Object 'System.Collections.Generic.List[string]';$warnings=New-Object 'System.Collections.Generic.List[string]';$errors=New-Object 'System.Collections.Generic.List[string]';$exclusiveDiagnostic=$null
    if($PSVersionTable.PSVersion.Major -ge 5){[void]$ok.Add(('PowerShell: '+$PSVersionTable.PSVersion.ToString()))}else{[void]$errors.Add(('PowerShell 5.1以上が必要です。現在: '+$PSVersionTable.PSVersion.ToString()))}
    $excelRegistered=$false;try{$excelRegistered=Test-Path -LiteralPath 'Registry::HKEY_CLASSES_ROOT\Excel.Application\CLSID'}catch{$excelRegistered=$false}
    if($excelRegistered){[void]$ok.Add('Microsoft Excel: COM登録確認済み')}else{[void]$warnings.Add('Microsoft ExcelのCOM登録を確認できません。Excel未導入または登録異常の可能性があります。')}
    $git=Get-Command git.exe -ErrorAction SilentlyContinue;if($null-ne$git){[void]$ok.Add(('Git: '+$git.Source))}else{[void]$warnings.Add('GitをPATHから検出できません。GitHub操作を使う場合はGitを確認してください。')}
    try{$drive=[IO.Path]::GetPathRoot([IO.Path]::GetFullPath($UserDataRoot));$di=New-Object IO.DriveInfo($drive);$freeGB=[Math]::Round($di.AvailableFreeSpace/1GB,2);if($di.AvailableFreeSpace -lt 512MB){[void]$warnings.Add(('ユーザーデータ保存先の空き容量が少なくなっています: '+$freeGB+' GB'))}else{[void]$ok.Add(('ユーザーデータ保存先空き容量: '+$freeGB+' GB'))}}catch{[void]$warnings.Add(('空き容量を確認できません: '+$_.Exception.Message))}
    if($PreviousSessionUnclean){[void]$warnings.Add('前回のGUIセッションが正常終了した記録を確認できません。更新前に対象ブックと直近ログを確認してください。')}
    $lockRoot=Join-Path $UserDataRoot 'runtime';if(Test-Path -LiteralPath $lockRoot -PathType Container){$stale=@(Get-ChildItem -LiteralPath $lockRoot -File -ErrorAction SilentlyContinue|Where-Object{$_.Name -ne 'gui-session.json' -and $_.LastWriteTime -lt (Get-Date).AddHours(-6)});if($stale.Count -gt 0){[void]$warnings.Add(('6時間以上残っているruntimeファイルがあります: '+$stale.Count+'件'))}}
    if(-not[string]::IsNullOrWhiteSpace($ProjectDirectory)){if(Test-Path -LiteralPath $ProjectDirectory -PathType Container){[void]$ok.Add('選択Projectフォルダー: 確認済み')}else{[void]$errors.Add('選択Projectフォルダーが見つかりません。')}}
    if(-not[string]::IsNullOrWhiteSpace($TargetPath) -and $TargetPath -ne '-'){
        if(Test-Path -LiteralPath $TargetPath -PathType Leaf){
            [void]$ok.Add('対象ブック: 存在確認済み');try{$stream=[IO.File]::Open($TargetPath,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite);$stream.Dispose();[void]$ok.Add('対象ブック: 読み取り可能')}catch{[void]$warnings.Add(('対象ブックを読み取れません: '+$_.Exception.Message))}
            $exclusiveDiagnostic=Get-WorkbookExclusiveAccessDiagnostic -Path $TargetPath
            if($exclusiveDiagnostic.Available){[void]$ok.Add('対象ブック: 排他ReadWrite診断 PASS')}else{[void]$warnings.Add(('対象ブック: 排他ReadWrite診断 FAIL（診断のみ・ロック解除操作なし） HResult='+$exclusiveDiagnostic.HResult+' / '+$exclusiveDiagnostic.Message))}
        }else{[void]$errors.Add('対象ブックが見つかりません。')}
    }
    return [PSCustomObject]@{CheckedAt=(Get-Date).ToString('o');ProcessId=$PID;Overall=if($errors.Count -gt 0){'ERROR'}elseif($warnings.Count -gt 0){'WARNING'}else{'OK'};ExclusiveWriteDiagnostic=$exclusiveDiagnostic;Ok=@($ok);Warnings=@($warnings);Errors=@($errors)}
}

function Get-VBAUpdaterOperationalRetryAssessment {
    param([Parameter(Mandatory=$true)]$Snapshot)
    $errorCount=@($Snapshot.Errors).Count;$warningCount=@($Snapshot.Warnings).Count;$previousUnclean=$false
    foreach($warning in @($Snapshot.Warnings)){if(([string]$warning).IndexOf('前回のGUIセッション',[StringComparison]::Ordinal) -ge 0){$previousUnclean=$true;break}}
    if($errorCount -gt 0){$status='BLOCK';$message='再実行前にエラー項目を解消してください。更新処理は開始しないでください。'}elseif($previousUnclean){$status='REVIEW';$message='前回セッションが正常終了していない可能性があります。対象ブックと直近ログを確認してから再実行してください。'}elseif($warningCount -gt 0){$status='REVIEW';$message='注意項目があります。内容を確認してから必要な操作を実行してください。'}else{$status='READY';$message='運用安全診断上、再実行を妨げる項目は検出されていません。'}
    return [PSCustomObject]@{AssessedAt=(Get-Date).ToString('o');Status=$status;Message=$message;ErrorCount=$errorCount;WarningCount=$warningCount}
}

function Get-VBAUpdaterOperationalSupportRecord {
    param([Parameter(Mandatory=$true)]$Snapshot,[Parameter(Mandatory=$true)]$RetryAssessment,[string]$Build='',[string]$ProjectName='',[string]$TargetPath='')
    $targetExtension='';$targetExists=$false;if(-not[string]::IsNullOrWhiteSpace($TargetPath)-and$TargetPath-ne'-'){$targetExtension=[IO.Path]::GetExtension($TargetPath);$targetExists=Test-Path -LiteralPath $TargetPath -PathType Leaf}
    $exclusive=$Snapshot.ExclusiveWriteDiagnostic
    return [PSCustomObject][ordered]@{schemaVersion=2;createdAt=(Get-Date).ToString('o');build=$Build;projectName=$ProjectName;targetExtension=$targetExtension;targetExists=$targetExists;diagnosticProcessId=$Snapshot.ProcessId;exclusiveWriteAvailable=if($null-ne$exclusive){[bool]$exclusive.Available}else{$null};exclusiveWriteExceptionType=if($null-ne$exclusive){[string]$exclusive.ExceptionType}else{''};exclusiveWriteHResult=if($null-ne$exclusive){[string]$exclusive.HResult}else{''};exclusiveWriteMessage=if($null-ne$exclusive){[string]$exclusive.Message}else{''};safetyOverall=[string]$Snapshot.Overall;retryStatus=[string]$RetryAssessment.Status;errorCount=@($Snapshot.Errors).Count;warningCount=@($Snapshot.Warnings).Count;errors=@($Snapshot.Errors);warnings=@($Snapshot.Warnings);ok=@($Snapshot.Ok)}
}

function Get-VBAUpdaterOperationalGuidanceLines {
    param([Parameter(Mandatory=$true)]$Snapshot,[Parameter(Mandatory=$true)]$RetryAssessment)
    $lines=New-Object 'System.Collections.Generic.List[string]';[void]$lines.Add('VBAUpdater 運用安全・再実行ガイダンス');[void]$lines.Add(('診断結果: '+[string]$Snapshot.Overall));[void]$lines.Add(('再実行判定: '+[string]$RetryAssessment.Status));[void]$lines.Add(('案内: '+[string]$RetryAssessment.Message));[void]$lines.Add('')
    if(@($Snapshot.Errors).Count -gt 0){[void]$lines.Add('[エラー]');foreach($item in @($Snapshot.Errors)){[void]$lines.Add(('・'+[string]$item))};[void]$lines.Add('')}
    if(@($Snapshot.Warnings).Count -gt 0){[void]$lines.Add('[注意]');foreach($item in @($Snapshot.Warnings)){[void]$lines.Add(('・'+[string]$item))};[void]$lines.Add('')}
    [void]$lines.Add('推奨手順:');[void]$lines.Add('1. エラー/注意がある場合は内容を確認する。');[void]$lines.Add('2. 前回異常終了の可能性がある場合は、対象ブックがExcelで開かれていないことを確認する。');[void]$lines.Add('3. 必要に応じて「ログを見る」「診断情報を保存」「サポートZIPを作成」を利用する。');[void]$lines.Add('4. BLOCKの場合は原因解消まで更新処理を開始しない。');return $lines.ToArray()
}

Export-ModuleMember -Function Get-VBAUpdaterSessionMarkerPath,Start-VBAUpdaterOperationalSession,Stop-VBAUpdaterOperationalSession,Get-WorkbookExclusiveAccessDiagnostic,Invoke-VBAUpdaterSafeWorkbookLockRecovery,Assert-VBAUpdaterWorkbookExclusiveSafe,Get-VBAUpdaterOperationalSafetySnapshot,Get-VBAUpdaterOperationalRetryAssessment,Get-VBAUpdaterOperationalSupportRecord,Get-VBAUpdaterOperationalGuidanceLines
