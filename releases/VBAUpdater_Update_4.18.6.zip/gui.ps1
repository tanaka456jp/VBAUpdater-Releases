﻿param(
    [string]$Project,
    [switch]$ProcessSelfTest,
    [switch]$UsabilitySelfTest,
    [switch]$CompileGateWarningSelfTest,
    [switch]$RenewalSelfTest,
    [switch]$RegistrationSelfTest,
    [switch]$RegistrationHotFixSelfTest,
    [switch]$ProjectRootSelfTest,
    [switch]$ProjectRootMigrationSelfTest,
    [switch]$CodexIntegrationSelfTest,
    [switch]$DirectReferenceSelfTest,
    [switch]$TestMode,
    [string]$TestRoot,
    [string]$ExpectedMigrationStatus,
    [int]$ExpectedMigrationProjects = -1
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

if ($null -eq ('VBAUpdater.NativeWindowAttention' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
namespace VBAUpdater {
    public static class NativeWindowAttention {
        [StructLayout(LayoutKind.Sequential)]
        public struct FLASHWINFO { public UInt32 cbSize; public IntPtr hwnd; public UInt32 dwFlags; public UInt32 uCount; public UInt32 dwTimeout; }
        [DllImport("user32.dll")] public static extern bool FlashWindowEx(ref FLASHWINFO info);
    }
}
'@
}

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$versionFile = Join-Path $root 'VERSION.txt'
if (-not (Test-Path -LiteralPath $versionFile -PathType Leaf)) { throw "VERSION.txtが見つかりません: $versionFile" }
$script:ProductVersion = ([System.IO.File]::ReadAllText($versionFile)).Trim()
if ($script:ProductVersion -notmatch '^\d+\.\d+\.\d+$') { throw "VERSION.txtの形式が不正です: $script:ProductVersion" }
$cliPath = Join-Path $root 'vba.ps1'
$projectRegistrationModulePath = Join-Path $root 'tools\ProjectRegistration.psm1'
if (-not (Test-Path -LiteralPath $projectRegistrationModulePath -PathType Leaf)) {
    throw "共通Project Registrationモジュールが見つかりません: $projectRegistrationModulePath"
}
Import-Module $projectRegistrationModulePath -Force -ErrorAction Stop
$script:GuiLogRetentionCount = 100
$script:settingsInfo = $null
$script:registeredProjectFolders = @{}

function Get-GuiTestPropagationArguments {
    if (-not $TestMode) { return @() }
    if ([string]::IsNullOrWhiteSpace($TestRoot) -or -not [System.IO.Path]::IsPathRooted($TestRoot)) {
        throw 'GUI Test Modeには絶対パスの-TestRootが必要です。'
    }
    return @('-TestMode','-TestRoot',[System.IO.Path]::GetFullPath($TestRoot))
}

function Get-ProjectRootInfoFromCli {
    $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',$cliPath,'project-root','-Json')+@(Get-GuiTestPropagationArguments)
    $outputLines = @(& powershell.exe @arguments 2>&1)
    $exitCode = $LASTEXITCODE
    $output = $outputLines -join [Environment]::NewLine
    if ($exitCode -ne 0) { throw "プロジェクト保存先をCLIから取得できません。ExitCode=$exitCode / 詳細: $output" }
    try { return $output | ConvertFrom-Json }
    catch { throw "プロジェクト保存先のCLI応答を解析できません: $($_.Exception.Message) / 応答: $output" }
}

function Get-ProjectRootCheckFromCli {
    param([string]$Path)
    $arguments = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$cliPath,'project-root-check','-Json')
    if (-not [string]::IsNullOrWhiteSpace($Path)) { $arguments += @('-Path',$Path) }
    $arguments += @(Get-GuiTestPropagationArguments)
    $outputLines = @(& powershell.exe @arguments 2>&1)
    $exitCode = $LASTEXITCODE
    $output = $outputLines -join [Environment]::NewLine
    if ($exitCode -ne 0) { throw "プロジェクト保存先をCLIで確認できません。ExitCode=$exitCode / 詳細: $output" }
    try { return $output | ConvertFrom-Json }
    catch { throw "プロジェクト保存先確認のCLI応答を解析できません: $($_.Exception.Message) / 応答: $output" }
}

function Get-ProjectFolderCheckFromCli {
    param([Parameter(Mandatory=$true)][string]$Path,[string]$WorkbookPath)
    $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',$cliPath,'project-folder-check','-Path',$Path,'-Json')
    if (-not [string]::IsNullOrWhiteSpace($WorkbookPath)) { $arguments += @('-WorkbookPath',$WorkbookPath) }
    $arguments += @(Get-GuiTestPropagationArguments)
    $outputLines=@(& powershell.exe @arguments 2>&1)
    $exitCode=$LASTEXITCODE
    $output=$outputLines -join [Environment]::NewLine
    if ($exitCode -ne 0) { throw "プロジェクトフォルダーを確認できません。ExitCode=$exitCode / 詳細: $output" }
    try { return $output|ConvertFrom-Json }
    catch { throw "プロジェクトフォルダー確認のCLI応答を解析できません: $($_.Exception.Message) / 応答: $output" }
}

function Get-GuiTargetFingerprint {
    param([AllowEmptyString()][string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path) -or $Path -eq '-' -or -not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
    $item=Get-Item -LiteralPath $Path -Force
    return [PSCustomObject]@{
        Length=[long]$item.Length
        LastWriteTimeUtc=$item.LastWriteTimeUtc.ToString('o')
        Sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash
    }
}

function Assert-GuiProjectSelectionSafe {
    param([Parameter(Mandatory=$true)][string]$Command)
    if ($null -eq $script:selectedProjectInfo) { throw '選択Projectを再確認できません。' }
    $rootPath=[System.IO.Path]::GetFullPath([string]$script:selectedProjectInfo.ProjectRoot)
    $targetPath=[System.IO.Path]::GetFullPath([string]$script:selectedProjectInfo.TargetPath)
    if (-not (Test-Path -LiteralPath $rootPath -PathType Container)) { throw "選択Project Rootが見つかりません: $rootPath" }
    if (-not (Test-Path -LiteralPath (Join-Path $rootPath 'project.json') -PathType Leaf)) { throw "project.jsonが見つかりません: $rootPath" }
    if (-not (Test-Path -LiteralPath $targetPath -PathType Leaf)) { throw "対象ブックが見つかりません: $targetPath" }
    $prefix=$rootPath.TrimEnd('\','/')+[System.IO.Path]::DirectorySeparatorChar
    if (-not $targetPath.StartsWith($prefix,[System.StringComparison]::OrdinalIgnoreCase)) { throw "対象ブックがProject Root外です: $targetPath" }
    $probe=Get-ProjectFolderCheckFromCli -Path $rootPath -WorkbookPath $targetPath
    if (-not [bool]$probe.CanPush -or
        -not [string]::Equals([string]$probe.ProjectRoot,$rootPath,[System.StringComparison]::OrdinalIgnoreCase) -or
        -not [string]::Equals([string]$probe.WorkbookPath,$targetPath,[System.StringComparison]::OrdinalIgnoreCase)) {
        throw '更新開始時のProject／対象ブック再検証に失敗しました。Projectを選択し直してください。'
    }
    $current=Get-GuiTargetFingerprint -Path $targetPath
    $selected=$script:selectedProjectInfo.TargetFingerprint
    if ($null -eq $selected -or $null -eq $current -or [long]$selected.Length -ne [long]$current.Length -or
        [string]$selected.LastWriteTimeUtc -ne [string]$current.LastWriteTimeUtc -or
        [string]$selected.Sha256 -ne [string]$current.Sha256) {
        throw "選択後に対象ブックが変更されました。安全のため$Commandを開始しません。Projectを再選択してください。"
    }
    Append-Log ("[GUI] 更新直前安全確認: Project Root={0} / Target={1} / SHA-256={2}" -f $rootPath,$targetPath,$current.Sha256)
}

function Get-ProjectNames {
    $script:settingsInfo=Get-SettingsInfoFromCli
    if($script:settingsInfo.PSObject.Properties['Logging'] -and $script:settingsInfo.Logging.PSObject.Properties['retentionCount']){$script:GuiLogRetentionCount=[Math]::Max(1,[int]$script:settingsInfo.Logging.retentionCount)}
    $script:registeredProjectFolders=@{}
    $names=New-Object 'System.Collections.Generic.List[string]'
    foreach($entry in @($script:settingsInfo.Projects|Sort-Object Name,ProjectFolder)){
        if($null-eq$entry){continue}
        $name=[string]$entry.Name
        if([string]::IsNullOrWhiteSpace($name)){continue}
        $script:registeredProjectFolders[$name]=[string]$entry.ProjectFolder
        if(-not $names.Contains($name)){$names.Add($name)}
    }
    return @($names.ToArray())
}

function Quote-ProcessArgument([string]$Value) {
    if ($null -eq $Value) { return '""' }
    return '"' + ($Value -replace '(\\*)"', '$1$1\"' -replace '(\\+)$', '$1$1') + '"'
}

function New-CliRunnerContent {
    param(
        [Parameter(Mandatory=$true)][string]$CliScriptPath,
        [Parameter(Mandatory=$true)][string[]]$CliArguments,
        [Parameter(Mandatory=$true)][string]$OutputPath
    )

    $CliArguments=@($CliArguments)+@(Get-GuiTestPropagationArguments)
    $escapedCli = $CliScriptPath.Replace("'", "''")
    $argLines = @($CliArguments | ForEach-Object { "    '" + ([string]$_).Replace("'", "''") + "'" })
    $escapedOutput = $OutputPath.Replace("'", "''")
    $runnerLines = New-Object 'System.Collections.Generic.List[string]'
    $runnerLines.Add("`$ErrorActionPreference = 'Continue'")
    $runnerLines.Add("`$cli = '$escapedCli'")
    $runnerLines.Add('$cliArgs = @(')
    foreach ($line in $argLines) { $runnerLines.Add($line) }
    $runnerLines.Add(')')
    # Write-Host（Information）を含む全PowerShellストリームをログへ集約する。
    $runnerLines.Add("& `$cli @cliArgs *>&1 | Out-File -LiteralPath '$escapedOutput' -Encoding utf8")
    $runnerLines.Add('$exitCode = $LASTEXITCODE')
    $runnerLines.Add('if ($null -eq $exitCode) { $exitCode = 0 }')
    $runnerLines.Add('exit $exitCode')
    return $runnerLines -join "`r`n"
}

function Invoke-GuiProcessSelfTest {
    $tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('VBAUpdaterGuiProcessTest_' + [guid]::NewGuid().ToString('N'))
    try {
        [void](New-Item -ItemType Directory -Path $tempRoot -Force)
        $cases = @(
            [PSCustomObject]@{ Name='success'; Arguments=@('version'); ExpectedExit=0; ExpectedText=('VBA Project Update System Ver' + $script:ProductVersion) },
            [PSCustomObject]@{ Name='failure'; Arguments=@('definitely-invalid-command'); ExpectedExit=1; ExpectedText='不明なコマンドです: definitely-invalid-command' }
        )

        foreach ($case in $cases) {
            $outputPath = Join-Path $tempRoot ($case.Name + '.log')
            $runnerPath = Join-Path $tempRoot ($case.Name + '.ps1')
            $runner = New-CliRunnerContent -CliScriptPath $cliPath -CliArguments ([string[]]$case.Arguments) -OutputPath $outputPath
            [System.IO.File]::WriteAllText($runnerPath, $runner, (New-Object System.Text.UTF8Encoding($true)))
            & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $runnerPath
            $actualExit = $LASTEXITCODE
            $actualText = [System.IO.File]::ReadAllText($outputPath, [System.Text.Encoding]::UTF8)
            if ($actualExit -ne $case.ExpectedExit) {
                throw "GUIランナー終了コードが一致しません。Case=$($case.Name) Expected=$($case.ExpectedExit) Actual=$actualExit"
            }
            if ($actualText.IndexOf([string]$case.ExpectedText, [System.StringComparison]::Ordinal) -lt 0) {
                throw "GUIランナー出力が不足しています。Case=$($case.Name) Expected=$($case.ExpectedText)"
            }
            if ($case.Name -eq 'success' -and $actualText.Trim() -ne [string]$case.ExpectedText) {
                throw "GUIランナー正常系に予期しない出力があります。Actual=$($actualText.Trim())"
            }
            Write-Host ("  [OK] {0}: ExitCode={1}, LogLength={2}" -f $case.Name, $actualExit, $actualText.Length)
        }
        Write-Host 'GUI Process回帰テストに成功しました。'
    }
    finally {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-GuiCompileGateWarningSelfTest {
    $tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('VBAUpdaterGuiCompileGateTest_' + [guid]::NewGuid().ToString('N'))
    try {
        [void](New-Item -ItemType Directory -Path $tempRoot -Force)
        $outputPath = Join-Path $tempRoot 'optional-warning.log'
        $runnerPath = Join-Path $tempRoot 'optional-warning.ps1'
        $runner = New-CliRunnerContent -CliScriptPath $cliPath -CliArguments @('compile-gate-optional-test','-ProbeCase','optional-missing') -OutputPath $outputPath
        [System.IO.File]::WriteAllText($runnerPath, $runner, (New-Object System.Text.UTF8Encoding($true)))
        & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $runnerPath
        $actualExit = $LASTEXITCODE
        $actualText = [System.IO.File]::ReadAllText($outputPath, [System.Text.Encoding]::UTF8)
        if ($actualExit -ne 0) { throw "任意Compile Gate警告をGUIランナーが失敗扱いにしました。ExitCode=$actualExit" }
        foreach ($expected in @('[WARNING] 更新後コンパイルゲートを実行できませんでした。','CompileGateResult=WarningMacroUnavailable','ProbeResult=WarningMacroUnavailable')) {
            if ($actualText.IndexOf($expected, [System.StringComparison]::Ordinal) -lt 0) {
                throw "GUIランナーの警告ログが不足しています: $expected"
            }
        }
        if (-not $actualText.Trim().EndsWith('ProbeResult=WarningMacroUnavailable', [System.StringComparison]::Ordinal)) {
            throw 'GUIランナーが任意Compile Gate警告ログの末尾まで取得できませんでした。'
        }

        $guiText = [System.IO.File]::ReadAllText((Join-Path $root 'gui.ps1'), [System.Text.Encoding]::UTF8)
        if ($guiText -notmatch "Invoke-DangerousProjectCommand\s+-Command\s+'project-sync'") { throw 'GUIのSyncボタンが既存CLIへ接続されていません。' }
        if ($guiText -notmatch 'if\s*\(\$exitCode\s+-eq\s+0\)[\s\S]{0,500}\$resultStatus\s*=\s*''処理成功''') { throw 'GUIの終了コード0判定が見つかりません。' }
        if ($guiText -match 'function\s+Get-ProjectCompileGateSettings|function\s+Invoke-ProjectCompileGate') { throw 'Compile GateロジックがGUIへ複製されています。' }
        if ($guiText -match '\$form\.Close\s*\(') { throw 'CLI終了時にGUIを閉じる処理が検出されました。' }
        Write-Host 'GUI Compile Gate警告回帰テストに成功しました。'
    }
    finally {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-GuiRenewalSelfTest {
    $guiText = [System.IO.File]::ReadAllText((Join-Path $root 'gui.ps1'), [System.Text.Encoding]::UTF8)
    $requirements = [ordered]@{
        'GUIバージョン' = '\$script:ProductVersion\s*='
        '標準タブ' = '\$standardTab\.Text\s*=\s*''ブック更新'''
        '標準タブ初期表示' = '\$tabs\.SelectedIndex\s*=\s*0'
        '開発者タブ' = '\$developerTab\.Text\s*=\s*''開発者向け'''
        '一般利用者向け主ボタン' = 'Add-OperationButton\s+\$primaryPanel\s+''ブックを更新する''[\s\S]{0,500}Invoke-ProjectCommand[\s\S]{0,200}project-sync'
        'ブック更新の確認' = 'function\s+New-BookUpdateConfirmationMessage[\s\S]{0,1800}更新前の安全確認[\s\S]{0,600}更新履歴の記録'
        '対象ブックを開く' = '''対象ブックを開く''[\s\S]{0,700}Start-Process'
        '対象ブック存在時のみ有効' = 'function\s+Update-OpenTargetButtonState[\s\S]{0,700}Test-Path[\s\S]{0,500}btnOpenTarget\.Enabled'
        'フォルダーを開く' = '''フォルダーを開く''[\s\S]{0,700}explorer\.exe'
        '詳細ログ初期折りたたみ' = '\$logBox\.Visible\s*=\s*\$false'
        '詳細ログ展開・折りたたみ' = '詳細ログを表示[\s\S]{0,500}\$logBox\.Visible\s*=\s*-not\s+\$logBox\.Visible[\s\S]{0,300}詳細ログを隠す'
        '終了コード0を成功扱い' = 'if\s*\(\$exitCode\s+-eq\s+0\)[\s\S]{0,500}\$resultStatus\s*=\s*''処理成功'''
        'WARNINGを警告付き成功扱い' = 'IndexOf\(''\[WARNING\]''[\s\S]{0,400}\$resultStatus\s*=\s*''警告付き成功'''
        '終了コード非0を失敗扱い' = 'else\s*\{[\s\S]{0,400}ExitCode=[\s\S]{0,300}\$resultStatus\s*=\s*''処理失敗'''
        '実行中の操作無効化' = '\$cmbProject\.Enabled\s*=\s*-not\s+\$Value[\s\S]{0,300}foreach\s*\(\$button\s+in\s+\$operationButtons\)[\s\S]{0,200}\$button\.Enabled\s*=\s*-not\s+\$Value'
        '実行中表示' = 'Set-CurrentStatus\s+''処理実行中''[\s\S]{0,500}この画面を閉じずにお待ちください'
        'FormClosing安全確認' = 'Add_FormClosing[\s\S]{0,1000}処理が実行中です。[\s\S]{0,600}\$eventArgs\.Cancel\s*=\s*\$true[\s\S]{0,500}Clear-CliRuntime\s+\$true'
        '開発者Pull' = '''ブックからソースを取得''[\s\S]{0,300}project-pull'
        '開発者Push' = '''ソースをブックへ反映''[\s\S]{0,300}project-push'
        '開発者Sync' = '''安全なブック更新''[\s\S]{0,300}project-sync'
        '開発者Rollback' = '''最新復元ポイントへ戻す''[\s\S]{0,400}rollback'
        '開発者ログ操作' = '\$developerLogPanel[\s\S]{0,2500}ログをクリア[\s\S]{0,2500}ログをコピー[\s\S]{0,2500}ログフォルダーを開く[\s\S]{0,2500}最新ログを開く'
        '更新結果の明示' = 'function\s+Set-OperationResult[\s\S]{0,2500}ブックの更新が完了しました[\s\S]{0,1000}ブックの更新は完了しました[\s\S]{0,1000}ブックを更新できませんでした'
    }
    foreach ($item in $requirements.GetEnumerator()) {
        if (-not [System.Text.RegularExpressions.Regex]::IsMatch($guiText, [string]$item.Value, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
            throw "GUI Renewal要件が見つかりません: $($item.Key)"
        }
        Write-Host ("  [OK] {0}" -f $item.Key)
    }
    $standardButtons = [System.Text.RegularExpressions.Regex]::Matches(
        $guiText,
        'Add-OperationButton\s+\$(?:primaryPanel|logPanel)\s+''([^'']+)''',
        [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    foreach ($match in $standardButtons) {
        if ($match.Groups[1].Value -match '(?i)\b(?:Pull|Push|Sync|Integrity|Rollback|Compile\s+Gate)\b') {
            throw "標準画面に開発者向け用語のボタンが表示されています: $($match.Groups[1].Value)"
        }
    }
    Write-Host '  [OK] 標準画面に開発者向け英語ボタンはありません。'
    if ($guiText -match 'function\s+Invoke-ProjectPush\b|function\s+Invoke-ProjectPull\b|function\s+Invoke-ProjectSync\b|function\s+Get-ProjectDiff\b|function\s+Invoke-ProjectCompileGate\b|function\s+New-RestorePoint\b|Excel\.Application|\bVBProject\b|\bVBComponents\b') {
        throw 'CLI処理ロジックまたはExcel/VBAアクセスがGUIへ複製されています。'
    }
    Write-Host '  [OK] CLI更新・差分・Compile Gate・復元ロジックはGUIへ複製されていません。'
}

function Invoke-GuiRegistrationSelfTest {
    $guiText = [System.IO.File]::ReadAllText((Join-Path $root 'gui.ps1'), [System.Text.Encoding]::UTF8)
    $requirements = [ordered]@{
        'GUIバージョン' = '\$script:ProductVersion\s*='
        '開発プロジェクト登録ボタン' = 'Add-OperationButton\s+\$primaryPanel\s+''開発プロジェクトを登録'''
        '一般利用者向け配置' = '\$btnUpdateBook[\s\S]{0,1200}\$btnCreateProject'
        '登録ウィザード' = 'function\s+Show-ProjectRegistrationWizard'
        '開発フォルダー選択' = 'FolderBrowserDialog[\s\S]{0,1200}開発プロジェクトフォルダ'
        'ブック選択' = 'OpenFileDialog[\s\S]{0,1200}Excel VBAブック'
        '対応形式' = '\*\.xlsm;\*\.xlsb;\*\.xlam'
        '共通Validationサービス' = 'Get-ProjectRegistrationValidation\s+-ProjectFolder'
        '確認表示' = '開発プロジェクト[\s\S]{0,800}作成されるもの[\s\S]{0,400}project\.json[\s\S]{0,200}target\\[\s\S]{0,200}source\\'
        'CLI ProjectFolder接続' = 'Start-CliCommand\s+-Command\s+''project-create''[\s\S]{0,300}-ProjectFolder[\s\S]{0,300}-WorkbookPath'
        '作成中表示' = '初期ソースを作成しています'
        '作成後再読込' = 'Select-RegisteredProject[\s\S]{0,500}Refresh-Projects'
        '作成結果表示' = '開発プロジェクトの登録が完了しました[\s\S]{0,900}開発プロジェクトを登録できませんでした'
    }
    foreach ($item in $requirements.GetEnumerator()) {
        if (-not [System.Text.RegularExpressions.Regex]::IsMatch($guiText, [string]$item.Value, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
            throw "GUI Initial Project Registration要件が見つかりません: $($item.Key)"
        }
        Write-Host ("  [OK] {0}" -f $item.Key)
    }
    if ($guiText -match 'Excel\.Application|\bVBProject\b|\bVBComponents\b') {
        throw 'GUIへExcel/VBAアクセス処理が複製されています。'
    }
    Write-Host '  [OK] GUIはExcel/VBA処理と独自Validationを持たず、共通サービスを利用'
}

function Get-SettingsInfoFromCli {
    $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',$cliPath,'settings','-Json')+@(Get-GuiTestPropagationArguments)
    $outputLines=@(& powershell.exe @arguments 2>&1)
    $exitCode=$LASTEXITCODE
    $output=$outputLines -join [Environment]::NewLine
    if($exitCode-ne 0){throw "永続設定をCLIから取得できません。ExitCode=$exitCode / 詳細: $output"}
    try{return $output|ConvertFrom-Json}catch{throw "永続設定のCLI応答を解析できません: $($_.Exception.Message) / 応答: $output"}
}

function Get-LegacyProjectMigrationCheckFromCli {
    $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',$cliPath,'project-migration-check','-Json')+@(Get-GuiTestPropagationArguments)
    $outputLines = @(& powershell.exe @arguments 2>&1)
    $exitCode = $LASTEXITCODE
    $output = $outputLines -join [Environment]::NewLine
    if ($exitCode -ne 0) { throw "旧形式プロジェクトを確認できません。ExitCode=$exitCode / 詳細: $output" }
    try { return $output | ConvertFrom-Json }
    catch { throw "旧形式プロジェクト確認のCLI応答を解析できません: $($_.Exception.Message) / 応答: $output" }
}

function Invoke-GuiRegistrationHotFixSelfTest {
    $guiText = [System.IO.File]::ReadAllText((Join-Path $root 'gui.ps1'), [System.Text.Encoding]::UTF8)
    $requirements = [ordered]@{
        'HotFixバージョン' = '\$script:ProductVersion\s*='
        '共通Validationモジュール' = 'Import-Module\s+\$projectRegistrationModulePath'
        'GUI共通サービス呼出' = 'function\s+Get-ProjectRegistrationValidationFromGui[\s\S]{0,500}Get-ProjectRegistrationValidation'
        'フォルダー変更の即時再判定' = '\$txtProjectFolder\.Add_TextChanged\(\{[\s\S]{0,200}updateRegistrationState'
        'ブック変更の即時再判定' = '\$txtWorkbook\.Add_TextChanged\(\{[\s\S]{0,200}updateRegistrationState'
        'フォルダー選択後の再判定' = '\$btnBrowseFolder\.Add_Click[\s\S]{0,1800}updateRegistrationState'
        'ブック選択後の再判定' = '\$btnBrowseWorkbook\.Add_Click[\s\S]{0,1800}updateRegistrationState'
        '登録ボタン共通判定' = '\$btnRegister\.Enabled\s*=\s*\[bool\]\$validation\.CanRegister'
    }
    foreach ($item in $requirements.GetEnumerator()) {
        if (-not [System.Text.RegularExpressions.Regex]::IsMatch($guiText,[string]$item.Value,[System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
            throw "GUI Chapter12-1 HotFix要件が見つかりません: $($item.Key)"
        }
        Write-Host ("  [OK] {0}" -f $item.Key)
    }

    $wizardMatch = [System.Text.RegularExpressions.Regex]::Match($guiText,'function\s+Show-ProjectRegistrationWizard\b(?<Body>[\s\S]*?)(?=\r?\nfunction\s+Set-CurrentStatus\b)',[System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    if (-not $wizardMatch.Success) { throw '登録ウィザード本体を検査できません。' }
    if ($wizardMatch.Groups['Body'].Value -match 'Get-ProjectRegistrationValidationMessage|Update-ProjectRegistrationCopyDestination|summaryUpdateTimer') {
        throw 'Ver4.17.0のGUI独自Validationまたは遅延タイマー判定が残っています。'
    }

    $tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('VBAUpdaterRegistration418_' + [guid]::NewGuid().ToString('N'))
    $folderText = $null
    $workbookText = $null
    $registerButton = $null
    try {
        New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null
        $projectFolder = Join-Path $tempRoot 'OneDrive - テスト\開発\日本語案件'
        New-Item -ItemType Directory -Path (Join-Path $projectFolder '.git') -Force | Out-Null
        $workbookPath = Join-Path $tempRoot '管理対象.xlsm'
        [System.IO.File]::WriteAllText($workbookPath,'registration hotfix placeholder')
        $eventErrors = New-Object 'System.Collections.Generic.List[string]'
        $states = New-Object 'System.Collections.Generic.List[object]'
        $folderText = New-Object System.Windows.Forms.TextBox
        $workbookText = New-Object System.Windows.Forms.TextBox
        $registerButton = New-Object System.Windows.Forms.Button
        $revalidate = {
            try {
                $state = Get-ProjectRegistrationValidationFromGui -ProjectFolder $folderText.Text -WorkbookPath $workbookText.Text
                $states.Add($state)
                $registerButton.Enabled = [bool]$state.CanRegister
            }
            catch { $eventErrors.Add($_.Exception.Message) }
        }.GetNewClosure()
        $folderText.Add_TextChanged({ & $revalidate }.GetNewClosure())
        $workbookText.Add_TextChanged({ & $revalidate }.GetNewClosure())

        $folderText.Text = $projectFolder
        if ($registerButton.Enabled) { throw 'ブック未選択時に登録ボタンが有効になりました。' }
        $workbookText.Text = $workbookPath
        if (-not $registerButton.Enabled) { throw 'フォルダーとブック選択後に登録ボタンが有効になりません。' }
        $validState = $states[$states.Count - 1]
        if ($validState.ProjectName -ne '日本語案件' -or -not $validState.IsGitRepository -or -not $validState.IsOneDrive) {
            throw '日本語・OneDrive・Git管理下の共通Validation結果が一致しません。'
        }
        $workbookText.Text = ''
        if ($registerButton.Enabled) { throw 'ブック選択解除後も登録ボタンが有効なままです。' }
        $workbookText.Text = $workbookPath
        if (-not $registerButton.Enabled) { throw 'ブック再選択後に登録ボタンが再有効化されません。' }
        if ($eventErrors.Count -ne 0) { throw ('入力イベント再判定で例外が発生しました: ' + ($eventErrors -join ' / ')) }
        Write-Host '  [OK] フォルダー・ブックの全TextChangedで無効→有効→無効→再有効をリアルタイム判定'
    }
    finally {
        if ($null -ne $folderText) { $folderText.Dispose() }
        if ($null -ne $workbookText) { $workbookText.Dispose() }
        if ($null -ne $registerButton) { $registerButton.Dispose() }
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-GuiProjectRootSelfTest {
    $guiText = [System.IO.File]::ReadAllText((Join-Path $root 'gui.ps1'), [System.Text.Encoding]::UTF8)
    $requirements = [ordered]@{
        'GUIバージョン' = '\$script:ProductVersion\s*='
        'CLIルート取得' = 'function\s+Get-ProjectRootInfoFromCli[\s\S]{0,1200}project-root[\s\S]{0,500}-Json'
        '保存先表示' = '\$lblProjectRootCaption\.Text\s*=\s*''Project Root（開発フォルダー）'''
        '変更ボタン' = '\$btnChangeProjectRoot[\s\S]{0,300}''変更する'''
        '既定復帰ボタン' = '\$btnResetProjectRoot[\s\S]{0,300}''既定に戻す'''
        'フォルダー選択' = 'FolderBrowserDialog'
        '設定CLI接続' = 'Start-CliCommand\s+-Command\s+''project-root-set''[\s\S]{0,300}-Path'
        '解除CLI接続' = 'Start-CliCommand\s+-Command\s+''project-root-reset'''
        '一覧再読込' = 'Refresh-ProjectRootAndProjects[\s\S]{0,900}Refresh-Projects'
        '登録先連携' = 'Start-CliCommand\s+-Command\s+''project-create''[\s\S]{0,300}-ProjectFolder'
        'フォルダー操作連携' = 'selectedProjectInfo\.ProjectDirectory[\s\S]{0,500}explorer\.exe'
        '破損警告表示' = 'projectRootInfo\.Warning[\s\S]{0,700}Append-Log'
    }
    foreach ($item in $requirements.GetEnumerator()) {
        if (-not [System.Text.RegularExpressions.Regex]::IsMatch($guiText,[string]$item.Value,[System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
            throw "GUI External Project Root要件が見つかりません: $($item.Key)"
        }
        Write-Host ("  [OK] {0}" -f $item.Key)
    }
    if ($guiText -match 'LOCALAPPDATA[\s\S]{0,300}settings\.json|GetFolderPath\([^\)]*LocalApplicationData') {
        throw 'GUIへ設定ファイル解決ロジックが複製されています。'
    }
    $info = Get-ProjectRootInfoFromCli
    if ([string]::IsNullOrWhiteSpace([string]$info.Path) -or [string]::IsNullOrWhiteSpace([string]$info.Source)) {
        throw 'CLIからプロジェクト保存先情報を取得できませんでした。'
    }
    Write-Host ("  [OK] CLIプロジェクト保存先取得: {0} ({1})" -f $info.Path,$info.Source)
}

function Invoke-GuiProjectRootMigrationSelfTest {
    $guiText = [System.IO.File]::ReadAllText((Join-Path $root 'gui.ps1'),[System.Text.Encoding]::UTF8)
    $requirements = [ordered]@{
        'GUIバージョン' = '\$script:ProductVersion\s*='
        'CLI保存先確認' = 'function\s+Get-ProjectRootCheckFromCli[\s\S]{0,1200}project-root-check[\s\S]{0,500}-Json'
        '喪失時ダイアログ' = 'function\s+Show-MissingProjectRootRecoveryDialog[\s\S]{0,3500}プロジェクト保存先が見つかりません。'
        '保存先変更ボタン' = '保存先を変更'
        '既定復帰ボタン' = '既定へ戻す'
        '終了ボタン' = '''終了'''
        '候補選択' = 'function\s+Select-ProjectRootMigrationCandidate[\s\S]{0,1800}Get-ProjectRootCheckFromCli'
        '候補件数表示' = '件のプロジェクトが見つかりました。'
        '0件許可' = 'Project Rootとして使用できます。'
        '状態表示' = '\$lblProjectRootStatusCaption\.Text\s*=\s*''状態''[\s\S]*✓ 利用可能[\s\S]*× 保存先が見つかりません'
        '同期設定更新' = 'Invoke-ProjectRootSettingCliSynchronously[\s\S]{0,600}project-root-set'
        '同期既定復帰' = 'Invoke-ProjectRootSettingCliSynchronously[\s\S]{0,600}project-root-reset'
        '一覧即時再読込' = 'Invoke-ProjectRootStartupRecovery[\s\S]{0,2200}Refresh-ProjectRootAndProjects'
        '起動前復旧' = 'skipStartupRecovery[\s\S]{0,700}Invoke-ProjectRootStartupRecovery[\s\S]*\[void\]\$form\.ShowDialog'
        '旧形式自動検出' = 'function\s+Get-LegacyProjectMigrationCheckFromCli[\s\S]{0,900}project-migration-check'
        '自動移行ウィザード' = 'function\s+Invoke-LegacyProjectMigrationWizard[\s\S]{0,3500}project-migrate'
        '元データ保持案内' = '移行元は削除しません'
    }
    foreach ($item in $requirements.GetEnumerator()) {
        if (-not [System.Text.RegularExpressions.Regex]::IsMatch($guiText,[string]$item.Value,[System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
            throw "GUI Project Root Migration要件が見つかりません: $($item.Key)"
        }
        Write-Host ("  [OK] {0}" -f $item.Key)
    }
    if ($guiText -match 'LOCALAPPDATA[\s\S]{0,300}settings\.json|GetFolderPath\([^\)]*LocalApplicationData') {
        throw 'GUIへ設定ファイル解決ロジックが複製されています。'
    }
    $check = Get-ProjectRootCheckFromCli
    if (-not [string]::IsNullOrWhiteSpace($ExpectedMigrationStatus) -and [string]$check.Status -ne $ExpectedMigrationStatus) {
        throw "GUIのCLI保存先状態が期待値と一致しません。Expected=$ExpectedMigrationStatus Actual=$($check.Status)"
    }
    if ($ExpectedMigrationProjects -ge 0 -and [int]$check.Projects -ne $ExpectedMigrationProjects) {
        throw "GUIの候補件数が期待値と一致しません。Expected=$ExpectedMigrationProjects Actual=$($check.Projects)"
    }
    Write-Host ("  [OK] CLI保存先状態: {0} / Projects={1}" -f $check.Status,$check.Projects)
}

function Invoke-GuiCodexIntegrationSelfTest {
    $guiText = [System.IO.File]::ReadAllText((Join-Path $root 'gui.ps1'),[System.Text.Encoding]::UTF8)
    $requirements = [ordered]@{
        'GUIバージョン' = '\$script:ProductVersion\s*='
        '開発者向けCodexグループ' = "New-ActionGroup\s+'Codex連携'"
        'Codex用ZIP作成' = "'Codex用ZIPを作成'"
        'Codex納品ZIP確認' = "'Codex納品ZIPを確認'"
        'Codex納品ZIP取込' = "'Codex納品ZIPを取り込む'"
        'CLI JSON共通呼出' = 'function\s+Invoke-CodexCliJson[\s\S]{0,1800}-Json'
        'export CLI接続' = "Invoke-CodexCliJson[\s\S]{0,1500}'codex-export'"
        'preview CLI接続' = "Invoke-CodexCliJson[\s\S]{0,1800}'codex-import-preview'"
        'import CLI接続' = "Invoke-CodexCliJson[\s\S]{0,2200}'codex-import'"
        'プレビュー成功後のみ取込' = 'lastCodexPreview[\s\S]{0,700}btnCodexImport\.Enabled'
        '空Path防止' = 'IsNullOrWhiteSpace\(\$ZipPath\)[\s\S]{0,400}return'
        '削除は既定非反映' = '削除候補は既定では反映しません'
        '同期案内' = 'ブックを更新するには「ブックを更新する」'
    }
    foreach ($item in $requirements.GetEnumerator()) {
        if (-not [System.Text.RegularExpressions.Regex]::IsMatch($guiText,[string]$item.Value,[System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
            throw "GUI Codex Integration要件が見つかりません: $($item.Key)"
        }
        Write-Host ('  [OK] ' + $item.Key)
    }
    foreach ($forbidden in @('function\s+Get-CodexExportResult','function\s+New-CodexImportContext','function\s+Expand-CodexZipSafely','System\.IO\.Compression\.Zip')) {
        if ([System.Text.RegularExpressions.Regex]::IsMatch($guiText,$forbidden,[System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
            throw "Codex ZIP/差分ロジックがGUIへ重複実装されています: $forbidden"
        }
    }
    Write-Host '  [OK] GUIはCodex連携CLIのJSON結果だけを利用しています。'
}

if ($CompileGateWarningSelfTest) {
    try {
        Invoke-GuiCompileGateWarningSelfTest
        exit 0
    }
    catch {
        Write-Error $_.Exception.Message
        exit 1
    }
}

if ($ProcessSelfTest) {
    try {
        Invoke-GuiProcessSelfTest
        exit 0
    }
    catch {
        Write-Error $_.Exception.Message
        exit 1
    }
}

$form = New-Object System.Windows.Forms.Form
$form.Text = ('VBAプロジェクト更新システム Ver' + $script:ProductVersion)
$form.StartPosition = 'CenterScreen'
$form.Size = New-Object System.Drawing.Size(1060, 930)
$form.MinimumSize = New-Object System.Drawing.Size(940, 820)
$form.Font = New-Object System.Drawing.Font('Yu Gothic UI', 9)
$script:taskbarAttentionPending = $false

function Stop-GuiTaskbarAttention {
    if($null-eq$form-or$form.IsDisposed){$script:taskbarAttentionPending=$false;return}
    if(-not$form.IsHandleCreated){$script:taskbarAttentionPending=$false;return}
    $info=New-Object 'VBAUpdater.NativeWindowAttention+FLASHWINFO'
    $info.cbSize=[uint32][System.Runtime.InteropServices.Marshal]::SizeOf($info)
    $info.hwnd=$form.Handle;$info.dwFlags=0;$info.uCount=0;$info.dwTimeout=0
    try{[void][VBAUpdater.NativeWindowAttention]::FlashWindowEx([ref]$info)}catch{Write-Verbose ('タスクバー点滅停止に失敗しました: '+$_.Exception.Message)}
    $script:taskbarAttentionPending=$false
}

function Request-GuiTaskbarAttention([string]$Reason) {
    if($null-eq$form-or$form.IsDisposed-or-not$form.IsHandleCreated){return $false}
    if($form.ContainsFocus-or[System.Windows.Forms.Form]::ActiveForm-eq$form){Stop-GuiTaskbarAttention;return $false}
    if($script:taskbarAttentionPending){return $true}
    $info=New-Object 'VBAUpdater.NativeWindowAttention+FLASHWINFO'
    $info.cbSize=[uint32][System.Runtime.InteropServices.Marshal]::SizeOf($info)
    $info.hwnd=$form.Handle;$info.dwFlags=15;$info.uCount=3;$info.dwTimeout=0
    $requested=$false
    try{$requested=[bool][VBAUpdater.NativeWindowAttention]::FlashWindowEx([ref]$info)}catch{Write-Verbose ('タスクバー通知に失敗しました: '+$_.Exception.Message)}
    if($requested){$script:taskbarAttentionPending=$true;Append-Log ('[GUI] タスクバー通知: '+$Reason)}
    return $requested
}

$form.Add_Activated({Stop-GuiTaskbarAttention})
$form.Add_FormClosed({Stop-GuiTaskbarAttention})

$toolTip = New-Object System.Windows.Forms.ToolTip

$rootLayout = New-Object System.Windows.Forms.TableLayoutPanel
$rootLayout.Dock = 'Fill'
$rootLayout.ColumnCount = 1
$rootLayout.RowCount = 2
$rootLayout.Padding = New-Object System.Windows.Forms.Padding(10)
[void]$rootLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 66)))
[void]$rootLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent', 100)))
$form.Controls.Add($rootLayout)

$headerPanel = New-Object System.Windows.Forms.Panel
$headerPanel.Dock = 'Fill'
$rootLayout.Controls.Add($headerPanel, 0, 0)

$lblTitle = New-Object System.Windows.Forms.Label
$lblTitle.Text = ('VBAプロジェクト更新システム Ver' + $script:ProductVersion)
$lblTitle.Font = New-Object System.Drawing.Font('Yu Gothic UI', 16, [System.Drawing.FontStyle]::Bold)
$lblTitle.AutoSize = $true
$lblTitle.Location = New-Object System.Drawing.Point(6, 3)
$headerPanel.Controls.Add($lblTitle)

$lblSubtitle = New-Object System.Windows.Forms.Label
$lblSubtitle.Text = 'Excelブックを安全に最新版へ更新します'
$lblSubtitle.AutoSize = $true
$lblSubtitle.ForeColor = [System.Drawing.Color]::DimGray
$lblSubtitle.Location = New-Object System.Drawing.Point(9, 38)
$headerPanel.Controls.Add($lblSubtitle)

$lblVersion = New-Object System.Windows.Forms.Label
$lblVersion.Text = ('Ver' + $script:ProductVersion)
$lblVersion.AutoSize = $true
$lblVersion.Anchor = 'Top,Right'
$lblVersion.Location = New-Object System.Drawing.Point(930, 12)
$headerPanel.Controls.Add($lblVersion)
$headerPanel.Add_Resize({ $lblVersion.Left = [Math]::Max(10, $headerPanel.ClientSize.Width - $lblVersion.Width - 10) })

$tabs = New-Object System.Windows.Forms.TabControl
$tabs.Dock = 'Fill'
$rootLayout.Controls.Add($tabs, 0, 1)

$standardTab = New-Object System.Windows.Forms.TabPage
$standardTab.Text = 'ブック更新'
$tabs.TabPages.Add($standardTab)

$developerTab = New-Object System.Windows.Forms.TabPage
$developerTab.Text = '開発者向け'
$tabs.TabPages.Add($developerTab)
$tabs.SelectedIndex = 0

$mainLayout = New-Object System.Windows.Forms.TableLayoutPanel
$mainLayout.Dock = 'Fill'
$mainLayout.ColumnCount = 1
$mainLayout.RowCount = 6
$mainLayout.Padding = New-Object System.Windows.Forms.Padding(10)
[void]$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 155)))
[void]$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 230)))
[void]$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 112)))
[void]$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 128)))
[void]$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 42)))
[void]$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent', 100)))
$standardTab.Controls.Add($mainLayout)

$projectPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$projectPanel.Dock = 'Fill'
$projectPanel.FlowDirection = 'LeftToRight'
$projectPanel.WrapContents = $true
$projectPanel.Padding = New-Object System.Windows.Forms.Padding(6, 7, 6, 4)
$mainLayout.Controls.Add($projectPanel, 0, 0)

$lblProject = New-Object System.Windows.Forms.Label
$lblProject.Text = '更新するプロジェクト'
$lblProject.AutoSize = $true
$lblProject.Margin = New-Object System.Windows.Forms.Padding(4, 8, 8, 0)
$projectPanel.Controls.Add($lblProject)

$cmbProject = New-Object System.Windows.Forms.ComboBox
$cmbProject.DropDownStyle = 'DropDownList'
$cmbProject.Size = New-Object System.Drawing.Size(350, 28)
$cmbProject.Margin = New-Object System.Windows.Forms.Padding(0, 3, 10, 0)
$projectPanel.Controls.Add($cmbProject)

$btnRefresh = New-Object System.Windows.Forms.Button
$btnRefresh.Text = '再読込'
$btnRefresh.Size = New-Object System.Drawing.Size(90, 32)
$btnRefresh.Margin = New-Object System.Windows.Forms.Padding(0, 1, 12, 0)
$projectPanel.Controls.Add($btnRefresh)

$lblProjectCount = New-Object System.Windows.Forms.Label
$lblProjectCount.Text = '0件'
$lblProjectCount.AutoSize = $true
$lblProjectCount.Margin = New-Object System.Windows.Forms.Padding(0, 8, 0, 0)
$projectPanel.Controls.Add($lblProjectCount)
$projectPanel.SetFlowBreak($lblProjectCount,$true)

$lblProjectRootCaption = New-Object System.Windows.Forms.Label
$lblProjectRootCaption.Text = 'Project Root（開発フォルダー）'
$lblProjectRootCaption.AutoSize = $true
$lblProjectRootCaption.Margin = New-Object System.Windows.Forms.Padding(4,9,8,0)
$projectPanel.Controls.Add($lblProjectRootCaption)

$lblProjectRootValue = New-Object System.Windows.Forms.Label
$lblProjectRootValue.Text = '-'
$lblProjectRootValue.AutoEllipsis = $true
$lblProjectRootValue.Size = New-Object System.Drawing.Size(315,28)
$lblProjectRootValue.Margin = New-Object System.Windows.Forms.Padding(0,7,8,0)
$projectPanel.Controls.Add($lblProjectRootValue)
$projectPanel.SetFlowBreak($lblProjectRootValue,$true)

$lblSettingsFolderCaption = New-Object System.Windows.Forms.Label
$lblSettingsFolderCaption.Text = '登録情報の保存場所'
$lblSettingsFolderCaption.AutoSize = $true
$lblSettingsFolderCaption.Margin = New-Object System.Windows.Forms.Padding(4,9,8,0)
$projectPanel.Controls.Add($lblSettingsFolderCaption)

$lblSettingsFolderValue = New-Object System.Windows.Forms.Label
$lblSettingsFolderValue.Text = '-'
$lblSettingsFolderValue.AutoEllipsis = $true
$lblSettingsFolderValue.Size = New-Object System.Drawing.Size(570,28)
$lblSettingsFolderValue.Margin = New-Object System.Windows.Forms.Padding(0,7,8,0)
$projectPanel.Controls.Add($lblSettingsFolderValue)
$projectPanel.SetFlowBreak($lblSettingsFolderValue,$true)

$infoGroup = New-Object System.Windows.Forms.GroupBox
$infoGroup.Text = '選択中のプロジェクトフォルダー'
$infoGroup.Dock = 'Fill'
$infoGroup.Padding = New-Object System.Windows.Forms.Padding(10, 6, 10, 8)
$mainLayout.Controls.Add($infoGroup, 0, 1)

$infoLayout = New-Object System.Windows.Forms.TableLayoutPanel
$infoLayout.Dock = 'Fill'
$infoLayout.ColumnCount = 2
$infoLayout.RowCount = 8
[void]$infoLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Absolute', 120)))
[void]$infoLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent', 100)))
for ($row = 0; $row -lt 8; $row++) { [void]$infoLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent', 12.5))) }
$infoGroup.Controls.Add($infoLayout)

function Add-InfoLabel([string]$Text, [int]$Column, [int]$Row) {
    $label = New-Object System.Windows.Forms.Label
    $label.Text = $Text
    $label.AutoSize = $true
    $label.Margin = New-Object System.Windows.Forms.Padding(3, 6, 3, 0)
    $infoLayout.Controls.Add($label, $Column, $Row)
}

function New-InfoValueLabel([int]$Column, [int]$Row) {
    $label = New-Object System.Windows.Forms.Label
    $label.Text = '-'
    $label.Dock = 'Fill'
    $label.AutoEllipsis = $true
    $label.Margin = New-Object System.Windows.Forms.Padding(3, 6, 8, 0)
    $infoLayout.Controls.Add($label, $Column, $Row)
    return $label
}

Add-InfoLabel 'プロジェクトルート' 0 0
$lblDirectProjectRootValue = New-InfoValueLabel 1 0
Add-InfoLabel 'sourceフォルダー' 0 1
$lblSourceFolderValue = New-InfoValueLabel 1 1
Add-InfoLabel 'targetフォルダー' 0 2
$lblTargetFolderValue = New-InfoValueLabel 1 2
Add-InfoLabel '対象ブック' 0 3
$lblTargetPathValue = New-InfoValueLabel 1 3
Add-InfoLabel 'manifest' 0 4
$lblManifestValue = New-InfoValueLabel 1 4
Add-InfoLabel 'Git管理' 0 5
$lblGitValue = New-InfoValueLabel 1 5
Add-InfoLabel '利用状態' 0 6
$lblDirectStatusValue = New-InfoValueLabel 1 6
Add-InfoLabel 'Workbook定義' 0 7
$lblWorkbookDefinitionValue = New-InfoValueLabel 1 7
$lblTargetNameValue = New-Object System.Windows.Forms.Label
$lblTargetWriteValue = New-Object System.Windows.Forms.Label

$statusGroup = New-Object System.Windows.Forms.GroupBox
$statusGroup.Text = '更新状態'
$statusGroup.Dock = 'Fill'
$mainLayout.Controls.Add($statusGroup, 0, 2)
$statusLayout = New-Object System.Windows.Forms.TableLayoutPanel
$statusLayout.Dock = 'Fill'
$statusLayout.ColumnCount = 2
$statusLayout.RowCount = 2
[void]$statusLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Absolute', 285)))
[void]$statusLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent', 100)))
$statusGroup.Controls.Add($statusLayout)
$lblStateValue = New-Object System.Windows.Forms.Label
$lblStateValue.Text = '未確認'
$lblStateValue.Font = New-Object System.Drawing.Font('Yu Gothic UI', 12, [System.Drawing.FontStyle]::Bold)
$lblStateValue.Dock = 'Fill'
$lblStateValue.TextAlign = 'MiddleLeft'
$statusLayout.Controls.Add($lblStateValue, 0, 0)
$lblInfoMessageValue = New-Object System.Windows.Forms.Label
$lblInfoMessageValue.Text = '-'
$lblInfoMessageValue.Dock = 'Fill'
$lblInfoMessageValue.TextAlign = 'MiddleLeft'
$statusLayout.Controls.Add($lblInfoMessageValue, 1, 0)
$lblCommandCaption = New-Object System.Windows.Forms.Label
$lblCommandCaption.Text = '実行状況'
$lblCommandCaption.Dock = 'Fill'
$lblCommandCaption.TextAlign = 'MiddleLeft'
$statusLayout.Controls.Add($lblCommandCaption, 0, 1)
$statusDetailPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$statusDetailPanel.Dock = 'Fill'
$statusDetailPanel.WrapContents = $false
$statusLayout.Controls.Add($statusDetailPanel, 1, 1)
$lblCommandValue = New-Object System.Windows.Forms.Label
$lblCommandValue.Text = '-'
$lblCommandValue.AutoSize = $true
$lblCommandValue.Margin = New-Object System.Windows.Forms.Padding(0, 4, 18, 0)
$statusDetailPanel.Controls.Add($lblCommandValue)
$lblElapsedValue = New-Object System.Windows.Forms.Label
$lblElapsedValue.Text = '-'
$lblElapsedValue.AutoSize = $true
$lblElapsedValue.Margin = New-Object System.Windows.Forms.Padding(0, 4, 0, 0)
$statusDetailPanel.Controls.Add($lblElapsedValue)

$primaryGroup = New-Object System.Windows.Forms.GroupBox
$primaryGroup.Text = '安全なブック更新'
$primaryGroup.Dock = 'Fill'
$mainLayout.Controls.Add($primaryGroup, 0, 3)
$primaryLayout = New-Object System.Windows.Forms.TableLayoutPanel
$primaryLayout.Dock = 'Fill'
$primaryLayout.ColumnCount = 1
$primaryLayout.RowCount = 2
[void]$primaryLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 72)))
[void]$primaryLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent', 100)))
$primaryGroup.Controls.Add($primaryLayout)
$primaryPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$primaryPanel.Dock = 'Fill'
$primaryPanel.FlowDirection = 'LeftToRight'
$primaryPanel.WrapContents = $true
$primaryPanel.Padding = New-Object System.Windows.Forms.Padding(12, 8, 6, 2)
$primaryLayout.Controls.Add($primaryPanel, 0, 0)
$lblUpdateExplanation = New-Object System.Windows.Forms.Label
$lblUpdateExplanation.Text = '更新前の確認、復元ポイント作成、差分更新、更新後の確認を自動で行います。'
$lblUpdateExplanation.Dock = 'Fill'
$lblUpdateExplanation.TextAlign = 'MiddleLeft'
$lblUpdateExplanation.Padding = New-Object System.Windows.Forms.Padding(15, 0, 0, 0)
$primaryLayout.Controls.Add($lblUpdateExplanation, 0, 1)

$logPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$logPanel.Dock = 'Fill'
$logPanel.FlowDirection = 'LeftToRight'
$logPanel.WrapContents = $false
$logPanel.Padding = New-Object System.Windows.Forms.Padding(4, 3, 4, 2)
$mainLayout.Controls.Add($logPanel, 0, 4)

$logBox = New-Object System.Windows.Forms.RichTextBox
$logBox.Dock = 'Fill'
$logBox.ReadOnly = $true
$logBox.WordWrap = $false
$logBox.Font = New-Object System.Drawing.Font('Consolas', 9)
$logBox.BackColor = [System.Drawing.Color]::White
$logBox.Visible = $false
$mainLayout.Controls.Add($logBox, 0, 5)

$developerLayout = New-Object System.Windows.Forms.TableLayoutPanel
$developerLayout.Dock = 'Fill'
$developerLayout.ColumnCount = 1
$developerLayout.RowCount = 3
$developerLayout.Padding = New-Object System.Windows.Forms.Padding(10)
[void]$developerLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 116)))
[void]$developerLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 210)))
[void]$developerLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent', 100)))
$developerTab.Controls.Add($developerLayout)

$developerInfoGroup = New-Object System.Windows.Forms.GroupBox
$developerInfoGroup.Text = 'ファイルシステム診断情報'
$developerInfoGroup.Dock = 'Fill'
$developerLayout.Controls.Add($developerInfoGroup, 0, 0)
$developerInfoLayout = New-Object System.Windows.Forms.TableLayoutPanel
$developerInfoLayout.Dock = 'Fill'
$developerInfoLayout.ColumnCount = 4
$developerInfoLayout.RowCount = 3
[void]$developerInfoLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Absolute', 120)))
[void]$developerInfoLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent', 50)))
[void]$developerInfoLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Absolute', 145)))
[void]$developerInfoLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent', 50)))
$developerInfoGroup.Controls.Add($developerInfoLayout)

function Add-DeveloperInfoLabel([string]$Text, [int]$Column, [int]$Row) {
    $label = New-Object System.Windows.Forms.Label
    $label.Text = $Text
    $label.AutoSize = $true
    $label.Margin = New-Object System.Windows.Forms.Padding(3, 6, 3, 0)
    $developerInfoLayout.Controls.Add($label, $Column, $Row)
}

function New-DeveloperInfoValueLabel([int]$Column, [int]$Row) {
    $label = New-Object System.Windows.Forms.Label
    $label.Text = '-'
    $label.Dock = 'Fill'
    $label.AutoEllipsis = $true
    $label.Margin = New-Object System.Windows.Forms.Padding(3, 6, 8, 0)
    $developerInfoLayout.Controls.Add($label, $Column, $Row)
    return $label
}

Add-DeveloperInfoLabel 'プロジェクト名' 0 0
$lblProjectNameValue = New-DeveloperInfoValueLabel 1 0
Add-DeveloperInfoLabel 'Source最終更新' 2 0
$lblSourceWriteValue = New-DeveloperInfoValueLabel 3 0
Add-DeveloperInfoLabel '復元ポイント' 0 1
$lblRestoreValue = New-DeveloperInfoValueLabel 1 1
Add-DeveloperInfoLabel '直近のIntegrity' 2 1
$lblIntegrityValue = New-DeveloperInfoValueLabel 3 1
Add-DeveloperInfoLabel '診断' 0 2
$lblDeveloperDiagnosticValue = New-DeveloperInfoValueLabel 1 2
$developerInfoLayout.SetColumnSpan($lblDeveloperDiagnosticValue, 3)

$actionsLayout = New-Object System.Windows.Forms.TableLayoutPanel
$actionsLayout.Dock = 'Fill'
$actionsLayout.ColumnCount = 4
$actionsLayout.RowCount = 1
[void]$actionsLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent', 28)))
[void]$actionsLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent', 20)))
[void]$actionsLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent', 24)))
[void]$actionsLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent', 28)))
$developerLayout.Controls.Add($actionsLayout, 0, 1)

function New-ActionGroup([string]$Title, [int]$Column) {
    $group = New-Object System.Windows.Forms.GroupBox
    $group.Text = $Title
    $group.Dock = 'Fill'
    $group.Margin = New-Object System.Windows.Forms.Padding(4)
    $panel = New-Object System.Windows.Forms.FlowLayoutPanel
    $panel.Dock = 'Fill'
    $panel.WrapContents = $true
    $panel.AutoScroll = $true
    $panel.Padding = New-Object System.Windows.Forms.Padding(6, 6, 6, 4)
    $group.Controls.Add($panel)
    $actionsLayout.Controls.Add($group, $Column, 0)
    return $panel
}

$referencePanel = New-ActionGroup '確認・参照' 0
$sourcePanel = New-ActionGroup 'ソース操作' 1
$bookPanel = New-ActionGroup 'ブック操作' 2
$codexPanel = New-ActionGroup 'Codex連携' 3

$developerLogGroup = New-Object System.Windows.Forms.GroupBox
$developerLogGroup.Text = '開発者ログ'
$developerLogGroup.Dock = 'Fill'
$developerLayout.Controls.Add($developerLogGroup, 0, 2)
$developerLogLayout = New-Object System.Windows.Forms.TableLayoutPanel
$developerLogLayout.Dock = 'Fill'
$developerLogLayout.ColumnCount = 1
$developerLogLayout.RowCount = 2
[void]$developerLogLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 44)))
[void]$developerLogLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent', 100)))
$developerLogGroup.Controls.Add($developerLogLayout)
$developerLogPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$developerLogPanel.Dock = 'Fill'
$developerLogPanel.WrapContents = $false
$developerLogPanel.Padding = New-Object System.Windows.Forms.Padding(4, 2, 4, 2)
$developerLogLayout.Controls.Add($developerLogPanel, 0, 0)
$developerLogBox = New-Object System.Windows.Forms.RichTextBox
$developerLogBox.Dock = 'Fill'
$developerLogBox.ReadOnly = $true
$developerLogBox.WordWrap = $false
$developerLogBox.Font = New-Object System.Drawing.Font('Consolas', 9)
$developerLogBox.BackColor = [System.Drawing.Color]::White
$developerLogLayout.Controls.Add($developerLogBox, 0, 1)

$script:busy = $false
$script:process = $null
$script:guiOutputPath = $null
$script:guiRunnerPath = $null
$script:lastOutputLength = 0
$script:commandStartedAt = $null
$script:currentCommand = $null
$script:selectedProjectInfo = $null
$script:refreshingProjects = $false
$script:currentStatus = '未確認'
$script:btnOpenTarget = $null
$script:pendingCreatedProject = $null
$script:pendingCreatedWorkbook = $null
$script:projectRootInfo = $null
$script:projectRootPreviousSelection = $null
$script:lastCodexPreview = $null
$script:lastCodexZipPath = $null
$script:btnCodexExport = $null
$script:btnCodexPreview = $null
$script:btnCodexImport = $null
$script:pollTimer = New-Object System.Windows.Forms.Timer
$script:pollTimer.Interval = 250
$operationButtons = New-Object 'System.Collections.Generic.List[System.Windows.Forms.Button]'
$workbookRequiredButtons = New-Object 'System.Collections.Generic.List[System.Windows.Forms.Button]'

function Append-LogText([string]$Text) {
    if ([string]::IsNullOrEmpty($Text)) { return }
    if ($logBox.InvokeRequired) {
        [void]$logBox.BeginInvoke([Action[string]]{ param($value) Append-LogText $value }, $Text)
        return
    }
    $logBox.AppendText($Text)
    $logBox.SelectionStart = $logBox.TextLength
    $logBox.ScrollToCaret()
    if ($null -ne $developerLogBox -and -not $developerLogBox.IsDisposed) {
        $developerLogBox.AppendText($Text)
        $developerLogBox.SelectionStart = $developerLogBox.TextLength
        $developerLogBox.ScrollToCaret()
    }
}

function Append-Log([string]$Text) {
    if ($null -eq $Text) { return }
    Append-LogText ($Text + [Environment]::NewLine)
}

function Show-GuiMessage([string]$Message, [string]$Title = 'お知らせ', [System.Windows.Forms.MessageBoxIcon]$Icon = [System.Windows.Forms.MessageBoxIcon]::Information) {
    [void][System.Windows.Forms.MessageBox]::Show($Message, $Title, [System.Windows.Forms.MessageBoxButtons]::OK, $Icon)
}

function Get-ProjectRegistrationValidationFromGui {
    param(
        [AllowNull()][AllowEmptyString()][string]$ProjectFolder,
        [AllowNull()][AllowEmptyString()][string]$WorkbookPath
    )
    return Get-ProjectRegistrationValidation -ProjectFolder $ProjectFolder -WorkbookPath $WorkbookPath -ToolRoot $root
}

function Show-ProjectRegistrationWizard {
    if ($script:busy) { return }

    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = '開発プロジェクトを登録'
    $dialog.StartPosition = 'CenterParent'
    $dialog.Size = New-Object System.Drawing.Size(760, 590)
    $dialog.MinimumSize = New-Object System.Drawing.Size(700, 540)
    $dialog.Font = $form.Font
    $dialog.FormBorderStyle = 'Sizable'
    $dialog.MaximizeBox = $false
    $dialog.MinimizeBox = $false

    $layout = New-Object System.Windows.Forms.TableLayoutPanel
    $layout.Dock = 'Fill'
    $layout.Padding = New-Object System.Windows.Forms.Padding(16)
    $layout.ColumnCount = 1
    $layout.RowCount = 8
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 48)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 34)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 72)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 34)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 68)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent', 100)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 34)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 50)))
    $dialog.Controls.Add($layout)

    $heading = New-Object System.Windows.Forms.Label
    $heading.Text = 'GitHub・Codexと共有する開発フォルダーを登録します'
    $heading.Font = New-Object System.Drawing.Font('Yu Gothic UI', 13, [System.Drawing.FontStyle]::Bold)
    $heading.Dock = 'Fill'
    $heading.TextAlign = 'MiddleLeft'
    $layout.Controls.Add($heading,0,0)

    $step1 = New-Object System.Windows.Forms.Label
    $step1.Text = 'ステップ1：既存の開発プロジェクトフォルダを選択'
    $step1.Dock = 'Fill'
    $step1.TextAlign = 'BottomLeft'
    $layout.Controls.Add($step1,0,1)

    $folderPanel = New-Object System.Windows.Forms.TableLayoutPanel
    $folderPanel.Dock = 'Fill'
    $folderPanel.ColumnCount = 2
    [void]$folderPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent',100)))
    [void]$folderPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Absolute',150)))
    $layout.Controls.Add($folderPanel,0,2)
    $txtProjectFolder = New-Object System.Windows.Forms.TextBox
    $txtProjectFolder.Dock = 'Fill'
    $txtProjectFolder.ReadOnly = $true
    $txtProjectFolder.Margin = New-Object System.Windows.Forms.Padding(0,8,8,8)
    $folderPanel.Controls.Add($txtProjectFolder,0,0)
    $btnBrowseFolder = New-Object System.Windows.Forms.Button
    $btnBrowseFolder.Text = 'フォルダを選択'
    $btnBrowseFolder.Dock = 'Fill'
    $btnBrowseFolder.Margin = New-Object System.Windows.Forms.Padding(0,6,0,6)
    $folderPanel.Controls.Add($btnBrowseFolder,1,0)

    $step2 = New-Object System.Windows.Forms.Label
    $step2.Text = 'ステップ2：管理対象Excelブックを選択'
    $step2.Dock = 'Fill'
    $step2.TextAlign = 'BottomLeft'
    $layout.Controls.Add($step2,0,3)
    $bookPanel = New-Object System.Windows.Forms.TableLayoutPanel
    $bookPanel.Dock = 'Fill'
    $bookPanel.ColumnCount = 2
    [void]$bookPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent',100)))
    [void]$bookPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Absolute',150)))
    $layout.Controls.Add($bookPanel,0,4)
    $txtWorkbook = New-Object System.Windows.Forms.TextBox
    $txtWorkbook.Dock = 'Fill'
    $txtWorkbook.ReadOnly = $true
    $txtWorkbook.Margin = New-Object System.Windows.Forms.Padding(0,8,8,8)
    $bookPanel.Controls.Add($txtWorkbook,0,0)
    $btnBrowseWorkbook = New-Object System.Windows.Forms.Button
    $btnBrowseWorkbook.Text = 'ブックを選択'
    $btnBrowseWorkbook.Dock = 'Fill'
    $btnBrowseWorkbook.Margin = New-Object System.Windows.Forms.Padding(0,6,0,6)
    $bookPanel.Controls.Add($btnBrowseWorkbook,1,0)

    $confirmationGroup = New-Object System.Windows.Forms.GroupBox
    $confirmationGroup.Text = 'ステップ3：設定内容を確認'
    $confirmationGroup.Dock = 'Fill'
    $layout.Controls.Add($confirmationGroup,0,5)
    $txtConfirmation = New-Object System.Windows.Forms.TextBox
    $txtConfirmation.Dock = 'Fill'
    $txtConfirmation.Multiline = $true
    $txtConfirmation.ReadOnly = $true
    $txtConfirmation.BackColor = [System.Drawing.Color]::White
    $txtConfirmation.ScrollBars = 'Vertical'
    $confirmationGroup.Controls.Add($txtConfirmation)

    $lblValidation = New-Object System.Windows.Forms.Label
    $lblValidation.Dock = 'Fill'
    $lblValidation.ForeColor = [System.Drawing.Color]::DarkRed
    $lblValidation.TextAlign = 'MiddleLeft'
    $layout.Controls.Add($lblValidation,0,6)

    $buttons = New-Object System.Windows.Forms.FlowLayoutPanel
    $buttons.Dock = 'Fill'
    $buttons.FlowDirection = 'RightToLeft'
    $buttons.WrapContents = $false
    $layout.Controls.Add($buttons,0,7)
    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = 'キャンセル'
    $btnCancel.Size = New-Object System.Drawing.Size(120,36)
    $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $buttons.Controls.Add($btnCancel)
    $btnRegister = New-Object System.Windows.Forms.Button
    $btnRegister.Text = '登録する'
    $btnRegister.Size = New-Object System.Drawing.Size(130,36)
    $btnRegister.Enabled = $false
    $buttons.Controls.Add($btnRegister)
    $dialog.CancelButton = $btnCancel

    $showSummaryError = {
        param([string]$Detail)
        $lblValidation.Text = '登録内容を確認できません。'
        $btnRegister.Enabled = $false
        $txtConfirmation.Text = @(
            '開発プロジェクトを登録します。',
            '',
            '開発プロジェクト：-',
            '管理対象ブック：-',
            '',
            '作成されるもの',
            'project.json',
            'target\',
            'source\'
        ) -join [Environment]::NewLine
        try { Append-Log ('[GUI] 登録Validationの更新に失敗しました: ' + $Detail) } catch { Write-Verbose ('登録Validation失敗ログの表示に失敗しました: ' + $_.Exception.Message) }
    }.GetNewClosure()
    $updateRegistrationState = {
        try {
            $projectFolder = $txtProjectFolder.Text.Trim()
            $workbookPath = $txtWorkbook.Text.Trim()
            $validation = Get-ProjectRegistrationValidationFromGui -ProjectFolder $projectFolder -WorkbookPath $workbookPath
            $lblValidation.Text = [string]$validation.Message
            $btnRegister.Enabled = [bool]$validation.CanRegister
            $displayFolder = if ([string]::IsNullOrWhiteSpace([string]$validation.ProjectFolder)) { '-' } else { [string]$validation.ProjectFolder }
            $displayBook = if ([string]::IsNullOrWhiteSpace([string]$validation.WorkbookFileName)) { '-' } else { [string]$validation.WorkbookFileName }
            $txtConfirmation.Text = @(
                '開発プロジェクト',
                $displayFolder,
                '',
                '管理対象ブック',
                $displayBook,
                '',
                '作成されるもの',
                'project.json',
                'target\',
                'source\',
                '',
                '元のExcelブックは移動せず、コピーします。'
            ) -join [Environment]::NewLine
            return $validation
        }
        catch { & $showSummaryError $_.Exception.Message }
    }.GetNewClosure()

    $btnBrowseFolder.Add_Click({
        $picker = $null
        try {
            $picker = New-Object System.Windows.Forms.FolderBrowserDialog
            $picker.Description = '既存の開発プロジェクトフォルダを選択してください。フォルダーは自動作成されません。'
            $picker.ShowNewFolderButton = $false
            $initialFolder = if (-not [string]::IsNullOrWhiteSpace($txtProjectFolder.Text) -and (Test-Path -LiteralPath $txtProjectFolder.Text -PathType Container)) {
                $txtProjectFolder.Text
            }
            elseif ($null -ne $script:projectRootInfo -and (Test-Path -LiteralPath ([string]$script:projectRootInfo.Path) -PathType Container)) {
                [string]$script:projectRootInfo.Path
            }
            else { '' }
            if (-not [string]::IsNullOrWhiteSpace($initialFolder)) { $picker.SelectedPath = $initialFolder }
            if ($picker.ShowDialog($dialog) -eq [System.Windows.Forms.DialogResult]::OK) {
                $txtProjectFolder.Text = $picker.SelectedPath
                [void](& $updateRegistrationState)
            }
        }
        catch { & $showSummaryError $_.Exception.Message }
        finally { if ($null -ne $picker) { $picker.Dispose() } }
    }.GetNewClosure())

    $btnBrowseWorkbook.Add_Click({
        $picker = $null
        try {
            $picker = New-Object System.Windows.Forms.OpenFileDialog
            $picker.Title = '管理するExcel VBAブックを選択'
            $picker.Filter = 'Excel VBAブック (*.xlsm;*.xlsb;*.xlam)|*.xlsm;*.xlsb;*.xlam|すべてのファイル (*.*)|*.*'
            $picker.CheckFileExists = $true
            $picker.Multiselect = $false
            if (-not [string]::IsNullOrWhiteSpace($txtWorkbook.Text) -and (Test-Path -LiteralPath $txtWorkbook.Text -PathType Leaf)) {
                $picker.InitialDirectory = Split-Path -Parent $txtWorkbook.Text
            }
            else {
                $picker.InitialDirectory = [Environment]::GetFolderPath('Desktop')
            }
            if ($picker.ShowDialog($dialog) -eq [System.Windows.Forms.DialogResult]::OK) {
                $txtWorkbook.Text = $picker.FileName
                [void](& $updateRegistrationState)
            }
        }
        catch { & $showSummaryError $_.Exception.Message }
        finally { if ($null -ne $picker) { $picker.Dispose() } }
    }.GetNewClosure())
    $txtProjectFolder.Add_TextChanged({ [void](& $updateRegistrationState) }.GetNewClosure())
    $txtWorkbook.Add_TextChanged({ [void](& $updateRegistrationState) }.GetNewClosure())
    $btnRegister.Add_Click({
        try {
            $projectFolder = $txtProjectFolder.Text.Trim()
            $workbookPath = $txtWorkbook.Text.Trim()
            $validation = Get-ProjectRegistrationValidationFromGui -ProjectFolder $projectFolder -WorkbookPath $workbookPath
            if (-not [bool]$validation.CanRegister) {
                $lblValidation.Text = [string]$validation.Message
                $btnRegister.Enabled = $false
                return
            }
            $script:pendingCreatedProject = [string]$validation.ProjectName
            $script:pendingCreatedWorkbook = [string]$validation.WorkbookFileName
            Append-Log ("[GUI] 開発プロジェクトを登録します: {0}" -f [string]$validation.ProjectFolder)
            Start-CliCommand -Command 'project-create' -Arguments @('-ProjectFolder',[string]$validation.ProjectFolder,'-WorkbookPath',[string]$validation.WorkbookPath)
            $dialog.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $dialog.Close()
        }
        catch { & $showSummaryError $_.Exception.Message }
    }.GetNewClosure())

    [void](& $updateRegistrationState)
    [void]$dialog.ShowDialog($form)
    $dialog.Dispose()
}

function Set-CurrentStatus([string]$Status) {
    $script:currentStatus = $Status
    switch ($Status) {
        '正常' { $lblStateValue.Text = '● 更新できます'; $lblStateValue.ForeColor = [System.Drawing.Color]::DarkGreen }
        '処理成功' { $lblStateValue.Text = '✓ 処理が完了しました'; $lblStateValue.ForeColor = [System.Drawing.Color]::DarkGreen }
        '警告あり' { $lblStateValue.Text = '▲ 確認が必要です'; $lblStateValue.ForeColor = [System.Drawing.Color]::DarkOrange }
        '警告付き成功' { $lblStateValue.Text = '▲ 処理は完了しました'; $lblStateValue.ForeColor = [System.Drawing.Color]::DarkOrange }
        'エラーあり' { $lblStateValue.Text = '× 更新できません'; $lblStateValue.ForeColor = [System.Drawing.Color]::DarkRed }
        '処理失敗' { $lblStateValue.Text = '× 処理を完了できませんでした'; $lblStateValue.ForeColor = [System.Drawing.Color]::DarkRed }
        '処理実行中' {
            $lblStateValue.Text = $(if ($script:currentCommand -eq 'project-sync') {
                'ブックを更新しています'
            }
            elseif ($script:currentCommand -eq 'project-create') {
                '開発プロジェクトを登録しています'
            }
            elseif ($script:currentCommand -in @('project-root-set','project-root-reset')) {
                'プロジェクト保存先を変更しています'
            }
            else { '処理を実行しています' })
            $lblStateValue.ForeColor = [System.Drawing.Color]::DarkBlue
        }
        default { $lblStateValue.Text = $Status; $lblStateValue.ForeColor = [System.Drawing.Color]::Black }
    }
}

function Get-GuiCommandDisplayName([string]$Command) {
    switch ($Command) {
        'project-create' { return '開発プロジェクトを登録' }
        'project-root-set' { return 'Project Rootを変更' }
        'project-root-reset' { return 'Project Rootを既定に戻す' }
        'project-sync' { return '安全なブック更新' }
        'project-pull' { return 'ブックからソースを取得' }
        'project-push' { return 'ソースをブックへ反映' }
        'codex-export' { return 'Codex用ZIPを作成' }
        'codex-import-preview' { return 'Codex納品ZIPを確認' }
        'codex-import' { return 'Codex納品ZIPを取り込む' }
        'rollback' { return '最新復元ポイントへ戻す' }
        'rollback-list' { return '復元ポイント一覧' }
        'integrity' { return '整合性検証' }
        'project-diff' { return '差分確認' }
        'history' { return '履歴表示' }
        'status' { return '状態確認' }
        default { return $Command }
    }
}

function Format-GuiElapsed([TimeSpan]$Elapsed) {
    $hours = [Math]::Floor($Elapsed.TotalHours)
    return ('{0:00}:{1:00}:{2:00}' -f $hours, $Elapsed.Minutes, $Elapsed.Seconds)
}

function Update-OpenTargetButtonState {
    if ($null -eq $script:btnOpenTarget) { return }
    $targetExists = $false
    if ($null -ne $script:selectedProjectInfo -and
        -not [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.TargetPath) -and
        [string]$script:selectedProjectInfo.TargetPath -ne '-') {
        $targetExists = Test-Path -LiteralPath ([string]$script:selectedProjectInfo.TargetPath) -PathType Leaf
    }
    $script:btnOpenTarget.Enabled = (-not $script:busy) -and $targetExists
}

function Update-WorkbookRequiredButtonState {
    $canUseWorkbook=(-not $script:busy) -and $null -ne $script:selectedProjectInfo -and [bool]$script:selectedProjectInfo.CanPush
    foreach($button in $workbookRequiredButtons) { $button.Enabled=$canUseWorkbook }
}

function Reset-ProjectInformation {
    $lblProjectNameValue.Text = '-'
    $lblTargetNameValue.Text = '-'
    $lblTargetPathValue.Text = '-'
    $lblTargetWriteValue.Text = '-'
    $lblDirectProjectRootValue.Text = '-'
    $lblSourceFolderValue.Text = '-'
    $lblTargetFolderValue.Text = '-'
    $lblManifestValue.Text = '-'
    $lblWorkbookDefinitionValue.Text = '-'
    $lblGitValue.Text = '-'
    $lblDirectStatusValue.Text = '-'
    $lblSourceWriteValue.Text = '-'
    $lblRestoreValue.Text = '-'
    $lblIntegrityValue.Text = '-'
    $lblDeveloperDiagnosticValue.Text = '-'
    $lblCommandValue.Text = '-'
    $lblElapsedValue.Text = '-'
    $lblInfoMessageValue.Text = '-'
    $script:selectedProjectInfo = $null
    Set-CurrentStatus '未確認'
    Update-OpenTargetButtonState
    Update-WorkbookRequiredButtonState
    Update-CodexButtonState
}

function Format-GuiDate($Value) {
    if ($null -eq $Value) { return 'なし' }
    return ([DateTime]$Value).ToString('yyyy-MM-dd HH:mm:ss')
}

function Resolve-GuiProjectPath([string]$ProjectDirectory, [string]$PathValue) {
    if ([string]::IsNullOrWhiteSpace($PathValue)) { throw 'project.jsonのパス指定が空です。' }
    if ([System.IO.Path]::IsPathRooted($PathValue)) {
        return [System.IO.Path]::GetFullPath($PathValue)
    }
    return [System.IO.Path]::GetFullPath((Join-Path $ProjectDirectory $PathValue))
}

function Get-LatestPathWriteTime([string]$Path) {
    $item = Get-Item -LiteralPath $Path -Force
    $latest = $item.LastWriteTime
    if ($item.PSIsContainer) {
        foreach ($child in @(Get-ChildItem -LiteralPath $Path -Recurse -Force -ErrorAction Stop)) {
            if ($child.LastWriteTime -gt $latest) { $latest = $child.LastWriteTime }
        }
    }
    return $latest
}

function Get-LatestRestorePointTime([string]$ProjectName) {
    $directory = Join-Path $root (Join-Path 'backups\restore_points' $ProjectName)
    if (-not (Test-Path -LiteralPath $directory -PathType Container)) { return $null }
    $latest = $null
    foreach ($file in @(Get-ChildItem -LiteralPath $directory -Filter '*.json' -File -ErrorAction SilentlyContinue)) {
        try {
            $payload = Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
            $created = $file.LastWriteTime
            if ($payload.PSObject.Properties['createdAt'] -and -not [string]::IsNullOrWhiteSpace([string]$payload.createdAt)) {
                $created = ([DateTimeOffset]::Parse([string]$payload.createdAt)).LocalDateTime
            }
            if ($null -eq $latest -or $created -gt $latest) { $latest = $created }
        }
        catch {
            # 壊れたメタデータは自動情報更新を中断せず読み飛ばす。
        }
    }
    return $latest
}

function Get-LatestIntegrityResult([string]$ProjectName) {
    $logDirectory = Join-Path $root 'logs'
    if (-not (Test-Path -LiteralPath $logDirectory -PathType Container)) { return $null }
    $files = @(Get-ChildItem -LiteralPath $logDirectory -Filter 'project_integrity_*.json' -File -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending)
    foreach ($file in $files) {
        try {
            $payload = Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
            if (-not $payload.PSObject.Properties['project'] -or
                -not [string]::Equals([string]$payload.project, $ProjectName, [System.StringComparison]::OrdinalIgnoreCase)) {
                continue
            }
            $executedAt = $file.LastWriteTime
            if ($payload.PSObject.Properties['timestamp'] -and -not [string]::IsNullOrWhiteSpace([string]$payload.timestamp)) {
                $executedAt = ([DateTimeOffset]::Parse([string]$payload.timestamp)).LocalDateTime
            }
            $errors = 0
            $warnings = 0
            if ($payload.PSObject.Properties['summary'] -and $null -ne $payload.summary) {
                if ($payload.summary.PSObject.Properties['errors']) { $errors = [int]$payload.summary.errors }
                if ($payload.summary.PSObject.Properties['warnings']) { $warnings = [int]$payload.summary.warnings }
            }
            return [PSCustomObject]@{ ExecutedAt=$executedAt; Errors=$errors; Warnings=$warnings; Path=$file.FullName }
        }
        catch {
            # 読めないログがあっても、さらに古い正常なログを探索する。
        }
    }
    return $null
}

function Update-DirectProjectInformationCore([switch]$PreserveStatus) {
    if ($cmbProject.SelectedItem -eq $null) {
        Reset-ProjectInformation
        $lblInfoMessageValue.Text='プロジェクトを選択するか、「プロジェクトフォルダを開く」を使用してください。'
        return
    }
    $previousStatus=$script:currentStatus
    if (-not $PreserveStatus) { Set-CurrentStatus '確認中' }
    $selected=[string]$cmbProject.SelectedItem
    if ($null -eq $script:projectRootInfo) { throw 'プロジェクト保存先を取得できません。' }
    $projectDirectory=if($null-ne$script:registeredProjectFolders-and$script:registeredProjectFolders.ContainsKey($selected)){[string]$script:registeredProjectFolders[$selected]}else{Join-Path ([string]$script:projectRootInfo.Path) $selected}
    $workbookPath=''
    $restoredFromPrevious=$false
    if ($script:projectRootInfo.PSObject.Properties['LastProjectRoot'] -and
        -not [string]::IsNullOrWhiteSpace([string]$script:projectRootInfo.LastProjectRoot) -and
        (Test-Path -LiteralPath ([string]$script:projectRootInfo.LastProjectRoot) -PathType Container)) {
        $lastRoot=[string]$script:projectRootInfo.LastProjectRoot
        try {
            $lastProbe=Get-ProjectFolderCheckFromCli -Path $lastRoot
            if ([string]::Equals([string]$lastProbe.ProjectName,$selected,[System.StringComparison]::OrdinalIgnoreCase) -or
                [string]::Equals([System.IO.Path]::GetFileName($lastRoot),$selected,[System.StringComparison]::OrdinalIgnoreCase)) {
                $projectDirectory=$lastRoot
                $restoredFromPrevious=$true
                if ($script:projectRootInfo.PSObject.Properties['LastWorkbookPath'] -and [bool]$script:projectRootInfo.LastWorkbookExists) {
                    $workbookPath=[string]$script:projectRootInfo.LastWorkbookPath
                }
            }
        }
        catch { Append-Log ('[GUI] 最後に開いたプロジェクトの確認に失敗しました: '+$_.Exception.Message) }
    }

    $context=Get-ProjectFolderCheckFromCli -Path $projectDirectory -WorkbookPath $workbookPath
    $script:selectedProjectInfo=[PSCustomObject]@{
        Selection=$selected;ProjectName=[string]$context.ProjectName;ProjectDirectory=[string]$context.ProjectRoot
        ProjectRoot=[string]$context.ProjectRoot;SourcePath=[string]$context.SourcePath;TargetDirectory=[string]$context.TargetDirectory
        TargetName=$(if([string]::IsNullOrWhiteSpace([string]$context.WorkbookPath)){'-'}else{[System.IO.Path]::GetFileName([string]$context.WorkbookPath)})
        TargetPath=$(if([string]::IsNullOrWhiteSpace([string]$context.WorkbookPath)){'-'}else{[string]$context.WorkbookPath})
        ManifestPath=[string]$context.ManifestPath;IsGitRepository=[bool]$context.IsGitRepository
        IsAvailable=[bool]$context.IsAvailable;CanPush=[bool]$context.CanPush;WorkbookCandidates=@($context.WorkbookCandidates)
        RestoredFromPrevious=$restoredFromPrevious
        TargetFingerprint=$(Get-GuiTargetFingerprint -Path ([string]$context.WorkbookPath))
    }
    $lblProjectNameValue.Text=[string]$context.ProjectName
    $lblDirectProjectRootValue.Text=[string]$context.ProjectRoot
    $lblSourceFolderValue.Text=[string]$context.SourcePath
    $lblTargetFolderValue.Text=[string]$context.TargetDirectory
    $lblTargetNameValue.Text=[string]$script:selectedProjectInfo.TargetName
    $lblTargetPathValue.Text=[string]$script:selectedProjectInfo.TargetPath
    $lblManifestValue.Text=[string]$context.ManifestPath
    $lblWorkbookDefinitionValue.Text='なし（従来VBAのみ）'
    try {
        if (Test-Path -LiteralPath ([string]$context.ManifestPath) -PathType Leaf) {
            $projectManifest=Get-Content -LiteralPath ([string]$context.ManifestPath) -Raw -Encoding UTF8|ConvertFrom-Json
            if ($projectManifest.PSObject.Properties['workbook'] -and $null -ne $projectManifest.workbook) {
                $enabled=$true
                if ($projectManifest.workbook.PSObject.Properties['enabled']) { $enabled=[bool]$projectManifest.workbook.enabled }
                if (-not $enabled) { $lblWorkbookDefinitionValue.Text='無効' }
                elseif ($projectManifest.workbook.PSObject.Properties['definition'] -and -not [string]::IsNullOrWhiteSpace([string]$projectManifest.workbook.definition)) {
                    $definitionPath=Join-Path ([string]$context.ProjectRoot) ([string]$projectManifest.workbook.definition)
                    $lblWorkbookDefinitionValue.Text=$(if(Test-Path -LiteralPath $definitionPath -PathType Leaf){'✓ あり'}else{'× 定義ファイルなし'})
                    $toolTip.SetToolTip($lblWorkbookDefinitionValue,$definitionPath)
                }
                else { $lblWorkbookDefinitionValue.Text='× definition未指定' }
            }
        }
    }
    catch { $lblWorkbookDefinitionValue.Text='× 定義確認エラー' }
    $lblGitValue.Text=$(if([bool]$context.IsGitRepository){'✓ Git管理あり（Git操作は行いません）'}else{'－ Git管理なし'})
    $lblDirectStatusValue.Text=$(if([bool]$context.CanPush){$(if($restoredFromPrevious){'▲ 前回選択を復元（更新時に再検証）'}else{'✓ 利用可能'})}elseif([bool]$context.IsAvailable){'▲ プロジェクト選択済み／対象ブック未選択'}else{'× 利用不可'})
    foreach($label in @($lblDirectProjectRootValue,$lblSourceFolderValue,$lblTargetFolderValue,$lblTargetPathValue,$lblManifestValue)) { $toolTip.SetToolTip($label,$label.Text) }
    $lblTargetWriteValue.Text='-'
    if ([string]$script:selectedProjectInfo.TargetPath -ne '-' -and (Test-Path -LiteralPath ([string]$script:selectedProjectInfo.TargetPath) -PathType Leaf)) {
        $lblTargetWriteValue.Text=Format-GuiDate (Get-Item -LiteralPath ([string]$script:selectedProjectInfo.TargetPath)).LastWriteTime
    }
    $lblSourceWriteValue.Text='-'
    if (Test-Path -LiteralPath ([string]$context.SourcePath) -PathType Container) { $lblSourceWriteValue.Text=Format-GuiDate (Get-LatestPathWriteTime -Path ([string]$context.SourcePath)) }
    $restoreTime=Get-LatestRestorePointTime -ProjectName ([string]$context.ProjectName)
    $lblRestoreValue.Text=$(if($null -eq $restoreTime){'なし'}else{Format-GuiDate $restoreTime})
    $integrity=Get-LatestIntegrityResult -ProjectName ([string]$context.ProjectName)
    $lblIntegrityValue.Text=$(if($null -eq $integrity){'未実行'}else{("{0} (E={1}/W={2})" -f (Format-GuiDate $integrity.ExecutedAt),$integrity.Errors,$integrity.Warnings)})
    $details=@(@($context.Errors)+@($context.Warnings)+@($context.Messages)|Where-Object{-not [string]::IsNullOrWhiteSpace([string]$_)}|Select-Object -Unique)
    $lblDeveloperDiagnosticValue.Text=$(if($details.Count -eq 0){'CLI共通判定でファイルシステム情報を確認しました。'}else{$details -join ' / '})
    $toolTip.SetToolTip($lblDeveloperDiagnosticValue,$lblDeveloperDiagnosticValue.Text)
    if (@($context.Errors).Count -gt 0) {
        $lblInfoMessageValue.Text='プロジェクトフォルダーの構成を確認してください。'
        if (-not $PreserveStatus) { Set-CurrentStatus 'エラーあり' }
    }
    elseif (-not [bool]$context.CanPush) {
        $lblInfoMessageValue.Text=$(if([string]$context.WorkbookSelectionStatus -eq 'Multiple'){'対象ブックが複数あります。「プロジェクトフォルダを開く」から選択してください。'}else{'対象ブックは未登録です。プロジェクト選択は保存されています。'})
        if (-not $PreserveStatus) { Set-CurrentStatus '警告あり' }
    }
    else {
        $lblInfoMessageValue.Text='更新前の安全確認を行った後、対象ブックを最新版へ更新します。'
        if (-not $PreserveStatus) { Set-CurrentStatus '正常' }
    }
    if ($PreserveStatus) { Set-CurrentStatus $previousStatus }
    Update-OpenTargetButtonState
    Update-WorkbookRequiredButtonState
}

function Update-ProjectInformation([switch]$PreserveStatus) {
    Update-DirectProjectInformationCore -PreserveStatus:$PreserveStatus
    return
    if ($cmbProject.SelectedItem -eq $null) {
        Reset-ProjectInformation
        $lblInfoMessageValue.Text = 'プロジェクトを選択してください。'
        return
    }

    $previousStatus = $script:currentStatus
    if (-not $PreserveStatus) { Set-CurrentStatus '確認中' }
    $selected = [string]$cmbProject.SelectedItem
    if ($null -eq $script:projectRootInfo) { throw 'プロジェクト保存先を取得できません。' }
    $projectDirectory = Join-Path ([string]$script:projectRootInfo.Path) $selected
    $manifestPath = Join-Path $projectDirectory 'project.json'
    $errors = New-Object 'System.Collections.Generic.List[string]'
    $warnings = New-Object 'System.Collections.Generic.List[string]'
    $userWarnings = New-Object 'System.Collections.Generic.List[string]'

    $lblProjectNameValue.Text = $selected
    $lblTargetNameValue.Text = '-'
    $lblTargetPathValue.Text = '-'
    $lblTargetWriteValue.Text = '-'
    $lblSourceWriteValue.Text = '-'
    $lblRestoreValue.Text = 'なし'
    $lblIntegrityValue.Text = '未実行'
    $lblInfoMessageValue.Text = '-'

    try {
        if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
            throw "project.jsonが見つかりません: $manifestPath"
        }
        $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $manifestProjectName = $selected
        if ($manifest.PSObject.Properties['projectName'] -and -not [string]::IsNullOrWhiteSpace([string]$manifest.projectName)) {
            $manifestProjectName = [string]$manifest.projectName
        }
        else {
            [void]$warnings.Add('project.jsonにprojectNameがありません。フォルダー名を表示します。')
        }
        $lblProjectNameValue.Text = $manifestProjectName

        $targetPath = $null
        if (-not $manifest.PSObject.Properties['target'] -or $null -eq $manifest.target) {
            [void]$errors.Add('project.jsonにtarget設定がありません。')
        }
        else {
            $targetDirectoryValue = if ($manifest.target.PSObject.Properties['directory']) { [string]$manifest.target.directory } else { '' }
            $targetFileValue = if ($manifest.target.PSObject.Properties['file']) { [string]$manifest.target.file } else { '' }
            if ([string]::IsNullOrWhiteSpace($targetFileValue)) {
                [void]$errors.Add('project.jsonのtarget.fileが空です。')
            }
            else {
                $targetDirectory = if ([string]::IsNullOrWhiteSpace($targetDirectoryValue)) {
                    $projectDirectory
                }
                else {
                    Resolve-GuiProjectPath -ProjectDirectory $projectDirectory -PathValue $targetDirectoryValue
                }
                $targetPath = Join-Path $targetDirectory $targetFileValue
                $lblTargetNameValue.Text = [System.IO.Path]::GetFileName($targetPath)
                $lblTargetPathValue.Text = $targetPath
            $toolTip.SetToolTip($lblTargetPathValue, $targetPath)

                if (-not (Test-Path -LiteralPath $targetPath -PathType Leaf)) {
                    $autoDetect = $false
                    if ($manifest.target.PSObject.Properties['autoDetectWhenMissing']) { $autoDetect = [bool]$manifest.target.autoDetectWhenMissing }
                    if ($autoDetect -and (Test-Path -LiteralPath $targetDirectory -PathType Container)) {
                        $candidates = @(Get-ChildItem -LiteralPath $targetDirectory -File -ErrorAction SilentlyContinue |
                            Where-Object { $_.Extension.ToLowerInvariant() -in @('.xlsm','.xlsb','.xlam') })
                        if ($candidates.Count -eq 1) {
                            $targetPath = $candidates[0].FullName
                            $lblTargetNameValue.Text = $candidates[0].Name
                            $lblTargetPathValue.Text = $targetPath
            $toolTip.SetToolTip($lblTargetPathValue, $targetPath)
                            [void]$warnings.Add("target.fileの対象がないため候補を表示しています: $targetPath")
                            [void]$userWarnings.Add('設定上のファイル名とは異なる候補を表示しています。開発者に確認してください。')
                        }
                    }
                }

                if (Test-Path -LiteralPath $targetPath -PathType Leaf) {
                    $lblTargetWriteValue.Text = Format-GuiDate (Get-Item -LiteralPath $targetPath).LastWriteTime
                }
                else {
                    [void]$errors.Add("対象ブックが見つかりません: $targetPath")
                }
            }
        }

        if (-not $manifest.PSObject.Properties['source'] -or $null -eq $manifest.source -or
            -not $manifest.source.PSObject.Properties['root']) {
            [void]$errors.Add('project.jsonにsource.root設定がありません。')
        }
        else {
            $sourcePath = Resolve-GuiProjectPath -ProjectDirectory $projectDirectory -PathValue ([string]$manifest.source.root)
            if (Test-Path -LiteralPath $sourcePath -PathType Container) {
                $lblSourceWriteValue.Text = Format-GuiDate (Get-LatestPathWriteTime -Path $sourcePath)
            }
            else {
                [void]$errors.Add("sourceフォルダーが見つかりません: $sourcePath")
            }
        }

        $restoreTime = Get-LatestRestorePointTime -ProjectName $manifestProjectName
        if ($null -ne $restoreTime) {
            $lblRestoreValue.Text = Format-GuiDate $restoreTime
        }
        else {
            [void]$warnings.Add('復元ポイントはまだありません。')
            [void]$userWarnings.Add('復元ポイントはまだありません。更新時に新しい復元ポイントを作成します。')
        }

        $integrity = Get-LatestIntegrityResult -ProjectName $manifestProjectName
        if ($null -ne $integrity) {
            $integrityState = if ($integrity.Errors -gt 0) { 'エラーあり' } elseif ($integrity.Warnings -gt 0) { '警告あり' } else { '正常' }
            $lblIntegrityValue.Text = ('{0} ({1}, E={2}/W={3})' -f $integrityState, (Format-GuiDate $integrity.ExecutedAt), $integrity.Errors, $integrity.Warnings)
            if ($integrity.Errors -gt 0) { [void]$errors.Add('直近のIntegrity実行結果にエラーがあります。') }
            elseif ($integrity.Warnings -gt 0) { [void]$warnings.Add('直近のIntegrity実行結果に警告があります。') }
        }
        else {
            [void]$warnings.Add('Integrityはまだ実行されていません。')
        }

        $script:selectedProjectInfo = [PSCustomObject]@{
            Selection=$selected
            ProjectName=$manifestProjectName
            ProjectDirectory=$projectDirectory
            TargetName=$lblTargetNameValue.Text
            TargetPath=$lblTargetPathValue.Text
        }
    }
    catch {
        [void]$errors.Add($_.Exception.Message)
        $script:selectedProjectInfo = [PSCustomObject]@{
            Selection=$selected
            ProjectName=$selected
            ProjectDirectory=$projectDirectory
            TargetName=$lblTargetNameValue.Text
            TargetPath=$lblTargetPathValue.Text
        }
    }

    if ($errors.Count -gt 0) {
        $lblDeveloperDiagnosticValue.Text = ($errors -join ' / ')
        $toolTip.SetToolTip($lblDeveloperDiagnosticValue, ($errors -join ' / '))
        $lblInfoMessageValue.Text = '対象ブックまたは更新元データを確認できません。開発者向け画面で設定を確認してください。'
        $toolTip.SetToolTip($lblInfoMessageValue, '')
        if (-not $PreserveStatus) { Set-CurrentStatus 'エラーあり' }
    }
    elseif ($userWarnings.Count -gt 0) {
        $lblDeveloperDiagnosticValue.Text = ($warnings -join ' / ')
        $toolTip.SetToolTip($lblDeveloperDiagnosticValue, ($warnings -join ' / '))
        $lblInfoMessageValue.Text = ($userWarnings -join ' / ')
        $toolTip.SetToolTip($lblInfoMessageValue, '')
        if (-not $PreserveStatus) { Set-CurrentStatus '警告あり' }
    }
    else {
        $lblDeveloperDiagnosticValue.Text = $(if ($warnings.Count -gt 0) { $warnings -join ' / ' } else { 'ファイルシステム情報を確認しました。' })
        $toolTip.SetToolTip($lblDeveloperDiagnosticValue, $lblDeveloperDiagnosticValue.Text)
        $lblInfoMessageValue.Text = '更新前の安全確認を行った後、対象ブックを最新版へ更新します。'
        $toolTip.SetToolTip($lblInfoMessageValue, '')
        if (-not $PreserveStatus) { Set-CurrentStatus '正常' }
    }

    if ($PreserveStatus) { Set-CurrentStatus $previousStatus }
    Update-OpenTargetButtonState
}

function Get-GuiLogDirectory {
    if($null-eq$script:settingsInfo){try{$script:settingsInfo=Get-SettingsInfoFromCli}catch{Write-Verbose ('CLIから設定情報を取得できませんでした: '+$_.Exception.Message)}}
    $directory=if($null-ne$script:settingsInfo-and$script:settingsInfo.PSObject.Properties['LogsFolder']){Join-Path ([string]$script:settingsInfo.LogsFolder) 'gui'}else{Join-Path $root 'logs\gui'}
    if (-not (Test-Path -LiteralPath $directory -PathType Container)) {
        [void](New-Item -ItemType Directory -Path $directory -Force)
    }
    return $directory
}

function Trim-GuiLogs {
    $directory = Get-GuiLogDirectory
    $files = @(Get-ChildItem -LiteralPath $directory -Filter '*.log' -File -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending)
    foreach ($file in @($files | Select-Object -Skip $script:GuiLogRetentionCount)) {
        try {
            Remove-Item -LiteralPath $file.FullName -Force
        }
        catch {
            Append-Log ('[GUI] 警告: 古いGUIログを削除できませんでした: ' + $file.FullName + ' / ' + $_.Exception.Message)
        }
    }
}

function Update-ElapsedDisplay {
    if (-not $script:busy -or $null -eq $script:commandStartedAt) { return }
    $elapsed = [DateTime]::Now - [DateTime]$script:commandStartedAt
    $lblElapsedValue.Text = '経過時間：' + (Format-GuiElapsed $elapsed)
}

function Set-Busy([bool]$Value, [string]$Command = '') {
    $script:busy = $Value
    $cmbProject.Enabled = -not $Value
    $btnRefresh.Enabled = -not $Value
    foreach ($button in $operationButtons) { $button.Enabled = -not $Value }
    Update-OpenTargetButtonState
    $form.UseWaitCursor = $Value
    if ($Value) {
        $script:commandStartedAt = [DateTime]::Now
        $script:currentCommand = $Command
        $lblCommandCaption.Text = '処理状況'
        $lblCommandValue.Text = Get-GuiCommandDisplayName $Command
        $lblElapsedValue.Text = '経過時間：00:00:00'
        Set-CurrentStatus '処理実行中'
        $lblInfoMessageValue.Text = $(if ($Command -eq 'project-sync') {
            '安全な更新処理を実行しています。この画面を閉じずにお待ちください。'
        }
        elseif ($Command -eq 'project-create') {
            '開発プロジェクトへExcelブックを登録し、初期ソースを作成しています。この画面を閉じずにお待ちください。'
        }
        elseif ($Command -in @('project-root-set','project-root-reset')) {
            '設定を保存し、プロジェクト一覧を読み直しています。'
        }
        elseif ($Command -eq 'codex-export') {
            'Codex用ZIPを作成しています。この画面を閉じずにお待ちください。'
        }
        elseif ($Command -eq 'codex-import-preview') {
            'Codex納品ZIPを安全に検証し、差分を確認しています。'
        }
        elseif ($Command -eq 'codex-import') {
            'バックアップを作成してCodex納品ZIPを取り込んでいます。'
        }
        else { '処理を実行しています。この画面を閉じずにお待ちください。' })
    }
    else {
        $script:commandStartedAt = $null
        $script:currentCommand = $null
    }
    Update-CodexButtonState
    Update-WorkbookRequiredButtonState
}

function Set-OperationResult([string]$Command, [string]$ResultStatus, [DateTime]$CompletedAt, [TimeSpan]$Elapsed) {
    Set-CurrentStatus $ResultStatus
    $targetName = if ($null -ne $script:selectedProjectInfo -and
        -not [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.TargetName)) {
        [string]$script:selectedProjectInfo.TargetName
    }
    else { '<不明>' }
    $elapsedText = Format-GuiElapsed $Elapsed
    $lblCommandCaption.Text = '完了情報'
    $lblCommandValue.Text = '完了日時：' + $CompletedAt.ToString('yyyy-MM-dd HH:mm:ss')
    $lblElapsedValue.Text = '処理時間：' + $elapsedText

    if ($Command -eq 'project-sync') {
        switch ($ResultStatus) {
            '処理成功' {
                $lblStateValue.Text = '✓ ブックの更新が完了しました'
                $lblInfoMessageValue.Text = '対象ブック：' + $targetName
            }
            '警告付き成功' {
                $lblStateValue.Text = '▲ ブックの更新は完了しました'
                $lblInfoMessageValue.Text = '更新処理は正常に完了しましたが、確認事項があります。詳細ログを確認してください。対象ブック：' + $targetName
            }
            default {
                $lblStateValue.Text = '× ブックを更新できませんでした'
                $lblInfoMessageValue.Text = '対象ブックは更新完了扱いにしていません。詳細ログを確認してください。対象ブック：' + $targetName
            }
        }
    }
    elseif ($Command -eq 'project-create') {
        switch ($ResultStatus) {
            '処理成功' {
                $lblStateValue.Text = '✓ 開発プロジェクトの登録が完了しました'
                $lblInfoMessageValue.Text = 'Excelブックを登録し、初期ソースを作成しました。今後は「ブックを更新する」から安全に更新できます。'
            }
            '警告付き成功' {
                $lblStateValue.Text = '▲ 開発プロジェクトの登録は完了しました'
                $lblInfoMessageValue.Text = '登録は完了しましたが、確認事項があります。詳細ログを確認してください。'
            }
            default {
                $lblStateValue.Text = '× プロジェクトを作成できませんでした'
                $lblInfoMessageValue.Text = '作成に失敗しました。クリーンアップ結果と残存場所を詳細ログで確認してください。元のExcelブックは変更していません。'
            }
        }
    }
    elseif ($Command -in @('project-root-set','project-root-reset')) {
        switch ($ResultStatus) {
            '処理成功' {
                $lblStateValue.Text = '✓ プロジェクト保存先を変更しました'
                $lblInfoMessageValue.Text = '新しい保存先からプロジェクト一覧を読み直しました。既存フォルダーの自動移動や削除は行っていません。'
            }
            '警告付き成功' {
                $lblStateValue.Text = '▲ プロジェクト保存先を変更しました'
                $lblInfoMessageValue.Text = '保存先は変更されましたが、確認事項があります。詳細ログを確認してください。'
            }
            default {
                $lblStateValue.Text = '× プロジェクト保存先を変更できませんでした'
                $lblInfoMessageValue.Text = '以前の保存先設定は維持されています。詳細ログを確認してください。'
            }
        }
    }
    else {
        $lblInfoMessageValue.Text = (Get-GuiCommandDisplayName $Command) + ' / ExitCodeに基づく実行結果です。'
    }
}

function Copy-NewCliOutputToLog([bool]$FinalRead = $false) {
    if ([string]::IsNullOrWhiteSpace($script:guiOutputPath) -or
        -not (Test-Path -LiteralPath $script:guiOutputPath -PathType Leaf)) {
        if ($FinalRead) { throw 'CLIログファイルを取得できませんでした。' }
        return
    }

    try {
        $text = [System.IO.File]::ReadAllText($script:guiOutputPath, [System.Text.Encoding]::UTF8)
    }
    catch {
        # Out-Fileが書き込み中の一時的な競合は次回のTimer Tickで再試行する。
        if ($FinalRead) { throw }
        return
    }

    if ($text.Length -lt $script:lastOutputLength) { $script:lastOutputLength = 0 }
    if ($text.Length -le $script:lastOutputLength) { return }
    $chunk = $text.Substring($script:lastOutputLength)
    $script:lastOutputLength = $text.Length
    Append-LogText $chunk
}

function Remove-GuiRunnerFile {
    if (-not [string]::IsNullOrWhiteSpace($script:guiRunnerPath) -and (Test-Path -LiteralPath $script:guiRunnerPath)) {
        Remove-Item -LiteralPath $script:guiRunnerPath -Force -ErrorAction SilentlyContinue
    }
}

function Clear-CliRuntime([bool]$StopProcess) {
    $script:pollTimer.Stop()
    try {
        if ($null -ne $script:process) {
            if ($StopProcess -and -not $script:process.HasExited) {
                $script:process.Kill()
                $script:process.WaitForExit()
            }
            elseif ($script:process.HasExited) {
                $script:process.WaitForExit()
            }
            $script:process.Dispose()
        }
    }
    catch {
        # 後始末エラーでGUIを終了させない。
    }
    try { Remove-GuiRunnerFile } catch { Write-Verbose ('GUI runner一時ファイルを削除できませんでした: ' + $_.Exception.Message) }
    $script:process = $null
    $script:guiOutputPath = $null
    $script:guiRunnerPath = $null
    $script:lastOutputLength = 0
}

function Get-SelectedProject {
    if ($cmbProject.SelectedItem -eq $null) {
        Show-GuiMessage 'プロジェクトを選択してください。' '確認'
        return $null
    }
    return [string]$cmbProject.SelectedItem
}

function New-DangerousOperationMessage([string]$Operation, [string]$ChangeTarget, [switch]$RollbackWarning) {
    $selected = Get-SelectedProject
    if ($null -eq $selected) { return $null }
    $projectName = $selected
    $targetName = '<不明>'
    if ($null -ne $script:selectedProjectInfo -and $script:selectedProjectInfo.Selection -eq $selected) {
        $projectName = [string]$script:selectedProjectInfo.ProjectName
        if (-not [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.TargetName) -and $script:selectedProjectInfo.TargetName -ne '-') {
            $targetName = [string]$script:selectedProjectInfo.TargetName
        }
    }
    $lines = New-Object 'System.Collections.Generic.List[string]'
    $lines.Add('選択中プロジェクト名：' + $projectName)
    $lines.Add('対象ブック名：' + $targetName)
    $lines.Add('実行する操作：' + $Operation)
    $lines.Add('変更される対象：' + $ChangeTarget)
    if ($RollbackWarning) {
        $lines.Add('')
        $lines.Add('対象ブックが復元ポイント作成時の状態へ戻ります。現在のブック内容は上書きされる可能性があります。')
    }
    $lines.Add('')
    $lines.Add('この操作を実行しますか？')
    return $lines -join [Environment]::NewLine
}

function New-BookUpdateConfirmationMessage {
    $selected = Get-SelectedProject
    if ($null -eq $selected) { return $null }
    $projectName = $selected
    $targetName = '<不明>'
    if ($null -ne $script:selectedProjectInfo -and $script:selectedProjectInfo.Selection -eq $selected) {
        $projectName = [string]$script:selectedProjectInfo.ProjectName
        if (-not [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.TargetName) -and
            [string]$script:selectedProjectInfo.TargetName -ne '-') {
            $targetName = [string]$script:selectedProjectInfo.TargetName
        }
    }
    return @(
        'ブック更新の確認',
        '',
        'プロジェクト：' + $projectName,
        '対象ブック：' + $targetName,
        '',
        '次の処理を行います。',
        '',
        '・更新前の安全確認',
        '・復元ポイントの作成',
        '・最新版との差分確認',
        '・必要な部分だけを更新',
        '・更新後の確認',
        '・更新履歴の記録',
        '',
        'ブックを更新しますか？'
    ) -join [Environment]::NewLine
}

function Start-CliCommand {
    param(
        [Parameter(Mandatory=$true)][string]$Command,
        [string[]]$Arguments = @(),
        [string]$ConfirmMessage
    )

    if ($script:busy) { return }
    if (-not [string]::IsNullOrWhiteSpace($ConfirmMessage)) {
        $answer = [System.Windows.Forms.MessageBox]::Show(
            $ConfirmMessage,
            '実行確認',
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Warning)
        if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
            Append-Log '[GUI] 操作をキャンセルしました。'
            return
        }
    }

    Append-Log ''
    Append-Log ('> .\vba.cmd ' + $Command + $(if ($Arguments.Count -gt 0) { ' ' + ($Arguments -join ' ') } else { '' }))
    Set-Busy $true $Command

    try {
        $runId = [DateTime]::Now.ToString('yyyyMMdd_HHmmss_fff')
        $guiLogDir = Get-GuiLogDirectory
        $outputPath = Join-Path $guiLogDir ('gui_' + $runId + '.log')
        $runnerPath = Join-Path $guiLogDir ('gui_' + $runId + '.ps1')
        $script:guiOutputPath = $outputPath
        $script:guiRunnerPath = $runnerPath
        $script:lastOutputLength = 0
        $allArgs = @($Command) + @($Arguments)
        $runner = New-CliRunnerContent -CliScriptPath $cliPath -CliArguments ([string[]]$allArgs) -OutputPath $outputPath
        [System.IO.File]::WriteAllText($runnerPath, $runner, (New-Object System.Text.UTF8Encoding($true)))

        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = 'powershell.exe'
        $psi.Arguments = '-NoProfile -ExecutionPolicy Bypass -File ' + (Quote-ProcessArgument $runnerPath)
        $psi.WorkingDirectory = $root
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true

        $process = New-Object System.Diagnostics.Process
        $process.StartInfo = $psi
        $script:process = $process
        [void]$process.Start()
        $script:pollTimer.Start()
    }
    catch {
        Append-Log ('[GUI] 起動準備または起動に失敗しました: ' + $_.Exception.Message)
        $failedCommand = $script:currentCommand
        $failedStartedAt = $script:commandStartedAt
        $failedAt = [DateTime]::Now
        Clear-CliRuntime $true
        Set-Busy $false
        $failedElapsed = if ($null -ne $failedStartedAt) { $failedAt - [DateTime]$failedStartedAt } else { [TimeSpan]::Zero }
        Set-OperationResult -Command $failedCommand -ResultStatus '処理失敗' -CompletedAt $failedAt -Elapsed $failedElapsed
        if ($failedCommand -eq 'project-create') {
            $script:pendingCreatedProject = $null
            $script:pendingCreatedWorkbook = $null
        }
    }
}

$script:pollTimer.Add_Tick({
    try {
        Update-ElapsedDisplay
        Copy-NewCliOutputToLog
        if ($null -eq $script:process -or -not $script:process.HasExited) { return }

        $exitCode = $null
        $resultStatus = '処理失敗'
        $completedCommand = $script:currentCommand
        $completedStartedAt = $script:commandStartedAt
        try {
            $script:pollTimer.Stop()
            $script:process.WaitForExit()
            Copy-NewCliOutputToLog $true
            $exitCode = $script:process.ExitCode
            if ($exitCode -eq 0) {
                Append-Log '[GUI] コマンドは正常終了しました。'
                $resultStatus = '処理成功'
                $completedOutput = ''
                if (-not [string]::IsNullOrWhiteSpace($script:guiOutputPath) -and (Test-Path -LiteralPath $script:guiOutputPath -PathType Leaf)) {
                    $completedOutput = [System.IO.File]::ReadAllText($script:guiOutputPath, [System.Text.Encoding]::UTF8)
                }
                if ($completedOutput.IndexOf('[WARNING]', [System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
                    $resultStatus = '警告付き成功'
                    Append-Log '[GUI] ブック更新は完了しましたが、確認事項があります。詳細ログを確認してください。'
                }
            }
            else {
                Append-Log ('[GUI] コマンドが失敗しました。ExitCode=' + $exitCode)
                $resultStatus = '処理失敗'
            }
        }
        catch {
            Append-Log ('[GUI] 結果取得に失敗しました: ' + $_.Exception.Message)
            $resultStatus = '処理失敗'
        }
        finally {
            $completedAt = [DateTime]::Now
            $completedElapsed = if ($null -ne $completedStartedAt) { $completedAt - [DateTime]$completedStartedAt } else { [TimeSpan]::Zero }
            $completedProject = $script:pendingCreatedProject
            $completedWorkbook = $script:pendingCreatedWorkbook
            $previousRootProject = $script:projectRootPreviousSelection
            Clear-CliRuntime $false
            Set-Busy $false
            try {
                if ($completedCommand -eq 'project-create' -and $resultStatus -in @('処理成功','警告付き成功') -and -not [string]::IsNullOrWhiteSpace($completedProject)) {
                    Select-RegisteredProject -ProjectName $completedProject
                }
                elseif ($completedCommand -in @('project-root-set','project-root-reset') -and $resultStatus -in @('処理成功','警告付き成功')) {
                    Refresh-ProjectRootAndProjects -PreferredProject $previousRootProject -StrictSelection
                }
                else {
                    Update-ProjectInformation -PreserveStatus
                }
            }
            catch { Append-Log ('[GUI] 作成後のプロジェクト再読込に失敗しました: ' + $_.Exception.Message) }
            Set-OperationResult -Command $completedCommand -ResultStatus $resultStatus -CompletedAt $completedAt -Elapsed $completedElapsed
            if($completedCommand-in@('project-sync','project-push','workbook-apply','rollback','project-create')){
                $attentionReason=switch($resultStatus){'処理失敗'{'処理失敗'}'警告付き成功'{'確認が必要'}default{'処理完了'}}
                [void](Request-GuiTaskbarAttention -Reason $attentionReason)
            }
            if ($completedCommand -eq 'project-create') {
                if ($resultStatus -in @('処理成功','警告付き成功')) {
                    Show-GuiMessage ("開発プロジェクトの登録が完了しました。`r`n`r`nプロジェクト：{0}`r`n対象ブック：{1}`r`n`r`nExcelブックを登録し、初期ソースを作成しました。" -f $completedProject,$completedWorkbook) '開発プロジェクトを登録'
                }
                else {
                    Show-GuiMessage '開発プロジェクトを登録できませんでした。詳細ログでエラーとクリーンアップ結果を確認してください。元のExcelブックと既存の開発ファイルは変更していません。' '開発プロジェクトを登録' ([System.Windows.Forms.MessageBoxIcon]::Error)
                }
                $script:pendingCreatedProject = $null
                $script:pendingCreatedWorkbook = $null
            }
            if ($completedCommand -in @('project-root-set','project-root-reset')) {
                $script:projectRootPreviousSelection = $null
            }
        }
    }
    catch {
        Append-Log ('[GUI] 実行監視に失敗しました: ' + $_.Exception.Message)
        $failedCommand = $script:currentCommand
        $failedStartedAt = $script:commandStartedAt
        $failedAt = [DateTime]::Now
        Clear-CliRuntime $true
        Set-Busy $false
        $failedElapsed = if ($null -ne $failedStartedAt) { $failedAt - [DateTime]$failedStartedAt } else { [TimeSpan]::Zero }
        Set-OperationResult -Command $failedCommand -ResultStatus '処理失敗' -CompletedAt $failedAt -Elapsed $failedElapsed
    }
})

function Add-OperationButton([System.Windows.Forms.Control]$Parent, [string]$Text, [scriptblock]$OnClick, [int]$Width = 150) {
    $button = New-Object System.Windows.Forms.Button
    $button.Text = $Text
    $button.Size = New-Object System.Drawing.Size($Width, 38)
    $button.Margin = New-Object System.Windows.Forms.Padding(4)
    $handler = {
        try { & $OnClick }
        catch {
            Append-Log ('[GUI] 操作に失敗しました: ' + $_.Exception.Message)
            Show-GuiMessage $_.Exception.Message 'GUI操作エラー' ([System.Windows.Forms.MessageBoxIcon]::Error)
        }
    }.GetNewClosure()
    $button.Add_Click($handler)
    $Parent.Controls.Add($button)
    $operationButtons.Add($button)
    return $button
}

function Invoke-ProjectCommand([string]$Command, [string[]]$Extra = @(), [string]$ConfirmMessage) {
    $selected = Get-SelectedProject
    if ($null -eq $selected) { return }
    if ($Command -in @('project-push','project-pull','project-sync','rollback','codex-import','workbook-apply')) {
        Assert-GuiProjectSelectionSafe -Command $Command
    }
    $arguments = @('-Project', $selected)
    if ($null -ne $script:selectedProjectInfo -and -not [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.ProjectRoot)) {
        $arguments += @('-ProjectRoot',[string]$script:selectedProjectInfo.ProjectRoot)
        if (-not [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.TargetPath) -and [string]$script:selectedProjectInfo.TargetPath -ne '-') {
            $arguments += @('-WorkbookPath',[string]$script:selectedProjectInfo.TargetPath)
        }
    }
    $arguments += $Extra
    Start-CliCommand -Command $Command -Arguments $arguments -ConfirmMessage $ConfirmMessage
}

function Invoke-DangerousProjectCommand {
    param(
        [string]$Command,
        [string]$Operation,
        [string]$ChangeTarget,
        [string[]]$Extra = @(),
        [switch]$RollbackWarning
    )
    $message = New-DangerousOperationMessage -Operation $Operation -ChangeTarget $ChangeTarget -RollbackWarning:$RollbackWarning
    if ($null -eq $message) { return }
    Invoke-ProjectCommand -Command $Command -Extra $Extra -ConfirmMessage $message
}

function Invoke-ProjectRootSettingCliSynchronously {
    param([Parameter(Mandatory=$true)][string]$Command,[string[]]$Arguments=@())
    $cliArguments = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$cliPath,$Command) + @($Arguments) + @(Get-GuiTestPropagationArguments)
    Append-Log ('> .\vba.cmd ' + $Command + $(if ($Arguments.Count -gt 0) { ' ' + ($Arguments -join ' ') } else { '' }))
    $outputLines = @(& powershell.exe @cliArguments 2>&1)
    $exitCode = $LASTEXITCODE
    foreach ($line in $outputLines) { Append-Log ([string]$line) }
    if ($exitCode -ne 0) { throw "保存先設定コマンドに失敗しました。Command=$Command ExitCode=$exitCode" }
}

function Select-ProjectRootMigrationCandidate {
    $picker = New-Object System.Windows.Forms.FolderBrowserDialog
    $picker.Description = 'プロジェクトの保存先フォルダーを選択してください。'
    $picker.ShowNewFolderButton = $true
    if ($null -ne $script:projectRootInfo -and [bool]$script:projectRootInfo.Exists) {
        $picker.SelectedPath = [string]$script:projectRootInfo.Path
    }
    try {
        if ($picker.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { return $null }
        $check = Get-ProjectRootCheckFromCli -Path ([string]$picker.SelectedPath)
        if ([string]$check.Status -ne 'OK') {
            Show-GuiMessage ("選択した保存先を使用できません。`r`n`r`n保存先：{0}`r`n状態：{1}`r`n詳細：{2}" -f $check.Path,$check.Status,$check.Message) 'プロジェクト保存先' ([System.Windows.Forms.MessageBoxIcon]::Error)
            return $null
        }

        $names = @($check.ProjectNames)
        $detectionText = if ([int]$check.Projects -eq 0) {
            @(
                'プロジェクトは見つかりませんでした。',
                '登録済みプロジェクトはありませんが、Project Rootとして使用できます。'
            ) -join [Environment]::NewLine
        }
        else {
            $displayNames = @($names | Select-Object -First 20)
            $moreText = if ($names.Count -gt 20) { [Environment]::NewLine + ("ほか{0}件" -f ($names.Count-20)) } else { '' }
            (("{0}件のプロジェクトが見つかりました。" -f [int]$check.Projects) + [Environment]::NewLine + [Environment]::NewLine + ($displayNames -join [Environment]::NewLine) + $moreText)
        }
        $currentPath = if ($null -ne $script:projectRootInfo) { [string]$script:projectRootInfo.Path } else { '-' }
        $message = @(
            'プロジェクト保存先を変更します。',
            '',
            '変更前：' + $currentPath,
            '変更後：' + [string]$check.Path,
            '',
            $detectionText,
            '',
            '既存プロジェクトは自動移動・コピー・削除されません。',
            '',
            'この保存先を使用しますか？'
        ) -join [Environment]::NewLine
        $answer = [System.Windows.Forms.MessageBox]::Show($message,'プロジェクト保存先の確認',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question)
        if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { return $null }
        return $check
    }
    finally { $picker.Dispose() }
}

function Show-MissingProjectRootRecoveryDialog {
    param([Parameter(Mandatory=$true)][string]$CurrentPath)
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = 'プロジェクト保存先が見つかりません'
    $dialog.StartPosition = 'CenterScreen'
    $dialog.Size = New-Object System.Drawing.Size(680,330)
    $dialog.MinimumSize = New-Object System.Drawing.Size(620,300)
    $dialog.Font = $form.Font
    $dialog.FormBorderStyle = 'FixedDialog'
    $dialog.MaximizeBox = $false
    $dialog.MinimizeBox = $false
    $dialog.Tag = 'Exit'

    $layout = New-Object System.Windows.Forms.TableLayoutPanel
    $layout.Dock = 'Fill'
    $layout.Padding = New-Object System.Windows.Forms.Padding(20)
    $layout.RowCount = 4
    $layout.ColumnCount = 1
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute',55)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute',78)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent',100)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute',58)))
    $dialog.Controls.Add($layout)

    $heading = New-Object System.Windows.Forms.Label
    $heading.Text = 'プロジェクト保存先が見つかりません。'
    $heading.Font = New-Object System.Drawing.Font('Yu Gothic UI',13,[System.Drawing.FontStyle]::Bold)
    $heading.Dock = 'Fill'
    $heading.TextAlign = 'MiddleLeft'
    $layout.Controls.Add($heading,0,0)

    $pathText = New-Object System.Windows.Forms.TextBox
    $pathText.Multiline = $true
    $pathText.ReadOnly = $true
    $pathText.Dock = 'Fill'
    $pathText.Text = "現在の設定`r`n$CurrentPath"
    $layout.Controls.Add($pathText,0,1)

    $message = New-Object System.Windows.Forms.Label
    $message.Text = 'このフォルダーは存在しません。保存先を変更してください。'
    $message.Dock = 'Fill'
    $message.TextAlign = 'MiddleLeft'
    $message.ForeColor = [System.Drawing.Color]::DarkRed
    $layout.Controls.Add($message,0,2)

    $buttons = New-Object System.Windows.Forms.FlowLayoutPanel
    $buttons.Dock = 'Fill'
    $buttons.FlowDirection = 'RightToLeft'
    $buttons.WrapContents = $false
    $layout.Controls.Add($buttons,0,3)
    foreach ($definition in @(
        [PSCustomObject]@{ Text='終了'; Choice='Exit'; Width=100 },
        [PSCustomObject]@{ Text='既定へ戻す'; Choice='Reset'; Width=130 },
        [PSCustomObject]@{ Text='保存先を変更'; Choice='Change'; Width=150 }
    )) {
        $button = New-Object System.Windows.Forms.Button
        $button.Text = $definition.Text
        $button.Size = New-Object System.Drawing.Size($definition.Width,38)
        $choice = [string]$definition.Choice
        $button.Add_Click({ $dialog.Tag=$choice; $dialog.DialogResult=[System.Windows.Forms.DialogResult]::OK; $dialog.Close() }.GetNewClosure())
        $buttons.Controls.Add($button)
    }
    [void]$dialog.ShowDialog()
    $result = [string]$dialog.Tag
    $dialog.Dispose()
    return $result
}

function Invoke-ProjectRootStartupRecovery {
    while ($null -ne $script:projectRootInfo -and [bool]$script:projectRootInfo.RecoveryRequired) {
        $missingPath=if($script:projectRootInfo.PSObject.Properties['LastProjectRoot'] -and -not [string]::IsNullOrWhiteSpace([string]$script:projectRootInfo.LastProjectRoot) -and -not [bool]$script:projectRootInfo.LastProjectExists){[string]$script:projectRootInfo.LastProjectRoot}else{[string]$script:projectRootInfo.Path}
        $choice = Show-MissingProjectRootRecoveryDialog -CurrentPath $missingPath
        switch ($choice) {
            'Change' {
                if ($script:projectRootInfo.PSObject.Properties['LastProjectRoot'] -and -not [string]::IsNullOrWhiteSpace([string]$script:projectRootInfo.LastProjectRoot)) {
                    if (Show-DirectProjectFolderOpenDialog) { return $true }
                    continue
                }
                $candidate = Select-ProjectRootMigrationCandidate
                if ($null -eq $candidate) { continue }
                try {
                    Invoke-ProjectRootSettingCliSynchronously -Command 'project-root-set' -Arguments @('-Path',[string]$candidate.Path)
                    Refresh-ProjectRootAndProjects
                    $script:startupFailure = $null
                    return $true
                }
                catch { Show-GuiMessage $_.Exception.Message '保存先を変更できません' ([System.Windows.Forms.MessageBoxIcon]::Error) }
            }
            'Reset' {
                try {
                    Invoke-ProjectRootSettingCliSynchronously -Command 'project-root-reset'
                    Refresh-ProjectRootAndProjects
                    $script:startupFailure = $null
                    return $true
                }
                catch { Show-GuiMessage $_.Exception.Message '既定へ戻せません' ([System.Windows.Forms.MessageBoxIcon]::Error) }
            }
            default { return $false }
        }
    }
    return $true
}

function Invoke-LegacyProjectMigrationWizard {
    $check = Get-LegacyProjectMigrationCheckFromCli
    if (-not [bool]$check.RequiresMigration) { return $true }
    $names = @($check.ProjectNames)
    $displayNames = @($names | Select-Object -First 20)
    $more = if ($names.Count -gt 20) { "`r`nほか$($names.Count - 20)件" } else { '' }
    $message = @(
        'Ver4.17以前のVBAUpdater専用プロジェクトを検出しました。',
        '',
        '移行元：' + [string]$check.SourceRoot,
        '対象：' + [string]$check.Projects + '件',
        ($displayNames -join [Environment]::NewLine) + $more,
        '',
        'GitHub・Codex・VBAUpdaterで共有するDevelopmentフォルダーへ安全にコピーします。',
        '移行後に必須ファイルを検証し、移行元は削除しません。',
        '',
        '移行ウィザードを開始しますか？'
    ) -join [Environment]::NewLine
    $answer = [System.Windows.Forms.MessageBox]::Show($message,'旧形式プロジェクトの移行',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Information)
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
        Append-Log '[GUI] 旧形式プロジェクトの移行は今回実行しませんでした。'
        return $true
    }

    $picker = New-Object System.Windows.Forms.FolderBrowserDialog
    try {
        $picker.Description = '既に存在するDevelopmentフォルダーを選択してください。移行先は自動作成しません。'
        $picker.ShowNewFolderButton = $false
        if ($null -ne $script:projectRootInfo -and [bool]$script:projectRootInfo.Exists -and
            -not [string]::Equals([string]$script:projectRootInfo.Path,[string]$check.SourceRoot,[System.StringComparison]::OrdinalIgnoreCase)) {
            $picker.SelectedPath = [string]$script:projectRootInfo.Path
        }
        if ($picker.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { return $true }
        $destination = [string]$picker.SelectedPath
        $destinationCheck = Get-ProjectRootCheckFromCli -Path $destination
        if ([string]$destinationCheck.Status -ne 'OK') {
            throw "移行先Project Rootを使用できません: $($destinationCheck.Message)"
        }
        Invoke-ProjectRootSettingCliSynchronously -Command 'project-migrate' -Arguments @('-SourceRoot',[string]$check.SourceRoot,'-DestinationRoot',$destination)
        Refresh-ProjectRootAndProjects
        $script:startupFailure = $null
        Append-Log ("[GUI] 旧形式プロジェクトを移行しました。移行先: {0}" -f $destination)
        Show-GuiMessage ("旧形式プロジェクトの移行が完了しました。`r`n`r`n移行先：$destination`r`n対象：$($check.Projects)件`r`n`r`n移行元は安全のため残しています。") '移行完了'
        return $true
    }
    catch {
        Append-Log ('[GUI] 旧形式プロジェクトの移行に失敗しました: ' + $_.Exception.Message)
        Show-GuiMessage $_.Exception.Message '移行できません' ([System.Windows.Forms.MessageBoxIcon]::Error)
        return $false
    }
    finally { $picker.Dispose() }
}

function Show-ProjectRootChangeDialog {
    if ($script:busy) { return }
    $candidate = Select-ProjectRootMigrationCandidate
    if ($null -eq $candidate) { return }
    $currentPath = if ($null -ne $script:projectRootInfo) { [string]$script:projectRootInfo.Path } else { '-' }
    if ([string]::Equals($currentPath,[string]$candidate.Path,[System.StringComparison]::OrdinalIgnoreCase)) {
        Show-GuiMessage '現在と同じ保存先が選択されています。' 'プロジェクト保存先'
        return
    }
    $script:projectRootPreviousSelection = if ($cmbProject.SelectedItem -ne $null) { [string]$cmbProject.SelectedItem } else { $null }
    Start-CliCommand -Command 'project-root-set' -Arguments @('-Path',[string]$candidate.Path)
}

function Reset-ProjectRootFromGui {
    if ($script:busy) { return }
    $currentPath = if ($null -ne $script:projectRootInfo) { [string]$script:projectRootInfo.Path } else { '-' }
    $defaultPath = if ($null -ne $script:projectRootInfo -and $script:projectRootInfo.PSObject.Properties['DefaultPath']) {
        [string]$script:projectRootInfo.DefaultPath
    }
    else { Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::UserProfile)) 'Development' }
    $message = @(
        'プロジェクト保存先を既定に戻します。',
        '',
        '変更前：' + $currentPath,
        '変更後：' + $defaultPath,
        '',
        '既存のプロジェクトフォルダーは自動で移動・コピー・削除されません。',
        '',
        '既定に戻しますか？'
    ) -join [Environment]::NewLine
    $answer = [System.Windows.Forms.MessageBox]::Show($message,'プロジェクト保存先を既定に戻す',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Warning)
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { return }
    $script:projectRootPreviousSelection = if ($cmbProject.SelectedItem -ne $null) { [string]$cmbProject.SelectedItem } else { $null }
    Start-CliCommand -Command 'project-root-reset'
}

function Update-CodexButtonState {
    $hasProject = $cmbProject.SelectedItem -ne $null -and $null -ne $script:selectedProjectInfo
    $rootAvailable = $null -ne $script:projectRootInfo -and [bool]$script:projectRootInfo.Exists
    $baseEnabled = (-not $script:busy) -and $hasProject -and $rootAvailable
    if ($null -ne $script:btnCodexExport) { $script:btnCodexExport.Enabled = $baseEnabled }
    if ($null -ne $script:btnCodexPreview) { $script:btnCodexPreview.Enabled = $baseEnabled }
    $previewReady = $baseEnabled -and $null -ne $script:lastCodexPreview -and
        [bool]$script:lastCodexPreview.success -and [bool]$script:lastCodexPreview.projectMatch -and
        -not [string]::IsNullOrWhiteSpace([string]$script:lastCodexZipPath) -and
        (Test-Path -LiteralPath $script:lastCodexZipPath -PathType Leaf) -and
        [string]::Equals([string]$script:lastCodexPreview.project,[string]$cmbProject.SelectedItem,[System.StringComparison]::OrdinalIgnoreCase)
    if ($null -ne $script:btnCodexImport) { $script:btnCodexImport.Enabled = $previewReady }
}

function Invoke-CodexCliJson {
    param(
        [Parameter(Mandatory=$true)][string]$Command,
        [Parameter(Mandatory=$true)][AllowEmptyString()][string]$ProjectName,
        [AllowEmptyString()][string]$ZipPath,
        [string[]]$ExtraArguments=@()
    )
    if ([string]::IsNullOrWhiteSpace($ProjectName)) { return $null }
    if ($Command -in @('codex-import-preview','codex-import') -and [string]::IsNullOrWhiteSpace($ZipPath)) { return $null }
    $arguments = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$cliPath,$Command,'-Project',$ProjectName)
    if ($null -ne $script:selectedProjectInfo -and -not [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.ProjectRoot)) {
        $arguments += @('-ProjectRoot',[string]$script:selectedProjectInfo.ProjectRoot)
    }
    if (-not [string]::IsNullOrWhiteSpace($ZipPath)) { $arguments += @('-ZipPath',$ZipPath) }
    $arguments += @($ExtraArguments)
    $arguments += '-Json'
    $arguments += @(Get-GuiTestPropagationArguments)
    $outputLines = @(& powershell.exe @arguments 2>&1)
    $exitCode = $LASTEXITCODE
    $output = $outputLines -join [Environment]::NewLine
    if ([string]::IsNullOrWhiteSpace($output)) { throw "Codex連携CLIから応答がありません。Command=$Command / ExitCode=$exitCode" }
    try { $result = $output | ConvertFrom-Json }
    catch { throw "Codex連携CLIのJSON応答を解析できません: $($_.Exception.Message) / 応答: $output" }
    if ($exitCode -ne 0 -or -not [bool]$result.success) {
        $details = @($result.errors) -join ' / '
        if ([string]::IsNullOrWhiteSpace($details)) { $details = "ExitCode=$exitCode" }
        throw $details
    }
    return $result
}

function Get-CodexPreviewDisplayText {
    param([Parameter(Mandatory=$true)]$Result)
    $lines = New-Object 'System.Collections.Generic.List[string]'
    $lines.Add('Codex Import Preview')
    $lines.Add('')
    $lines.Add('Project: ' + [string]$Result.project)
    $lines.Add('Project Match: ' + [string]$Result.projectMatch)
    foreach ($group in @(
        [PSCustomObject]@{Name='追加';Items=@($Result.added)},
        [PSCustomObject]@{Name='変更';Items=@($Result.modified)},
        [PSCustomObject]@{Name='削除候補（既定では反映しません）';Items=@($Result.deleted)},
        [PSCustomObject]@{Name='変更なし';Items=@($Result.unchanged)},
        [PSCustomObject]@{Name='反映対象外';Items=@($Result.ignored)},
        [PSCustomObject]@{Name='危険なファイル';Items=@($Result.dangerous)},
        [PSCustomObject]@{Name='構造異常';Items=@($Result.structuralErrors)},
        [PSCustomObject]@{Name='警告';Items=@($Result.warnings)},
        [PSCustomObject]@{Name='エラー';Items=@($Result.errors)})) {
        $lines.Add('')
        $lines.Add($group.Name + ': ' + $group.Items.Count + '件')
        foreach ($item in $group.Items) { $lines.Add('  ' + [string]$item) }
    }
    return $lines.ToArray() -join [Environment]::NewLine
}

function Show-CodexPreviewResultDialog {
    param([Parameter(Mandatory=$true)]$Result)
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = 'Codex納品ZIPの確認'
    $dialog.StartPosition = 'CenterParent'
    $dialog.Size = New-Object System.Drawing.Size(860,650)
    $dialog.MinimumSize = New-Object System.Drawing.Size(700,500)
    $dialog.Font = $form.Font
    $layout = New-Object System.Windows.Forms.TableLayoutPanel
    $layout.Dock='Fill';$layout.RowCount=2;$layout.ColumnCount=1;$layout.Padding=New-Object System.Windows.Forms.Padding(10)
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent',100)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute',46)))
    $dialog.Controls.Add($layout)
    $textBox=New-Object System.Windows.Forms.RichTextBox
    $textBox.Dock='Fill';$textBox.ReadOnly=$true;$textBox.WordWrap=$false;$textBox.Font=New-Object System.Drawing.Font('Consolas',9)
    $textBox.Text=Get-CodexPreviewDisplayText -Result $Result
    $layout.Controls.Add($textBox,0,0)
    $close=New-Object System.Windows.Forms.Button
    $close.Text='閉じる';$close.Size=New-Object System.Drawing.Size(110,32);$close.Anchor='Right';$close.DialogResult=[System.Windows.Forms.DialogResult]::OK
    $layout.Controls.Add($close,0,1);$dialog.AcceptButton=$close;$dialog.CancelButton=$close
    [void]$dialog.ShowDialog($form)
    $dialog.Dispose()
}

function Show-CodexExportFromGui {
    $picker = $null
    try {
        $projectName = Get-SelectedProject
        if ([string]::IsNullOrWhiteSpace($projectName) -or $null -eq $script:projectRootInfo -or -not [bool]$script:projectRootInfo.Exists) { return }
        $picker = New-Object System.Windows.Forms.SaveFileDialog
        $picker.Filter = 'ZIPファイル (*.zip)|*.zip'
        $picker.DefaultExt = 'zip'
        $picker.AddExtension = $true
        $picker.OverwritePrompt = $true
        $picker.FileName = $projectName + '_Codex_' + [DateTime]::Now.ToString('yyyyMMdd_HHmmss') + '.zip'
        if ($picker.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { return }
        $outputPath = [string]$picker.FileName
        if ([string]::IsNullOrWhiteSpace($outputPath)) { return }
        if (Test-Path -LiteralPath $outputPath) {
            Show-GuiMessage '既存ZIPは上書きしません。別のファイル名を指定してください。' 'Codex用ZIPを作成'
            return
        }
        $message = @(
            'Codex用ZIPを作成します。','',
            '対象プロジェクト：' + $projectName,
            'プロジェクト保存先：' + [string]$script:projectRootInfo.Path,
            'ZIP出力先：' + $outputPath,'',
            '含まれる主な内容：project.json、source、README、docs、tests、tools、templates',
            '除外される主な内容：target、backups、history、logs、tmp、個人設定、認証情報','',
            '作成しますか？') -join [Environment]::NewLine
        $answer=[System.Windows.Forms.MessageBox]::Show($message,'Codex用ZIPを作成',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question)
        if($answer -ne [System.Windows.Forms.DialogResult]::Yes){return}
        Set-Busy $true 'codex-export'
        try { $result=Invoke-CodexCliJson -Command 'codex-export' -ProjectName $projectName -ZipPath '' -ExtraArguments @('-OutputPath',$outputPath) }
        finally { Set-Busy $false }
        Append-Log ('[GUI] Codex用ZIPを作成しました: ' + [string]$result.zipPath)
        $open=[System.Windows.Forms.MessageBox]::Show(('Codex用ZIPを作成しました。'+[Environment]::NewLine+[Environment]::NewLine+'ファイル：'+[Environment]::NewLine+[string]$result.zipPath+[Environment]::NewLine+[Environment]::NewLine+'保存フォルダーを開きますか？'),'Codex用ZIPを作成',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Information)
        if($open -eq [System.Windows.Forms.DialogResult]::Yes){Start-Process -FilePath 'explorer.exe' -ArgumentList (Quote-ProcessArgument (Split-Path -Parent ([string]$result.zipPath))) | Out-Null}
    }
    catch { Append-Log ('[GUI] Codex用ZIP作成に失敗しました: '+$_.Exception.Message); Show-GuiMessage ('Codex用ZIPを作成できませんでした。'+[Environment]::NewLine+$_.Exception.Message) 'Codex用ZIPを作成' }
    finally { if($null -ne $picker){$picker.Dispose()}; Update-CodexButtonState }
}

function Show-CodexImportPreviewFromGui {
    $picker=$null
    try {
        $projectName=Get-SelectedProject
        if([string]::IsNullOrWhiteSpace($projectName)){return}
        $picker=New-Object System.Windows.Forms.OpenFileDialog
        $picker.Filter='ZIPファイル (*.zip)|*.zip';$picker.CheckFileExists=$true;$picker.Multiselect=$false
        if($picker.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK){return}
        $zipPath=[string]$picker.FileName
        if([string]::IsNullOrWhiteSpace($zipPath)){return}
        Set-Busy $true 'codex-import-preview'
        try{$result=Invoke-CodexCliJson -Command 'codex-import-preview' -ProjectName $projectName -ZipPath $zipPath}
        finally{Set-Busy $false}
        $script:lastCodexPreview=$result;$script:lastCodexZipPath=$zipPath
        Append-Log ('[GUI] Codex納品ZIPを確認しました: '+$zipPath)
        Update-CodexButtonState
        Show-CodexPreviewResultDialog -Result $result
    }
    catch { $script:lastCodexPreview=$null;$script:lastCodexZipPath=$null;Append-Log ('[GUI] Codex納品ZIPの確認に失敗しました: '+$_.Exception.Message);Show-GuiMessage ('Codex納品ZIPを確認できませんでした。'+[Environment]::NewLine+$_.Exception.Message) 'Codex納品ZIPの確認' }
    finally { if($null -ne $picker){$picker.Dispose()};Update-CodexButtonState }
}

function Import-CodexZipFromGui {
    try {
        $projectName=Get-SelectedProject
        if([string]::IsNullOrWhiteSpace($projectName) -or $null -eq $script:lastCodexPreview -or [string]::IsNullOrWhiteSpace([string]$script:lastCodexZipPath)){return}
        if(-not (Test-Path -LiteralPath $script:lastCodexZipPath -PathType Leaf)){Show-GuiMessage '確認済みのCodex納品ZIPが見つかりません。もう一度「Codex納品ZIPを確認」を実行してください。' 'Codex納品ZIPを取り込む';return}
        $message=@('Codex納品ZIPを取り込みます。','','対象：'+$projectName,'','追加：'+@($script:lastCodexPreview.added).Count+'件','変更：'+@($script:lastCodexPreview.modified).Count+'件','削除候補：'+@($script:lastCodexPreview.deleted).Count+'件','','既存sourceと開発文書のバックアップを作成してから反映します。','削除候補は既定では反映しません。','','取り込みますか？') -join [Environment]::NewLine
        $answer=[System.Windows.Forms.MessageBox]::Show($message,'Codex納品ZIPを取り込む',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Warning)
        if($answer -ne [System.Windows.Forms.DialogResult]::Yes){return}
        Set-Busy $true 'codex-import'
        try{$result=Invoke-CodexCliJson -Command 'codex-import' -ProjectName $projectName -ZipPath $script:lastCodexZipPath -ExtraArguments @('-Confirm')}
        finally{Set-Busy $false}
        Append-Log ('[GUI] Codex納品ZIPを取り込みました。Backup='+[string]$result.backupPath)
        $script:lastCodexPreview=$null;$script:lastCodexZipPath=$null;Update-CodexButtonState
        Show-GuiMessage ('Codex納品ZIPを取り込みました。'+[Environment]::NewLine+[Environment]::NewLine+'ブックを更新するには「ブックを更新する」を実行してください。'+[Environment]::NewLine+[Environment]::NewLine+'バックアップ：'+[Environment]::NewLine+[string]$result.backupPath) 'Codex納品ZIPを取り込む'
        Update-ProjectInformation -PreserveStatus
    }
    catch { Append-Log ('[GUI] Codex納品ZIPの取り込みに失敗しました: '+$_.Exception.Message);Show-GuiMessage ('Codex納品ZIPを取り込めませんでした。'+[Environment]::NewLine+$_.Exception.Message) 'Codex納品ZIPを取り込む' }
    finally { Update-CodexButtonState }
}

function Show-DirectProjectFolderOpenDialog {
    if ($script:busy) { return $false }
    $picker=New-Object System.Windows.Forms.FolderBrowserDialog
    $picker.Description='GitHub・Codexで管理しているプロジェクトフォルダーを選択してください。sourceまたはtargetを選んだ場合は親へ補正します。'
    $picker.ShowNewFolderButton=$false
    if ($null -ne $script:selectedProjectInfo -and (Test-Path -LiteralPath ([string]$script:selectedProjectInfo.ProjectDirectory) -PathType Container)) {
        $picker.SelectedPath=[string]$script:selectedProjectInfo.ProjectDirectory
    }
    try {
        if ($picker.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { return $false }
        $check=Get-ProjectFolderCheckFromCli -Path ([string]$picker.SelectedPath)
        if (-not [bool]$check.IsAvailable) {
            Show-GuiMessage ((@('選択したフォルダーをプロジェクトとして利用できません。','',('選択：'+[string]$check.RequestedPath),('判定：'+[string]$check.ProjectRoot),'')+@($check.Errors)) -join [Environment]::NewLine) 'プロジェクトフォルダー' ([System.Windows.Forms.MessageBoxIcon]::Error)
            return $false
        }
        $selectedWorkbook=''
        if ([string]$check.WorkbookSelectionStatus -eq 'Multiple') {
            $bookPicker=New-Object System.Windows.Forms.OpenFileDialog
            try {
                $bookPicker.Title='対象ブックを選択してください'
                $bookPicker.InitialDirectory=[string]$check.TargetDirectory
                $bookPicker.Filter='Excel VBAブック (*.xlsm;*.xlam;*.xlsb)|*.xlsm;*.xlam;*.xlsb'
                $bookPicker.Multiselect=$false
                if ($bookPicker.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { return $false }
                $selectedWorkbook=[string]$bookPicker.FileName
                $check=Get-ProjectFolderCheckFromCli -Path ([string]$check.ProjectRoot) -WorkbookPath $selectedWorkbook
            }
            finally { $bookPicker.Dispose() }
        }
        $workbookText=if([string]::IsNullOrWhiteSpace([string]$check.WorkbookPath)){'（対象ブックなし。選択だけ保存します）'}else{[string]$check.WorkbookPath}
        $correctionText=if([bool]$check.Corrected){[Environment]::NewLine+[Environment]::NewLine+[string]$check.CorrectionMessage}else{''}
        $message=@(
            'このプロジェクトフォルダーを開きますか？','',
            ('プロジェクト：'+[string]$check.ProjectName),
            ('ルート：'+[string]$check.ProjectRoot),
            ('source：'+[string]$check.SourcePath),
            ('target：'+[string]$check.TargetDirectory),
            ('対象ブック：'+$workbookText),
            ('manifest：'+[string]$check.ManifestPath),
            ('Git管理：'+$(if([bool]$check.IsGitRepository){'あり'}else{'なし'})),
            $correctionText,'','フォルダーやファイルの移動、コピー、Git操作は行いません。'
        ) -join [Environment]::NewLine
        $answer=[System.Windows.Forms.MessageBox]::Show($message,'プロジェクトフォルダーを開く',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question)
        if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { return $false }
        $arguments=@('-Path',[string]$check.ProjectRoot)
        if (-not [string]::IsNullOrWhiteSpace([string]$check.WorkbookPath)) { $arguments += @('-WorkbookPath',[string]$check.WorkbookPath) }
        Invoke-ProjectRootSettingCliSynchronously -Command 'project-folder-set' -Arguments $arguments
        Refresh-ProjectRootAndProjects -PreferredProject ([System.IO.Path]::GetFileName([string]$check.ProjectRoot)) -StrictSelection
        $script:startupFailure=$null
        Append-Log ('[GUI] プロジェクトフォルダーを直接開きました: '+[string]$check.ProjectRoot)
        if ([bool]$check.Corrected) { Append-Log ('[GUI] '+[string]$check.CorrectionMessage) }
        return $true
    }
    catch {
        Append-Log ('[GUI] プロジェクトフォルダーを開けませんでした: '+$_.Exception.Message)
        Show-GuiMessage $_.Exception.Message 'プロジェクトフォルダーを開けません' ([System.Windows.Forms.MessageBoxIcon]::Error)
        return $false
    }
    finally { $picker.Dispose() }
}

function Unregister-SelectedProjectFromGui {
    if($cmbProject.SelectedItem-eq$null){throw '登録解除するプロジェクトを選択してください。'}
    $name=[string]$cmbProject.SelectedItem
    $folder=if($null-ne$script:selectedProjectInfo){[string]$script:selectedProjectInfo.ProjectDirectory}else{[string]$script:registeredProjectFolders[$name]}
    $message="登録情報だけを解除します。`r`n`r`nプロジェクト：$name`r`nフォルダー：$folder`r`n`r`nプロジェクトフォルダーとファイルは削除しません。"
    if([System.Windows.Forms.MessageBox]::Show($message,'プロジェクトの登録解除',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Warning)-ne[System.Windows.Forms.DialogResult]::Yes){return}
    Invoke-ProjectRootSettingCliSynchronously -Command 'project-unregister' -Arguments @('-Project',$name)
    Refresh-ProjectRootAndProjects
    Show-GuiMessage '登録情報を解除しました。プロジェクトフォルダーは削除していません。' '登録解除'
}

function Relocate-SelectedProjectFromGui {
    $name=if($cmbProject.SelectedItem-ne$null){[string]$cmbProject.SelectedItem}else{''}
    $oldFolder=if($null-ne$script:selectedProjectInfo){[string]$script:selectedProjectInfo.ProjectDirectory}elseif(-not[string]::IsNullOrWhiteSpace($name)){[string]$script:registeredProjectFolders[$name]}else{''}
    $picker=New-Object System.Windows.Forms.FolderBrowserDialog
    try{
        $picker.Description='移動後の開発プロジェクトフォルダーを選択してください。VBAUpdaterはフォルダーを移動しません。'
        $picker.ShowNewFolderButton=$false
        if(Test-Path -LiteralPath $oldFolder -PathType Container){$picker.SelectedPath=$oldFolder}
        if($picker.ShowDialog($form)-ne[System.Windows.Forms.DialogResult]::OK){return}
        $newFolder=[string]$picker.SelectedPath
        $check=Get-ProjectFolderCheckFromCli -Path $newFolder
        if(-not[bool]$check.IsAvailable){throw ('移動後のプロジェクトフォルダーを利用できません: '+(@($check.Errors)-join ' / '))}
        if([string]::IsNullOrWhiteSpace($name)){$name=[string]$check.ProjectName}
        $message="projects.jsonの登録先を変更します。`r`n`r`nプロジェクト：$name`r`n現在：$oldFolder`r`n変更後：$newFolder`r`n`r`nフォルダーやファイルの移動は行いません。"
        if([System.Windows.Forms.MessageBox]::Show($message,'登録先を変更',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question)-ne[System.Windows.Forms.DialogResult]::Yes){return}
        Invoke-ProjectRootSettingCliSynchronously -Command 'project-relocate' -Arguments @('-Project',$name,'-ProjectFolder',$newFolder)
        Refresh-ProjectRootAndProjects -PreferredProject $name -StrictSelection
        Show-GuiMessage '移動後のフォルダーへ登録先を変更しました。' '登録先を変更'
    }
    finally{$picker.Dispose()}
}

$btnChangeProjectRoot = Add-OperationButton $projectPanel '変更する' {
    Show-ProjectRootChangeDialog
} 100
$btnChangeProjectRoot.Height = 32
$toolTip.SetToolTip($btnChangeProjectRoot,'プロジェクト保存先を選択します。既存プロジェクトは自動移動しません。')

$btnOpenDirectProject = Add-OperationButton $projectPanel 'プロジェクトフォルダを開く' {
    [void](Show-DirectProjectFolderOpenDialog)
} 210
$btnOpenDirectProject.Height=32
$toolTip.SetToolTip($btnOpenDirectProject,'project.json、source、targetを持つ個別プロジェクトフォルダーを直接選択します。')

$btnRelocateProject = Add-OperationButton $projectPanel '登録先を変更' {
    Relocate-SelectedProjectFromGui
} 135
$btnRelocateProject.Height=32
$toolTip.SetToolTip($btnRelocateProject,'プロジェクトを外部で移動した後、projects.jsonの登録先だけを変更します。')

$btnUnregisterProject = Add-OperationButton $projectPanel '登録解除' {
    Unregister-SelectedProjectFromGui
} 105
$btnUnregisterProject.Height=32
$toolTip.SetToolTip($btnUnregisterProject,'projects.jsonから登録情報だけを削除します。プロジェクトフォルダーは削除しません。')

$btnResetProjectRoot = Add-OperationButton $projectPanel '既定に戻す' {
    Reset-ProjectRootFromGui
} 110
$btnResetProjectRoot.Height = 32
$toolTip.SetToolTip($btnResetProjectRoot,'%USERPROFILE%\Developmentを既定のProject Rootとしてsettings.jsonへ保存します。登録一覧は保持します。')
$projectPanel.SetFlowBreak($btnResetProjectRoot,$true)

$lblProjectRootStatusCaption = New-Object System.Windows.Forms.Label
$lblProjectRootStatusCaption.Text = '状態'
$lblProjectRootStatusCaption.AutoSize = $true
$lblProjectRootStatusCaption.Margin = New-Object System.Windows.Forms.Padding(4,8,8,0)
$projectPanel.Controls.Add($lblProjectRootStatusCaption)

$lblProjectRootStatusValue = New-Object System.Windows.Forms.Label
$lblProjectRootStatusValue.Text = '-'
$lblProjectRootStatusValue.AutoSize = $true
$lblProjectRootStatusValue.Margin = New-Object System.Windows.Forms.Padding(0,8,0,0)
$projectPanel.Controls.Add($lblProjectRootStatusValue)

$btnUpdateBook = Add-OperationButton $primaryPanel 'ブックを更新する' {
    $message = New-BookUpdateConfirmationMessage
    if ($null -ne $message) {
        Invoke-ProjectCommand -Command 'project-sync' -ConfirmMessage $message
    }
} 220
$btnUpdateBook.Height = 52
$btnUpdateBook.Font = New-Object System.Drawing.Font('Yu Gothic UI', 11, [System.Drawing.FontStyle]::Bold)
$toolTip.SetToolTip($btnUpdateBook, '更新前の安全確認、復元ポイント作成、必要部分の更新、更新後の確認、履歴記録を自動で行います。')
$workbookRequiredButtons.Add($btnUpdateBook)

$btnCreateProject = Add-OperationButton $primaryPanel '開発プロジェクトを登録' {
    Show-ProjectRegistrationWizard
} 230
$btnCreateProject.Height = 44
$toolTip.SetToolTip($btnCreateProject, 'GitHub・Codexと共有する既存フォルダーとExcelブックを登録します。')

$script:btnOpenTarget = Add-OperationButton $primaryPanel '対象ブックを開く' {
    if ($null -eq $script:selectedProjectInfo -or [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.TargetPath)) {
        throw '対象ブックが選択されていません。'
    }
    if (-not (Test-Path -LiteralPath $script:selectedProjectInfo.TargetPath -PathType Leaf)) {
        throw "対象ブックが見つかりません: $($script:selectedProjectInfo.TargetPath)"
    }
    Start-Process -FilePath $script:selectedProjectInfo.TargetPath | Out-Null
} 170
$script:btnOpenTarget.Height = 44

$btnOpenProjectFolder = Add-OperationButton $primaryPanel 'フォルダーを開く' {
    if ($null -ne $script:selectedProjectInfo) {
        $path = [string]$script:selectedProjectInfo.ProjectDirectory
        if (-not (Test-Path -LiteralPath $path -PathType Container)) { throw "プロジェクトフォルダーが見つかりません: $path" }
        Start-Process -FilePath 'explorer.exe' -ArgumentList (Quote-ProcessArgument $path) | Out-Null
    }
} 150
$btnOpenProjectFolder.Height = 44

[void](Add-OperationButton $referencePanel '状態確認' { Invoke-ProjectCommand 'status' } 158)
[void](Add-OperationButton $referencePanel '整合性検証' { Invoke-ProjectCommand 'integrity' } 158)
[void](Add-OperationButton $referencePanel '差分確認' { Invoke-ProjectCommand 'project-diff' } 158)
[void](Add-OperationButton $referencePanel '履歴表示' { Invoke-ProjectCommand 'history' } 158)
[void](Add-OperationButton $referencePanel '復元ポイント一覧' { Invoke-ProjectCommand 'rollback-list' } 158)
[void](Add-OperationButton $referencePanel 'プロジェクトフォルダーを開く' {
    if ($null -ne $script:selectedProjectInfo) {
        $path = [string]$script:selectedProjectInfo.ProjectDirectory
        if (-not (Test-Path -LiteralPath $path -PathType Container)) { throw "プロジェクトフォルダーが見つかりません: $path" }
        Start-Process -FilePath 'explorer.exe' -ArgumentList (Quote-ProcessArgument $path) | Out-Null
    }
} 224)

$btnDeveloperPull=Add-OperationButton $sourcePanel 'ブックからソースを取得' {
    Invoke-DangerousProjectCommand -Command 'project-pull' -Operation 'ブックからソースを取得' -ChangeTarget 'sourceフォルダー'
} 190
$workbookRequiredButtons.Add($btnDeveloperPull)

$btnDeveloperPush=Add-OperationButton $bookPanel 'ソースをブックへ反映' {
    Invoke-DangerousProjectCommand -Command 'project-push' -Operation 'ソースをブックへ反映' -ChangeTarget '対象ブック'
} 190
$workbookRequiredButtons.Add($btnDeveloperPush)
$btnDeveloperSync=Add-OperationButton $bookPanel '安全なブック更新' {
    Invoke-DangerousProjectCommand -Command 'project-sync' -Operation '安全なブック更新' -ChangeTarget '対象ブック'
} 190
$workbookRequiredButtons.Add($btnDeveloperSync)
$btnDeveloperRollback=Add-OperationButton $bookPanel '最新復元ポイントへ戻す' {
    Invoke-DangerousProjectCommand -Command 'rollback' -Operation '最新復元ポイントへ戻す' -ChangeTarget '対象ブック' -Extra @('-RestorePoint','latest','-Apply') -RollbackWarning
} 224
$workbookRequiredButtons.Add($btnDeveloperRollback)

$script:btnCodexExport = Add-OperationButton $codexPanel 'Codex用ZIPを作成' { Show-CodexExportFromGui } 220
$script:btnCodexPreview = Add-OperationButton $codexPanel 'Codex納品ZIPを確認' { Show-CodexImportPreviewFromGui } 220
$script:btnCodexImport = Add-OperationButton $codexPanel 'Codex納品ZIPを取り込む' { Import-CodexZipFromGui } 220
$toolTip.SetToolTip($script:btnCodexExport,'選択中の外部プロジェクトからCodex開発用ZIPを安全に作成します。')
$toolTip.SetToolTip($script:btnCodexPreview,'Codexから返却されたZIPを安全に検証し、追加・変更・削除候補を確認します。')
$toolTip.SetToolTip($script:btnCodexImport,'確認済みZIPだけを、バックアップ作成後にsourceへ反映します。')
Update-CodexButtonState

$btnToggleLog = Add-OperationButton $logPanel '▶ 詳細ログを表示' {
    $logBox.Visible = -not $logBox.Visible
    $btnToggleLog.Text = $(if ($logBox.Visible) { '▼ 詳細ログを隠す' } else { '▶ 詳細ログを表示' })
} 180
[void](Add-OperationButton $logPanel 'ログをコピー' {
    if ([string]::IsNullOrEmpty($logBox.Text)) {
        Show-GuiMessage 'コピーするログがありません。' 'ログをコピー'
        return
    }
    [System.Windows.Forms.Clipboard]::SetText($logBox.Text)
    Show-GuiMessage '画面ログをクリップボードへコピーしました。' 'ログをコピー'
} 120)
[void](Add-OperationButton $logPanel 'ログフォルダーを開く' {
    $directory = Get-GuiLogDirectory
    Start-Process -FilePath 'explorer.exe' -ArgumentList (Quote-ProcessArgument $directory) | Out-Null
} 160)
[void](Add-OperationButton $logPanel '最新ログを開く' {
    $directory = Get-GuiLogDirectory
    $latest = Get-ChildItem -LiteralPath $directory -Filter '*.log' -File -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1
    if ($null -eq $latest) {
        Show-GuiMessage 'GUIログはまだありません。' '最新ログを開く'
        return
    }
    Start-Process -FilePath $latest.FullName | Out-Null
} 140)

[void](Add-OperationButton $developerLogPanel 'ログをクリア' {
    $logBox.Clear()
    $developerLogBox.Clear()
} 130)
[void](Add-OperationButton $developerLogPanel 'ログをコピー' {
    if ([string]::IsNullOrEmpty($developerLogBox.Text)) {
        Show-GuiMessage 'コピーするログがありません。' 'ログをコピー'
        return
    }
    [System.Windows.Forms.Clipboard]::SetText($developerLogBox.Text)
    Show-GuiMessage '画面ログをクリップボードへコピーしました。' 'ログをコピー'
} 130)
[void](Add-OperationButton $developerLogPanel 'ログフォルダーを開く' {
    $directory = Get-GuiLogDirectory
    Start-Process -FilePath 'explorer.exe' -ArgumentList (Quote-ProcessArgument $directory) | Out-Null
} 170)
[void](Add-OperationButton $developerLogPanel '最新ログを開く' {
    $directory = Get-GuiLogDirectory
    $latest = Get-ChildItem -LiteralPath $directory -Filter '*.log' -File -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1
    if ($null -eq $latest) {
        Show-GuiMessage 'GUIログはまだありません。' '最新ログを開く'
        return
    }
    Start-Process -FilePath $latest.FullName | Out-Null
} 140)

function Select-RegisteredProject {
    param([Parameter(Mandatory=$true)][string]$ProjectName)
    Refresh-ProjectRootAndProjects -PreferredProject $ProjectName -StrictSelection
    $index = $cmbProject.Items.IndexOf($ProjectName)
    if ($index -lt 0) { throw "作成したプロジェクトを一覧から選択できません: $ProjectName" }
    $cmbProject.SelectedIndex = $index
    Update-ProjectInformation -PreserveStatus
}

function Refresh-ProjectRootInfo {
    $script:projectRootInfo = Get-ProjectRootInfoFromCli
    $lblProjectRootValue.Text = [string]$script:projectRootInfo.Path
    $toolTip.SetToolTip($lblProjectRootValue,[string]$script:projectRootInfo.Path)
    $lblSettingsFolderValue.Text=[string]$script:projectRootInfo.SettingsFolder
    $toolTip.SetToolTip($lblSettingsFolderValue,[string]$script:projectRootInfo.SettingsFolder)
    if ([bool]$script:projectRootInfo.Exists) {
        $lblProjectRootStatusValue.Text = '✓ 利用可能'
        $lblProjectRootStatusValue.ForeColor = [System.Drawing.Color]::DarkGreen
    }
    else {
        $lblProjectRootStatusValue.Text = '× 保存先が見つかりません'
        $lblProjectRootStatusValue.ForeColor = [System.Drawing.Color]::DarkRed
    }
    if (-not [string]::IsNullOrWhiteSpace([string]$script:projectRootInfo.Warning)) {
        Append-Log ('[GUI] 警告: ' + [string]$script:projectRootInfo.Warning)
    }
    if ($script:projectRootInfo.PSObject.Properties['LegacyMigrationRequired'] -and [bool]$script:projectRootInfo.LegacyMigrationRequired) {
        Append-Log ("[GUI] Ver4.17以前のVBAUpdater専用projectフォルダーに{0}件あります。移行ウィザードの対象です。" -f [int]$script:projectRootInfo.InternalProjectCount)
    }
    return $script:projectRootInfo
}

function Refresh-ProjectRootAndProjects {
    param([string]$PreferredProject,[switch]$StrictSelection)
    $script:lastCodexPreview = $null
    $script:lastCodexZipPath = $null
    [void](Refresh-ProjectRootInfo)
    Refresh-Projects -PreferredProject $PreferredProject -StrictSelection:$StrictSelection
    Update-CodexButtonState
}

function Refresh-Projects {
    param([string]$PreferredProject,[switch]$StrictSelection)
    $previous = if (-not [string]::IsNullOrWhiteSpace($PreferredProject)) {
        $PreferredProject
    }
    elseif ($cmbProject.SelectedItem -ne $null) {
        [string]$cmbProject.SelectedItem
    }
    elseif ($null -ne $script:projectRootInfo -and $script:projectRootInfo.PSObject.Properties['LastProjectRoot'] -and
        -not [string]::IsNullOrWhiteSpace([string]$script:projectRootInfo.LastProjectRoot) -and [bool]$script:projectRootInfo.LastProjectExists) {
        [System.IO.Path]::GetFileName([string]$script:projectRootInfo.LastProjectRoot)
    }
    else { $Project }
    $script:refreshingProjects = $true
    try {
        $cmbProject.Items.Clear()
        foreach ($name in @(Get-ProjectNames)) { [void]$cmbProject.Items.Add($name) }
        $lblProjectCount.Text = ($cmbProject.Items.Count.ToString() + '件')
        if ($cmbProject.Items.Count -eq 0) {
            Reset-ProjectInformation
            $lblInfoMessageValue.Text = 'projects.jsonに利用可能な登録済みプロジェクトがありません。「開発プロジェクトを登録」から追加できます。'
            Set-CurrentStatus '警告あり'
            return
        }
        $index = -1
        if (-not [string]::IsNullOrWhiteSpace($previous)) { $index = $cmbProject.Items.IndexOf($previous) }
        if ($index -ge 0) { $cmbProject.SelectedIndex = $index }
        elseif ($StrictSelection) {
            $cmbProject.SelectedIndex = -1
            Reset-ProjectInformation
            $lblInfoMessageValue.Text = '以前選択していたプロジェクトは新しい保存先にありません。'
        }
        else { $cmbProject.SelectedIndex = 0 }
    }
    finally {
        $script:refreshingProjects = $false
    }
    if ($cmbProject.SelectedIndex -ge 0) { Update-ProjectInformation }
}

$btnRefresh.Add_Click({
    try {
        $preferred = if ($cmbProject.SelectedItem -ne $null) { [string]$cmbProject.SelectedItem } else { $null }
        Refresh-ProjectRootAndProjects -PreferredProject $preferred
    }
    catch {
        Append-Log ('[GUI] プロジェクト再読込に失敗しました: ' + $_.Exception.Message)
        Set-CurrentStatus 'エラーあり'
        $lblInfoMessageValue.Text = $_.Exception.Message
    }
})

$cmbProject.Add_SelectedIndexChanged({
    if ($script:refreshingProjects -or $script:busy) { return }
    try {
        $script:lastCodexPreview = $null
        $script:lastCodexZipPath = $null
        Update-ProjectInformation
        Update-CodexButtonState
    }
    catch {
        Append-Log ('[GUI] プロジェクト情報更新に失敗しました: ' + $_.Exception.Message)
        Set-CurrentStatus 'エラーあり'
        $lblInfoMessageValue.Text = $_.Exception.Message
    }
})

function Apply-PersistedGuiSettings {
    if($null-eq$script:settingsInfo-or$null-eq$script:settingsInfo.Gui){return}
    $width=[Math]::Max(940,[int]$script:settingsInfo.Gui.windowWidth)
    $height=[Math]::Max(820,[int]$script:settingsInfo.Gui.windowHeight)
    $form.Size=New-Object System.Drawing.Size($width,$height)
    if([string]$script:settingsInfo.Gui.windowState-eq'Maximized'){$form.WindowState=[System.Windows.Forms.FormWindowState]::Maximized}
}

function Save-PersistedGuiSettings {
    $bounds=if($form.WindowState-eq[System.Windows.Forms.FormWindowState]::Normal){$form.Bounds}else{$form.RestoreBounds}
    $state=if($form.WindowState-eq[System.Windows.Forms.FormWindowState]::Maximized){'Maximized'}else{'Normal'}
    Invoke-ProjectRootSettingCliSynchronously -Command 'settings-gui-set' -Arguments @('-Width',[string]$bounds.Width,'-Height',[string]$bounds.Height,'-WindowState',$state)
}

$form.Add_FormClosing({
    param($sender, $eventArgs)
    if ($script:busy -and $null -ne $script:process -and -not $script:process.HasExited) {
        $answer = [System.Windows.Forms.MessageBox]::Show(
            '処理が実行中です。終了すると実行中の処理を中断します。GUIを終了しますか？',
            '終了確認',
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Warning)
        if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
            $eventArgs.Cancel = $true
            return
        }
        Clear-CliRuntime $true
    }
    else {
        Clear-CliRuntime $false
    }
    try{Save-PersistedGuiSettings}catch{Append-Log ('[GUI] GUI設定を保存できませんでした: '+$_.Exception.Message)}
    $script:pollTimer.Stop()
    $script:pollTimer.Dispose()
})

Reset-ProjectInformation
Append-Log ('VBA Project Update System GUI Ver' + $script:ProductVersion)
Append-Log 'プロジェクトを選択し、「ブックを更新する」をクリックしてください。'
try { Trim-GuiLogs } catch { Append-Log ('[GUI] 警告: GUIログ整理に失敗しました: ' + $_.Exception.Message) }
$script:startupFailure = $null
try { Refresh-ProjectRootAndProjects } catch {
    $script:startupFailure = $_.Exception.Message
    Append-Log ('[GUI] 初期情報の読込に失敗しました: ' + $_.Exception.Message)
    if ($null -eq $script:projectRootInfo) {
        $lblProjectRootStatusValue.Text = '× 保存先を確認できません'
        $lblProjectRootStatusValue.ForeColor = [System.Drawing.Color]::DarkRed
    }
    Set-CurrentStatus 'エラーあり'
    $lblInfoMessageValue.Text = $_.Exception.Message
}
$skipStartupRecovery = $RenewalSelfTest -or $RegistrationSelfTest -or $RegistrationHotFixSelfTest -or
    $ProjectRootSelfTest -or $ProjectRootMigrationSelfTest -or $CodexIntegrationSelfTest -or $DirectReferenceSelfTest -or $UsabilitySelfTest
if (-not $skipStartupRecovery -and $null -ne $script:projectRootInfo -and [bool]$script:projectRootInfo.RecoveryRequired) {
    $recovered = Invoke-ProjectRootStartupRecovery
    if (-not $recovered) {
        $script:pollTimer.Stop()
        $script:pollTimer.Dispose()
        $form.Dispose()
        exit 0
    }
}
try{Apply-PersistedGuiSettings}catch{Append-Log ('[GUI] GUI設定を復元できませんでした: '+$_.Exception.Message)}
if (-not $skipStartupRecovery -and $null -ne $script:projectRootInfo -and
    $script:projectRootInfo.PSObject.Properties['LegacyMigrationRequired'] -and [bool]$script:projectRootInfo.LegacyMigrationRequired) {
    [void](Invoke-LegacyProjectMigrationWizard)
}
if ($DirectReferenceSelfTest) {
    $selfTestExitCode=0
    try {
        if (-not [string]::IsNullOrWhiteSpace($script:startupFailure)) { throw ('直接参照GUIの初期読込に失敗しました: '+$script:startupFailure) }
        if ($lblVersion.Text -ne ('Ver' + $script:ProductVersion)) { throw '直接参照GUIのバージョン表示が一致しません。' }
        if ($null -eq $btnOpenDirectProject -or $btnOpenDirectProject.Text -ne 'プロジェクトフォルダを開く' -or $operationButtons.IndexOf($btnOpenDirectProject) -lt 0) { throw '直接参照ボタンを初期化できませんでした。' }
        if ($null -eq $script:selectedProjectInfo -or [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.ProjectRoot)) { throw '保存済みの直接プロジェクトを復元できませんでした。' }
        if ($lblDirectProjectRootValue.Text -ne [string]$script:selectedProjectInfo.ProjectRoot -or $lblSourceFolderValue.Text -ne [string]$script:selectedProjectInfo.SourcePath -or $lblTargetFolderValue.Text -ne [string]$script:selectedProjectInfo.TargetDirectory) { throw '直接プロジェクトの共通判定結果がGUI表示と一致しません。' }
        if ($lblGitValue.Text -notmatch 'Git管理あり' -or $lblDirectStatusValue.Text -notmatch '利用可能|前回選択を復元') { throw 'Git管理または利用可否表示が一致しません。' }
        if ($null-eq$script:selectedProjectInfo.TargetFingerprint -or [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.TargetFingerprint.Sha256)) { throw '対象ブックの選択時fingerprintを保持できませんでした。' }
        if (-not $btnUpdateBook.Enabled -or -not $script:btnOpenTarget.Enabled) { throw '利用可能な直接プロジェクトの操作ボタンが有効ではありません。' }
        Write-Host '  [OK] Windows PowerShell 5.1で直接プロジェクトの起動復元、詳細表示、ボタン状態を確認しました。'
    }
    catch { Write-Error $_.Exception.Message;$selfTestExitCode=1 }
    finally { $script:pollTimer.Stop();$script:pollTimer.Dispose();$form.Dispose() }
    exit $selfTestExitCode
}
if ($CodexIntegrationSelfTest) {
    $selfTestExitCode = 0
    try {
        if (-not [string]::IsNullOrWhiteSpace($script:startupFailure)) { throw ('Codex連携GUIの初期読込に失敗しました: ' + $script:startupFailure) }
        Invoke-GuiCodexIntegrationSelfTest
        if ($lblVersion.Text -ne ('Ver' + $script:ProductVersion)) { throw 'Codex連携GUIのバージョン表示が一致しません。' }
        if ($codexPanel.Parent.Text -ne 'Codex連携') { throw '開発者向けCodex連携グループを初期化できませんでした。' }
        foreach ($button in @($script:btnCodexExport,$script:btnCodexPreview,$script:btnCodexImport)) {
            if ($null -eq $button -or $operationButtons.IndexOf($button) -lt 0) { throw 'Codex連携ボタンが操作中ロック対象に登録されていません。' }
        }
        if ($cmbProject.Items.Count -gt 0) {
            if (-not $script:btnCodexExport.Enabled -or -not $script:btnCodexPreview.Enabled) { throw 'プロジェクト選択時にCodex作成・確認ボタンが有効ではありません。' }
            if ($script:btnCodexImport.Enabled) { throw 'プレビュー前にCodex取込ボタンが有効です。' }
        }
        $emptyProbe = Invoke-CodexCliJson -Command 'codex-import-preview' -ProjectName '' -ZipPath ''
        if ($null -ne $emptyProbe) { throw '空文字Pathプローブが処理を開始しました。' }
        Write-Host '  [OK] Windows PowerShell 5.1でCodex連携GUI、ボタン状態、空Path回帰を確認しました。'
    }
    catch { Write-Error $_.Exception.Message; $selfTestExitCode = 1 }
    finally { $script:pollTimer.Stop(); $script:pollTimer.Dispose(); $form.Dispose() }
    exit $selfTestExitCode
}
if ($RenewalSelfTest) {
    $selfTestExitCode = 0
    try {
        Invoke-GuiRenewalSelfTest
        if ($tabs.SelectedIndex -ne 0 -or $tabs.SelectedTab -ne $standardTab) {
            throw '初期表示が「ブック更新」タブではありません。'
        }
        if ($btnUpdateBook.Text -ne 'ブックを更新する') {
            throw '一般利用者向け主ボタンを初期化できませんでした。'
        }
        if ($logBox.Visible) {
            throw '一般利用者向け詳細ログが初期状態で折りたたまれていません。'
        }
        if ($cmbProject.Items.Count -gt 0 -and $cmbProject.SelectedIndex -lt 0) {
            throw 'プロジェクトが自動選択されていません。'
        }
        if (-not [string]::IsNullOrWhiteSpace($Project) -and
            -not [string]::Equals([string]$cmbProject.SelectedItem, $Project, [System.StringComparison]::OrdinalIgnoreCase)) {
            throw "起動引数で指定したプロジェクトが選択されていません: $Project"
        }
        $targetExists = $false
        if ($null -ne $script:selectedProjectInfo -and
            -not [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.TargetPath) -and
            [string]$script:selectedProjectInfo.TargetPath -ne '-') {
            $targetExists = Test-Path -LiteralPath ([string]$script:selectedProjectInfo.TargetPath) -PathType Leaf
            if ($toolTip.GetToolTip($lblTargetPathValue) -ne [string]$script:selectedProjectInfo.TargetPath) {
                throw '対象ブックのフルパスを確認するToolTipが設定されていません。'
            }
        }
        if ($script:btnOpenTarget.Enabled -ne $targetExists) {
            throw '「対象ブックを開く」ボタンの有効状態がファイル存在状態と一致しません。'
        }
        Write-Host '  [OK] Windows PowerShell 5.1でGUI構成、初期タブ、自動選択、ログ初期状態を確認しました。'
    }
    catch {
        Write-Error $_.Exception.Message
        $selfTestExitCode = 1
    }
    finally {
        $script:pollTimer.Stop()
        $script:pollTimer.Dispose()
        $form.Dispose()
    }
    exit $selfTestExitCode
}
if ($RegistrationSelfTest) {
    $selfTestExitCode = 0
    try {
        Invoke-GuiRegistrationSelfTest
        if ($btnCreateProject.Text -ne '開発プロジェクトを登録') {
            throw '一般利用者向け画面に新規登録ボタンを初期化できませんでした。'
        }
        if ($operationButtons.IndexOf($btnCreateProject) -lt 0) {
            throw '新規登録ボタンが操作中ロック対象に登録されていません。'
        }
        Write-Host '  [OK] Windows PowerShell 5.1で初回登録GUIを初期化しました。'
    }
    catch {
        Write-Error $_.Exception.Message
        $selfTestExitCode = 1
    }
    finally {
        $script:pollTimer.Stop()
        $script:pollTimer.Dispose()
        $form.Dispose()
    }
    exit $selfTestExitCode
}
if ($RegistrationHotFixSelfTest) {
    $selfTestExitCode = 0
    try {
        Invoke-GuiRegistrationHotFixSelfTest
        Write-Host '  [OK] Windows PowerShell 5.1でChapter12-1 HotFix GUIテストを完了しました。'
    }
    catch {
        Write-Error $_.Exception.Message
        $selfTestExitCode = 1
    }
    finally {
        $script:pollTimer.Stop()
        $script:pollTimer.Dispose()
        $form.Dispose()
    }
    exit $selfTestExitCode
}
if ($ProjectRootMigrationSelfTest) {
    $selfTestExitCode = 0
    try {
        Invoke-GuiProjectRootMigrationSelfTest
        if ($operationButtons.IndexOf($btnChangeProjectRoot) -lt 0 -or $operationButtons.IndexOf($btnResetProjectRoot) -lt 0) {
            throw '保存先変更操作が操作中ロック対象に登録されていません。'
        }
        if ($ExpectedMigrationStatus -eq 'Missing') {
            if ($null -eq $script:projectRootInfo -or [bool]$script:projectRootInfo.Exists) { throw 'GUIが保存先喪失状態を保持していません。' }
            if ($lblProjectRootStatusValue.Text -ne '× 保存先が見つかりません') { throw 'GUIの保存先喪失表示が一致しません。' }
            if ($cmbProject.Items.Count -ne 0 -or $null -ne $script:selectedProjectInfo) { throw '保存先喪失時に古いプロジェクト選択が残っています。' }
        }
        elseif ($ExpectedMigrationStatus -eq 'OK') {
            if ($null -eq $script:projectRootInfo -or -not [bool]$script:projectRootInfo.Exists) { throw 'GUIが利用可能な保存先を認識していません。' }
            if ($lblProjectRootStatusValue.Text -ne '✓ 利用可能') { throw 'GUIの利用可能表示が一致しません。' }
        }
        Write-Host '  [OK] Windows PowerShell 5.1でProject Root Migration GUIを初期化しました。'
    }
    catch {
        Write-Error $_.Exception.Message
        $selfTestExitCode = 1
    }
    finally {
        $script:pollTimer.Stop()
        $script:pollTimer.Dispose()
        $form.Dispose()
    }
    exit $selfTestExitCode
}
if ($ProjectRootSelfTest) {
    $selfTestExitCode = 0
    try {
        if (-not [string]::IsNullOrWhiteSpace($script:startupFailure)) {
            throw ('外部プロジェクトルートの初期読込に失敗しました: ' + $script:startupFailure)
        }
        Invoke-GuiProjectRootSelfTest
        if ($null -eq $script:projectRootInfo -or [string]$lblProjectRootValue.Text -ne [string]$script:projectRootInfo.Path) {
            throw 'CLIで解決したプロジェクト保存先がGUIに表示されていません。'
        }
        if ($operationButtons.IndexOf($btnChangeProjectRoot) -lt 0 -or $operationButtons.IndexOf($btnResetProjectRoot) -lt 0) {
            throw '保存先変更ボタンが操作中ロック対象に登録されていません。'
        }
        $expectedNames = @(Get-ProjectNames)
        if ($cmbProject.Items.Count -ne $expectedNames.Count) {
            throw 'GUIのプロジェクト一覧が現在の保存先と一致しません。'
        }
        Write-Host ("  [OK] Windows PowerShell 5.1で外部プロジェクトルートGUIを初期化しました: {0}" -f $script:projectRootInfo.Path)
    }
    catch {
        Write-Error $_.Exception.Message
        $selfTestExitCode = 1
    }
    finally {
        $script:pollTimer.Stop()
        $script:pollTimer.Dispose()
        $form.Dispose()
    }
    exit $selfTestExitCode
}
if ($UsabilitySelfTest) {
    $script:pollTimer.Stop()
    $script:pollTimer.Dispose()
    $form.Dispose()
    if (-not [string]::IsNullOrWhiteSpace($script:startupFailure)) {
        Write-Error ('GUI Usabilityランタイムセルフテストに失敗しました: ' + $script:startupFailure)
        exit 1
    }
    Write-Host 'GUI Usabilityランタイムセルフテストに成功しました。'
    exit 0
}
[void]$form.ShowDialog()
