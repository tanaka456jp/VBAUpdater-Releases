﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function ConvertTo-ProjectRegistrationAbsolutePath {
    param(
        [AllowNull()][AllowEmptyString()][string]$Path,
        [Parameter(Mandatory=$true)][string]$Label
    )

    if ([string]::IsNullOrWhiteSpace($Path)) { throw "$Label を指定してください。" }
    $expanded = [Environment]::ExpandEnvironmentVariables($Path.Trim('"'))
    if (-not [System.IO.Path]::IsPathRooted($expanded)) { throw "$Label は絶対パスで指定してください: $expanded" }
    if ($expanded.IndexOfAny([System.IO.Path]::GetInvalidPathChars()) -ge 0) { throw "$Label に無効な文字が含まれています。" }
    try {
        return [System.IO.Path]::GetFullPath($expanded).TrimEnd(
            [System.IO.Path]::DirectorySeparatorChar,
            [System.IO.Path]::AltDirectorySeparatorChar)
    }
    catch { throw "$Label を解決できません: $($_.Exception.Message)" }
}

function Test-ProjectRegistrationPathsEqual {
    param([AllowNull()][string]$First,[AllowNull()][string]$Second)
    if ([string]::IsNullOrWhiteSpace($First) -or [string]::IsNullOrWhiteSpace($Second)) { return $false }
    try {
        return [string]::Equals(
            [System.IO.Path]::GetFullPath($First).TrimEnd('\','/'),
            [System.IO.Path]::GetFullPath($Second).TrimEnd('\','/'),
            [System.StringComparison]::OrdinalIgnoreCase)
    }
    catch { return $false }
}

function Get-ProjectRegistrationValidation {
    <#
      GUIとCLIが共有する開発プロジェクト登録Validationサービス。
      検証だけを行い、フォルダーやファイルは作成・変更しない。
    #>
    param(
        [AllowNull()][AllowEmptyString()][string]$ProjectFolder,
        [AllowNull()][AllowEmptyString()][string]$WorkbookPath,
        [AllowNull()][AllowEmptyString()][string]$ToolRoot
    )

    $errors = New-Object 'System.Collections.Generic.List[string]'
    $projectDirectory = ''
    $resolvedWorkbook = ''
    $projectName = ''
    $workbookFileName = ''
    $sourceDirectory = ''
    $targetDirectory = ''
    $targetPath = ''
    $manifestPath = ''

    try { $projectDirectory = ConvertTo-ProjectRegistrationAbsolutePath -Path $ProjectFolder -Label '開発プロジェクトフォルダ' }
    catch { $errors.Add($_.Exception.Message) }

    if (-not [string]::IsNullOrWhiteSpace($projectDirectory)) {
        if (Test-Path -LiteralPath $projectDirectory -PathType Leaf -ErrorAction SilentlyContinue) {
            $errors.Add("開発プロジェクトフォルダにファイルは指定できません: $projectDirectory")
        }
        elseif (-not (Test-Path -LiteralPath $projectDirectory -PathType Container -ErrorAction SilentlyContinue)) {
            $errors.Add("開発プロジェクトフォルダが見つかりません。自動作成は行いません: $projectDirectory")
        }
        else {
            $projectName = [System.IO.Path]::GetFileName($projectDirectory)
            if ([string]::IsNullOrWhiteSpace($projectName)) {
                $errors.Add('ドライブ直下は開発プロジェクトフォルダに指定できません。')
            }
            if (-not [string]::IsNullOrWhiteSpace($ToolRoot)) {
                try {
                    $resolvedToolRoot = [System.IO.Path]::GetFullPath($ToolRoot).TrimEnd('\','/')
                    if (Test-ProjectRegistrationPathsEqual $projectDirectory $resolvedToolRoot) {
                        $errors.Add('VBAUpdater本体フォルダーは開発プロジェクトフォルダに指定できません。')
                    }
                    foreach ($reservedName in @('addin','engine','tools','tests','test','config','logs','backups','project')) {
                        if (Test-ProjectRegistrationPathsEqual $projectDirectory (Join-Path $resolvedToolRoot $reservedName)) {
                            $errors.Add("VBAUpdater本体の管理フォルダーは開発プロジェクトフォルダに指定できません: $projectDirectory")
                            break
                        }
                    }
                }
                catch { $errors.Add("VBAUpdater本体とのパス関係を確認できません: $($_.Exception.Message)") }
            }
            $sourceDirectory = Join-Path $projectDirectory 'source'
            $targetDirectory = Join-Path $projectDirectory 'target'
            $manifestPath = Join-Path $projectDirectory 'project.json'
            if (Test-Path -LiteralPath $manifestPath -ErrorAction SilentlyContinue) {
                $errors.Add("この開発プロジェクトは既に登録されています: $manifestPath")
            }
            if (Test-Path -LiteralPath $sourceDirectory -ErrorAction SilentlyContinue) {
                $errors.Add("登録用のsourceフォルダーが既に存在します。既存データ保護のため上書きしません: $sourceDirectory")
            }
            if (Test-Path -LiteralPath $targetDirectory -ErrorAction SilentlyContinue) {
                $errors.Add("登録用のtargetフォルダーが既に存在します。既存データ保護のため上書きしません: $targetDirectory")
            }
        }
    }

    try { $resolvedWorkbook = ConvertTo-ProjectRegistrationAbsolutePath -Path $WorkbookPath -Label '管理対象Excelブック' }
    catch { $errors.Add($_.Exception.Message) }

    if (-not [string]::IsNullOrWhiteSpace($resolvedWorkbook)) {
        if (-not (Test-Path -LiteralPath $resolvedWorkbook -PathType Leaf -ErrorAction SilentlyContinue)) {
            $errors.Add("管理対象Excelブックが見つかりません: $resolvedWorkbook")
        }
        else {
            $extension = [System.IO.Path]::GetExtension($resolvedWorkbook).ToLowerInvariant()
            if ($extension -notin @('.xlsm','.xlsb','.xlam')) {
                $errors.Add("対応していないブック形式です: $extension（対応形式: .xlsm / .xlsb / .xlam）")
            }
            $workbookFileName = [System.IO.Path]::GetFileName($resolvedWorkbook)
            $stream = $null
            try {
                $stream = [System.IO.File]::Open($resolvedWorkbook,[System.IO.FileMode]::Open,[System.IO.FileAccess]::Read,[System.IO.FileShare]::ReadWrite)
                if ($stream.Length -le 0) { $errors.Add("管理対象Excelブックのファイルサイズが0です: $resolvedWorkbook") }
            }
            catch { $errors.Add("管理対象Excelブックを読み取れません: $resolvedWorkbook / 詳細: $($_.Exception.Message)") }
            finally { if ($null -ne $stream) { $stream.Dispose() } }
        }
    }

    if (-not [string]::IsNullOrWhiteSpace($targetDirectory) -and -not [string]::IsNullOrWhiteSpace($workbookFileName)) {
        $targetPath = Join-Path $targetDirectory $workbookFileName
        if (Test-ProjectRegistrationPathsEqual $resolvedWorkbook $targetPath) {
            $errors.Add('管理対象Excelブックは登録前のtargetフォルダー外から選択してください。')
        }
    }

    $message = if ($errors.Count -gt 0) { [string]$errors[0] } else { '' }
    return [PSCustomObject]@{
        SchemaVersion='1.0'
        IsValid=($errors.Count -eq 0)
        CanRegister=($errors.Count -eq 0)
        Message=$message
        Errors=@($errors.ToArray())
        ProjectFolder=$projectDirectory
        ProjectName=$projectName
        WorkbookPath=$resolvedWorkbook
        WorkbookFileName=$workbookFileName
        SourceDirectory=$sourceDirectory
        TargetDirectory=$targetDirectory
        TargetPath=$targetPath
        ManifestPath=$manifestPath
        IsGitRepository=(-not [string]::IsNullOrWhiteSpace($projectDirectory) -and (Test-Path -LiteralPath (Join-Path $projectDirectory '.git') -ErrorAction SilentlyContinue))
        IsOneDrive=(-not [string]::IsNullOrWhiteSpace($projectDirectory) -and $projectDirectory.IndexOf('OneDrive',[System.StringComparison]::OrdinalIgnoreCase) -ge 0)
    }
}

Export-ModuleMember -Function Get-ProjectRegistrationValidation,Test-ProjectRegistrationPathsEqual
