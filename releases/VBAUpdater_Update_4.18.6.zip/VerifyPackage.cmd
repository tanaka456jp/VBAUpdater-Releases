@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0VerifyPackage.ps1"
if errorlevel 1 pause
