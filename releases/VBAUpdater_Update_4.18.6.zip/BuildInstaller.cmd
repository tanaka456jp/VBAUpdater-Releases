@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0BuildInstaller.ps1"
set rc=%errorlevel%
if not "%rc%"=="0" (
  echo.
  echo Installer build failed. ErrorLevel=%rc%
  pause
)
exit /b %rc%
