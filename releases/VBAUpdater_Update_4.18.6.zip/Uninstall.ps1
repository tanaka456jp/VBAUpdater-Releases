﻿$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
Add-Type -AssemblyName System.Windows.Forms

$productName = 'VBAUpdater'
$installRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$desktop = [Environment]::GetFolderPath('Desktop')
$startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\VBAUpdater'
$uninstallKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\VBAUpdater'

try {
    $answer = [System.Windows.Forms.MessageBox]::Show(
        'VBAUpdaterをアンインストールしますか？',
        'VBAUpdater Uninstall',
        'YesNo',
        'Question'
    )
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { exit 0 }

    Remove-Item -LiteralPath (Join-Path $desktop 'VBAUpdater.lnk') -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $startMenu -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $uninstallKey -Recurse -Force -ErrorAction SilentlyContinue

    # The uninstaller cannot delete its own directory while running, so a temporary
    # cmd file removes the installed directory after PowerShell exits.
    $cleanup = Join-Path $env:TEMP ('VBAUpdaterCleanup_' + [guid]::NewGuid().ToString('N') + '.cmd')
    $cleanupLines = @(
        '@echo off',
        'ping 127.0.0.1 -n 3 >nul',
        ('rmdir /s /q "' + $installRoot.Replace('%','%%') + '"'),
        'del /q "%~f0"'
    )
    [System.IO.File]::WriteAllLines($cleanup, $cleanupLines, [System.Text.Encoding]::ASCII)
    Start-Process -FilePath $cleanup -WindowStyle Hidden

    [System.Windows.Forms.MessageBox]::Show(
        'VBAUpdaterをアンインストールしました。',
        'VBAUpdater Uninstall',
        'OK',
        'Information'
    ) | Out-Null
    exit 0
}
catch {
    [System.Windows.Forms.MessageBox]::Show(
        "アンインストールに失敗しました。`r`n`r`n$($_.Exception.Message)",
        'VBAUpdater Uninstall',
        'OK',
        'Error'
    ) | Out-Null
    exit 1
}
