﻿VBAUpdater Ver1.0

ProductVersion: 4.18.6

Windows Standard UI
- ホーム
- GitHub
- 履歴
- 設定
- 開発者

Chapter5-1_01ではRelease Candidate検証工程を整理しています。
アプリ本体の機能基準はChapter4-2 FINALから変更ありません。

初めて利用する場合は START_HERE.txt を確認してください。

Build ID: VBAUpdater_V4.18.6_RC2
