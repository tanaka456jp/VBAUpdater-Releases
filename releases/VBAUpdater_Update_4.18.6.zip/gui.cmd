@echo off
setlocal
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0gui.ps1" %*
exit /b %ERRORLEVEL%
