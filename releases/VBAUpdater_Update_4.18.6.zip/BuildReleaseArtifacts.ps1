$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$root = $PSScriptRoot
$buildVersionFile = Join-Path $root 'BUILD_VERSION.txt'
if (-not (Test-Path -LiteralPath $buildVersionFile -PathType Leaf)) { throw 'BUILD_VERSION.txt not found.' }
$build = ([System.IO.File]::ReadAllText($buildVersionFile)).Trim()

$productVersionFile = Join-Path $root 'App\VERSION.txt'
$productVersion = ([System.IO.File]::ReadAllText($productVersionFile)).Trim()

$dist = Join-Path $root 'dist'

Write-Host "=== Release Update ZIP Generation: $productVersion ===" -ForegroundColor Cyan

# Development ZIP generation (without RC2 suffix)
Write-Host "Generating update ZIP..." -ForegroundColor Yellow

$updateZipName = "VBAUpdater_Update_{0}.zip" -f $productVersion
$updateZipPath = Join-Path $dist $updateZipName

$tempDirPath = Join-Path $env:TEMP ("VBAUpdater_Release_Artifacts_" + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $tempDirPath | Out-Null
$tempDir = Get-Item -LiteralPath $tempDirPath

$excludeDirs = @('dist', '.git', 'logs', 'backups', 'tests')
$excludePatterns = @(
    '*.log', '*.tmp', '*.bak', '*.old',
    'Test*.ps1', '*test*.ps1',
    'get_hash.ps1', 'force_clean_dist.ps1', 'clean_dist*.ps1',
    'V*_RC*_*.md', 'V*_TEST_RESULTS.md', 'V*_RC*_RELEASE_NOTES.md',
    'CHAPTER*.txt', 'MVP_*.txt', 'HOTFIX*.txt', 'SALES_*.md', 'RELEASE*.txt',
    'DESIGN_*.md', 'MIGRATION_*.md', 'CHANGED_FILES_*.md', 'CHANGELOG_*.md',
    'TEST_RESULTS_*.md', 'PROJECTS_JSON_*.md', 'SETTINGS_JSON_*.md',
    'README_Chapter*.md', 'README_Chapter*.txt', 'FINAL_ACCEPTANCE_TEST.txt'
)

function ShouldInclude($name, $isDir) {
    if ($isDir) {
        if ($excludeDirs -contains $name) { return $false }
        return $true
    } else {
        foreach ($pattern in $excludePatterns) {
            if ($name -like $pattern) { return $false }
        }
        return $true
    }
}

function CopyItem($src, $dest) {
    if ($src.PSIsContainer) {
        $destDir = New-Item -ItemType Directory -Path (Join-Path $dest $src.Name) -Force
        foreach ($child in Get-ChildItem -LiteralPath $src.FullName -Force) {
            if (ShouldInclude $child.Name $child.PSIsContainer) {
                CopyItem $child $destDir
            }
        }
    } else {
        Copy-Item -LiteralPath $src.FullName -Destination (Join-Path $dest $src.Name) -Force
    }
}

foreach ($item in Get-ChildItem -LiteralPath $root -Force) {
    if (ShouldInclude $item.Name $item.PSIsContainer) {
        CopyItem $item (Get-Item -LiteralPath $tempDir)
    }
}

Add-Type -AssemblyName System.IO.Compression.FileSystem
if (Test-Path -LiteralPath $updateZipPath) { Remove-Item -LiteralPath $updateZipPath -Force }
[IO.Compression.ZipFile]::CreateFromDirectory($tempDirPath, $updateZipPath, [IO.Compression.CompressionLevel]::Optimal, $false)
Remove-Item -LiteralPath $tempDirPath -Recurse -Force

$updateZipHash = (Get-FileHash -LiteralPath $updateZipPath -Algorithm SHA256).Hash.ToUpperInvariant()
$updateZipSize = [math]::Round((Get-Item -LiteralPath $updateZipPath).Length / 1MB, 2)
Write-Host ("  $updateZipName ($updateZipSize MB, SHA256: $updateZipHash)") -ForegroundColor Green

# SHA-256 file for update ZIP
$updateZipHashFile = Join-Path $dist ("VBAUpdater_Update_{0}_SHA256.txt" -f $productVersion)
$updateZipHashText = ("{0}  {1}`r`n" -f $updateZipHash, $updateZipName)
[System.IO.File]::WriteAllText($updateZipHashFile, $updateZipHashText, (New-Object System.Text.UTF8Encoding($false)))
Write-Host ("  Update ZIP SHA256: $updateZipHash") -ForegroundColor Green

# Summary
Write-Host "" 
Write-Host "=== Release Artifacts Generation Complete ===" -ForegroundColor Green
Write-Host ""
Get-ChildItem -LiteralPath $dist -File | Sort-Object Name | ForEach-Object {
    $size = [math]::Round($_.Length / 1KB, 1)
    Write-Host ("  {0,-55} {1,10} KB" -f $_.Name, $size)
}
exit 0