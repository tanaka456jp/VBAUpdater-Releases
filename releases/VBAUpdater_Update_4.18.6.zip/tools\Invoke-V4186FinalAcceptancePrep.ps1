﻿param([string]$RepositoryRoot=(Split-Path -Parent $PSScriptRoot))
Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'

Push-Location $RepositoryRoot
try {
    $branch=(git branch --show-current).Trim()
    if($branch -ne 'hotfix/v4186-json-cli-warning-isolation'){throw "Expected hotfix branch, current=$branch"}

    $status=@(git status --porcelain)
    $allowed=@(' M App/gui.ps1',' M App/tools/WorkbookUpdate.psm1',' M tools/Apply-V4186JsonWarningSourceHotFix.ps1',' M tools/Invoke-V4186FinalAcceptancePrep.ps1','?? tests/test-v4186-json-cli-warning-isolation.ps1','?? tools/Test-V4186ProjectEnumeration.ps1')
    $unexpected=@($status|Where-Object{$_ -notin $allowed})
    if($unexpected.Count -gt 0){throw "Unrelated local changes detected. Refusing to continue:`n$($unexpected -join [Environment]::NewLine)"}

    # Verify the formal App GUI from this branch. HotFix source is already committed.
    $guiText=[IO.File]::ReadAllText((Join-Path $RepositoryRoot 'App\gui.ps1'),[Text.Encoding]::UTF8)
    foreach($required in @('$standardTab.Text = ''ブック更新''','$developerTab.Text = ''開発者向け''','function Get-ProjectNames','foreach ($name in @($projectNames.Names)) { [void]$cmbProject.Items.Add([string]$name) }')){
        if($guiText.IndexOf($required,[StringComparison]::Ordinal)-lt 0){throw "RC2 App GUI gate failed: $required"}
    }

    # Verify WorkbookUpdate.psm1 has the warning suppression
    $workbookText=[IO.File]::ReadAllText((Join-Path $RepositoryRoot 'App\tools\WorkbookUpdate.psm1'),[Text.Encoding]::UTF8)
    $expected='Import-Module $script:GeneratedDifferenceProvenanceModulePath -Force -DisableNameChecking -ErrorAction Stop'
    $legacy='Import-Module $script:GeneratedDifferenceProvenanceModulePath -Force -ErrorAction Stop'
    if(-not $workbookText.Contains($expected)){throw 'Warning suppression was not applied in source.'}
    if($workbookText.Contains($legacy)){throw 'Legacy warning-producing import remains in source.'}

    # PowerShell 5.1 regression gate: three registered projects must remain three independent strings/items.
    & (Join-Path $RepositoryRoot 'tools\Test-V4186ProjectEnumeration.ps1') -RepositoryRoot $RepositoryRoot

    Write-Host '[PASS] Acceptance preparation completed. Source verified, no mutation performed.'
    Write-Host 'Next acceptance target: .\App\vba.cmd gui'
    Write-Host 'Expected: RC2 GUI, three separate registered projects, count=3, no module warning.'
    git status --short
}
finally { Pop-Location }