# Chapter1～9A Safety HotFix

## 1. 事象と原因

Chapter1～9実装後の包括回帰で、CLIのProject解決が `%LOCALAPPDATA%\VBAUpdater` に保存された `lastProjectRoot` / `lastWorkbookPath` をProject指定省略時のフォールバックとして使用した。そのため、テストが明示していない外部のJournalConverter Projectを選択し、業務ブックへVBA更新を実行した。

対象ブックは既存復元ポイントから復元し、復元後SHA-256 `040E34B5149C9C445B55180C0EB9B92EBE9D2F26C9F059DFC5A29D9F22A1799D` を確認した。しかし「変更後に復元できた」ことは安全性の代替にならない。根本原因は、表示用の前回選択状態と、CLI更新対象を確定する権限を分離していなかったことである。

## 2. 修正後のProject解決順序

通常CLIは次の順序だけを使用する。

1. 明示 `-ProjectRoot`。Project folder自身を絶対パスで指定する。
2. 明示 `-Project`。登録一覧から名前が一意に一致する場合だけ使用する。
3. 通常CLIに限り、現在directoryまたは親階層で最初に見つかる `project.json`。
4. GUIは画面上で選択済みのProject Rootとtargetを、CLIへ `-ProjectRoot` / `-WorkbookPath` として明示する。

`lastProjectRoot`、`lastWorkbookPath`、登録一覧の先頭、単一の登録ProjectをCLIが暗黙選択する経路は削除した。複数の同名登録Projectはエラーである。Test Modeでは3も無効であり、`-ProjectRoot`なしのProject更新・参照コマンドは更新前に失敗する。

更新系CLIは処理開始前にProject名、Project Root、target絶対パス、Workbook定義の有無、VBA差分数、Workbook差分数、Backup作成先を表示する。

## 3. Test Mode

テストコマンドは一意な `%TEMP%\VU_<id>` を作り、`test-context.json` を安全マーカーとして配置する。親から子へ環境変数だけでなく、必ず `-TestMode -TestRoot <absolute-path>` を渡す。子は既存マーカーがなければ開始しない。

Test Modeでは次を強制する。

- `%LOCALAPPDATA%\VBAUpdater`、GUI状態、前回選択、外部Project自動検出を参照しない。
- settings、projects registry、logs、backups、restore pointsをTest Root内へ隔離する。
- Project Rootは絶対パスかつ許可ルート内、`project.json`ありとする。
- targetはProject Root内、Test Mode開始後に作成またはコピーされたfileに限定する。
- `..`正規化後の境界、UNC、network drive、OneDrive、reparse point、read-only属性をOpen前に検査する。
- UNC/network/OneDriveは `-AllowUnsafeTestPath` の明示がない限り拒否する。通常の回帰ではこの許可を使用しない。
- 親が登録したDenied Rootへ解決した場合は直ちに停止する。
- Test Rootを所有する親processが終了時に一時fileを削除する。

## 4. Workbook Open監査とCanary

Excel COMをOpenする共通経路とVBAUpdater add-inへtargetを渡す直前に監査hookを置いた。監査は `workbook-open-audit.jsonl` へProject Rootとtarget絶対パスを記録する。監査を通らない外部target、Project Root外target、古い原本、read-only原本はOpen前に失敗する。

`test-isolation-test` と `regression-test` はDenied Root内にCanaryを作り、開始前後のSHA-256を比較する。Canaryが監査に1件でも現れた場合は、内容が変化していなくても失敗する。

## 5. GUI安全確認

GUIが前回選択を復元した場合は `前回選択を復元（更新時に再検証）` と表示する。選択時にtargetの絶対パス、length、LastWriteTimeUtc、SHA-256を保持する。更新開始時に次を再検査する。

- Project Rootと `project.json` が存在する。
- CLI共通判定が同じProject Rootとtargetを返す。
- targetがProject Root内にある。
- targetのlength、時刻、SHA-256が選択時から変わっていない。

変化があれば更新を開始せず、Project再選択を要求する。GUIはExcel/COM処理を持たず、検査後も明示Project RootとtargetをCLIへ渡す。

## 6. Log access拒否の修正

旧テストは本体直下 `logs` / `backups` を共有し、sandbox ACL、同名file、削除とhandle解放の競合を受け得た。全テストのruntime log/backup rootをTest Rootへ切り替えた。2本の別logを同時に排他Openし、両handle解放後に再書込できることを自動確認する。業務logの読取・削除・上書きは行わない。

## 7. 自動テスト

安全境界だけを検証するコマンド:

```powershell
.\vba.cmd test-isolation-test
```

Excel不要の包括回帰:

```powershell
.\vba.cmd regression-test
```

Excel COMを使う隔離統合回帰:

```powershell
.\vba.cmd isolated-excel-regression-test
```

最後のコマンドは、専用copyだけを使ってlegacy Standard/Class/Document/UserForm、Workbook Validate/Diff/Apply/Verify、Workbook＋VBA Push、VBA-only Diff/Push/Pull、再実行差分0、rollback、Canary、Workbook Open監査、Excel process残留を確認する。Excelを起動できない環境では成功扱いにしない。

## 8. 判定とversion

HotFixの静的検証とExcel不要回帰が成功しても、`isolated-excel-regression-test` を受入環境で完走するまではWorkbook＋VBA統合PushをAへ戻さずBとする。version表示は `4.18.0` を維持する。実機受入と隔離Excel包括回帰の成功後、修正版候補は既存採番との整合上 `4.18.1` が妥当であり、`4.19.0` へは上げない。

| 対象 | 分類 | 根拠 |
|---|---|---|
| 暗黙Project選択禁止、明示Project解決 | A | 自動安全境界・包括回帰成功 |
| Test Mode、許可/拒否root、path traversal/reparse/read-only拒否 | A | 10条件＋追加境界回帰成功 |
| 隔離settings/logs/backups、log access 2件 | A | 排他Open・handle解放後再書込成功 |
| GUI前回選択表示、target fingerprint、更新直前再検証 | A | GUI runtime/self-test成功 |
| Workbook Open監査hook | B | 拒否・記録のunit回帰成功、Excel COM実機回帰未実行 |
| VBA-only実ブックPush/Pull/Diff | B | HotFix後Excel COM回帰未実行 |
| Workbook Validate/Diff/Apply/Verify | B | Excel不要定義回帰成功、HotFix後Excel COM回帰未実行 |
| Workbook＋VBA統合Push、rollback、冪等性 | B | 隔離Excel包括回帰未実行 |
| 新規機能 | 対象外 | 本HotFixでは追加しない |

## 9. 再発防止チェック

- 暗黙Project解決を追加する変更は、安全境界テストを更新しない限り受入れない。
- テストから起動する全子processで `-TestMode -TestRoot` を確認する。
- Excel test結果にはCanary hash、Open監査件数、新規Excel PID残留を含める。
- 未実行のCOM testを成功と記録しない。
- Git Commit、Git Push、branch、tagは本HotFixの処理に含めない。

## 10. Chapter1～9B Final HotFix

利用者実機で `isolated-excel-regression-test` を実行したところ、legacy VBA統合テスト12工程は成功したが、`workbook-integration-test` が `[SAFE1023]` で停止した。Workbook Integration Fixtureが `%TEMP%\VBAUpdaterWorkbookIntegration_<id>` にWorkbook定義、asset、targetだけを生成し、正式な `project.json` を作っていなかったためである。

SAFE1023は不完全なfolderをProjectとして扱わないための正常な安全停止であり、検査処理は変更・緩和していない。修正対象をWorkbook Integration Fixtureだけに限定し、親Test Root配下の `WorkbookIntegration_<id>` へ次をテスト開始後に生成するよう変更した。

- 現行schema 1.0の `project.json`
- `source/workbook/workbook.json`
- `source/standard/modWorkbookIntegration.bas`
- `source/assets/pixel.png`
- `target/WorkbookIntegration.xlsm`
- `logs`、`backups`、`restore_points`

Manifest、Workbook定義、asset、source、targetにはProject外絶対pathや `..` を使用しない。Workbook Integration moduleには親Test Rootを引数で明示し、保存済み設定やcurrent directoryからrootを解決しない。

2026-08-09の最終回帰結果:

- `test-isolation-test`: 成功
- `regression-test`: 26成功 / 0失敗
- `isolated-excel-regression-test`: 全23工程成功
- `workbook-integration-test`: 成功
- 初回Diffあり、Apply/Backup成功、Verify 0件、再Diff 0件
- 管理対象外sheet/cell保全成功
- `AfterOpen`、`AfterWorksheet`、`BeforeSave`、`AfterSave`のrollback hash一致
- 復元失敗をWB3004として区別
- Canary SHA-256前後一致
- Workbook Open監査47件、外部Workbook 0件
- 新規Excel process残留0、`VU_*`/旧Workbook Integration root残留0

この結果により、Chapter1～9Aで暫定Bへ下げていたWorkbook Open監査、VBA-only実ブック処理、Workbook Apply/Verify、Workbook＋VBA統合Push、rollback、冪等性は、既存の機能別B/C制約を除く正式対応範囲についてAへ戻せる。
