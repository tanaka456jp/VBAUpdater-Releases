﻿# VBAUpdater 現行アーキテクチャと安全性分析

> Chapter1～9A Safety HotFix後のProject解決とテスト隔離は `CHAPTER1-9A_SAFETY_HOTFIX.md` を優先する。保存済み `lastProjectRoot` / `lastWorkbookPath` をCLIが暗黙利用する旧経路は削除済みである。

## 調査基準

本書は Ver4.18.5 RC1 の実コードを基準にする。構想と実装が異なる場合は実装を正とする。Workbook更新は `tools/WorkbookUpdate.psm1`、VBA文字コード診断は `tools/VbaEncoding.psm1` に分離し、既存VBA更新エンジンの正式Import/Export APIを維持している。

## 現行コンポーネント

| 責務 | 実装 |
|---|---|
| CLIエントリーポイント | `vba.cmd` → `vba.ps1` のコマンドルーター |
| GUIエントリーポイント | `gui.cmd` → `gui.ps1`。CLIを子プロセスとして呼び出す |
| Project登録・GUI/CLI共通検証 | `tools/ProjectRegistration.psm1`、`Invoke-ProjectCreateCore` |
| 永続設定 | `%LOCALAPPDATA%\VBAUpdater\settings.json` と `projects.json`。環境変数によるテスト差替えあり |
| Project自動検出 | Project Root直下の `project.json` と、最後に開いた直接Project Folder |
| project.json読込 | `Read-ProjectManifest`、`Test-ProjectManifest`、`Resolve-ManifestTarget` |
| VBA Export / Pull | `Invoke-ProjectPull`、`Export-VbComponentSafe`。一時領域へ全件Export後にsourceへ反映 |
| VBA Import / Push | `Invoke-ManifestComponentPush` → `push-*` → `Invoke-EngineComponentUpdate` → `addin/VBAUpdater.xlam` 内マクロ |
| VBA Diff | `Get-ProjectDiff`。ブックをReadOnlyで開き、正規化済みコードを比較 |
| Preflight | `Invoke-Preflight`、`Invoke-ProjectPreflight`、Manifest/Source/Target検証 |
| Compile Check | `Invoke-ProjectCompileGate`、設定マクロを新規Excelプロセスで実行 |
| Backup | コンポーネント単位バックアップと `New-ProjectRestorePoint` |
| 手動復旧 | `rollback-list` / `rollback -Apply`、SHA-256検証付きCopy復元 |
| Workbook更新 | `tools/WorkbookUpdate.psm1`。定義、検証、Plan、Diff、Apply、Verify、復元を担当 |
| COM生成・終了 | 既存 `New-ExcelApplication` / `Close-ExcelApplication`、新規モジュール内の報告可能な終了処理 |
| ログ | `logs` 配下の操作別JSON/診断ログ。Workbookログは値を出さずID・種別・対象だけを記録 |
| バージョン | ルート/Appの `VERSION.txt`（4.18.5）をCLI/GUIが読み、Installer・Package・RC検証が一致を強制 |

## 実際の既存Pushフロー

Workbook定義がない場合は、今回も次の既存経路をそのまま通る。

1. Project解決、`project.json`読込
2. `prePush` hookとPrepareSource
3. Manifest検証、対象ブック解決
4. 復元ポイント作成（`-SkipRestorePoint`時を除く）
5. ReadOnlyでVBA差分取得
6. changed/addedコンポーネントだけを、Add-inマクロ経由で1件ずつ更新・保存
7. Compile Gate
8. `postPush` hook
9. 変更時だけ再Diffし、残差0件を確認
10. JSON結果出力

V4.18.5ではVBA-only Pushも失敗時にExcel COMを解放してから復元ポイントを自動適用し、SHA-256を再確認する。手動`rollback`も引き続き利用できる。

## Workbook統合Pushフロー

`project.json` に有効な `workbook` がある場合だけ、外側のトランザクション経路へ分岐する。

1. Project/Workbook定義の構文・schema・競合・相対パス検証
2. 対象ブックをReadOnlyで開きWorkbook差分を作成
3. 統合復元ポイント作成
4. Workbookのchanged操作だけを順序適用して保存
5. ReadOnly再オープン相当の再読込でWorkbook差分0件を確認
6. 既存VBA Pushを `-SkipRestorePoint` 付きで実行
7. Workbookを再Verify
8. どの段階でも失敗した場合、Excelを閉じた後に統合復元ポイントからCopy復元しSHA-256を確認

Workbookを先に適用する理由は、Worksheet追加/Rename後の実在構造に対してVBAを反映するためである。CodeName変更は扱わず、既存Document Module更新は既存エンジンへ委ねる。VBAまたはCompile Gateが失敗した場合も、外側のバックアップでWorkbook変更ごと戻す。

## Backup・復元

- 既存復元ポイントは `backups/restore_points/<project>/` にブックとメタデータを保存する。
- Workbook単独Applyは、差分がある場合だけ更新前バックアップを作成する。
- 更新途中、Save、Excel終了、保存後Verifyの失敗を同じ失敗経路で扱う。
- `WB3003` は更新失敗・復元成功、`WB3004` は更新失敗・復元失敗である。
- 復元前後のSHA-256を比較する。復元失敗は元の更新エラーと分けてログへ残す。
- テスト用障害注入は専用一時ブックだけで使用する。

## 発見した既存リスク

| リスク | 現状 | 今回の対処 |
|---|---|---|
| Excelプロセス残留 | 既存終了処理は `Quit` / `FinalReleaseComObject` / GCだが空catchで失敗を隠す | Workbook経路はClose/Quitエラーを収集し失敗扱い。テストで新規PID残留を確認 |
| 更新途中例外 | 既存VBA-only Pushは自動復元しない | Workbook統合PushとWorkbook単独Applyは自動復元 |
| Save失敗 | 既存は例外化するが自動復元なし | Workbook経路は復元と保存後再検証 |
| ReadOnly/構造保護 | 更新開始後にCOM例外となる可能性 | 書込前にReadOnlyとWorkbook構造保護を停止条件として検証 |
| 保護ビュー/破損ブック | Workbooks.Openが失敗 | 変更前に停止。修復モードで勝手に開かない |
| 外部リンク | Excel既定挙動の副作用リスク | `AskToUpdateLinks=false`、Open時UpdateLinks=0、定義内の外部パスは禁止 |
| マクロ/VBProjectアクセス | セキュリティ設定依存 | Workbook COMはマクロ無効。VBA/削除前コード確認でアクセス不可なら停止 |
| Events/Calculation/Alerts | 副作用と復元漏れ | 専用Excelプロセスで無効化し、Calculationを保存前に復元。終了失敗を報告 |
| 管理外データ上書き | 全面同期は危険 | ID付き明示範囲だけを更新。管理外Sheet/Cell/Shape/Name等は列挙削除しない |
| シート削除 | 数式、名前、VBAコード消失 | 明示宣言、空データ、参照なし、図形/テーブルなし、VBAコードなしを全て要求 |
| 画像置換 | Office API差で参照やZ-orderを壊し得る | 安全なReplace APIがない環境では更新前に `WB2592` で停止。削除再挿入しない |
| 既存復元失敗 | ロック、破損、権限 | ハッシュ検証し `WB3004` として別報告 |

## 後方互換性方針

- `workbook` はProject schema 1.0の任意拡張であり、未指定時は無効。
- 未指定Projectへ新規ファイルや設定変更を要求しない。
- `project-push`、`project-pull`、`project-diff`、GUIボタン名を変更しない。
- 既存VBAソース、Add-inマクロ、正規化エンジンを置換しない。
- GUIはWorkbook定義の有無を1行追加し、操作結果は従来のCLIログ表示へ流す。大規模レイアウト変更はしない。
- ProductVersionは`VERSION.txt`を正本とし、手入力箇所の不一致はRC Validationで停止する。

## V4.18.5 UserForm正式仕様

- `project.json`の正式typeは`userform`。実使用根拠のない`form` aliasは追加しない。
- `.frm`と同一フォルダー・同一ベース名の非空`.frx`を1組として扱う。FRXはVBE Export由来の実バイナリであり、ダミー生成しない。
- Pullは`VBComponent.Export`が生成したFRM/FRXを一時領域で確認後にsourceへ反映する。
- Pushは既存UserFormを確認・削除してFRMをImportし、component type 3とNameを確認する。失敗時はWorkbook単位の復元ポイントへ戻す。
- DiffはFRMのdesigner/code境界を保ったSemantic CompareとFRX raw SHA-256を併記する。FRMが同じで両側FRXが存在する場合だけFRX hash単独差をResultOverrideできる。

## V4.18.5 COM ownershipと自己回復

- VBAUpdaterが`New-Object -ComObject Excel.Application`で作成したApplicationだけをHWNDキーで所有登録する。
- Close順は子RCW、Workbook.Close、Workbook release、owned Application.Quit、Application release、GC/finalizerである。
- 外部ロック判定は最大3回行い、再試行間では現在プロセスのRCW/finalizerだけを解放する。他Excelの列挙・Quit・Killはしない。
- 真の外部ロックは`SAFE2001`/`WB2001`でFail Closedする。実Excelで開いた対象拒否、閉じた後の再試行、別Workbook非干渉を隔離実機テストで確認する。

## V4.18.5 Encoding Safety

- Source readerでUTF-8（BOM有無）または既存ANSIを解決した後、現在のWindows ANSI code pageでUnicode scalarごとのencode/decode round-tripを検査する。
- 不一致は`ENC1001`としてComponent、type、file、line、column、character、code point、code page、reasonを返す。
- 全managed sourceをWorkbook変更前に検査する。通常のCP932日本語は許可し、非互換文字だけを停止する。
- `〜`と`?`をSemantic Compareで同一視する緩和は行わない。

## V4.18.5 Taskbar attention

- WinForms Form handleへWindows標準`FlashWindowEx`を適用する。
- Active時は通知しない。success/failure/action-requiredを共通経路で要求し、重複中は追加Flashを発生させない。
- Form ActivatedとFormClosedで`FLASHW_STOP`を送る。

## Chapter 1～9 品質ゲート計画

各Chapterで、構文解析、定義の静的検証、非COMテスト、専用ブック統合テスト、既存回帰、未対応記録の順に確認する。後続機能が安全に識別できない場合はApplyへ入れず、B（基盤）またはC（設計のみ）とする。
