﻿VBAUpdater Ver1.0 - MVP Release03 Safe Self Update


ProductVersion: 4.18.6

販売MVPセルフアップデート:
- ユーザー操作による更新確認
- 更新内容表示
- 明示同意後のみダウンロード
- SHA-256検証
- 明示同意後のみ本体更新
- 更新前にアプリ本体をUpdateBackupへ退避
- LOCALAPPDATAのユーザーデータを更新対象外とする
- Project source / target / project.jsonは更新対象外
- 更新後再起動
- 失敗時はアプリ本体のbest-effort rollback

現在:
正式配布Manifest URL未設定のためenabled=false。
販売用配布先決定後に有効化する。

Build ID: VBAUpdater_V4.18.6_RC2
