﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Reflection;
using System.Windows.Forms;

internal static class Program
{
    private static DialogResult ShowTopMostMessage(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton)
    {
        using (Form owner = new Form())
        {
            owner.StartPosition = FormStartPosition.CenterScreen;
            owner.Size = new System.Drawing.Size(1, 1);
            owner.ShowInTaskbar = false;
            owner.FormBorderStyle = FormBorderStyle.None;
            owner.TopMost = true;
            owner.Opacity = 0;
            owner.Show();
            owner.Activate();
            owner.BringToFront();
            return MessageBox.Show(owner, text, caption, buttons, icon, defaultButton);
        }
    }

    [STAThread]
    private static int Main()
    {
        string root = Path.Combine(Path.GetTempPath(), "VBAUpdaterSetup_" + Guid.NewGuid().ToString("N"));
        try
        {
            Directory.CreateDirectory(root);
            string zipPath = Path.Combine(root, "Payload.zip");
            using (Stream input = Assembly.GetExecutingAssembly().GetManifestResourceStream("Payload.zip"))
            {
                if (input == null) throw new InvalidOperationException("インストーラーデータを読み込めませんでした。");
                using (FileStream output = File.Create(zipPath)) input.CopyTo(output);
            }
            ZipFile.ExtractToDirectory(zipPath, root);
            try { File.Delete(zipPath); } catch { }

            string setup = Path.Combine(root, "Setup.ps1");
            if (!File.Exists(setup)) throw new FileNotFoundException("Setup.ps1を展開できませんでした。", setup);

            string ps = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "WindowsPowerShell", "v1.0", "powershell.exe");
            if (!File.Exists(ps)) ps = "powershell.exe";

            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = ps;
            psi.Arguments = "-NoProfile -STA -ExecutionPolicy Bypass -File \"" + setup + "\"";
            psi.UseShellExecute = false;
            psi.WorkingDirectory = root;
            using (Process p = Process.Start(psi))
            {
                p.WaitForExit();
                if (p.ExitCode != 0) return p.ExitCode;
            }

            // The EXE bootstrap owns the final launch prompt. This makes the prompt
            // reliably visible after Setup.ps1 has fully completed.
            string buildVersion = "unknown";
            try
            {
                string buildFile = Path.Combine(root, "BUILD_VERSION.txt");
                if (File.Exists(buildFile)) buildVersion = File.ReadAllText(buildFile).Trim();
            }
            catch { }

            DialogResult launch = ShowTopMostMessage(
                "インストールが完了しました。\r\n\r\n製品ビルド: " + buildVersion +
                "\r\n\r\n今すぐVBAUpdaterを起動しますか？",
                "VBAUpdater Setup",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Information,
                MessageBoxDefaultButton.Button2);

            if (launch == DialogResult.Yes)
            {
                string installRoot = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Programs", "VBAUpdater");
                string gui = Path.Combine(installRoot, "gui.ps1");
                if (!File.Exists(gui))
                    throw new FileNotFoundException("インストール済みのgui.ps1が見つかりません。", gui);

                ProcessStartInfo launchPsi = new ProcessStartInfo();
                launchPsi.FileName = ps;
                launchPsi.Arguments = "-NoProfile -STA -ExecutionPolicy Bypass -File \"" + gui + "\"";
                launchPsi.UseShellExecute = false;
                launchPsi.WorkingDirectory = installRoot;
                Process.Start(launchPsi);
            }

            return 0;
        }
        catch (Exception ex)
        {
            ShowTopMostMessage("VBAUpdaterインストーラーの起動に失敗しました。\r\n\r\n" + ex.Message,
                "VBAUpdater Setup", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            return 1;
        }
        finally
        {
            try { if (Directory.Exists(root)) Directory.Delete(root, true); } catch { }
        }
    }
}
