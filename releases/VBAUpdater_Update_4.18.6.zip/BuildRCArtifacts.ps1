$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$root = $PSScriptRoot
$buildFile = Join-Path $root 'BUILD_VERSION.txt'
if (-not (Test-Path -LiteralPath $buildFile -PathType Leaf)) { throw 'BUILD_VERSION.txt not found.' }
$build = ([System.IO.File]::ReadAllText($buildFile)).Trim()
if ([string]::IsNullOrWhiteSpace($build)) { throw 'BUILD_VERSION.txt is empty.' }

$productVersionFile = Join-Path $root 'App\VERSION.txt'
$productVersion = ([System.IO.File]::ReadAllText($productVersionFile)).Trim()
if ($productVersion -notmatch '^\d+\.\d+\.\d+$') { throw "App VERSION.txt invalid: $productVersion" }

$dist = Join-Path $root 'dist'
if (-not (Test-Path -LiteralPath $dist -PathType Container)) { throw "dist folder not found: $dist" }

Write-Host "=== RC Artifacts Generation: $build ===" -ForegroundColor Cyan
Write-Host "Product Version: $productVersion" -ForegroundColor Cyan
Write-Host ""

# 1. Required files check
$required = @(
    "VBAUpdater_Setup_{0}.exe" -f $productVersion,
    "VBAUpdater_Setup_{0}_SHA256.txt" -f $productVersion,
    "RC_VALIDATION_{0}.txt" -f $build,
    "V{0}_RC2_RELEASE_NOTES.md" -f $productVersion,
    "V{0}_RC2_TEST_RESULTS.md" -f $productVersion
)

$missing = @()
foreach ($item in $required) {
    $path = Join-Path $dist $item
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        $missing += $item
    }
}
if ($missing.Count -gt 0) {
    throw ("Missing required artifacts: " + ($missing -join ', '))
}

# 2. Development ZIP generation
Write-Host "Generating development ZIP..." -ForegroundColor Yellow

$devZipName = "VBAUpdater_Development_{0}_RC2.zip" -f $productVersion
$devZipPath = Join-Path $dist $devZipName

$tempDirPath = Join-Path $env:TEMP ("VBAUpdater_RC2_Artifacts_" + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $tempDirPath | Out-Null
$tempDir = Get-Item -LiteralPath $tempDirPath

$excludeDirs = @('dist', '.git', 'logs', 'backups', 'tests')
$excludePatterns = @(
    '*.log', '*.tmp', '*.bak', '*.old',
    'Test*.ps1', '*test*.ps1',
    'get_hash.ps1', 'force_clean_dist.ps1', 'clean_dist*.ps1',
    'V{0}_RC1_*.md' -f $productVersion, 'V{0}_TEST_RESULTS.md' -f $productVersion, 'V{0}_RC1_RELEASE_NOTES.md' -f $productVersion,
    'CHAPTER*.txt', 'MVP_*.txt', 'HOTFIX*.txt', 'SALES_*.md', 'RELEASE*.txt',
    'DESIGN_*.md', 'MIGRATION_*.md', 'CHANGED_FILES_*.md', 'CHANGELOG_*.md',
    'TEST_RESULTS_*.md', 'PROJECTS_JSON_*.md', 'SETTINGS_JSON_*.md',
    'README_Chapter*.md', 'README_Chapter*.txt', 'FINAL_ACCEPTANCE_TEST.txt'
)

function ShouldInclude($name, $isDir) {
    if ($isDir) {
        if ($excludeDirs -contains $name) { return $false }
        return $true
    } else {
        foreach ($pattern in $excludePatterns) {
            if ($name -like $pattern) { return $false }
        }
        return $true
    }
}

function CopyItem($src, $dest) {
    if ($src.PSIsContainer) {
        $destDir = New-Item -ItemType Directory -Path (Join-Path $dest $src.Name) -Force
        foreach ($child in Get-ChildItem -LiteralPath $src.FullName -Force) {
            if (ShouldInclude $child.Name $child.PSIsContainer) {
                CopyItem $child $destDir
            }
        }
    } else {
        Copy-Item -LiteralPath $src.FullName -Destination (Join-Path $dest $src.Name) -Force
    }
}

foreach ($item in Get-ChildItem -LiteralPath $root -Force) {
    if (ShouldInclude $item.Name $item.PSIsContainer) {
        CopyItem $item (Get-Item -LiteralPath $tempDir)
    }
}

Add-Type -AssemblyName System.IO.Compression.FileSystem
if (Test-Path -LiteralPath $devZipPath) { Remove-Item -LiteralPath $devZipPath -Force }
[IO.Compression.ZipFile]::CreateFromDirectory($tempDirPath, $devZipPath, [IO.Compression.CompressionLevel]::Optimal, $false)
Remove-Item -LiteralPath $tempDirPath -Recurse -Force

$devZipHash = (Get-FileHash -LiteralPath $devZipPath -Algorithm SHA256).Hash.ToUpperInvariant()
$devZipSize = [math]::Round((Get-Item -LiteralPath $devZipPath).Length / 1MB, 2)
Write-Host ("  $devZipName ($devZipSize MB, SHA256: $devZipHash)") -ForegroundColor Green

# 3. SHA-256 update (installer)
Write-Host "SHA-256 verification..." -ForegroundColor Yellow

$exePath = Join-Path $dist ("VBAUpdater_Setup_{0}.exe" -f $productVersion)
$hashFile = Join-Path $dist ("VBAUpdater_Setup_{0}_SHA256.txt" -f $productVersion)

$actualHash = (Get-FileHash -LiteralPath $exePath -Algorithm SHA256).Hash.ToUpperInvariant()
$hashText = ("{0}  {1}`r`n" -f $actualHash, [IO.Path]::GetFileName($exePath))
[System.IO.File]::WriteAllText($hashFile, $hashText, (New-Object System.Text.UTF8Encoding($false)))
Write-Host ("  Installer SHA256: $actualHash") -ForegroundColor Green

# 4. Development ZIP SHA-256 file
$devZipHashFile = Join-Path $dist ("VBAUpdater_Development_{0}_RC2_SHA256.txt" -f $productVersion)
$devZipHashText = ("{0}  {1}`r`n" -f $devZipHash, $devZipName)
[System.IO.File]::WriteAllText($devZipHashFile, $devZipHashText, (New-Object System.Text.UTF8Encoding($false)))
Write-Host ("  Dev ZIP SHA256: $devZipHash") -ForegroundColor Green

# 5. Artifacts summary
Write-Host "Generating artifacts summary..." -ForegroundColor Yellow

$summaryPath = Join-Path $dist ("RC2_ARTIFACTS_{0}.txt" -f $build)
$summaryLines = @(
    "VBAUpdater V{0} RC2 Artifacts Summary" -f $productVersion,
    "Build: $build",
    "Product Version: $productVersion",
    "GeneratedAt: " + (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'),
    "",
    "Artifacts:",
    "  VBAUpdater_Setup_${productVersion}.exe  $actualHash  $((Get-Item $exePath).Length)",
    "  $devZipName  $devZipHash",
    "  RC_VALIDATION_${build}.txt",
    "  V{0}_RC2_RELEASE_NOTES.md" -f $productVersion,
    "  V{0}_RC2_TEST_RESULTS.md" -f $productVersion,
    "  VBAUpdater_Setup_${productVersion}_SHA256.txt",
    "  VBAUpdater_Development_{0}_RC2_SHA256.txt" -f $productVersion,
    "",
    "Verification:",
    "  All artifacts present and hashed.",
    "  Installer verified against SHA256 file.",
    "  Development ZIP verified against SHA256 file."
)
[IO.File]::WriteAllLines($summaryPath, $summaryLines, (New-Object Text.UTF8Encoding($true)))
Write-Host ("  Summary: $summaryPath") -ForegroundColor Green

# 6. Final artifacts listing
Write-Host ""
Write-Host "=== RC2 Artifacts Generation Complete ===" -ForegroundColor Green
Write-Host ""
Get-ChildItem -LiteralPath $dist -File | Sort-Object Name | ForEach-Object {
    $size = [math]::Round($_.Length / 1KB, 1)
    Write-Host ("  {0,-55} {1,10} KB" -f $_.Name, $size)
}
Write-Host ""
Write-Host "Next: Windows installer test, GUI launch, JournalConverter update test" -ForegroundColor Cyan
exit 0