$ErrorActionPreference='Stop'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$versionFile=Join-Path $root 'BUILD_VERSION.txt'
if(-not (Test-Path -LiteralPath $versionFile)){throw 'BUILD_VERSION.txt not found.'}
$build=(Get-Content -LiteralPath $versionFile -Raw).Trim()
if([String]::IsNullOrWhiteSpace($build)){throw 'BUILD_VERSION.txt is empty.'}
if($build -notmatch '^[A-Za-z0-9._-]+$'){throw ("Invalid BUILD_VERSION.txt value: {0}" -f $build)}
$productVersionFile=Join-Path $root 'App\VERSION.txt'
if(-not (Test-Path -LiteralPath $productVersionFile -PathType Leaf)){throw 'App VERSION.txt not found.'}
$productVersion=(Get-Content -LiteralPath $productVersionFile -Raw).Trim()
if($productVersion -ne '4.18.6'){throw ("App VERSION.txt must be 4.18.6: {0}" -f $productVersion)}

# Distribution hygiene: reject local/runtime artifacts and backup files under App.
$appRoot=Join-Path $root 'App'
if(-not (Test-Path -LiteralPath $appRoot -PathType Container)){throw 'App directory not found.'}
$forbiddenNames=@('installed-addin.json')
$forbiddenExtensions=@('.bak','.tmp','.old','.log')
Get-ChildItem -LiteralPath $appRoot -Recurse -Force -File | ForEach-Object {
 if($forbiddenNames -contains $_.Name){throw ("Forbidden distribution item under App: {0}" -f $_.Name)}
 if($forbiddenExtensions -contains $_.Extension.ToLowerInvariant()){throw ("Temporary/backup file found under App: {0}" -f $_.FullName)}
}

$baselineFile=Join-Path $root 'RUNTIME_BASELINE.sha256'
if(-not (Test-Path -LiteralPath $baselineFile)){throw 'RUNTIME_BASELINE.sha256 not found.'}
# Read explicitly as UTF-8 so Windows PowerShell 5.1 does not reinterpret a
# BOM-less UTF-8 baseline using the active ANSI code page. Trim a leading BOM
# defensively as well; the digest and path grammar remains strict below.
$baselineText=[Text.Encoding]::UTF8.GetString([IO.File]::ReadAllBytes($baselineFile))
$baselineText=$baselineText.TrimStart([char]0xFEFF)
$baselineLines=$baselineText -split "`r?`n" | Where-Object { -not [String]::IsNullOrWhiteSpace($_) }
if($baselineLines.Count -eq 0){throw 'RUNTIME_BASELINE.sha256 is empty.'}
foreach($line in $baselineLines){
 $line=$line.TrimStart([char]0xFEFF)
 if($line -notmatch '^([A-Fa-f0-9]{64})\s+\*(.+)$'){throw ("Invalid RUNTIME_BASELINE.sha256 line: {0}" -f $line)}
 $expected=$matches[1].ToUpperInvariant()
 $rel=$matches[2]
 $path=Join-Path $root $rel
 if(-not (Test-Path -LiteralPath $path -PathType Leaf)){throw ("Runtime baseline file missing: {0}" -f $rel)}
 $extension=[IO.Path]::GetExtension($path).ToLowerInvariant()
 $textExtensions=@('.ps1','.psm1','.cmd','.bat','.cs','.json','.md','.txt','.bas','.cls','.frm')
 if($textExtensions -contains $extension){
  $raw=[IO.File]::ReadAllBytes($path)
  $normalized=New-Object 'System.Collections.Generic.List[byte]'
  for($i=0;$i -lt $raw.Length;$i++){
   $b=$raw[$i]
   if($b -eq 13){
    if(($i+1) -lt $raw.Length -and $raw[$i+1] -eq 10){$i++}
    [void]$normalized.Add([byte]10)
   } else {
    [void]$normalized.Add([byte]$b)
   }
  }
  $sha=[Security.Cryptography.SHA256]::Create()
  try { $actual=([BitConverter]::ToString($sha.ComputeHash($normalized.ToArray()))).Replace('-','').ToUpperInvariant() }
  finally { $sha.Dispose() }
 } else {
  $actual=(Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash.ToUpperInvariant()
 }
 if($actual -ne $expected){throw ("Frozen runtime differs from baseline: {0}; Expected={1}; Actual={2}" -f $rel,$expected,$actual)}
}

# OperationalSafety public API required by Chapter5-2_02.
$opsText=[IO.File]::ReadAllText((Join-Path $root 'App\tools\OperationalSafety.psm1'))
foreach($api in @('Get-VBAUpdaterOperationalRetryAssessment','Get-VBAUpdaterOperationalSupportRecord','Get-VBAUpdaterOperationalGuidanceLines')){
 if($opsText.IndexOf($api,[StringComparison]::Ordinal) -lt 0){throw ("OperationalSafety API missing: {0}" -f $api)}
}

# Parse critical PowerShell files before packaging.
$parseTargets=@('Setup.ps1','Uninstall.ps1','BuildInstaller.ps1','RunRCValidation.ps1','VerifyPackage.ps1','TestOperationalSafety.ps1','TestGitWarningHandling.ps1','TestDangerousOperationSafetyGate.ps1','TestSafetyGateTestMode.ps1','TestTaskbarNotification.ps1','TestV4185VersionConsistency.ps1','App\gui.ps1','App\vba.ps1','App\tools\OperationalSafety.psm1','App\tools\VbaEncoding.psm1')
foreach($rel in $parseTargets){
 $tokens=$null; $errors=$null
 [void][System.Management.Automation.Language.Parser]::ParseFile((Join-Path $root $rel),[ref]$tokens,[ref]$errors)
 if($errors.Count -gt 0){ throw ("PowerShell parse error: {0}: {1}" -f $rel,$errors[0].Message) }
}

Write-Host ("Package verification passed: product={0}; build={1}" -f $productVersion,$build) -ForegroundColor Green
