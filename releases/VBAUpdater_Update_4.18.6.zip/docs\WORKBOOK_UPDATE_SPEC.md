﻿# Workbook更新仕様

> Apply/統合PushのProject選択、Test Mode、許可ルート、Canary、Workbook Open監査は `CHAPTER1-9A_SAFETY_HOTFIX.md` を必須安全条件とする。Chapter1～9Bの正式一時Projectによる隔離Excel包括回帰が完走したため、正式対応範囲のExcel COM Apply/統合PushはAである。

## 有効化

既存 `project.json` に次の任意フィールドを追加したProjectだけがWorkbook更新を使用する。

```json
{
  "workbook": {
    "enabled": true,
    "definition": "source/workbook/workbook.json"
  }
}
```

`workbook` 未指定または `enabled: false` はVBA-onlyである。`definition` はProject Root相対のJSONだけを許可し、絶対パス、`..`によるProject外参照、存在しないファイルを拒否する。

## Workbook schema 1.0

ルートで許可するフィールドは次のとおり。未知のフィールドは黙って無視しない。

```text
schemaVersion (必須、"1.0")
workbookId
worksheets
ranges
rows
columns
names
validations
conditionalFormats
tables
shapes
pageSetups
migrations
```

全操作の `id` はSectionをまたいで一意でなければならない。JSON配列の並び順自体は差分理由にしない。Worksheet positionのように意味を持つ順序は明示値で管理する。

## 実行モード

| モード | 動作 |
|---|---|
| Validate | Project/Workbook JSON、schema、型、重複、範囲、パス、未対応機能を検証。ブックを変更しない |
| Diff | ブックをReadOnlyで開き、明示管理対象だけを正規化比較。値はログに出さない |
| Apply | Diff、更新前バックアップ、changed操作だけを適用、Save、再Diff、失敗時復元 |
| Verify | ReadOnly再読込で残差0件を要求 |

## Worksheet

```json
{
  "id": "main",
  "action": "ensure",
  "name": "Main",
  "position": 1,
  "visible": "visible",
  "tabColor": "#336699",
  "view": {
    "freezeAt": "B2",
    "zoom": 90,
    "showGridlines": true,
    "showHeadings": true
  }
}
```

`action` は `ensure` / `rename` / `delete`。Renameは `from` を必要とし、削除・再作成しない。Deleteは `allowDelete: true` が必須で、最後のシート、データ/数式/Table/Shapeを持つシート、Nameや他シート数式から参照されるシート、VBAコードを持つシート、VBAコード有無を確認できないシートを拒否する。定義にない既存シートは削除しない。CodeName変更とパスワード付き保護は対象外で、`protection.mode: "preserve"` だけを許可する。

## Cell / Range

```json
{
  "id": "title",
  "sheet": "Main",
  "address": "A1:B2",
  "policy": "managed",
  "values": [["A", "B"], [1, 2]]
}
```

対応policy:

| policy | 意味 |
|---|---|
| managed | 値または数式を定義どおり管理 |
| preserve | 既存内容を読み書きしない |
| setIfBlank | 管理範囲が空の時だけ設定 |
| clear | `ClearContents`を明示実行 |
| formulaOnly | formula/formulasだけを管理 |
| valueOnly | value/valuesだけを管理 |

`values` / `formulas` は範囲と同じ行列の2次元配列で、COMへ一括設定する。Managed Range同士、およびTable Rangeとの重なりは事前エラー。数式は英語関数名を使う非Local形式を正本とし、`Formula2`を優先し利用不可時だけ`Formula`へフォールバックする。外部Excelブック参照を含む数式・名前定義は解決結果を保証できないため事前拒否する。動的配列のspill領域を破壊する操作は今回保証しない。

`note`、`hyperlink`、`merge`、`allowDataLoss`を定義できる。新規Mergeは複数の既存値/数式がある場合に事前停止する。`allowDataLoss`は明示的な例外許可だが、管理外範囲まで拡張しない。

## Style / Row / Column / View

Range `style` でfont name/size/bold/italic/underline/color、fillColor、horizontal/vertical alignment、wrap、shrink、indent、orientation、numberFormat、borderを指定できる。色は `#RRGGBB`。ThemeColor/ColorIndexをRGBへ暗黙変換しない。

`rows` / `columns` はsheet、1始まりindex、size、hiddenを明示する。シート全体へ設定しない。AutoFitは環境差で冪等性を保証できないため `autoFit: true` を拒否する。Freeze Panes、Zoom、Gridline、HeadingはWorksheet `view` で管理する。

## Validation / Table / Name

- Validationは list / whole / decimal / date / time / textLength / custom。明示Range内だけを `replaceManagedRange` で置換する。
- Tableは一意なNameとRangeで識別し、新規作成または拡張だけを許可する。既存Tableの行/列縮小は拒否する。
- NameはWorkbook scopeまたはWorksheet名scopeで追加/更新する。未定義Nameを削除せず、`_xlnm.*`を通常名として管理しない。
- 条件付き書式は安全な管理ルール識別を保証できないため、schema/識別設計はBだが非空定義をApply前に `WB1170` で拒否する。
- AutoFilter、Outline、Groupは今回のApply対象外。

## Shape / Asset

AssetはProject内の `source` または `assets` 配下の相対パスだけを許可し、png/jpg/jpeg/gif/bmpの存在とSHA-256を検証する。

- Picture新規追加、同一Hash再実行、位置/サイズ/縦横比/Placement/代替テキスト/Nameを管理できる。
- 既存Pictureの内容差分は検出する。Office COMに参照保持Replace APIがない環境では `WB2592` で更新前停止し、削除・再挿入しない。
- TextBox追加/文字列/位置/サイズは対応。
- Basic ShapeとChartObjectの追加/位置/サイズのコード基盤はあるが、全Excelバージョンの統合検証未完了。
- Group/OLE/ActiveX/SmartArtを名前で対象にした場合は検出して停止する。
- `OnAction` は定義を許可せず、既存値を変更しない。
- Chart series、軸、凡例、Chart type、SmartArt詳細、Slicer/Timelineは設計のみ。

## Page Setup

printArea、printTitleRows/Columns、paperSize、orientation、zoomまたはFitToPages、各margin、中央寄せ、header/footer、白黒、draft、comment/error、gridline、heading、order、手動改ページ追加を明示管理できる。

`zoom` と `fitToPagesWide/Tall` の同時指定はエラー。Fit指定時は先にZoomをfalseへする。既存の管理外手動改ページを消す `resetManualBreaks` は拒否する。Page Setupは既定プリンター/driver依存の項目があり、実機統合テストで確認していない組合せはB分類とする。

## 差分・冪等性

- Excelの数値、日付、Boolean、改行、Range配列の下限を正規化する。
- RowHeight等はExcel丸めを考慮した許容差を使う。
- Shape座標はポイント換算誤差を考慮する。
- PictureはAsset SHA-256を管理Markerに保存する。値本文はログに保存しない。
- ApplyはPlanでchangedとなったIDだけを実行する。
- 保存後に同じ定義で再Diffし、残差があれば成功にしない。

## Transactionとログ

ログ項目はProject、Target、Mode、schema、時刻、changed/applied、Backup、Restore試行/結果、Close/Quitエラー、エラーコード。Cell値、Password、Tokenは出力しない。

主なコード:

| Code | 意味 |
|---|---|
| WB0000 | 成功 |
| WB0001 | Workbook定義なし/無効 |
| WB0002 | 差分0、更新なし |
| WB10xx | Project設定/Pathエラー |
| WB11xx～12xx | schema/型/重複/競合/未対応定義 |
| WB20xx～26xx | Workbook状態/COM/安全性エラー |
| WB2592 | 安全な既存画像置換APIなし |
| WB3001 | 保存後Verify残差 |
| WB3003 | 更新失敗、復元成功 |
| WB3004 | 更新失敗、復元失敗 |
| WB3999 | 専用テスト用の障害注入 |

CLIプロセス終了コードは従来互換で成功0、エラー1。詳細はメッセージとJSONログのWB codeで区別する。

## Migration基盤

Project schemaは既存1.0を維持し、Workbook schemaは独立した1.0。将来はProject schema、Workbook schema、ブック側適用version、Migration ID、前提version、順序、再実行可否、rollback可否を分離する。今回 `migrations` は空配列だけを許可し、実行済み情報をブックへ書かない。将来の格納候補はVeryHidden管理SheetまたはCustomDocumentPropertyだが、破損耐性・ユーザー業務影響を検証してから採用する。

## CLI

```powershell
.\vba.cmd workbook-validate -Project Sample
.\vba.cmd workbook-diff -Project Sample
.\vba.cmd workbook-apply -Project Sample
.\vba.cmd workbook-verify -Project Sample
.\vba.cmd project-push -Project Sample
.\vba.cmd workbook-test
.\vba.cmd workbook-integration-test
```

各コマンドは直接Project Folderを指定する既存 `-ProjectRoot` 解決にも対応する。`-Json` はWorkbookコマンド成功結果に利用できる。

## GUI

既存画面へ「Workbook定義」を1行追加し、なし/無効/あり/ファイルなし/エラーを表示する。Push時のPreflight、差分件数、警告、更新・復元結果は従来のCLI出力ログ領域へ表示する。GUI固有の更新ロジックは複製しない。
