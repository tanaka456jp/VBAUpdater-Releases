﻿$ErrorActionPreference='Stop'
Set-StrictMode -Version 2.0
$root=$PSScriptRoot

$forbiddenTrackedRoots=@('logs','backups','dist','build','out','artifacts')
foreach($name in $forbiddenTrackedRoots){
 $p=Join-Path $root $name
 if(Test-Path -LiteralPath $p -PathType Container){
  $files=@(Get-ChildItem -LiteralPath $p -Recurse -Force -File -ErrorAction SilentlyContinue)
  if($files.Count -gt 0){
   $fileList = ($files | ForEach-Object { "  - $($_.FullName.Substring($root.Length+1)) ($($_.Length) bytes, $($_.LastWriteTime))" }) -join "`n"
   throw ("ローカル専用フォルダにファイルが残っています: $name ($($files.Count) files)`n" +
          "これらのフォルダはビルド成果物・一時ファイル用であり、Git管理外です。`n" +
          "RC Validation実行前は空である必要があります。`n" +
          "残存ファイル一覧:`n$fileList`n`n" +
          "対処: これらが前回のRC成果物生成で残ったものなら、手動で削除するか、正式な clean 手順を実行してください。`n" +
          "ユーザー作成ファイルが含まれている場合は、別の場所へ移動してから再実行してください。")
  }
 }
}

foreach($pattern in @('*.log','*.tmp','*.bak','*.old')){
 $hits=@(Get-ChildItem -LiteralPath $root -Recurse -Force -File -Filter $pattern -ErrorAction SilentlyContinue |
  Where-Object { $_.FullName -notmatch '\\.git\\' })
 if($hits.Count -gt 0){throw "ローカル/一時ファイルが正本に混在しています: $($hits[0].FullName)"}
}

$required=@('.gitignore','.gitattributes','VerifyPackage.ps1','RUNTIME_BASELINE.sha256','BuildInstaller.cmd','BuildInstaller.ps1')
foreach($rel in $required){
 if(-not(Test-Path -LiteralPath (Join-Path $root $rel) -PathType Leaf)){throw "Git正本必須ファイル不足: $rel"}
}
Write-Host 'Repository hygiene check passed.' -ForegroundColor Green
exit 0
