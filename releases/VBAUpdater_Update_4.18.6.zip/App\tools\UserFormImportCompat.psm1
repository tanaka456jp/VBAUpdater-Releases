Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Get-UserFormVbeAnsiEncoding {
    [CmdletBinding()]
    param([int]$CodePage = 0)

    if ($CodePage -le 0) {
        $CodePage = [System.Globalization.CultureInfo]::CurrentCulture.TextInfo.ANSICodePage
    }

    return [System.Text.Encoding]::GetEncoding(
        $CodePage,
        [System.Text.EncoderFallback]::ExceptionFallback,
        [System.Text.DecoderFallback]::ExceptionFallback)
}

function Read-UserFormCanonicalText {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Path)

    $bytes = [System.IO.File]::ReadAllBytes($Path)
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        return [System.Text.Encoding]::UTF8.GetString($bytes, 3, $bytes.Length - 3)
    }

    $strictUtf8 = New-Object System.Text.UTF8Encoding($false, $true)
    try {
        return $strictUtf8.GetString($bytes)
    }
    catch {
        throw "[UFI1001] UserForm .frm must be canonical UTF-8. Path=$Path / $($_.Exception.Message)"
    }
}

function New-UserFormVbeImportPair {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$FrmPath,
        [Parameter(Mandatory=$true)][string]$FrxPath,
        [int]$CodePage = 0
    )

    if (-not (Test-Path -LiteralPath $FrmPath -PathType Leaf)) { throw "[UFI1002] .frm not found: $FrmPath" }
    if (-not (Test-Path -LiteralPath $FrxPath -PathType Leaf)) { throw "[UFI1003] .frx not found: $FrxPath" }
    if ([System.IO.Path]::GetExtension($FrmPath) -ine '.frm') { throw "[UFI1004] Invalid .frm path: $FrmPath" }
    if ([System.IO.Path]::GetExtension($FrxPath) -ine '.frx') { throw "[UFI1005] Invalid .frx path: $FrxPath" }

    $frmBase = [System.IO.Path]::GetFileNameWithoutExtension($FrmPath)
    $frxBase = [System.IO.Path]::GetFileNameWithoutExtension($FrxPath)
    if (-not [string]::Equals($frmBase, $frxBase, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "[UFI1006] .frm/.frx basename mismatch. Frm=$FrmPath / Frx=$FrxPath"
    }

    $text = Read-UserFormCanonicalText -Path $FrmPath
    $encoding = Get-UserFormVbeAnsiEncoding -CodePage $CodePage

    try {
        $ansiBytes = $encoding.GetBytes($text)
        $roundTrip = $encoding.GetString($ansiBytes)
    }
    catch {
        throw "[UFI1007] UserForm contains text not representable by VBE ANSI code page $($encoding.CodePage). Path=$FrmPath / $($_.Exception.Message)"
    }

    if (-not [string]::Equals($text, $roundTrip, [System.StringComparison]::Ordinal)) {
        throw "[UFI1008] UserForm ANSI conversion is not lossless. CodePage=$($encoding.CodePage) / Path=$FrmPath"
    }

    $tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('VBAUpdater_UserForm_' + [Guid]::NewGuid().ToString('N'))
    $tempFrm = Join-Path $tempRoot ($frmBase + '.frm')
    $tempFrx = Join-Path $tempRoot ($frmBase + '.frx')

    try {
        [System.IO.Directory]::CreateDirectory($tempRoot) | Out-Null
        [System.IO.File]::WriteAllBytes($tempFrm, $ansiBytes)
        [System.IO.File]::Copy($FrxPath, $tempFrx, $false)

        if (-not (Test-Path -LiteralPath $tempFrm -PathType Leaf)) { throw '[UFI1009] Temporary .frm was not created.' }
        if (-not (Test-Path -LiteralPath $tempFrx -PathType Leaf)) { throw '[UFI1010] Temporary .frx was not created.' }

        $sourceFrxHash = (Get-FileHash -LiteralPath $FrxPath -Algorithm SHA256).Hash
        $tempFrxHash = (Get-FileHash -LiteralPath $tempFrx -Algorithm SHA256).Hash
        if ($sourceFrxHash -ne $tempFrxHash) { throw '[UFI1011] Temporary .frx copy verification failed.' }

        return [PSCustomObject]@{
            TempRoot = $tempRoot
            FrmPath = $tempFrm
            FrxPath = $tempFrx
            CodePage = $encoding.CodePage
            SourceFrmPath = [System.IO.Path]::GetFullPath($FrmPath)
            SourceFrxPath = [System.IO.Path]::GetFullPath($FrxPath)
        }
    }
    catch {
        if (Test-Path -LiteralPath $tempRoot) {
            Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
        }
        throw
    }
}

function Remove-UserFormVbeImportPair {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)]$Pair)

    $root = [string]$Pair.TempRoot
    if ([string]::IsNullOrWhiteSpace($root)) { throw '[UFI1012] Temporary UserForm root is empty.' }

    $tempBase = [System.IO.Path]::GetFullPath([System.IO.Path]::GetTempPath()).TrimEnd('\') + '\'
    $fullRoot = [System.IO.Path]::GetFullPath($root)
    if (-not $fullRoot.StartsWith($tempBase, [System.StringComparison]::OrdinalIgnoreCase) -or
        [System.IO.Path]::GetFileName($fullRoot) -notlike 'VBAUpdater_UserForm_*') {
        throw "[UFI1013] Refusing to delete unexpected path: $fullRoot"
    }

    if (Test-Path -LiteralPath $fullRoot) {
        Remove-Item -LiteralPath $fullRoot -Recurse -Force -ErrorAction Stop
    }
    if (Test-Path -LiteralPath $fullRoot) { throw "[UFI1014] Temporary UserForm files could not be removed: $fullRoot" }
}

Export-ModuleMember -Function New-UserFormVbeImportPair,Remove-UserFormVbeImportPair,Get-UserFormVbeAnsiEncoding
