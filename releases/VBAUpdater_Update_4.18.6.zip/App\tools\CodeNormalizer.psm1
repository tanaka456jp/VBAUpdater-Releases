﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Read-VbaTextFile {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "テキストファイルが見つかりません: $Path"
    }

    $bytes = [System.IO.File]::ReadAllBytes($Path)
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        return [System.Text.Encoding]::UTF8.GetString($bytes, 3, $bytes.Length - 3)
    }
    if ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
        return [System.Text.Encoding]::Unicode.GetString($bytes, 2, $bytes.Length - 2)
    }
    if ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFE -and $bytes[1] -eq 0xFF) {
        return [System.Text.Encoding]::BigEndianUnicode.GetString($bytes, 2, $bytes.Length - 2)
    }

    # UTF-8を厳密判定し、失敗した場合はWindows既定コードページ（日本語環境ではShift-JIS）を使う。
    try {
        $utf8Strict = New-Object System.Text.UTF8Encoding($false, $true)
        return $utf8Strict.GetString($bytes)
    }
    catch {
        return [System.Text.Encoding]::Default.GetString($bytes)
    }
}

function Remove-VbeMetadataLines {
    [CmdletBinding()]
    param(
        [AllowNull()][AllowEmptyCollection()][AllowEmptyString()][string[]]$Lines,
        [Parameter(Mandatory=$true)][ValidateSet('standard','class','document','userform')][string]$ComponentType
    )

    $result = New-Object System.Collections.Generic.List[string]
    $inClassHeader = $false

    foreach ($line in $Lines) {
        $trim = $line.Trim()

        if ($trim -match '^Attribute\s+') { continue }

        if ($ComponentType -in @('class','document')) {
            if ($trim -match '^VERSION\s+[0-9.]+\s+CLASS\s*$') {
                $inClassHeader = $true
                continue
            }
            if ($inClassHeader) {
                if ($trim -eq 'BEGIN') { continue }
                if ($trim -eq 'END') { $inClassHeader = $false; continue }
                # MultiUse等のクラスヘッダー設定
                if ($trim -match '^[A-Za-z][A-Za-z0-9_]*\s*=') { continue }
                # 不明なヘッダー行でもOption Explicit以前は除去
                if ($trim -notmatch '^(Option\s+|Public\s+|Private\s+|Friend\s+|Dim\s+|Const\s+|Sub\s+|Function\s+|Property\s+|Event\s+|Enum\s+|Type\s+|Declare\s+|#)') { continue }
                $inClassHeader = $false
            }
        }

        if ($ComponentType -eq 'userform') {
            # .frxのファイル名は展開・一時出力先で変わり得るため名前だけ正規化する。
            if ($line -match '^(\s*OleObjectBlob\s*=\s*")[^"]+("\s*:\s*[0-9A-Fa-f]+\s*)$') {
                $line = $matches[1] + '__FORM_BINARY__.frx' + $matches[2]
            }
        }

        $result.Add($line)
    }

    return @($result)
}

function Normalize-VbaText {
    [CmdletBinding()]
    param(
        [AllowEmptyString()][string]$Text,
        [Parameter(Mandatory=$true)][ValidateSet('standard','class','document','userform')][string]$ComponentType
    )

    if ($null -eq $Text) { $Text = '' }
    $Text = $Text.TrimStart([char]0xFEFF)
    $Text = $Text -replace "`r`n", "`n"
    $Text = $Text -replace "`r", "`n"

    $lines = @($Text.Split([string[]]@("`n"), [System.StringSplitOptions]::None))
    $lines = Remove-VbeMetadataLines -Lines $lines -ComponentType $ComponentType

    $normalized = New-Object System.Collections.Generic.List[string]
    $previousBlank = $true
    foreach ($line in $lines) {
        $value = $line.TrimEnd()
        $isBlank = [string]::IsNullOrWhiteSpace($value)
        if ($isBlank) {
            if (-not $previousBlank) { $normalized.Add('') }
        }
        else {
            $normalized.Add($value)
        }
        $previousBlank = $isBlank
    }

    while ($normalized.Count -gt 0 -and [string]::IsNullOrWhiteSpace($normalized[0])) {
        $normalized.RemoveAt(0)
    }
    while ($normalized.Count -gt 0 -and [string]::IsNullOrWhiteSpace($normalized[$normalized.Count - 1])) {
        $normalized.RemoveAt($normalized.Count - 1)
    }

    return ($normalized -join "`n")
}

function Get-NormalizedVbaFileContent {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][ValidateSet('standard','class','document','userform')][string]$ComponentType
    )
    return Normalize-VbaText -Text (Read-VbaTextFile -Path $Path) -ComponentType $ComponentType
}

function Get-FileSha256 {
    [CmdletBinding()]
    param([Parameter(Mandatory=$true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "バイナリファイルが見つかりません: $Path" }
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToUpperInvariant()
}


function ConvertTo-VbaSemanticLine {
    [CmdletBinding()]
    param([AllowEmptyString()][string]$Line)

    if ($null -eq $Line) { return '' }

    $builder = New-Object System.Text.StringBuilder
    $inString = $false
    $pendingSpace = $false
    $i = 0

    while ($i -lt $Line.Length) {
        $ch = $Line[$i]

        if ($inString) {
            [void]$builder.Append($ch)
            if ($ch -eq '"') {
                if (($i + 1) -lt $Line.Length -and $Line[$i + 1] -eq '"') {
                    [void]$builder.Append('"')
                    $i += 2
                    continue
                }
                $inString = $false
            }
            $i++
            continue
        }

        if ($ch -eq '"') {
            if ($pendingSpace -and $builder.Length -gt 0) { [void]$builder.Append(' ') }
            $pendingSpace = $false
            [void]$builder.Append($ch)
            $inString = $true
            $i++
            continue
        }

        if ([char]::IsWhiteSpace($ch)) {
            $pendingSpace = $true
            $i++
            continue
        }

        if ($pendingSpace -and $builder.Length -gt 0) { [void]$builder.Append(' ') }
        $pendingSpace = $false

        # VBAのキーワード・識別子は大文字小文字を区別しない。
        # 文字列リテラルだけは原文のまま保持する。
        [void]$builder.Append([char]::ToLowerInvariant($ch))
        $i++
    }

    return $builder.ToString().Trim()
}

function ConvertTo-VbaSemanticText {
    [CmdletBinding()]
    param(
        [AllowEmptyString()][string]$Text,
        [Parameter(Mandatory=$true)][ValidateSet('standard','class','document','userform')][string]$ComponentType
    )

    $normalized = Normalize-VbaText -Text $Text -ComponentType $ComponentType
    if ([string]::IsNullOrEmpty($normalized)) { return '' }

    $result = New-Object System.Collections.Generic.List[string]
    $userFormDesignerDepth = 0
    $userFormDesignerSeen = $false
    foreach ($line in @($normalized.Split([string[]]@("`n"), [System.StringSplitOptions]::None))) {
        $value = ConvertTo-VbaSemanticLine -Line $line

        if ($ComponentType -eq 'userform') {
            if ($value -match '^begin\s+') {
                $userFormDesignerDepth++
                $userFormDesignerSeen = $true
            }

            # VBEはUserFormデザイナの既知twip整数プロパティを再エクスポートすると、
            # 同じ値を 9036.001 / 9036 のように表記し直すことがある。
            # デザイナ定義ブロック内の .001 だけを吸収し、VBAコード、Caption、
            # 文字列、実際の座標・寸法変更は比較対象に残す。
            if ($userFormDesignerSeen -and $userFormDesignerDepth -gt 0 -and
                $value -match '^(?<property>(?:client|scroll)?(?:height|width|left|top))\s*=\s*(?<integer>-?\d+)\.001$') {
                $value = $matches['property'] + ' = ' + $matches['integer']
            }

            # FRX内の格納位置はVBEの再エクスポートで変化するため比較対象外。
            if ($value -match '^(oleobjectblob|picture|mouseicon|icon)\s*=') {
                $value = $value -replace ':\s*[0-9a-f]+\s*$', ':__binary_offset__'
            }

            # UserFormをVBEから再エクスポートすると、フォーム定義のEndと
            # Option Explicitの間などに空行が自動挿入されることがある。
            # 空行はフォーム定義・VBAコードの意味に影響しないため比較対象外とする。
            if ([string]::IsNullOrWhiteSpace($value)) { continue }

            if ($userFormDesignerSeen -and $userFormDesignerDepth -gt 0 -and $value -eq 'end') {
                $userFormDesignerDepth--
            }
        }
        $result.Add($value)
    }

    return ($result -join "`n").Normalize([System.Text.NormalizationForm]::FormC)
}

function Get-VbaSemanticDifference {
    [CmdletBinding()]
    param(
        [AllowEmptyString()][string]$Left,
        [AllowEmptyString()][string]$Right,
        [Parameter(Mandatory=$true)][ValidateSet('standard','class','document','userform')][string]$ComponentType
    )

    $leftValue = ConvertTo-VbaSemanticText -Text $Left -ComponentType $ComponentType
    $rightValue = ConvertTo-VbaSemanticText -Text $Right -ComponentType $ComponentType
    $max = [Math]::Min($leftValue.Length, $rightValue.Length)
    $index = 0
    while ($index -lt $max -and $leftValue[$index] -eq $rightValue[$index]) { $index++ }

    if ($index -eq $leftValue.Length -and $index -eq $rightValue.Length) {
        return [PSCustomObject]@{ Same=$true; Index=-1; LeftLength=$leftValue.Length; RightLength=$rightValue.Length; LeftContext=''; RightContext='' }
    }

    $start = [Math]::Max(0, $index - 30)
    $leftCount = [Math]::Min(80, [Math]::Max(0, $leftValue.Length - $start))
    $rightCount = [Math]::Min(80, [Math]::Max(0, $rightValue.Length - $start))
    return [PSCustomObject]@{
        Same=$false
        Index=$index
        LeftLength=$leftValue.Length
        RightLength=$rightValue.Length
        LeftContext=if($leftCount -gt 0){$leftValue.Substring($start,$leftCount)}else{''}
        RightContext=if($rightCount -gt 0){$rightValue.Substring($start,$rightCount)}else{''}
    }
}

function Test-VbaTextEquivalent {
    [CmdletBinding()]
    param(
        [AllowEmptyString()][string]$Left,
        [AllowEmptyString()][string]$Right,
        [Parameter(Mandatory=$true)][ValidateSet('standard','class','document','userform')][string]$ComponentType
    )
    $difference = Get-VbaSemanticDifference -Left $Left -Right $Right -ComponentType $ComponentType
    return [bool]$difference.Same
}

Export-ModuleMember -Function Read-VbaTextFile, Normalize-VbaText, Get-NormalizedVbaFileContent, Get-FileSha256, Test-VbaTextEquivalent, ConvertTo-VbaSemanticText, Get-VbaSemanticDifference
