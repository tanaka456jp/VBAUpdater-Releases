@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RunRCValidation.ps1"
set EC=%ERRORLEVEL%
echo.
if not "%EC%"=="0" (
  echo RC validation failed. ErrorLevel=%EC%
) else (
  echo RC validation completed successfully.
)
pause
exit /b %EC%
