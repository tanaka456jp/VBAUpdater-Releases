# Internal Project Root

この`project`フォルダーは後方互換用の既定プロジェクトルートです。

外部プロジェクトルートを設定していない場合だけ、ここにあるプロジェクトを使用します。Ver4.14.0以降の推奨運用では、業務プロジェクトをVBAUpdater本体の外部へ保存します。

```powershell
.\vba.cmd project-root-set -Path "C:\VBAProjects"
```

保存先の変更で既存プロジェクトが自動移動・コピー・削除されることはありません。詳しくはルート直下の`README_Chapter12-1_ExternalProjectRoot.md`を参照してください。
