﻿param([string]$RepositoryRoot=(Split-Path -Parent $PSScriptRoot))
Set-StrictMode -Version 2.0
$ErrorActionPreference='Stop'

# This script verifies that the V4.18.6 HotFix source changes are already present.
# It does NOT mutate tracked source files. The HotFix must be committed directly.

$workbook=Join-Path $RepositoryRoot 'App\tools\WorkbookUpdate.psm1'
if(-not(Test-Path -LiteralPath $workbook -PathType Leaf)){throw "WorkbookUpdate.psm1 not found: $workbook"}
$text=[IO.File]::ReadAllText($workbook,[Text.Encoding]::UTF8)

$expected='Import-Module $script:GeneratedDifferenceProvenanceModulePath -Force -DisableNameChecking -ErrorAction Stop'
$legacy='Import-Module $script:GeneratedDifferenceProvenanceModulePath -Force -ErrorAction Stop'

if($text.Contains($expected)){
    Write-Host '[OK] Provenance import warning suppression already applied in source.'
}elseif($text.Contains($legacy)){
    throw 'Legacy warning-producing import found in WorkbookUpdate.psm1. HotFix must be committed directly.'
}else{
    throw 'Expected GeneratedDifferenceProvenance import was not found in WorkbookUpdate.psm1.'
}

$gui=Join-Path $RepositoryRoot 'App\gui.ps1'
$guiText=[IO.File]::ReadAllText($gui,[Text.Encoding]::UTF8)

$required1 = '$standardTab.Text = ''ブック更新'''
$required2 = '$developerTab.Text = ''開発者向け'''
foreach($required in @($required1,$required2,'function Get-ProjectNames','function Refresh-Projects')){
  if($guiText.IndexOf($required,[StringComparison]::Ordinal)-lt 0){throw "RC2 GUI release gate failed: $required"}
}

$expectedReturn='return [PSCustomObject]@{ Names=[string[]]$names.ToArray() }'
if($guiText.Contains($expectedReturn)){
    Write-Host '[OK] Project-name return uses PSCustomObject envelope pattern.'
}else{
    throw 'Expected Get-ProjectNames PSCustomObject envelope return not found.'
}

$expectedEnumeration='foreach ($name in @($projectNames.Names)) { [void]$cmbProject.Items.Add([string]$name) }'
if($guiText.Contains($expectedEnumeration)){
    Write-Host '[OK] Refresh-Projects uses explicit PSCustomObject enumeration with [string] cast.'
}else{
    throw 'Expected Refresh-Projects enumeration pattern not found.'
}

$legacyEnumeration='foreach ($name in @(Get-ProjectNames)) { [void]$cmbProject.Items.Add($name) }'
if($guiText.Contains($legacyEnumeration)){
    throw 'Obsolete bare-array population detected in Refresh-Projects.'
}

if($guiText -match 'VBAUpdater_projects_json_'){
    throw 'Rejected GUI-side stderr isolation patch detected.'
}

Write-Host '[PASS] V4.18.6 HotFix source verification completed. No source mutation performed.'