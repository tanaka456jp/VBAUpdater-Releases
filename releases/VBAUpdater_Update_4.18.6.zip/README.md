﻿# VBAUpdater

## Ver4.18.0 Chapter1～9A/9B Safety Final HotFix

Project指定を省略したCLIが、保存済みの前回選択Projectや登録Projectを暗黙利用する経路を廃止しました。更新・テストでは `-ProjectRoot` を明示してください。通常CLIだけは、現在directoryまたは親階層の `project.json` を使用できます。Test Modeではこのcurrent-directory fallbackも無効です。

```powershell
.\vba.cmd project-preflight -ProjectRoot "C:\Development\ProjectName"
.\vba.cmd test-isolation-test
.\vba.cmd regression-test
.\vba.cmd isolated-excel-regression-test
```

テストは専用settings/logs/backups、許可ルート、Canary SHA-256、Workbook Open監査を使用します。Chapter1～9BではSAFE1023を維持したままWorkbook Integration Fixtureを正式Project構造へ修正し、全23工程のExcel統合回帰に成功しました。詳細とJournalConverter誤更新事象の記録は `docs/CHAPTER1-9A_SAFETY_HOTFIX.md` を参照してください。表示versionは4.18.0を維持します。

---

## Ver4.18.0 Chapter2 Persistent Project Settings

登録済みプロジェクト情報をVBAUpdater本体から分離し、`%LOCALAPPDATA%\VBAUpdater`へ永続化しました。本体を更新・差し替え・別フォルダーへ配置しても、Project Root、最近開いたプロジェクト、登録一覧、GUIサイズを復元します。

```powershell
.\vba.cmd settings
.\vba.cmd settings-persistence-test
```

GUIには「登録情報の保存場所」「登録先を変更」「登録解除」を追加しました。登録解除ではプロジェクトフォルダーを削除しません。

詳細: `README_Chapter13-2_SettingsPersistence.md` / `SETTINGS_JSON_SPEC_Ver4.18.0_Chapter2.md` / `PROJECTS_JSON_SPEC_Ver4.18.0_Chapter2.md` / `TEST_RESULTS_Ver4.18.0_Chapter2.md`

---

## Ver4.18.0 Development Project Sharing

GitHub・Codex・VBAUpdaterが同じ開発プロジェクトフォルダーを正本として共有する方式へ変更しました。GUIの「開発プロジェクトを登録」で既存フォルダーとExcelブックを選択してください。ProjectFolderは自動作成しません。

```powershell
.\vba.cmd project-create -ProjectFolder "C:\Development\OBCjournal" -WorkbookPath "C:\Work\OBCjournal.xlsm"
.\vba.cmd project-registration-v418-test
```

Ver4.17.0の「登録する」ボタンが有効にならない不具合は、GUI・CLI共通Validationと全入力イベントの即時再判定により根本修正しました。

詳細: `README_Chapter13-1_DevelopmentProjectSharing.md` / `DESIGN_Ver4.18.0.md` / `MIGRATION_Ver4.18.0.md` / `TEST_RESULTS_Ver4.18.0.md` / `CHANGED_FILES_Ver4.18.0.md` / `CHANGELOG_Ver4.18.0.md`

---

- code-read-test実行前のprePushフックを追加
- project-push/project-sync直前の復元ポイント自動作成
- rollback-list / rollback / rollback-testを追加
- SHA-256検証と復元直前安全バックアップを追加

# VBAUpdater Ver4.3.1 Chapter5-2 Manifest

## New commands

```powershell
.\vba.cmd manifest-test
.\vba.cmd project-preflight -Project PropertyManagement
.\vba.cmd project-push -Project PropertyManagement
.\vba.cmd project-compile -Project PropertyManagement
```

`project.json` defines the target workbook, source root, ordered components, optional hooks, and compile gate. Target file fallback remains safe: exact name first, then single-candidate auto detection only.


## Chapter5-2 Fixture Test 修正

`manifest-test` は PowerShell オブジェクトの `Clone()` を使用しません。
`tests/manifest` 配下の実ファイル `project.json` と `expectations.json` を読み込んで検証します。

```powershell
.\vba.cmd manifest-test
```

正常時:

```text
Manifestファイル回帰テストに成功しました。件数: 8
```

## Fixture test fix

`expectedErrorContains` is optional for successful test cases. The test runner now checks property existence before reading optional expectation fields.


## Fixture test correction

`multiple-targets` の期待エラーは、実装文言の接頭辞に依存しない `対象ブックが複数あります` の部分一致へ修正しています。

---

## Chapter5-3追加

```powershell
.\vba.cmd normalize-test
.\vba.cmd project-diff -Project PropertyManagement
```

詳細は `README_Chapter5-3.md` を参照してください。


## Chapter5-5B COM Collection Fix

`Get-ComProperty` が `VBComponents` などのCOMコレクションを PowerShell の出力パイプライン上で列挙し、`System.Object[]` に変換する問題を修正しました。`Write-Output -NoEnumerate` によりCOMコレクションを単一オブジェクトとして保持します。

Chapter5-5D Diagnostic: project-diff COM詳細診断ログを追加。

## Chapter5-5D6

Export後のPowerShell差分処理をD10-D23およびDXで診断します。詳細は `README_Chapter5-5D6_PostExportDiagnostic.md` を参照してください。


Chapter5-5D9: Format-HResultHexを自己完結関数として追加し、D30以降の本来の例外を診断します。

---

## Chapter5-5D10

`Get-ProjectDiff` の `List[object]` に対する `@()` 配列化を廃止し、差分項目を個別に返す方式へ修正しました。
詳細は `README_Chapter5-5D10_ResultPipelineFixed.md` を参照してください。


## Chapter5-6A
別ユーザー固定パスを廃止し、VBAUpdater.xlamの現在環境からの自動検出・設定自己修復・パッケージフォールバックを追加しました。


## Chapter5-6C
更新後差分確認の CodeModule.Lines 呼び出しを、COMのパラメーター付きプロパティとして取得するよう修正しました。


## Chapter5-6C 変更点

- VBEによる識別子の大文字・小文字補正を意味的に同一として比較
- 文字列リテラル内の大文字・小文字は保持
- 空白・タブ差を正規化
- UserFormのFRXオフセットを比較対象外に変更
- FRXの生SHA-256は診断情報として保持し、正規化済み.frmが一致した場合は同一判定
- 差分が残る場合、最初の差分位置と前後文脈を診断ログへ出力

## Chapter7-1: Project Status (Ver4.6.0)

Read-only project status:

```powershell
.\vba.cmd status
.\vba.cmd status -Project PropertyManagement
```

See `README_Chapter7-1_ProjectStatus.md`.

---

## Ver4.7.0 Chapter7-2

- Chapter7-1.1: 引数なし `status` のCountエラーを修正
- Chapter7-2: `history` コマンドを追加

詳細は以下を参照してください。

- `README_Chapter7-1-1_StatusHotFix.md`
- `README_Chapter7-2_ProjectHistory.md`

## Ver4.8.0 Chapter8-1

CLI引数解析とプロジェクト列挙を共通コアへ統合しました。引数なしの `status` / `history` で発生していたCountエラーを修正し、`cli-core-test` を追加しています。Pull／Sync日時はプロジェクト配下の `.vba/state.json` に永続保存されます。


## Ver4.8.1 Chapter8-1.1

CodeModuleの直接読取が空になる環境向けに、VBComponent.Exportによるフォールバックを追加しました。`code-read-test -Project <name>`で標準・クラス・Documentモジュールの読取を診断できます。

## Ver4.10.0 Chapter9 Integrity Check

Added project integrity validation:

```powershell
.\vba.cmd integrity-test
.\vba.cmd integrity -Project PropertyManagement
```

The check covers the manifest, source files, target workbook, required package files, and rollback restore points. Results are also written as JSON under `logs`.

## Ver4.10.1 Chapter9-1 Integrity Parser HotFix

復元ポイント整合性検証部のPowerShell ParserErrorを修正しました。詳細は `README_Chapter9-1_IntegrityParserHotFix.md` を参照してください。

## Ver4.10.2 Chapter9-2 Integrity Result Formatting HotFix

Integrity Checkの結果コレクションが入れ子配列として返され、コンソールに`System.Object[]`と表示される問題を修正しました。

- 検証結果をフラットな配列として返却
- 各Findingを`[OK] / [WARN] / [ERROR]`形式で個別表示
- Errors、Warnings、OKを実際の検証項目数で集計
- `integrity-test`に複数Findingの展開・集計回帰テストを追加

## Ver4.11.2 Chapter10-1 Windows GUI

Windows GUIを追加しました。`gui.cmd`または`.\vba.cmd gui`で起動します。詳細は`README_Chapter10-1_WindowsGUI.md`を参照してください。

## Ver4.11.3 Chapter10-1-3 GUI Output Reliability HotFix

Ver4.11.2のGUI用一時ランナーで発生するPowerShell構文エラー、`Write-Host`を含むCLI出力の欠落、終了直前の末尾ログ取りこぼしを修正しました。起動準備から終了までの例外処理と後始末も強化しています。

```powershell
.\vba.cmd gui-process-test
```

詳細は`README_Chapter10-1-3_GUIOutputReliabilityHotFix.md`を参照してください。

## Ver4.12.0 Chapter10-2 GUI Usability Improvements

Ver4.11.3を基準として、既存CLIロジックを変更・複製せず、Windows GUIの操作性と安全性を改善しました。

- 選択中プロジェクトのファイルシステム情報を自動表示
- 操作ボタンを「確認・参照」「ソース取得」「ブック更新」へ分類
- Pull、Push、Sync、最新復元ポイントへの復元で詳細な実行確認を表示
- 実行コマンド、1秒単位の経過時間、成功・失敗状態を表示
- 画面ログのクリア／コピー、ログフォルダー／最新ログ表示を追加
- GUIログを起動時に最新100件へ整理
- 実行中の画面終了確認と、子プロセス・Timer・一時ランナーの後始末を強化

追加回帰テスト:

```powershell
.\vba.cmd gui-usability-test
```

推奨確認コマンド:

```powershell
.\vba.cmd version
.\vba.cmd cli-core-test
.\vba.cmd integrity-test
.\vba.cmd gui-process-test
.\vba.cmd gui-usability-test
```

詳細は`README_Chapter10-2_GUIUsabilityImprovements.md`を参照してください。

## Ver4.12.1 Chapter10-3 Optional Compile Gate HotFix

Compile Gateをプロジェクト単位のオプション機能へ変更しました。`project-push`と`project-sync`は共通処理を使用し、GUIはCLIの終了コードとWARNINGログをそのまま表示します。

任意Compile Gate:

```json
"compileGate": {
  "macro": "EnsurePropertyHeaders",
  "required": false
}
```

必須Compile Gate:

```json
"compileGate": {
  "macro": "EnsurePropertyHeaders",
  "required": true
}
```

- `compileGate`未設定、または`required=false`でmacro未設定: スキップして正常終了
- `required=false`でマクロ不在・非Public・引数必須・マクロセキュリティ: WARNING、処理継続
- `required=true`でマクロ不在または実行不可: ERROR、処理失敗
- マクロ内部の実行時エラー、Excel COM失敗、分類不能な実行例外: requiredにかかわらずERROR
- `required`省略時は`false`
- 旧`validation.compileMacro`設定は`required=false`として後方互換読込

追加テスト:

```powershell
.\vba.cmd compile-gate-optional-test
```

詳細は`README_Chapter10-3_OptionalCompileGateHotFix.md`を参照してください。

## Ver4.13.0 Chapter11-1 GUIリニューアル

- 一般利用者向けの「ブック更新」タブを初期表示
- 主操作を「ブックを更新する」に一本化し、内部ではproject-syncを実行
- 開発者向け機能を別タブへ分離
- 対象ブック名、保存場所、最終更新日時と利用者向け更新状態を表示
- 詳細ログ折りたたみ、警告付き成功、完了日時・処理時間、対象ブックを開く操作を追加
- Source、Integrity、Pull／Push／Rollback等の高度な情報・操作は開発者タブに保持
- CLI更新・差分・Compile Gate・復元ロジックをGUIへ複製せず、終了コードを成否判定の正本として維持
- `gui-renewal-test`を追加

確認コマンド:

```powershell
.\vba.cmd version
.\vba.cmd gui-process-test
.\vba.cmd gui-usability-test
.\vba.cmd gui-renewal-test
.\vba.cmd compile-gate-optional-test
.\vba.cmd rollback-test
.\vba.cmd manifest-test
.\vba.cmd differential-push-test
.\vba.cmd cli-core-test
```

詳細は `README_Chapter11-1_GUIRenewal.md` を参照してください。

## Ver4.13.1 Chapter11-2 初回プロジェクト登録ウィザード

- 一般利用者向け画面へ「新しいプロジェクトを作成」を追加
- `.xlsm`、`.xlsb`、`.xlam`を選択して新規プロジェクトを登録
- 元ブックを変更せず、`target`へ上書き禁止でコピー
- 既存`schemaVersion: 1.0`互換の`project.json`を生成
- `project-create`から既存`project-pull`を呼び出して初期`source`を作成
- 失敗時は今回新規作成した項目だけをクリーンアップ
- 作成後にGUIのプロジェクト一覧を再読込し、新規プロジェクトを選択
- `project-create-test`と`project-registration-test`を追加

```powershell
.\vba.cmd project-create -Project <ProjectName> -WorkbookPath "<WorkbookPath>"
.\vba.cmd project-create-test
.\vba.cmd project-registration-test
```

詳細は `README_Chapter11-2_InitialProjectRegistration.md` を参照してください。

## Ver4.14.0 Chapter12-1 外部プロジェクトルート対応

- プロジェクトの保存先をVBAUpdater本体の外部へ変更可能
- GUIに現在の「プロジェクト保存先」「変更する」「既定に戻す」を追加
- ユーザー設定を `%LOCALAPPDATA%\VBAUpdater\settings.json` にUTF-8（BOMなし）で原子的に保存
- CLI、GUI、初回登録のすべてで同じプロジェクトルート解決を使用
- 優先順位は `-ProjectRoot`、ユーザー設定、従来の本体内設定、内部`project`フォルダーの順
- 設定破損時は破損ファイルを残したまま内部`project`へ安全にフォールバック
- 保存先変更時に既存プロジェクトを自動移動・コピー・削除しない

主なコマンド:

```powershell
.\vba.cmd project-root
.\vba.cmd project-root -Json
.\vba.cmd project-root-set -Path "D:\VBAProjects"
.\vba.cmd project-root-reset
.\vba.cmd project-sync -Project PropertyManagement -ProjectRoot "D:\VBAProjects"
.\vba.cmd project-root-test
```

詳細は `README_Chapter12-1_ExternalProjectRoot.md` を参照してください。

## Ver4.14.1 Chapter12-1 HotFix

新しいプロジェクト作成ウィザードで、Excelブック選択後にプロジェクト内部名を編集した際、空のパスが`Join-Path`へ渡されることがある問題を修正しました。

- 保存先、ブックパス、内部名を一括確認するコピー先表示共通関数を追加
- いずれかが空の場合は「対象ブック：-」「コピー先：-」を表示
- 計算失敗を「コピー先を計算できません。」という画面内メッセージへ変換
- `TextChanged`では150ミリ秒の遅延更新予約だけを行い、入力ごとのパス組み立てを抑止
- ブック選択中の内部名自動設定では表示更新を抑制し、最後に1回だけ更新
- 内部名の変更、再変更、削除、再入力を繰り返す専用回帰テストを追加

```powershell
.\vba.cmd project-registration-hotfix-test
```

詳細は `README_Chapter12-1_HotFix.md` を参照してください。

## Ver4.15.0 Chapter12-2 Project Root Migration Wizard

PC買い替え、Windows再インストール、OneDrive・NAS・外付SSDの移行などで、設定済みのプロジェクト保存先が見つからなくなった場合のGUI復旧機能を追加しました。

- GUI起動前に保存先喪失を検出し、「保存先を変更」「既定へ戻す」「終了」を表示
- 選択フォルダー直下から`project.json`、`source`、`target`を持つプロジェクトを検出
- 検出したプロジェクト名と件数を確認してから設定更新
- 0件の空フォルダーも新規プロジェクト作成先として設定可能
- 保存先表示へ「✓ 利用可能」「× 保存先が見つかりません」を追加
- 設定変更後はGUIを閉じずに一覧、対象ブック、選択状態を再読込
- プロジェクトの自動移動・コピー・削除は行わない

```powershell
.\vba.cmd project-root-check
.\vba.cmd project-root-check -Json
.\vba.cmd project-root-check -Path "D:\VBAProjects" -Json
.\vba.cmd project-root-migration-test
```

詳細は `README_Chapter12-2_ProjectRootMigration.md` を参照してください。

## Ver4.16.0 Chapter12-3 Codex Integration Export / Import

外部業務プロジェクトをCodexへ渡す直下構成ZIPの作成と、返却ZIPの安全なプレビュー・バックアップ・取り込みを追加しました。GUIでは「開発者向け」タブの「Codex連携」グループから操作できます。

- `project.json`、`source`、README、開発文書だけをエクスポート
- `target`、`backups`、`logs`、個人設定、秘密情報、VBAUpdater本体を除外
- 全ZIPエントリを展開前検証し、Zip Slip、絶対パス、UNC、重複、不正名を拒否
- 追加・変更・削除候補・変更なし・無視・危険項目をプレビュー
- 既存`source`と開発文書をZIPバックアップ後、ステージングから反映
- 削除候補と`project-sync`は既定で実行しない
- `-Json`時は標準出力を有効なJSONだけに限定

主なコマンド:

```powershell
.\vba.cmd codex-export -Project PropertyManagement
.\vba.cmd codex-export -Project PropertyManagement -OutputDir "C:\Users\User\Desktop" -Json
.\vba.cmd codex-import-preview -Project PropertyManagement -ZipPath "C:\Downloads\PropertyManagement_Codex_Result.zip"
.\vba.cmd codex-import-preview -Project PropertyManagement -ZipPath "C:\Downloads\PropertyManagement_Codex_Result.zip" -Json
.\vba.cmd codex-import -Project PropertyManagement -ZipPath "C:\Downloads\PropertyManagement_Codex_Result.zip"
.\vba.cmd codex-import -Project PropertyManagement -ZipPath "C:\Downloads\PropertyManagement_Codex_Result.zip" -Confirm -Json
.\vba.cmd codex-integration-test
```

詳細は `README_Chapter12-3_CodexIntegration.md` を参照してください。

## Ver4.17.0 Chapter12-4 Project Folder Direct Reference

GitHub・Codexで管理する個別プロジェクトフォルダーをコピーせず直接開けるようになりました。GUIの「プロジェクトフォルダを開く」、またはCLIの`-ProjectRoot "C:\Projects\PropertyManagement"`を使用します。

`project.json`、`source`、`target`を共通判定し、対象ブックはmanifest指定、`.xlsm`、`.xlam`、`.xlsb`の順で選択します。`.git`は任意であり、VBAUpdaterはGit操作や`.git`配下の走査を行いません。従来の`-Project PropertyManagement`方式も引き続き利用できます。

詳細は `README_Chapter12-4_ProjectFolderDirectReference.md` を参照してください。
