﻿$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$packageRoot = $PSScriptRoot
$buildVersionFile = Join-Path $packageRoot 'BUILD_VERSION.txt'
if (-not (Test-Path -LiteralPath $buildVersionFile -PathType Leaf)) { throw "BUILD_VERSION.txtが見つかりません: $buildVersionFile" }
$buildVersion = ([System.IO.File]::ReadAllText($buildVersionFile)).Trim()
if ([string]::IsNullOrWhiteSpace($buildVersion)) { throw 'BUILD_VERSION.txtが空です。' }
if ($buildVersion -notmatch '^[A-Za-z0-9._-]+$') { throw "BUILD_VERSION.txtに使用できない文字が含まれています: $buildVersion" }
$productVersionFile = Join-Path $packageRoot 'App\VERSION.txt'
if (-not (Test-Path -LiteralPath $productVersionFile -PathType Leaf)) { throw "App VERSION.txtが見つかりません: $productVersionFile" }
$productVersion = ([System.IO.File]::ReadAllText($productVersionFile)).Trim()
if ($productVersion -notmatch '^\d+\.\d+\.\d+$') { throw "App VERSION.txtの形式が不正です: $productVersion" }
$outputDir = Join-Path $packageRoot 'dist'
$workRoot = Join-Path $env:TEMP ('VBAUpdaterInstallerBuild_' + [guid]::NewGuid().ToString('N'))
$payloadZip = Join-Path $workRoot 'Payload.zip'
$csPath = Join-Path $workRoot 'VBAUpdaterSetupBootstrap.cs'
$outputExe = Join-Path $outputDir ("VBAUpdater_Setup_{0}.exe" -f $productVersion)

function Invoke-WithFileRetry {
    param(
        [Parameter(Mandatory=$true)][scriptblock]$Action,
        [string]$Description='ファイル処理',
        [int]$MaxAttempts=8,
        [int]$DelayMilliseconds=350
    )
    $last=$null
    for($attempt=1;$attempt -le $MaxAttempts;$attempt++){
        try {
            & $Action
            return
        } catch {
            $last=$_.Exception
            if($attempt -ge $MaxAttempts){break}
            Start-Sleep -Milliseconds $DelayMilliseconds
        }
    }
    throw ("{0}に失敗しました。{1}回試行しました。詳細: {2}" -f $Description,$MaxAttempts,$last.Message)
}

function Add-FileToPayloadZip {
    param(
        [Parameter(Mandatory=$true)]$Archive,
        [Parameter(Mandatory=$true)][string]$SourcePath,
        [Parameter(Mandatory=$true)][string]$EntryName
    )

    Invoke-WithFileRetry -Description ("Payload追加: "+$EntryName) -MaxAttempts 8 -DelayMilliseconds 300 -Action {
        $stream=$null
        $entryStream=$null
        try {
            # Read directly from the canonical source. FileShare.ReadWrite/Delete tolerates
            # non-exclusive antivirus/indexer access and avoids freshly copied Temp files.
            $stream=New-Object IO.FileStream(
                $SourcePath,
                [IO.FileMode]::Open,
                [IO.FileAccess]::Read,
                ([IO.FileShare]::ReadWrite -bor [IO.FileShare]::Delete)
            )
            $entry=$Archive.CreateEntry(($EntryName -replace '\\','/'),[IO.Compression.CompressionLevel]::Optimal)
            $entryStream=$entry.Open()
            $stream.CopyTo($entryStream)
        } finally {
            if($null-ne$entryStream){$entryStream.Dispose()}
            if($null-ne$stream){$stream.Dispose()}
        }
    }
}

function Add-DirectoryToPayloadZip {
    param(
        [Parameter(Mandatory=$true)]$Archive,
        [Parameter(Mandatory=$true)][string]$SourceDirectory,
        [Parameter(Mandatory=$true)][string]$EntryPrefix
    )
    if(-not(Test-Path -LiteralPath $SourceDirectory -PathType Container)){
        throw "ビルド対象フォルダーが見つかりません: $SourceDirectory"
    }
    foreach($file in @(Get-ChildItem -LiteralPath $SourceDirectory -Recurse -Force -File | Sort-Object FullName)){
        $relative=$file.FullName.Substring($SourceDirectory.Length).TrimStart('\','/')
        $entryName=($EntryPrefix.TrimEnd('/','\')+'/'+($relative -replace '\\','/'))
        Add-FileToPayloadZip -Archive $Archive -SourcePath $file.FullName -EntryName $entryName
    }
}

function New-VBAUpdaterPayloadZip {
    param([Parameter(Mandatory=$true)][string]$DestinationPath)

    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem

    if(Test-Path -LiteralPath $DestinationPath -PathType Leaf){
        Remove-Item -LiteralPath $DestinationPath -Force
    }

    $zipStream=$null
    $archive=$null
    try {
        $zipStream=New-Object IO.FileStream(
            $DestinationPath,
            [IO.FileMode]::CreateNew,
            [IO.FileAccess]::ReadWrite,
            [IO.FileShare]::None
        )
        $archive=New-Object IO.Compression.ZipArchive(
            $zipStream,
            [IO.Compression.ZipArchiveMode]::Create,
            $false
        )

        Add-DirectoryToPayloadZip -Archive $archive -SourceDirectory (Join-Path $packageRoot 'App') -EntryPrefix 'App'

        foreach($name in @('Setup.ps1','Uninstall.ps1','BUILD_VERSION.txt')){
            $source=Join-Path $packageRoot $name
            if(-not(Test-Path -LiteralPath $source -PathType Leaf)){throw "ビルド対象が見つかりません: $source"}
            Add-FileToPayloadZip -Archive $archive -SourcePath $source -EntryName $name
        }

        $readme=Join-Path $packageRoot 'README.txt'
        if(Test-Path -LiteralPath $readme -PathType Leaf){
            Add-FileToPayloadZip -Archive $archive -SourcePath $readme -EntryName 'README.txt'
        }
    } finally {
        if($null-ne$archive){$archive.Dispose()}
        if($null-ne$zipStream){$zipStream.Dispose()}
    }
}

function Find-CSharpCompiler {
    $candidates = @(
        (Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'),
        (Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe')
    )
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
    }
    $cmd = Get-Command csc.exe -ErrorAction SilentlyContinue
    if ($null -ne $cmd) { return $cmd.Source }
    throw 'WindowsのC#コンパイラ(csc.exe)が見つかりません。Windowsの.NET Framework 4.x機能を有効にしてから再実行してください。'
}

try {
    $verifyScript = Join-Path $packageRoot 'VerifyPackage.ps1'
    if (-not (Test-Path -LiteralPath $verifyScript -PathType Leaf)) { throw "VerifyPackage.ps1が見つかりません: $verifyScript" }
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $verifyScript
    if ($LASTEXITCODE -ne 0) { throw "配布前検証に失敗しました。ExitCode=$LASTEXITCODE" }

    New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
    New-Item -ItemType Directory -Path $workRoot -Force | Out-Null
    New-VBAUpdaterPayloadZip -DestinationPath $payloadZip

    $templateCs = Join-Path $packageRoot 'VBAUpdaterSetupBootstrap.cs'
    if (-not (Test-Path -LiteralPath $templateCs -PathType Leaf)) { throw "C#ブートストラップが見つかりません: $templateCs" }
    Invoke-WithFileRetry -Description 'C#ブートストラップコピー' -Action {
        Copy-Item -LiteralPath $templateCs -Destination $csPath -Force -ErrorAction Stop
    }

    $csc = Find-CSharpCompiler
    if (Test-Path -LiteralPath $outputExe) { Remove-Item -LiteralPath $outputExe -Force }

    $frameworkDir = Split-Path -Parent $csc
    $refs = @(
        (Join-Path $frameworkDir 'System.dll'),
        (Join-Path $frameworkDir 'System.Core.dll'),
        (Join-Path $frameworkDir 'System.Windows.Forms.dll'),
        (Join-Path $frameworkDir 'System.IO.Compression.dll'),
        (Join-Path $frameworkDir 'System.IO.Compression.FileSystem.dll')
    )
    foreach ($ref in $refs) {
        if (-not (Test-Path -LiteralPath $ref -PathType Leaf)) { throw "必要な.NET Framework DLLが見つかりません: $ref" }
    }

    $args = @('/nologo','/target:winexe','/platform:anycpu','/optimize+','/utf8output',('/out:' + $outputExe),('/resource:' + $payloadZip + ',Payload.zip'))
    foreach ($ref in $refs) { $args += ('/reference:' + $ref) }
    $args += $csPath

    $global:LASTEXITCODE = 0
    $compilerOutput = & $csc @args 2>&1
    $compilerExitCode = $global:LASTEXITCODE
    if ($compilerExitCode -ne 0 -or -not (Test-Path -LiteralPath $outputExe -PathType Leaf)) {
        $details = ($compilerOutput | Out-String).Trim()
        throw "EXE生成に失敗しました。ExitCode=$compilerExitCode`r`n$details"
    }

    $hash = (Get-FileHash -LiteralPath $outputExe -Algorithm SHA256).Hash
    $hashFile = Join-Path $outputDir ("VBAUpdater_Setup_{0}_SHA256.txt" -f $productVersion)
    [System.IO.File]::WriteAllText($hashFile,("{0}  {1}`r`n" -f $hash,[System.IO.Path]::GetFileName($outputExe)),(New-Object System.Text.UTF8Encoding($false)))

    Write-Host ''
    Write-Host 'Installer build completed.' -ForegroundColor Green
    Write-Host "EXE: $outputExe"
    Write-Host "SHA-256: $hash"
    # Keep automated/RC builds non-interactive. The caller can open dist explicitly.
    exit 0
}
catch {
    Write-Host ''
    Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
finally {
    if (Test-Path -LiteralPath $workRoot) {
        Remove-Item -LiteralPath $workRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}
