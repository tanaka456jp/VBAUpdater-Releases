﻿param(
    [string]$Project,
    [switch]$ProcessSelfTest,
    [switch]$UsabilitySelfTest,
    [switch]$CompileGateWarningSelfTest,
    [switch]$RenewalSelfTest,
    [switch]$RegistrationSelfTest,
    [switch]$RegistrationHotFixSelfTest,
    [switch]$ProjectRootSelfTest,
    [switch]$ProjectRootMigrationSelfTest,
    [switch]$CodexIntegrationSelfTest,
    [switch]$DirectReferenceSelfTest,
    [switch]$TestMode,
    [string]$TestRoot,
    [string]$ExpectedMigrationStatus,
    [int]$ExpectedMigrationProjects = -1
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$cliPath = Join-Path $root 'vba.ps1'
$projectRegistrationModulePath = Join-Path $root 'tools\ProjectRegistration.psm1'
if (-not (Test-Path -LiteralPath $projectRegistrationModulePath -PathType Leaf)) {
    throw "共通Project Registrationモジュールが見つかりません: $projectRegistrationModulePath"
}
Import-Module $projectRegistrationModulePath -Force -ErrorAction Stop
$operationalSafetyModulePath = Join-Path $root 'tools\OperationalSafety.psm1'
if (-not (Test-Path -LiteralPath $operationalSafetyModulePath -PathType Leaf)) {
    throw "Operational Safetyモジュールが見つかりません: $operationalSafetyModulePath"
}
Import-Module $operationalSafetyModulePath -Force -ErrorAction Stop
$productUpdateModulePath = Join-Path $root 'tools\ProductUpdate.psm1'
if (-not (Test-Path -LiteralPath $productUpdateModulePath -PathType Leaf)) { throw "ProductUpdate module not found: $productUpdateModulePath" }
Import-Module $productUpdateModulePath -Force -ErrorAction Stop
$script:operationalSession = $null
$script:SafetyGateTestMode = 'OFF'
$script:GuiLogRetentionCount = 100
$script:settingsInfo = $null
$script:registeredProjectFolders = @{}

$script:ProductVersion = '4.18.3'

function Get-GuiTestPropagationArguments {
    if (-not $TestMode) { return @() }
    if ([string]::IsNullOrWhiteSpace($TestRoot) -or -not [System.IO.Path]::IsPathRooted($TestRoot)) {
        throw 'GUI Test Modeには絶対パスの-TestRootが必要です。'
    }
    return @('-TestMode','-TestRoot',[System.IO.Path]::GetFullPath($TestRoot))
}

function Get-ProjectRootInfoFromCli {
    $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',$cliPath,'project-root','-Json')+@(Get-GuiTestPropagationArguments)
    $outputLines = @(& powershell.exe @arguments 2>&1)
    $exitCode = $LASTEXITCODE
    $output = $outputLines -join [Environment]::NewLine
    if ($exitCode -ne 0) { throw "プロジェクト保存先をCLIから取得できません。ExitCode=$exitCode / 詳細: $output" }
    try { return $output | ConvertFrom-Json }
    catch { throw "プロジェクト保存先のCLI応答を解析できません: $($_.Exception.Message) / 応答: $output" }
}

function Get-ProjectRootCheckFromCli {
    param([string]$Path)
    $arguments = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$cliPath,'project-root-check','-Json')
    if (-not [string]::IsNullOrWhiteSpace($Path)) { $arguments += @('-Path',$Path) }
    $arguments += @(Get-GuiTestPropagationArguments)
    $outputLines = @(& powershell.exe @arguments 2>&1)
    $exitCode = $LASTEXITCODE
    $output = $outputLines -join [Environment]::NewLine
    if ($exitCode -ne 0) { throw "プロジェクト保存先をCLIで確認できません。ExitCode=$exitCode / 詳細: $output" }
    try { return $output | ConvertFrom-Json }
    catch { throw "プロジェクト保存先確認のCLI応答を解析できません: $($_.Exception.Message) / 応答: $output" }
}

function Get-ProjectFolderCheckFromCli {
    param([Parameter(Mandatory=$true)][string]$Path,[string]$WorkbookPath)
    $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',$cliPath,'project-folder-check','-Path',$Path,'-Json')
    if (-not [string]::IsNullOrWhiteSpace($WorkbookPath)) { $arguments += @('-WorkbookPath',$WorkbookPath) }
    $arguments += @(Get-GuiTestPropagationArguments)
    $outputLines=@(& powershell.exe @arguments 2>&1)
    $exitCode=$LASTEXITCODE
    $output=$outputLines -join [Environment]::NewLine
    if ($exitCode -ne 0) { throw "プロジェクトフォルダーを確認できません。ExitCode=$exitCode / 詳細: $output" }
    try { return $output|ConvertFrom-Json }
    catch { throw "プロジェクトフォルダー確認のCLI応答を解析できません: $($_.Exception.Message) / 応答: $output" }
}

function Get-GuiTargetFingerprint {
    param([AllowEmptyString()][string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path) -or $Path -eq '-' -or -not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
    $item=Get-Item -LiteralPath $Path -Force
    return [PSCustomObject]@{
        Length=[long]$item.Length
        LastWriteTimeUtc=$item.LastWriteTimeUtc.ToString('o')
        Sha256=(Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash
    }
}

function Assert-GuiProjectSelectionSafe {
    param([Parameter(Mandatory=$true)][string]$Command)
    if ($null -eq $script:selectedProjectInfo) { throw '選択Projectを再確認できません。' }
    $rootPath=[System.IO.Path]::GetFullPath([string]$script:selectedProjectInfo.ProjectRoot)
    $targetPath=[System.IO.Path]::GetFullPath([string]$script:selectedProjectInfo.TargetPath)
    if (-not (Test-Path -LiteralPath $rootPath -PathType Container)) { throw "選択Project Rootが見つかりません: $rootPath" }
    if (-not (Test-Path -LiteralPath (Join-Path $rootPath 'project.json') -PathType Leaf)) { throw "project.jsonが見つかりません: $rootPath" }
    if (-not (Test-Path -LiteralPath $targetPath -PathType Leaf)) { throw "対象ブックが見つかりません: $targetPath" }
    $prefix=$rootPath.TrimEnd('\','/')+[System.IO.Path]::DirectorySeparatorChar
    if (-not $targetPath.StartsWith($prefix,[System.StringComparison]::OrdinalIgnoreCase)) { throw "対象ブックがProject Root外です: $targetPath" }
    $probe=Get-ProjectFolderCheckFromCli -Path $rootPath -WorkbookPath $targetPath
    if (-not [bool]$probe.CanPush -or
        -not [string]::Equals([string]$probe.ProjectRoot,$rootPath,[System.StringComparison]::OrdinalIgnoreCase) -or
        -not [string]::Equals([string]$probe.WorkbookPath,$targetPath,[System.StringComparison]::OrdinalIgnoreCase)) {
        throw '更新開始時のProject／対象ブック再検証に失敗しました。Projectを選択し直してください。'
    }
    $current=Get-GuiTargetFingerprint -Path $targetPath
    $selected=$script:selectedProjectInfo.TargetFingerprint
    if ($null -eq $selected -or $null -eq $current -or [long]$selected.Length -ne [long]$current.Length -or
        [string]$selected.LastWriteTimeUtc -ne [string]$current.LastWriteTimeUtc -or
        [string]$selected.Sha256 -ne [string]$current.Sha256) {
        throw "選択後に対象ブックが変更されました。安全のため$Commandを開始しません。Projectを再選択してください。"
    }
    Append-Log ("[GUI] 更新直前安全確認: Project Root={0} / Target={1} / SHA-256={2}" -f $rootPath,$targetPath,$current.Sha256)
}

function Get-ProjectNames {
    $script:settingsInfo=Get-SettingsInfoFromCli
    if($script:settingsInfo.PSObject.Properties['Logging'] -and $script:settingsInfo.Logging.PSObject.Properties['retentionCount']){$script:GuiLogRetentionCount=[Math]::Max(1,[int]$script:settingsInfo.Logging.retentionCount)}
    $script:registeredProjectFolders=@{}
    $names=New-Object 'System.Collections.Generic.List[string]'
    foreach($entry in @($script:settingsInfo.Projects|Sort-Object Name,ProjectFolder)){
        if($null-eq$entry){continue}
        $name=[string]$entry.Name
        if([string]::IsNullOrWhiteSpace($name)){continue}
        $script:registeredProjectFolders[$name]=[string]$entry.ProjectFolder
        if(-not $names.Contains($name)){$names.Add($name)}
    }
    return @($names.ToArray())
}

function Quote-ProcessArgument([string]$Value) {
    if ($null -eq $Value) { return '""' }
    return '"' + ($Value -replace '(\\*)"', '$1$1\"' -replace '(\\+)$', '$1$1') + '"'
}

function New-CliRunnerContent {
    param(
        [Parameter(Mandatory=$true)][string]$CliScriptPath,
        [Parameter(Mandatory=$true)][string[]]$CliArguments,
        [Parameter(Mandatory=$true)][string]$OutputPath
    )

    $CliArguments=@($CliArguments)+@(Get-GuiTestPropagationArguments)
    $escapedCli = $CliScriptPath.Replace("'", "''")
    $argLines = @($CliArguments | ForEach-Object { "    '" + ([string]$_).Replace("'", "''") + "'" })
    $escapedOutput = $OutputPath.Replace("'", "''")
    $runnerLines = New-Object 'System.Collections.Generic.List[string]'
    $runnerLines.Add("`$ErrorActionPreference = 'Continue'")
    $runnerLines.Add("`$cli = '$escapedCli'")
    $runnerLines.Add('$cliArgs = @(')
    foreach ($line in $argLines) { $runnerLines.Add($line) }
    $runnerLines.Add(')')
    # Write-Host（Information）を含む全PowerShellストリームをログへ集約する。
    $runnerLines.Add("& `$cli @cliArgs *>&1 | Out-File -LiteralPath '$escapedOutput' -Encoding utf8")
    $runnerLines.Add('$exitCode = $LASTEXITCODE')
    $runnerLines.Add('if ($null -eq $exitCode) { $exitCode = 0 }')
    $runnerLines.Add('exit $exitCode')
    return $runnerLines -join "`r`n"
}

function Invoke-GuiProcessSelfTest {
    $tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('VBAUpdaterGuiProcessTest_' + [guid]::NewGuid().ToString('N'))
    try {
        [void](New-Item -ItemType Directory -Path $tempRoot -Force)
        $cases = @(
            [PSCustomObject]@{ Name='success'; Arguments=@('version'); ExpectedExit=0; ExpectedText='VBA Project Update System Ver4.18.0' },
            [PSCustomObject]@{ Name='failure'; Arguments=@('definitely-invalid-command'); ExpectedExit=1; ExpectedText='不明なコマンドです: definitely-invalid-command' }
        )

        foreach ($case in $cases) {
            $outputPath = Join-Path $tempRoot ($case.Name + '.log')
            $runnerPath = Join-Path $tempRoot ($case.Name + '.ps1')
            $runner = New-CliRunnerContent -CliScriptPath $cliPath -CliArguments ([string[]]$case.Arguments) -OutputPath $outputPath
            [System.IO.File]::WriteAllText($runnerPath, $runner, (New-Object System.Text.UTF8Encoding($true)))
            & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $runnerPath
            $actualExit = $LASTEXITCODE
            $actualText = [System.IO.File]::ReadAllText($outputPath, [System.Text.Encoding]::UTF8)
            if ($actualExit -ne $case.ExpectedExit) {
                throw "GUIランナー終了コードが一致しません。Case=$($case.Name) Expected=$($case.ExpectedExit) Actual=$actualExit"
            }
            if ($actualText.IndexOf([string]$case.ExpectedText, [System.StringComparison]::Ordinal) -lt 0) {
                throw "GUIランナー出力が不足しています。Case=$($case.Name) Expected=$($case.ExpectedText)"
            }
            if ($case.Name -eq 'success' -and $actualText.Trim() -ne [string]$case.ExpectedText) {
                throw "GUIランナー正常系に予期しない出力があります。Actual=$($actualText.Trim())"
            }
            Write-Host ("  [OK] {0}: ExitCode={1}, LogLength={2}" -f $case.Name, $actualExit, $actualText.Length)
        }
        Write-Host 'GUI Process回帰テストに成功しました。'
    }
    finally {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-GuiCompileGateWarningSelfTest {
    $tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('VBAUpdaterGuiCompileGateTest_' + [guid]::NewGuid().ToString('N'))
    try {
        [void](New-Item -ItemType Directory -Path $tempRoot -Force)
        $outputPath = Join-Path $tempRoot 'optional-warning.log'
        $runnerPath = Join-Path $tempRoot 'optional-warning.ps1'
        $runner = New-CliRunnerContent -CliScriptPath $cliPath -CliArguments @('compile-gate-optional-test','-ProbeCase','optional-missing') -OutputPath $outputPath
        [System.IO.File]::WriteAllText($runnerPath, $runner, (New-Object System.Text.UTF8Encoding($true)))
        & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $runnerPath
        $actualExit = $LASTEXITCODE
        $actualText = [System.IO.File]::ReadAllText($outputPath, [System.Text.Encoding]::UTF8)
        if ($actualExit -ne 0) { throw "任意Compile Gate警告をGUIランナーが失敗扱いにしました。ExitCode=$actualExit" }
        foreach ($expected in @('[WARNING] 更新後コンパイルゲートを実行できませんでした。','CompileGateResult=WarningMacroUnavailable','ProbeResult=WarningMacroUnavailable')) {
            if ($actualText.IndexOf($expected, [System.StringComparison]::Ordinal) -lt 0) {
                throw "GUIランナーの警告ログが不足しています: $expected"
            }
        }
        if (-not $actualText.Trim().EndsWith('ProbeResult=WarningMacroUnavailable', [System.StringComparison]::Ordinal)) {
            throw 'GUIランナーが任意Compile Gate警告ログの末尾まで取得できませんでした。'
        }

        $guiText = [System.IO.File]::ReadAllText((Join-Path $root 'gui.ps1'), [System.Text.Encoding]::UTF8)
        if ($guiText -notmatch "Invoke-DangerousProjectCommand\s+-Command\s+'project-sync'") { throw 'GUIのSyncボタンが既存CLIへ接続されていません。' }
        if ($guiText -notmatch 'if\s*\(\$exitCode\s+-eq\s+0\)[\s\S]{0,500}\$resultStatus\s*=\s*''処理成功''') { throw 'GUIの終了コード0判定が見つかりません。' }
        if ($guiText -match 'function\s+Get-ProjectCompileGateSettings|function\s+Invoke-ProjectCompileGate') { throw 'Compile GateロジックがGUIへ複製されています。' }
        if ($guiText -match '\$form\.Close\s*\(') { throw 'CLI終了時にGUIを閉じる処理が検出されました。' }
        Write-Host 'GUI Compile Gate警告回帰テストに成功しました。'
    }
    finally {
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-GuiRenewalSelfTest {
    $guiText = [System.IO.File]::ReadAllText((Join-Path $root 'gui.ps1'), [System.Text.Encoding]::UTF8)
    $requirements = [ordered]@{
        'GUIバージョン' = '\$lblVersion\.Text\s*=\s*''Ver4\.18\.0'''
        '標準タブ' = '\$standardTab\.Text\s*=\s*''ブック更新'''
        '標準タブ初期表示' = '\$tabs\.SelectedIndex\s*=\s*0'
        '開発者タブ' = '\$developerTab\.Text\s*=\s*''開発者向け'''
        '一般利用者向け主ボタン' = 'Add-OperationButton\s+\$primaryPanel\s+''ブックを更新する''[\s\S]{0,500}Invoke-ProjectCommand[\s\S]{0,200}project-sync'
        '一般利用者向け復元ボタン' = 'Add-OperationButton\s+\$primaryPanel\s+''直前の状態に戻す''[\s\S]{0,700}rollback[\s\S]{0,400}-RestorePoint[\s\S]{0,200}latest[\s\S]{0,200}-Apply'
        'ブック更新の確認' = 'function\s+New-BookUpdateConfirmationMessage[\s\S]{0,1800}更新前の安全確認[\s\S]{0,600}更新履歴の記録'
        '対象ブックを開く' = '''対象ブックを開く''[\s\S]{0,700}Start-Process'
        '対象ブック存在時のみ有効' = 'function\s+Update-OpenTargetButtonState[\s\S]{0,700}Test-Path[\s\S]{0,500}btnOpenTarget\.Enabled'
        'フォルダーを開く' = '''フォルダーを開く''[\s\S]{0,700}explorer\.exe'
        '詳細ログ初期折りたたみ' = '\$logBox\.Visible\s*=\s*\$false'
        '詳細ログ展開・折りたたみ' = '詳細ログを表示[\s\S]{0,500}\$logBox\.Visible\s*=\s*-not\s+\$logBox\.Visible[\s\S]{0,300}詳細ログを隠す'
        '終了コード0を成功扱い' = 'if\s*\(\$exitCode\s+-eq\s+0\)[\s\S]{0,500}\$resultStatus\s*=\s*''処理成功'''
        'WARNINGを警告付き成功扱い' = 'IndexOf\(''\[WARNING\]''[\s\S]{0,400}\$resultStatus\s*=\s*''警告付き成功'''
        '終了コード非0を失敗扱い' = 'else\s*\{[\s\S]{0,400}ExitCode=[\s\S]{0,300}\$resultStatus\s*=\s*''処理失敗'''
        '実行中の操作無効化' = '\$cmbProject\.Enabled\s*=\s*-not\s+\$Value[\s\S]{0,300}foreach\s*\(\$button\s+in\s+\$operationButtons\)[\s\S]{0,200}\$button\.Enabled\s*=\s*-not\s+\$Value'
        '実行中表示' = 'Set-CurrentStatus\s+''処理実行中''[\s\S]{0,500}この画面を閉じずにお待ちください'
        'FormClosing安全確認' = 'Add_FormClosing[\s\S]{0,1000}処理が実行中です。[\s\S]{0,600}\$eventArgs\.Cancel\s*=\s*\$true[\s\S]{0,500}Clear-CliRuntime\s+\$true'
        '更新前のブック排他確認' = 'function\s+Confirm-GuiProjectSyncPreflight[\s\S]{0,3500}Test-WorkbookExclusiveWriteAccess[\s\S]{0,1800}Try-AcquireGuiProjectSyncLock'
        '同一ブック二重更新防止' = 'function\s+Try-AcquireGuiProjectSyncLock[\s\S]{0,1800}FileShare]::None[\s\S]{0,1500}projectSyncLockStream'
        '開発者Pull' = '''ブックからソースを取得''[\s\S]{0,300}project-pull'
        '開発者Push' = '''ソースをブックへ反映''[\s\S]{0,300}project-push'
        '開発者Sync' = '''安全なブック更新''[\s\S]{0,300}project-sync'
        '開発者Rollback' = '''最新復元ポイントへ戻す''[\s\S]{0,400}rollback'
        '開発者ログ操作' = '\$developerLogPanel[\s\S]{0,2500}ログをクリア[\s\S]{0,2500}ログをコピー[\s\S]{0,2500}ログフォルダーを開く[\s\S]{0,2500}最新ログを開く'
        '更新結果の明示' = 'function\s+Set-OperationResult[\s\S]{0,2500}ブックの更新が完了しました[\s\S]{0,1000}ブックの更新は完了しました[\s\S]{0,1000}ブックを更新できませんでした'
    }
    foreach ($item in $requirements.GetEnumerator()) {
        if (-not [System.Text.RegularExpressions.Regex]::IsMatch($guiText, [string]$item.Value, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
            throw "GUI Renewal要件が見つかりません: $($item.Key)"
        }
        Write-Host ("  [OK] {0}" -f $item.Key)
    }
    $standardButtons = [System.Text.RegularExpressions.Regex]::Matches(
        $guiText,
        'Add-OperationButton\s+\$(?:primaryPanel|logPanel)\s+''([^'']+)''',
        [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    foreach ($match in $standardButtons) {
        if ($match.Groups[1].Value -match '(?i)\b(?:Pull|Push|Sync|Integrity|Rollback|Compile\s+Gate)\b') {
            throw "標準画面に開発者向け用語のボタンが表示されています: $($match.Groups[1].Value)"
        }
    }
    Write-Host '  [OK] 標準画面に開発者向け英語ボタンはありません。'
    if ($guiText -match 'function\s+Invoke-ProjectPush\b|function\s+Invoke-ProjectPull\b|function\s+Invoke-ProjectSync\b|function\s+Get-ProjectDiff\b|function\s+Invoke-ProjectCompileGate\b|function\s+New-RestorePoint\b|Excel\.Application|\bVBProject\b|\bVBComponents\b') {
        throw 'CLI処理ロジックまたはExcel/VBAアクセスがGUIへ複製されています。'
    }
    Write-Host '  [OK] CLI更新・差分・Compile Gate・復元ロジックはGUIへ複製されていません。'
}

function Invoke-GuiRegistrationSelfTest {
    $guiText = [System.IO.File]::ReadAllText((Join-Path $root 'gui.ps1'), [System.Text.Encoding]::UTF8)
    $requirements = [ordered]@{
        'GUIバージョン' = 'Ver4\.18\.0'
        '開発プロジェクト登録ボタン' = 'Add-OperationButton\s+\$primaryPanel\s+''開発プロジェクトを登録'''
        '一般利用者向け配置' = '\$btnUpdateBook[\s\S]{0,1200}\$btnCreateProject'
        '登録ウィザード' = 'function\s+Show-ProjectRegistrationWizard'
        '開発フォルダー選択' = 'FolderBrowserDialog[\s\S]{0,1200}開発プロジェクトフォルダ'
        'ブック選択' = 'OpenFileDialog[\s\S]{0,1200}Excel VBAブック'
        '対応形式' = '\*\.xlsm;\*\.xlsb;\*\.xlam'
        '共通Validationサービス' = 'Get-ProjectRegistrationValidation\s+-ProjectFolder'
        '確認表示' = '開発プロジェクト[\s\S]{0,800}作成されるもの[\s\S]{0,400}project\.json[\s\S]{0,200}target\\[\s\S]{0,200}source\\'
        'CLI ProjectFolder接続' = 'Start-CliCommand\s+-Command\s+''project-create''[\s\S]{0,300}-ProjectFolder[\s\S]{0,300}-WorkbookPath'
        '作成中表示' = '初期ソースを作成しています'
        '作成後再読込' = 'Select-RegisteredProject[\s\S]{0,500}Refresh-Projects'
        '作成結果表示' = '開発プロジェクトの登録が完了しました[\s\S]{0,900}開発プロジェクトを登録できませんでした'
    }
    foreach ($item in $requirements.GetEnumerator()) {
        if (-not [System.Text.RegularExpressions.Regex]::IsMatch($guiText, [string]$item.Value, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
            throw "GUI Initial Project Registration要件が見つかりません: $($item.Key)"
        }
        Write-Host ("  [OK] {0}" -f $item.Key)
    }
    if ($guiText -match 'Excel\.Application|\bVBProject\b|\bVBComponents\b') {
        throw 'GUIへExcel/VBAアクセス処理が複製されています。'
    }
    Write-Host '  [OK] GUIはExcel/VBA処理と独自Validationを持たず、共通サービスを利用'
}

function Get-SettingsInfoFromCli {
    $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',$cliPath,'settings','-Json')+@(Get-GuiTestPropagationArguments)
    $outputLines=@(& powershell.exe @arguments 2>&1)
    $exitCode=$LASTEXITCODE
    $output=$outputLines -join [Environment]::NewLine
    if($exitCode-ne 0){throw "永続設定をCLIから取得できません。ExitCode=$exitCode / 詳細: $output"}
    try{return $output|ConvertFrom-Json}catch{throw "永続設定のCLI応答を解析できません: $($_.Exception.Message) / 応答: $output"}
}

function Get-LegacyProjectMigrationCheckFromCli {
    $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',$cliPath,'project-migration-check','-Json')+@(Get-GuiTestPropagationArguments)
    $outputLines = @(& powershell.exe @arguments 2>&1)
    $exitCode = $LASTEXITCODE
    $output = $outputLines -join [Environment]::NewLine
    if ($exitCode -ne 0) { throw "旧形式プロジェクトを確認できません。ExitCode=$exitCode / 詳細: $output" }
    try { return $output | ConvertFrom-Json }
    catch { throw "旧形式プロジェクト確認のCLI応答を解析できません: $($_.Exception.Message) / 応答: $output" }
}

function Invoke-GuiRegistrationHotFixSelfTest {
    $guiText = [System.IO.File]::ReadAllText((Join-Path $root 'gui.ps1'), [System.Text.Encoding]::UTF8)
    $requirements = [ordered]@{
        'HotFixバージョン' = 'Ver4\.18\.0'
        '共通Validationモジュール' = 'Import-Module\s+\$projectRegistrationModulePath'
        'GUI共通サービス呼出' = 'function\s+Get-ProjectRegistrationValidationFromGui[\s\S]{0,500}Get-ProjectRegistrationValidation'
        'フォルダー変更の即時再判定' = '\$txtProjectFolder\.Add_TextChanged\(\{[\s\S]{0,200}updateRegistrationState'
        'ブック変更の即時再判定' = '\$txtWorkbook\.Add_TextChanged\(\{[\s\S]{0,200}updateRegistrationState'
        'フォルダー選択後の再判定' = '\$btnBrowseFolder\.Add_Click[\s\S]{0,1800}updateRegistrationState'
        'ブック選択後の再判定' = '\$btnBrowseWorkbook\.Add_Click[\s\S]{0,1800}updateRegistrationState'
        '登録ボタン共通判定' = '\$btnRegister\.Enabled\s*=\s*\[bool\]\$validation\.CanRegister'
    }
    foreach ($item in $requirements.GetEnumerator()) {
        if (-not [System.Text.RegularExpressions.Regex]::IsMatch($guiText,[string]$item.Value,[System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
            throw "GUI Chapter12-1 HotFix要件が見つかりません: $($item.Key)"
        }
        Write-Host ("  [OK] {0}" -f $item.Key)
    }

    $wizardMatch = [System.Text.RegularExpressions.Regex]::Match($guiText,'function\s+Show-ProjectRegistrationWizard\b(?<Body>[\s\S]*?)(?=\r?\nfunction\s+Set-CurrentStatus\b)',[System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
    if (-not $wizardMatch.Success) { throw '登録ウィザード本体を検査できません。' }
    if ($wizardMatch.Groups['Body'].Value -match 'Get-ProjectRegistrationValidationMessage|Update-ProjectRegistrationCopyDestination|summaryUpdateTimer') {
        throw 'Ver4.17.0のGUI独自Validationまたは遅延タイマー判定が残っています。'
    }

    $tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('VBAUpdaterRegistration418_' + [guid]::NewGuid().ToString('N'))
    $folderText = $null
    $workbookText = $null
    $registerButton = $null
    try {
        New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null
        $projectFolder = Join-Path $tempRoot 'OneDrive - テスト\開発\日本語案件'
        New-Item -ItemType Directory -Path (Join-Path $projectFolder '.git') -Force | Out-Null
        $workbookPath = Join-Path $tempRoot '管理対象.xlsm'
        [System.IO.File]::WriteAllText($workbookPath,'registration hotfix placeholder')
        $eventErrors = New-Object 'System.Collections.Generic.List[string]'
        $states = New-Object 'System.Collections.Generic.List[object]'
        $folderText = New-Object System.Windows.Forms.TextBox
        $workbookText = New-Object System.Windows.Forms.TextBox
        $registerButton = New-Object System.Windows.Forms.Button
        $revalidate = {
            try {
                $state = Get-ProjectRegistrationValidationFromGui -ProjectFolder $folderText.Text -WorkbookPath $workbookText.Text
                $states.Add($state)
                $registerButton.Enabled = [bool]$state.CanRegister
            }
            catch { $eventErrors.Add($_.Exception.Message) }
        }.GetNewClosure()
        $folderText.Add_TextChanged({ & $revalidate }.GetNewClosure())
        $workbookText.Add_TextChanged({ & $revalidate }.GetNewClosure())

        $folderText.Text = $projectFolder
        if ($registerButton.Enabled) { throw 'ブック未選択時に登録ボタンが有効になりました。' }
        $workbookText.Text = $workbookPath
        if (-not $registerButton.Enabled) { throw 'フォルダーとブック選択後に登録ボタンが有効になりません。' }
        $validState = $states[$states.Count - 1]
        if ($validState.ProjectName -ne '日本語案件' -or -not $validState.IsGitRepository -or -not $validState.IsOneDrive) {
            throw '日本語・OneDrive・Git管理下の共通Validation結果が一致しません。'
        }
        $workbookText.Text = ''
        if ($registerButton.Enabled) { throw 'ブック選択解除後も登録ボタンが有効なままです。' }
        $workbookText.Text = $workbookPath
        if (-not $registerButton.Enabled) { throw 'ブック再選択後に登録ボタンが再有効化されません。' }
        if ($eventErrors.Count -ne 0) { throw ('入力イベント再判定で例外が発生しました: ' + ($eventErrors -join ' / ')) }
        Write-Host '  [OK] フォルダー・ブックの全TextChangedで無効→有効→無効→再有効をリアルタイム判定'
    }
    finally {
        if ($null -ne $folderText) { $folderText.Dispose() }
        if ($null -ne $workbookText) { $workbookText.Dispose() }
        if ($null -ne $registerButton) { $registerButton.Dispose() }
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-GuiProjectRootSelfTest {
    $guiText = [System.IO.File]::ReadAllText((Join-Path $root 'gui.ps1'), [System.Text.Encoding]::UTF8)
    $requirements = [ordered]@{
        'GUIバージョン' = 'Ver4\.18\.0'
        'CLIルート取得' = 'function\s+Get-ProjectRootInfoFromCli[\s\S]{0,1200}project-root[\s\S]{0,500}-Json'
        '保存先表示' = '\$lblProjectRootCaption\.Text\s*=\s*''Project Root（開発フォルダー）'''
        '変更ボタン' = '\$btnChangeProjectRoot[\s\S]{0,300}''プロジェクト保存先を変更'''
        '既定復帰ボタン' = '\$btnResetProjectRoot[\s\S]{0,300}''既定に戻す'''
        'フォルダー選択' = 'FolderBrowserDialog'
        '設定CLI接続' = 'Start-CliCommand\s+-Command\s+''project-root-set''[\s\S]{0,300}-Path'
        '解除CLI接続' = 'Start-CliCommand\s+-Command\s+''project-root-reset'''
        '一覧再読込' = 'Refresh-ProjectRootAndProjects[\s\S]{0,900}Refresh-Projects'
        '登録先連携' = 'Start-CliCommand\s+-Command\s+''project-create''[\s\S]{0,300}-ProjectFolder'
        'フォルダー操作連携' = 'selectedProjectInfo\.ProjectDirectory[\s\S]{0,500}explorer\.exe'
        '破損警告表示' = 'projectRootInfo\.Warning[\s\S]{0,700}Append-Log'
    }
    foreach ($item in $requirements.GetEnumerator()) {
        if (-not [System.Text.RegularExpressions.Regex]::IsMatch($guiText,[string]$item.Value,[System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
            throw "GUI External Project Root要件が見つかりません: $($item.Key)"
        }
        Write-Host ("  [OK] {0}" -f $item.Key)
    }
    if ($guiText -match 'LOCALAPPDATA[\s\S]{0,300}settings\.json|GetFolderPath\([^\)]*LocalApplicationData') {
        throw 'GUIへ設定ファイル解決ロジックが複製されています。'
    }
    $info = Get-ProjectRootInfoFromCli
    if ([string]::IsNullOrWhiteSpace([string]$info.Path) -or [string]::IsNullOrWhiteSpace([string]$info.Source)) {
        throw 'CLIからプロジェクト保存先情報を取得できませんでした。'
    }
    Write-Host ("  [OK] CLIプロジェクト保存先取得: {0} ({1})" -f $info.Path,$info.Source)
}

function Invoke-GuiProjectRootMigrationSelfTest {
    $guiText = [System.IO.File]::ReadAllText((Join-Path $root 'gui.ps1'),[System.Text.Encoding]::UTF8)
    $requirements = [ordered]@{
        'GUIバージョン' = 'Ver4\.18\.0'
        'CLI保存先確認' = 'function\s+Get-ProjectRootCheckFromCli[\s\S]{0,1200}project-root-check[\s\S]{0,500}-Json'
        '喪失時ダイアログ' = 'function\s+Show-MissingProjectRootRecoveryDialog[\s\S]{0,3500}プロジェクト保存先が見つかりません。'
        '保存先変更ボタン' = '保存先を変更'
        '既定復帰ボタン' = '既定へ戻す'
        '終了ボタン' = '''終了'''
        '候補選択' = 'function\s+Select-ProjectRootMigrationCandidate[\s\S]{0,1800}Get-ProjectRootCheckFromCli'
        '候補件数表示' = '件のプロジェクトが見つかりました。'
        '0件許可' = 'Project Rootとして使用できます。'
        '状態表示' = '\$lblProjectRootStatusCaption\.Text\s*=\s*''状態''[\s\S]*✓ 利用可能[\s\S]*× 保存先が見つかりません'
        '同期設定更新' = 'Invoke-ProjectRootSettingCliSynchronously[\s\S]{0,600}project-root-set'
        '同期既定復帰' = 'Invoke-ProjectRootSettingCliSynchronously[\s\S]{0,600}project-root-reset'
        '一覧即時再読込' = 'Invoke-ProjectRootStartupRecovery[\s\S]{0,2200}Refresh-ProjectRootAndProjects'
        '起動前復旧' = 'skipStartupRecovery[\s\S]{0,700}Invoke-ProjectRootStartupRecovery[\s\S]*\[void\]\$form\.ShowDialog'
        '旧形式自動検出' = 'function\s+Get-LegacyProjectMigrationCheckFromCli[\s\S]{0,900}project-migration-check'
        '自動移行ウィザード' = 'function\s+Invoke-LegacyProjectMigrationWizard[\s\S]{0,3500}project-migrate'
        '元データ保持案内' = '移行元は削除しません'
    }
    foreach ($item in $requirements.GetEnumerator()) {
        if (-not [System.Text.RegularExpressions.Regex]::IsMatch($guiText,[string]$item.Value,[System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
            throw "GUI Project Root Migration要件が見つかりません: $($item.Key)"
        }
        Write-Host ("  [OK] {0}" -f $item.Key)
    }
    if ($guiText -match 'LOCALAPPDATA[\s\S]{0,300}settings\.json|GetFolderPath\([^\)]*LocalApplicationData') {
        throw 'GUIへ設定ファイル解決ロジックが複製されています。'
    }
    $check = Get-ProjectRootCheckFromCli
    if (-not [string]::IsNullOrWhiteSpace($ExpectedMigrationStatus) -and [string]$check.Status -ne $ExpectedMigrationStatus) {
        throw "GUIのCLI保存先状態が期待値と一致しません。Expected=$ExpectedMigrationStatus Actual=$($check.Status)"
    }
    if ($ExpectedMigrationProjects -ge 0 -and [int]$check.Projects -ne $ExpectedMigrationProjects) {
        throw "GUIの候補件数が期待値と一致しません。Expected=$ExpectedMigrationProjects Actual=$($check.Projects)"
    }
    Write-Host ("  [OK] CLI保存先状態: {0} / Projects={1}" -f $check.Status,$check.Projects)
}

function Invoke-GuiCodexIntegrationSelfTest {
    $guiText = [System.IO.File]::ReadAllText((Join-Path $root 'gui.ps1'),[System.Text.Encoding]::UTF8)
    $requirements = [ordered]@{
        'GUIバージョン' = 'Ver4\.18\.0'
        '開発者向けCodexグループ' = "New-ActionGroup\s+'Codex連携'"
        'Codex用ZIP作成' = "'Codex用ZIPを作成'"
        'Codex納品ZIP確認' = "'Codex納品ZIPを確認'"
        'Codex納品ZIP取込' = "'Codex納品ZIPを取り込む'"
        'CLI JSON共通呼出' = 'function\s+Invoke-CodexCliJson[\s\S]{0,1800}-Json'
        'export CLI接続' = "Invoke-CodexCliJson[\s\S]{0,1500}'codex-export'"
        'preview CLI接続' = "Invoke-CodexCliJson[\s\S]{0,1800}'codex-import-preview'"
        'import CLI接続' = "Invoke-CodexCliJson[\s\S]{0,2200}'codex-import'"
        'プレビュー成功後のみ取込' = 'lastCodexPreview[\s\S]{0,700}btnCodexImport\.Enabled'
        '空Path防止' = 'IsNullOrWhiteSpace\(\$ZipPath\)[\s\S]{0,400}return'
        '削除は既定非反映' = '削除候補は既定では反映しません'
        '同期案内' = 'ブックを更新するには「ブックを更新する」'
    }
    foreach ($item in $requirements.GetEnumerator()) {
        if (-not [System.Text.RegularExpressions.Regex]::IsMatch($guiText,[string]$item.Value,[System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
            throw "GUI Codex Integration要件が見つかりません: $($item.Key)"
        }
        Write-Host ('  [OK] ' + $item.Key)
    }
    foreach ($forbidden in @('function\s+Get-CodexExportResult','function\s+New-CodexImportContext','function\s+Expand-CodexZipSafely','System\.IO\.Compression\.Zip')) {
        if ([System.Text.RegularExpressions.Regex]::IsMatch($guiText,$forbidden,[System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
            throw "Codex ZIP/差分ロジックがGUIへ重複実装されています: $forbidden"
        }
    }
    Write-Host '  [OK] GUIはCodex連携CLIのJSON結果だけを利用しています。'
}

if ($CompileGateWarningSelfTest) {
    try {
        Invoke-GuiCompileGateWarningSelfTest
        exit 0
    }
    catch {
        Write-Error $_.Exception.Message
        exit 1
    }
}

if ($ProcessSelfTest) {
    try {
        Invoke-GuiProcessSelfTest
        exit 0
    }
    catch {
        Write-Error $_.Exception.Message
        exit 1
    }
}

$form = New-Object System.Windows.Forms.Form
$form.Text = ('VBAプロジェクト更新システム V' + $script:ProductVersion)
$form.StartPosition = 'CenterScreen'
$workingArea = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$formWidth = [Math]::Min(1100, [Math]::Max(900, $workingArea.Width - 80))
$formHeight = [Math]::Min(760, [Math]::Max(650, $workingArea.Height - 80))
$form.Size = New-Object System.Drawing.Size($formWidth, $formHeight)
$form.MinimumSize = New-Object System.Drawing.Size(900, 650)
$form.Font = New-Object System.Drawing.Font('Yu Gothic UI', 9)

$toolTip = New-Object System.Windows.Forms.ToolTip

$rootLayout = New-Object System.Windows.Forms.TableLayoutPanel
$rootLayout.Dock = 'Fill'
$rootLayout.ColumnCount = 1
$rootLayout.RowCount = 2
$rootLayout.Padding = New-Object System.Windows.Forms.Padding(10)
[void]$rootLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 58)))
[void]$rootLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent', 100)))
$form.Controls.Add($rootLayout)

$headerPanel = New-Object System.Windows.Forms.Panel
$headerPanel.Dock = 'Fill'
$rootLayout.Controls.Add($headerPanel, 0, 0)

$lblTitle = New-Object System.Windows.Forms.Label
$lblTitle.Text = ('VBAプロジェクト更新システム V' + $script:ProductVersion)
$lblTitle.Font = New-Object System.Drawing.Font('Yu Gothic UI', 16, [System.Drawing.FontStyle]::Bold)
$lblTitle.AutoSize = $true
$lblTitle.Location = New-Object System.Drawing.Point(6, 3)
$headerPanel.Controls.Add($lblTitle)

$lblSubtitle = New-Object System.Windows.Forms.Label
$lblSubtitle.Text = 'Excelブックを安全に最新版へ更新します'
$lblSubtitle.AutoSize = $true
$lblSubtitle.ForeColor = [System.Drawing.Color]::DimGray
$lblSubtitle.Location = New-Object System.Drawing.Point(9, 34)
$headerPanel.Controls.Add($lblSubtitle)

$lblVersion = New-Object System.Windows.Forms.Label
$lblVersion.Text = ('V' + $script:ProductVersion)
$lblVersion.AutoSize = $true
$lblVersion.Anchor = 'Top,Right'
$lblVersion.Location = New-Object System.Drawing.Point(930, 12)
$headerPanel.Controls.Add($lblVersion)
$headerPanel.Add_Resize({ $lblVersion.Left = [Math]::Max(10, $headerPanel.ClientSize.Width - $lblVersion.Width - 10) })

$tabs = New-Object System.Windows.Forms.TabControl
$tabs.Dock = 'Fill'
$rootLayout.Controls.Add($tabs, 0, 1)

$standardTab = New-Object System.Windows.Forms.TabPage
$standardTab.Text = 'ブック更新'
$standardTab.AutoScroll = $true
$tabs.TabPages.Add($standardTab)

$developerTab = New-Object System.Windows.Forms.TabPage
$developerTab.Text = '開発者向け'
$tabs.TabPages.Add($developerTab)
$tabs.SelectedIndex = 0

$mainLayout = New-Object System.Windows.Forms.TableLayoutPanel
$mainLayout.Dock = 'Top'
$mainLayout.AutoSize = $true
$mainLayout.AutoSizeMode = 'GrowAndShrink'
$mainLayout.ColumnCount = 1
$mainLayout.RowCount = 6
$mainLayout.Padding = New-Object System.Windows.Forms.Padding(10)
[void]$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 120)))
[void]$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 118)))
[void]$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 138)))
[void]$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 160)))
[void]$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 180)))
[void]$mainLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 235)))
$standardTab.Controls.Add($mainLayout)

$projectPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$projectPanel.Dock = 'Fill'
$projectPanel.FlowDirection = 'LeftToRight'
$projectPanel.WrapContents = $true
$projectPanel.AutoScroll = $false
$projectPanel.Padding = New-Object System.Windows.Forms.Padding(8, 10, 8, 6)
$mainLayout.Controls.Add($projectPanel, 0, 0)

$lblProject = New-Object System.Windows.Forms.Label
$lblProject.Text = '更新するプロジェクト'
$lblProject.AutoSize = $true
$lblProject.Margin = New-Object System.Windows.Forms.Padding(4, 8, 8, 0)
$projectPanel.Controls.Add($lblProject)

$cmbProject = New-Object System.Windows.Forms.ComboBox
$cmbProject.DropDownStyle = 'DropDownList'
$cmbProject.Size = New-Object System.Drawing.Size(390, 30)
$cmbProject.Margin = New-Object System.Windows.Forms.Padding(0, 3, 10, 0)
$projectPanel.Controls.Add($cmbProject)

$btnRefresh = New-Object System.Windows.Forms.Button
$btnRefresh.Text = '再読込'
$btnRefresh.Size = New-Object System.Drawing.Size(90, 32)
$btnRefresh.Margin = New-Object System.Windows.Forms.Padding(0, 1, 12, 0)
$projectPanel.Controls.Add($btnRefresh)

$lblProjectCount = New-Object System.Windows.Forms.Label
$lblProjectCount.Text = '0件'
$lblProjectCount.AutoSize = $true
$lblProjectCount.Margin = New-Object System.Windows.Forms.Padding(0, 8, 0, 0)
$projectPanel.Controls.Add($lblProjectCount)
$projectPanel.SetFlowBreak($lblProjectCount,$true)

$lblProjectRootCaption = New-Object System.Windows.Forms.Label
$lblProjectRootCaption.Text = 'Project Root（開発フォルダー）'
$lblProjectRootCaption.AutoSize = $true
$lblProjectRootCaption.Margin = New-Object System.Windows.Forms.Padding(4,9,8,0)
$projectPanel.Controls.Add($lblProjectRootCaption)

$lblProjectRootValue = New-Object System.Windows.Forms.Label
$lblProjectRootValue.Text = '-'
$lblProjectRootValue.AutoEllipsis = $true
$lblProjectRootValue.Size = New-Object System.Drawing.Size(315,28)
$lblProjectRootValue.Margin = New-Object System.Windows.Forms.Padding(0,7,8,0)
$projectPanel.Controls.Add($lblProjectRootValue)
$projectPanel.SetFlowBreak($lblProjectRootValue,$true)

$lblSettingsFolderCaption = New-Object System.Windows.Forms.Label
$lblSettingsFolderCaption.Text = '登録情報の保存場所'
$lblSettingsFolderCaption.AutoSize = $true
$lblSettingsFolderCaption.Margin = New-Object System.Windows.Forms.Padding(4,9,8,0)
$projectPanel.Controls.Add($lblSettingsFolderCaption)

$lblSettingsFolderValue = New-Object System.Windows.Forms.Label
$lblSettingsFolderValue.Text = '-'
$lblSettingsFolderValue.AutoEllipsis = $true
$lblSettingsFolderValue.Size = New-Object System.Drawing.Size(570,28)
$lblSettingsFolderValue.Margin = New-Object System.Windows.Forms.Padding(0,7,8,0)
$projectPanel.Controls.Add($lblSettingsFolderValue)
$projectPanel.SetFlowBreak($lblSettingsFolderValue,$true)

$infoGroup = New-Object System.Windows.Forms.GroupBox
$infoGroup.Text = '選択中のプロジェクトフォルダー'
$infoGroup.Dock = 'Fill'
$infoGroup.Visible = $false
$infoGroup.Padding = New-Object System.Windows.Forms.Padding(10, 6, 10, 8)
$mainLayout.Controls.Add($infoGroup, 0, 1)
$infoGroup.Visible = $false

$infoLayout = New-Object System.Windows.Forms.TableLayoutPanel
$infoLayout.Dock = 'Fill'
$infoLayout.ColumnCount = 2
$infoLayout.RowCount = 8
[void]$infoLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Absolute', 120)))
[void]$infoLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent', 100)))
for ($row = 0; $row -lt 8; $row++) { [void]$infoLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent', 12.5))) }
$infoGroup.Controls.Add($infoLayout)

function Add-InfoLabel([string]$Text, [int]$Column, [int]$Row) {
    $label = New-Object System.Windows.Forms.Label
    $label.Text = $Text
    $label.AutoSize = $true
    $label.Margin = New-Object System.Windows.Forms.Padding(3, 6, 3, 0)
    $infoLayout.Controls.Add($label, $Column, $Row)
}

function New-InfoValueLabel([int]$Column, [int]$Row) {
    $label = New-Object System.Windows.Forms.Label
    $label.Text = '-'
    $label.Dock = 'Fill'
    $label.AutoEllipsis = $true
    $label.Margin = New-Object System.Windows.Forms.Padding(3, 6, 8, 0)
    $infoLayout.Controls.Add($label, $Column, $Row)
    return $label
}

Add-InfoLabel 'プロジェクトルート' 0 0
$lblDirectProjectRootValue = New-InfoValueLabel 1 0
Add-InfoLabel 'sourceフォルダー' 0 1
$lblSourceFolderValue = New-InfoValueLabel 1 1
Add-InfoLabel 'targetフォルダー' 0 2
$lblTargetFolderValue = New-InfoValueLabel 1 2
Add-InfoLabel '対象ブック' 0 3
$lblTargetPathValue = New-InfoValueLabel 1 3
Add-InfoLabel 'manifest' 0 4
$lblManifestValue = New-InfoValueLabel 1 4
Add-InfoLabel 'Git管理' 0 5
$lblGitValue = New-InfoValueLabel 1 5
Add-InfoLabel '利用状態' 0 6
$lblDirectStatusValue = New-InfoValueLabel 1 6
Add-InfoLabel 'Workbook定義' 0 7
$lblWorkbookDefinitionValue = New-InfoValueLabel 1 7
$lblTargetNameValue = New-Object System.Windows.Forms.Label
$lblTargetWriteValue = New-Object System.Windows.Forms.Label

$statusGroup = New-Object System.Windows.Forms.GroupBox
$statusGroup.Text = '更新状態'
$statusGroup.Dock = 'Fill'
$mainLayout.Controls.Add($statusGroup, 0, 1)
$statusLayout = New-Object System.Windows.Forms.TableLayoutPanel
$statusLayout.Dock = 'Fill'
$statusLayout.ColumnCount = 2
$statusLayout.RowCount = 2
[void]$statusLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Absolute', 285)))
[void]$statusLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent', 100)))
$statusGroup.Controls.Add($statusLayout)
$lblStateValue = New-Object System.Windows.Forms.Label
$lblStateValue.Text = '未確認'
$lblStateValue.Font = New-Object System.Drawing.Font('Yu Gothic UI', 12, [System.Drawing.FontStyle]::Bold)
$lblStateValue.Dock = 'Fill'
$lblStateValue.TextAlign = 'MiddleLeft'
$statusLayout.Controls.Add($lblStateValue, 0, 0)
$lblInfoMessageValue = New-Object System.Windows.Forms.Label
$lblInfoMessageValue.Text = '-'
$lblInfoMessageValue.Dock = 'Fill'
$lblInfoMessageValue.TextAlign = 'MiddleLeft'
$statusLayout.Controls.Add($lblInfoMessageValue, 1, 0)
$lblCommandCaption = New-Object System.Windows.Forms.Label
$lblCommandCaption.Text = '実行状況'
$lblCommandCaption.Dock = 'Fill'
$lblCommandCaption.TextAlign = 'MiddleLeft'
$statusLayout.Controls.Add($lblCommandCaption, 0, 1)
$statusDetailPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$statusDetailPanel.Dock = 'Fill'
$statusDetailPanel.WrapContents = $false
$statusLayout.Controls.Add($statusDetailPanel, 1, 1)
$lblCommandValue = New-Object System.Windows.Forms.Label
$lblCommandValue.Text = '-'
$lblCommandValue.AutoSize = $true
$lblCommandValue.Margin = New-Object System.Windows.Forms.Padding(0, 4, 18, 0)
$statusDetailPanel.Controls.Add($lblCommandValue)
$lblElapsedValue = New-Object System.Windows.Forms.Label
$lblElapsedValue.Text = '-'
$lblElapsedValue.AutoSize = $true
$lblElapsedValue.Margin = New-Object System.Windows.Forms.Padding(0, 4, 0, 0)
$statusDetailPanel.Controls.Add($lblElapsedValue)

$statusLogGroup = New-Object System.Windows.Forms.GroupBox
$statusLogGroup.Text = 'ステータスログ'
$statusLogGroup.Dock = 'Fill'
$statusLogGroup.Padding = New-Object System.Windows.Forms.Padding(10, 6, 10, 8)
$mainLayout.Controls.Add($statusLogGroup, 0, 2)
$script:statusLogBox = New-Object System.Windows.Forms.RichTextBox
$script:statusLogBox.Dock = 'Fill'
$script:statusLogBox.ReadOnly = $true
$script:statusLogBox.WordWrap = $false
$script:statusLogBox.Font = New-Object System.Drawing.Font('Consolas', 9)
$script:statusLogBox.BackColor = [System.Drawing.Color]::White
$statusLogGroup.Controls.Add($script:statusLogBox)

$primaryGroup = New-Object System.Windows.Forms.GroupBox
$primaryGroup.Text = '安全なブック更新'
$primaryGroup.Dock = 'Fill'
$mainLayout.Controls.Add($primaryGroup, 0, 3)
$primaryLayout = New-Object System.Windows.Forms.TableLayoutPanel
$primaryLayout.Dock = 'Fill'
$primaryLayout.ColumnCount = 1
$primaryLayout.RowCount = 2
[void]$primaryLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 132)))
[void]$primaryLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent', 100)))
$primaryGroup.Controls.Add($primaryLayout)
$primaryPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$primaryPanel.Dock = 'Fill'
$primaryPanel.FlowDirection = 'LeftToRight'
$primaryPanel.WrapContents = $true
$primaryPanel.Padding = New-Object System.Windows.Forms.Padding(12, 8, 6, 2)
$primaryLayout.Controls.Add($primaryPanel, 0, 0)
$lblUpdateExplanation = New-Object System.Windows.Forms.Label
$lblUpdateExplanation.Text = '更新前の確認、復元ポイント作成、差分更新、更新後の確認を自動で行います。'
$lblUpdateExplanation.Dock = 'Fill'
$lblUpdateExplanation.TextAlign = 'MiddleLeft'
$lblUpdateExplanation.Padding = New-Object System.Windows.Forms.Padding(15, 0, 0, 0)
$primaryLayout.Controls.Add($lblUpdateExplanation, 0, 1)

$logPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$logPanel.Dock = 'Top'
$logPanel.Height = 42
$logPanel.Visible = $true
$logPanel.FlowDirection = 'LeftToRight'
$logPanel.WrapContents = $false
$logPanel.AutoScroll = $false
$logPanel.Padding = New-Object System.Windows.Forms.Padding(4, 3, 4, 2)

$detailLogGroup = New-Object System.Windows.Forms.GroupBox
$detailLogGroup.Text = '詳細ログ'
$detailLogGroup.Dock = 'Fill'
$detailLogGroup.Padding = New-Object System.Windows.Forms.Padding(8, 4, 8, 8)
$mainLayout.Controls.Add($detailLogGroup, 0, 5)
$detailLogLayout = New-Object System.Windows.Forms.TableLayoutPanel
$detailLogLayout.Dock = 'Fill'
$detailLogLayout.ColumnCount = 1
$detailLogLayout.RowCount = 2
[void]$detailLogLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 42)))
[void]$detailLogLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent', 100)))
$detailLogGroup.Controls.Add($detailLogLayout)
$detailLogLayout.Controls.Add($logPanel,0,0)

$logBox = New-Object System.Windows.Forms.RichTextBox
$logBox.Dock = 'Fill'
$logBox.ReadOnly = $true
$logBox.WordWrap = $false
$logBox.Font = New-Object System.Drawing.Font('Consolas', 9)
$logBox.BackColor = [System.Drawing.Color]::White
$logBox.Visible = $true
$detailLogLayout.Controls.Add($logBox,0,1)

$mainGitHubGroup = New-Object System.Windows.Forms.GroupBox
$mainGitHubGroup.Text = 'GitHub連携'
$mainGitHubGroup.Dock = 'Fill'
$mainGitHubGroup.Padding = New-Object System.Windows.Forms.Padding(10, 6, 10, 8)
$mainLayout.Controls.Add($mainGitHubGroup, 0, 4)
$mainGitHubLayout = New-Object System.Windows.Forms.TableLayoutPanel
$mainGitHubLayout.Dock = 'Fill'
$mainGitHubLayout.ColumnCount = 1
$mainGitHubLayout.RowCount = 3
[void]$mainGitHubLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 48)))
[void]$mainGitHubLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 58)))
[void]$mainGitHubLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent', 100)))
$mainGitHubGroup.Controls.Add($mainGitHubLayout)
$gitInfoPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$gitInfoPanel.Dock = 'Fill'
$gitInfoPanel.FlowDirection = 'LeftToRight'
$gitInfoPanel.WrapContents = $true
$gitInfoPanel.Padding = New-Object System.Windows.Forms.Padding(6, 2, 6, 0)
$mainGitHubLayout.Controls.Add($gitInfoPanel,0,0)
$script:lblGitConnectionStatus = New-Object System.Windows.Forms.Label
$script:lblGitConnectionStatus.Text = '● 未設定 / 未接続'
$script:lblGitConnectionStatus.AutoSize = $true
$script:lblGitConnectionStatus.Font = New-Object System.Drawing.Font('Yu Gothic UI', 10, [System.Drawing.FontStyle]::Bold)
$script:lblGitConnectionStatus.ForeColor = [System.Drawing.Color]::Firebrick
$script:lblGitConnectionStatus.Margin = New-Object System.Windows.Forms.Padding(2,4,16,0)
$gitInfoPanel.Controls.Add($script:lblGitConnectionStatus)
$script:lblGitRepository = New-Object System.Windows.Forms.Label
$script:lblGitRepository.Text = 'リポジトリ: -'
$script:lblGitRepository.AutoSize = $true
$script:lblGitRepository.Margin = New-Object System.Windows.Forms.Padding(0,5,16,0)
$gitInfoPanel.Controls.Add($script:lblGitRepository)
$script:lblGitBranch = New-Object System.Windows.Forms.Label
$script:lblGitBranch.Text = 'ブランチ: -    リモート: -'
$script:lblGitBranch.AutoSize = $true
$script:lblGitBranch.Margin = New-Object System.Windows.Forms.Padding(0,5,0,0)
$gitInfoPanel.Controls.Add($script:lblGitBranch)
$mainGitButtonPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$mainGitButtonPanel.Dock = 'Fill'
$mainGitButtonPanel.FlowDirection = 'LeftToRight'
$mainGitButtonPanel.WrapContents = $false
$mainGitButtonPanel.Padding = New-Object System.Windows.Forms.Padding(4, 4, 4, 2)
$mainGitHubLayout.Controls.Add($mainGitButtonPanel,0,1)
$script:lblGitCounts = New-Object System.Windows.Forms.Label
$script:lblGitCounts.Text = 'Ahead: -    Behind: -    変更ファイル: -    ステージ済み: -'
$script:lblGitCounts.Dock = 'Fill'
$script:lblGitCounts.TextAlign = 'MiddleLeft'
$script:lblGitCounts.Padding = New-Object System.Windows.Forms.Padding(8,0,0,0)
$mainGitHubLayout.Controls.Add($script:lblGitCounts,0,2)
$githubPanel = $mainGitButtonPanel

$developerLayout = New-Object System.Windows.Forms.TableLayoutPanel
$developerLayout.Dock = 'Fill'
$developerLayout.ColumnCount = 1
$developerLayout.RowCount = 3
$developerLayout.Padding = New-Object System.Windows.Forms.Padding(10)
# Chapter4-2 HotFix6: rebalance vertical space so every developer action is fully visible.
# Keep the diagnostic header compact, give the four-frame area enough height for 4/3 buttons,
# and leave the remaining space to the developer log.
[void]$developerLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 78)))
[void]$developerLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 362)))
[void]$developerLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent', 100)))
$developerTab.Controls.Add($developerLayout)

$developerInfoGroup = New-Object System.Windows.Forms.GroupBox
$developerInfoGroup.Text = 'ファイルシステム診断情報'
$developerInfoGroup.Dock = 'Fill'
$developerLayout.Controls.Add($developerInfoGroup, 0, 0)
$developerInfoLayout = New-Object System.Windows.Forms.TableLayoutPanel
$developerInfoLayout.Dock = 'Fill'
$developerInfoLayout.ColumnCount = 4
$developerInfoLayout.RowCount = 3
[void]$developerInfoLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Absolute', 120)))
[void]$developerInfoLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent', 50)))
[void]$developerInfoLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Absolute', 145)))
[void]$developerInfoLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent', 50)))
$developerInfoGroup.Controls.Add($developerInfoLayout)

function Add-DeveloperInfoLabel([string]$Text, [int]$Column, [int]$Row) {
    $label = New-Object System.Windows.Forms.Label
    $label.Text = $Text
    $label.AutoSize = $true
    $label.Margin = New-Object System.Windows.Forms.Padding(3, 6, 3, 0)
    $developerInfoLayout.Controls.Add($label, $Column, $Row)
}

function New-DeveloperInfoValueLabel([int]$Column, [int]$Row) {
    $label = New-Object System.Windows.Forms.Label
    $label.Text = '-'
    $label.Dock = 'Fill'
    $label.AutoEllipsis = $true
    $label.Margin = New-Object System.Windows.Forms.Padding(3, 6, 8, 0)
    $developerInfoLayout.Controls.Add($label, $Column, $Row)
    return $label
}

Add-DeveloperInfoLabel 'プロジェクト名' 0 0
$lblProjectNameValue = New-DeveloperInfoValueLabel 1 0
Add-DeveloperInfoLabel 'Source最終更新' 2 0
$lblSourceWriteValue = New-DeveloperInfoValueLabel 3 0
Add-DeveloperInfoLabel '復元ポイント' 0 1
$lblRestoreValue = New-DeveloperInfoValueLabel 1 1
Add-DeveloperInfoLabel '直近のIntegrity' 2 1
$lblIntegrityValue = New-DeveloperInfoValueLabel 3 1
Add-DeveloperInfoLabel '診断' 0 2
$lblDeveloperDiagnosticValue = New-DeveloperInfoValueLabel 1 2
$developerInfoLayout.SetColumnSpan($lblDeveloperDiagnosticValue, 3)

$actionsLayout = New-Object System.Windows.Forms.TableLayoutPanel
$actionsLayout.Dock = 'Fill'
$actionsLayout.ColumnCount = 2
$actionsLayout.RowCount = 2
$actionsLayout.Padding = New-Object System.Windows.Forms.Padding(0)
[void]$actionsLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent', 50)))
[void]$actionsLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent', 50)))
# HotFix6: heights include GroupBox caption/borders plus the standardized 36px buttons.
# Top row: four buttons. Bottom row: one / three buttons.
[void]$actionsLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 202)))
[void]$actionsLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 160)))
$developerLayout.Controls.Add($actionsLayout, 0, 1)

function New-ActionGroup([string]$Title, [int]$Column, [int]$Row) {
    $group = New-Object System.Windows.Forms.GroupBox
    $group.Text = $Title
    $group.Dock = 'Fill'
    $group.Margin = New-Object System.Windows.Forms.Padding(4)
    $panel = New-Object System.Windows.Forms.FlowLayoutPanel
    $panel.Dock = 'Fill'
    $panel.FlowDirection = 'TopDown'
    $panel.WrapContents = $false
    # HotFix6: main developer actions must be visible without scrolling.
    $panel.AutoScroll = $false
    $panel.Padding = New-Object System.Windows.Forms.Padding(8, 4, 8, 4)
    $group.Controls.Add($panel)
    $actionsLayout.Controls.Add($group, $Column, $Row)
    return $panel
}

$supportPanel = New-ActionGroup '診断・サポート' 0 0
$referencePanel = New-ActionGroup '確認・参照' 1 0
$sourcePanel = New-ActionGroup 'ソース操作' 0 1
$bookPanel = New-ActionGroup 'ブック操作' 1 1
# GitHub連携はChapter4-1からメイン画面へ一本化

$developerLogGroup = New-Object System.Windows.Forms.GroupBox
$developerLogGroup.Text = '開発者ログ'
$developerLogGroup.Dock = 'Fill'
$developerLayout.Controls.Add($developerLogGroup, 0, 2)
$developerLogLayout = New-Object System.Windows.Forms.TableLayoutPanel
$developerLogLayout.Dock = 'Fill'
$developerLogLayout.ColumnCount = 1
$developerLogLayout.RowCount = 2
[void]$developerLogLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 44)))
[void]$developerLogLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent', 100)))
$developerLogGroup.Controls.Add($developerLogLayout)
$developerLogPanel = New-Object System.Windows.Forms.FlowLayoutPanel
$developerLogPanel.Dock = 'Fill'
$developerLogPanel.WrapContents = $false
$developerLogPanel.Padding = New-Object System.Windows.Forms.Padding(4, 2, 4, 2)
$developerLogLayout.Controls.Add($developerLogPanel, 0, 0)
$developerLogBox = New-Object System.Windows.Forms.RichTextBox
$developerLogBox.Dock = 'Fill'
$developerLogBox.ReadOnly = $true
$developerLogBox.WordWrap = $false
$developerLogBox.Font = New-Object System.Drawing.Font('Consolas', 9)
$developerLogBox.BackColor = [System.Drawing.Color]::White
$developerLogLayout.Controls.Add($developerLogBox, 0, 1)

$script:busy = $false
$script:projectSyncLockStream = $null
$script:projectSyncLockPath = $null
$script:process = $null
$script:guiOutputPath = $null
$script:guiRunnerPath = $null
$script:lastOutputLength = 0
$script:commandStartedAt = $null
$script:currentCommand = $null
$script:selectedProjectInfo = $null
$script:btnRestoreLatest = $null
$script:btnOpenProjectFolder = $null
$script:btnProjectDetails = $null
$script:refreshingProjects = $false
$script:currentStatus = '未確認'
$script:btnOpenTarget = $null
$script:pendingCreatedProject = $null
$script:pendingCreatedWorkbook = $null
$script:projectRootInfo = $null
$script:projectRootPreviousSelection = $null
$script:btnGitCommit = $null
$script:btnGitPush = $null
$script:btnGitPull = $null
$script:btnGitStatus = $null
$script:btnGitRefresh = $null
$script:pollTimer = New-Object System.Windows.Forms.Timer
$script:pollTimer.Interval = 250
$operationButtons = New-Object 'System.Collections.Generic.List[System.Windows.Forms.Button]'
$workbookRequiredButtons = New-Object 'System.Collections.Generic.List[System.Windows.Forms.Button]'

function Append-LogText([string]$Text) {
    if ([string]::IsNullOrEmpty($Text)) { return }
    if ($logBox.InvokeRequired) {
        [void]$logBox.BeginInvoke([Action[string]]{ param($value) Append-LogText $value }, $Text)
        return
    }
    $logBox.AppendText($Text)
    $logBox.SelectionStart = $logBox.TextLength
    $logBox.ScrollToCaret()
    if ($null -ne $script:statusLogBox -and -not $script:statusLogBox.IsDisposed) {
        $script:statusLogBox.AppendText($Text)
        $script:statusLogBox.SelectionStart = $script:statusLogBox.TextLength
        $script:statusLogBox.ScrollToCaret()
    }
    if ($null -ne $developerLogBox -and -not $developerLogBox.IsDisposed) {
        $developerLogBox.AppendText($Text)
        $developerLogBox.SelectionStart = $developerLogBox.TextLength
        $developerLogBox.ScrollToCaret()
    }
}

function Append-Log([string]$Text) {
    if ($null -eq $Text) { return }
    Append-LogText ($Text + [Environment]::NewLine)
}

function Show-GuiMessage([string]$Message, [string]$Title = 'お知らせ', [System.Windows.Forms.MessageBoxIcon]$Icon = [System.Windows.Forms.MessageBoxIcon]::Information) {
    [void][System.Windows.Forms.MessageBox]::Show($Message, $Title, [System.Windows.Forms.MessageBoxButtons]::OK, $Icon)
}

function Get-ProjectRegistrationValidationFromGui {
    param(
        [AllowNull()][AllowEmptyString()][string]$ProjectFolder,
        [AllowNull()][AllowEmptyString()][string]$WorkbookPath
    )
    return Get-ProjectRegistrationValidation -ProjectFolder $ProjectFolder -WorkbookPath $WorkbookPath -ToolRoot $root
}

function Show-ProjectRegistrationWizard {
    if ($script:busy) { return }

    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = '開発プロジェクトを登録'
    $dialog.StartPosition = 'CenterParent'
    $dialog.Size = New-Object System.Drawing.Size(760, 590)
    $dialog.MinimumSize = New-Object System.Drawing.Size(700, 540)
    $dialog.Font = $form.Font
    $dialog.FormBorderStyle = 'Sizable'
    $dialog.MaximizeBox = $false
    $dialog.MinimizeBox = $false

    $layout = New-Object System.Windows.Forms.TableLayoutPanel
    $layout.Dock = 'Fill'
    $layout.Padding = New-Object System.Windows.Forms.Padding(16)
    $layout.ColumnCount = 1
    $layout.RowCount = 8
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 48)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 34)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 72)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 34)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 68)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent', 100)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 34)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 50)))
    $dialog.Controls.Add($layout)

    $heading = New-Object System.Windows.Forms.Label
    $heading.Text = 'GitHubと共有する開発フォルダーを登録します'
    $heading.Font = New-Object System.Drawing.Font('Yu Gothic UI', 13, [System.Drawing.FontStyle]::Bold)
    $heading.Dock = 'Fill'
    $heading.TextAlign = 'MiddleLeft'
    $layout.Controls.Add($heading,0,0)

    $step1 = New-Object System.Windows.Forms.Label
    $step1.Text = 'ステップ1：既存の開発プロジェクトフォルダを選択'
    $step1.Dock = 'Fill'
    $step1.TextAlign = 'BottomLeft'
    $layout.Controls.Add($step1,0,1)

    $folderPanel = New-Object System.Windows.Forms.TableLayoutPanel
    $folderPanel.Dock = 'Fill'
    $folderPanel.ColumnCount = 2
    [void]$folderPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent',100)))
    [void]$folderPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Absolute',150)))
    $layout.Controls.Add($folderPanel,0,2)
    $txtProjectFolder = New-Object System.Windows.Forms.TextBox
    $txtProjectFolder.Dock = 'Fill'
    $txtProjectFolder.ReadOnly = $true
    $txtProjectFolder.Margin = New-Object System.Windows.Forms.Padding(0,8,8,8)
    $folderPanel.Controls.Add($txtProjectFolder,0,0)
    $btnBrowseFolder = New-Object System.Windows.Forms.Button
    $btnBrowseFolder.Text = 'フォルダを選択'
    $btnBrowseFolder.Dock = 'Fill'
    $btnBrowseFolder.Margin = New-Object System.Windows.Forms.Padding(0,6,0,6)
    $folderPanel.Controls.Add($btnBrowseFolder,1,0)

    $step2 = New-Object System.Windows.Forms.Label
    $step2.Text = 'ステップ2：管理対象Excelブックを選択'
    $step2.Dock = 'Fill'
    $step2.TextAlign = 'BottomLeft'
    $layout.Controls.Add($step2,0,3)
    $bookPanel = New-Object System.Windows.Forms.TableLayoutPanel
    $bookPanel.Dock = 'Fill'
    $bookPanel.ColumnCount = 2
    [void]$bookPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent',100)))
    [void]$bookPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Absolute',150)))
    $layout.Controls.Add($bookPanel,0,4)
    $txtWorkbook = New-Object System.Windows.Forms.TextBox
    $txtWorkbook.Dock = 'Fill'
    $txtWorkbook.ReadOnly = $true
    $txtWorkbook.Margin = New-Object System.Windows.Forms.Padding(0,8,8,8)
    $bookPanel.Controls.Add($txtWorkbook,0,0)
    $btnBrowseWorkbook = New-Object System.Windows.Forms.Button
    $btnBrowseWorkbook.Text = 'ブックを選択'
    $btnBrowseWorkbook.Dock = 'Fill'
    $btnBrowseWorkbook.Margin = New-Object System.Windows.Forms.Padding(0,6,0,6)
    $bookPanel.Controls.Add($btnBrowseWorkbook,1,0)

    $confirmationGroup = New-Object System.Windows.Forms.GroupBox
    $confirmationGroup.Text = 'ステップ3：設定内容を確認'
    $confirmationGroup.Dock = 'Fill'
    $layout.Controls.Add($confirmationGroup,0,5)
    $txtConfirmation = New-Object System.Windows.Forms.TextBox
    $txtConfirmation.Dock = 'Fill'
    $txtConfirmation.Multiline = $true
    $txtConfirmation.ReadOnly = $true
    $txtConfirmation.BackColor = [System.Drawing.Color]::White
    $txtConfirmation.ScrollBars = 'Vertical'
    $confirmationGroup.Controls.Add($txtConfirmation)

    $lblValidation = New-Object System.Windows.Forms.Label
    $lblValidation.Dock = 'Fill'
    $lblValidation.ForeColor = [System.Drawing.Color]::DarkRed
    $lblValidation.TextAlign = 'MiddleLeft'
    $layout.Controls.Add($lblValidation,0,6)

    $buttons = New-Object System.Windows.Forms.FlowLayoutPanel
    $buttons.Dock = 'Fill'
    $buttons.FlowDirection = 'RightToLeft'
    $buttons.WrapContents = $false
    $layout.Controls.Add($buttons,0,7)
    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = 'キャンセル'
    $btnCancel.Size = New-Object System.Drawing.Size(120,36)
    $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $buttons.Controls.Add($btnCancel)
    $btnRegister = New-Object System.Windows.Forms.Button
    $btnRegister.Text = '登録する'
    $btnRegister.Size = New-Object System.Drawing.Size(130,36)
    $btnRegister.Enabled = $false
    $buttons.Controls.Add($btnRegister)
    $dialog.CancelButton = $btnCancel

    $showSummaryError = {
        param([string]$Detail)
        $lblValidation.Text = '登録内容を確認できません。'
        $btnRegister.Enabled = $false
        $txtConfirmation.Text = @(
            '開発プロジェクトを登録します。',
            '',
            '開発プロジェクト：-',
            '管理対象ブック：-',
            '',
            '作成されるもの',
            'project.json',
            'target\',
            'source\'
        ) -join [Environment]::NewLine
        try { Append-Log ('[GUI] 登録Validationの更新に失敗しました: ' + $Detail) } catch { Write-Verbose ('登録Validation失敗ログの表示に失敗しました: ' + $_.Exception.Message) }
    }.GetNewClosure()
    $updateRegistrationState = {
        try {
            $projectFolder = $txtProjectFolder.Text.Trim()
            $workbookPath = $txtWorkbook.Text.Trim()
            $validation = Get-ProjectRegistrationValidationFromGui -ProjectFolder $projectFolder -WorkbookPath $workbookPath
            $lblValidation.Text = [string]$validation.Message
            $btnRegister.Enabled = [bool]$validation.CanRegister
            $displayFolder = if ([string]::IsNullOrWhiteSpace([string]$validation.ProjectFolder)) { '-' } else { [string]$validation.ProjectFolder }
            $displayBook = if ([string]::IsNullOrWhiteSpace([string]$validation.WorkbookFileName)) { '-' } else { [string]$validation.WorkbookFileName }
            $txtConfirmation.Text = @(
                '開発プロジェクト',
                $displayFolder,
                '',
                '管理対象ブック',
                $displayBook,
                '',
                '作成されるもの',
                'project.json',
                'target\',
                'source\',
                '',
                '元のExcelブックは移動せず、コピーします。'
            ) -join [Environment]::NewLine
            return $validation
        }
        catch { & $showSummaryError $_.Exception.Message }
    }.GetNewClosure()

    $btnBrowseFolder.Add_Click({
        $picker = $null
        try {
            $picker = New-Object System.Windows.Forms.FolderBrowserDialog
            $picker.Description = '既存の開発プロジェクトフォルダを選択してください。フォルダーは自動作成されません。'
            $picker.ShowNewFolderButton = $false
            $initialFolder = if (-not [string]::IsNullOrWhiteSpace($txtProjectFolder.Text) -and (Test-Path -LiteralPath $txtProjectFolder.Text -PathType Container)) {
                $txtProjectFolder.Text
            }
            elseif ($null -ne $script:projectRootInfo -and (Test-Path -LiteralPath ([string]$script:projectRootInfo.Path) -PathType Container)) {
                [string]$script:projectRootInfo.Path
            }
            else { '' }
            if (-not [string]::IsNullOrWhiteSpace($initialFolder)) { $picker.SelectedPath = $initialFolder }
            if ($picker.ShowDialog($dialog) -eq [System.Windows.Forms.DialogResult]::OK) {
                $txtProjectFolder.Text = $picker.SelectedPath
                [void](& $updateRegistrationState)
            }
        }
        catch { & $showSummaryError $_.Exception.Message }
        finally { if ($null -ne $picker) { $picker.Dispose() } }
    }.GetNewClosure())

    $btnBrowseWorkbook.Add_Click({
        $picker = $null
        try {
            $picker = New-Object System.Windows.Forms.OpenFileDialog
            $picker.Title = '管理するExcel VBAブックを選択'
            $picker.Filter = 'Excel VBAブック (*.xlsm;*.xlsb;*.xlam)|*.xlsm;*.xlsb;*.xlam|すべてのファイル (*.*)|*.*'
            $picker.CheckFileExists = $true
            $picker.Multiselect = $false
            if (-not [string]::IsNullOrWhiteSpace($txtWorkbook.Text) -and (Test-Path -LiteralPath $txtWorkbook.Text -PathType Leaf)) {
                $picker.InitialDirectory = Split-Path -Parent $txtWorkbook.Text
            }
            else {
                $picker.InitialDirectory = [Environment]::GetFolderPath('Desktop')
            }
            if ($picker.ShowDialog($dialog) -eq [System.Windows.Forms.DialogResult]::OK) {
                $txtWorkbook.Text = $picker.FileName
                [void](& $updateRegistrationState)
            }
        }
        catch { & $showSummaryError $_.Exception.Message }
        finally { if ($null -ne $picker) { $picker.Dispose() } }
    }.GetNewClosure())
    $txtProjectFolder.Add_TextChanged({ [void](& $updateRegistrationState) }.GetNewClosure())
    $txtWorkbook.Add_TextChanged({ [void](& $updateRegistrationState) }.GetNewClosure())
    $btnRegister.Add_Click({
        try {
            $projectFolder = $txtProjectFolder.Text.Trim()
            $workbookPath = $txtWorkbook.Text.Trim()
            $validation = Get-ProjectRegistrationValidationFromGui -ProjectFolder $projectFolder -WorkbookPath $workbookPath
            if (-not [bool]$validation.CanRegister) {
                $lblValidation.Text = [string]$validation.Message
                $btnRegister.Enabled = $false
                return
            }
            $script:pendingCreatedProject = [string]$validation.ProjectName
            $script:pendingCreatedWorkbook = [string]$validation.WorkbookFileName
            Append-Log ("[GUI] 開発プロジェクトを登録します: {0}" -f [string]$validation.ProjectFolder)
            Start-CliCommand -Command 'project-create' -Arguments @('-ProjectFolder',[string]$validation.ProjectFolder,'-WorkbookPath',[string]$validation.WorkbookPath)
            $dialog.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $dialog.Close()
        }
        catch { & $showSummaryError $_.Exception.Message }
    }.GetNewClosure())

    [void](& $updateRegistrationState)
    [void]$dialog.ShowDialog($form)
    $dialog.Dispose()
}

function Set-CurrentStatus([string]$Status) {
    $script:currentStatus = $Status
    switch ($Status) {
        '未確認' { $lblStateValue.Text = '○ プロジェクトを選択してください'; $lblStateValue.ForeColor = [System.Drawing.Color]::DimGray }
        '待機中' { $lblStateValue.Text = '○ プロジェクトを選択してください'; $lblStateValue.ForeColor = [System.Drawing.Color]::DimGray }
        '確認中' { $lblStateValue.Text = '… 更新できる状態か確認しています'; $lblStateValue.ForeColor = [System.Drawing.Color]::DarkBlue }
        'サンプル準備完了' { $lblStateValue.Text = '● サンプルを更新できます'; $lblStateValue.ForeColor = [System.Drawing.Color]::DarkGreen }
        '正常' { $lblStateValue.Text = '● 更新できます'; $lblStateValue.ForeColor = [System.Drawing.Color]::DarkGreen }
        '処理成功' { $lblStateValue.Text = '✓ 処理が完了しました'; $lblStateValue.ForeColor = [System.Drawing.Color]::DarkGreen }
        '警告あり' { $lblStateValue.Text = '▲ 確認が必要です'; $lblStateValue.ForeColor = [System.Drawing.Color]::DarkOrange }
        '警告付き成功' { $lblStateValue.Text = '▲ 処理は完了しました'; $lblStateValue.ForeColor = [System.Drawing.Color]::DarkOrange }
        'エラーあり' { $lblStateValue.Text = '× 更新できません'; $lblStateValue.ForeColor = [System.Drawing.Color]::DarkRed }
        '処理失敗' { $lblStateValue.Text = '× 処理を完了できませんでした'; $lblStateValue.ForeColor = [System.Drawing.Color]::DarkRed }
        '操作中止' { $lblStateValue.Text = '■ 操作は開始されませんでした'; $lblStateValue.ForeColor = [System.Drawing.Color]::DarkOrange }
        '処理実行中' {
            $lblStateValue.Text = $(if ($script:currentCommand -eq 'project-sync') {
                'ブックを更新しています'
            }
            elseif ($script:currentCommand -eq 'project-create') {
                '開発プロジェクトを登録しています'
            }
            elseif ($script:currentCommand -in @('project-root-set','project-root-reset')) {
                'プロジェクト保存先を変更しています'
            }
            else { '処理を実行しています' })
            $lblStateValue.ForeColor = [System.Drawing.Color]::DarkBlue
        }
        default { $lblStateValue.Text = $Status; $lblStateValue.ForeColor = [System.Drawing.Color]::Black }
    }
}

function Get-GuiCommandDisplayName([string]$Command) {
    switch ($Command) {
        'project-create' { return '開発プロジェクトを登録' }
        'project-root-set' { return 'Project Rootを変更' }
        'project-root-reset' { return 'Project Rootを既定に戻す' }
        'project-sync' { return '安全なブック更新' }
        'project-pull' { return 'ブックからソースを取得' }
        'project-push' { return 'ソースをブックへ反映' }
        'codex-export' { return 'Codex用ZIPを作成' }
        'codex-import-preview' { return 'Codex納品ZIPを確認' }
        'codex-import' { return 'Codex納品ZIPを取り込む' }
        'rollback' { return '最新復元ポイントへ戻す' }
        'rollback-list' { return '復元ポイント一覧' }
        'integrity' { return '整合性検証' }
        'project-diff' { return '差分確認' }
        'history' { return '履歴表示' }
        'status' { return '状態確認' }
        default { return $Command }
    }
}

function Format-GuiElapsed([TimeSpan]$Elapsed) {
    $hours = [Math]::Floor($Elapsed.TotalHours)
    return ('{0:00}:{1:00}:{2:00}' -f $hours, $Elapsed.Minutes, $Elapsed.Seconds)
}

function Update-OpenTargetButtonState {
    if ($null -eq $script:btnOpenTarget) { return }
    $targetExists = $false
    if ($null -ne $script:selectedProjectInfo -and
        -not [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.TargetPath) -and
        [string]$script:selectedProjectInfo.TargetPath -ne '-') {
        $targetExists = Test-Path -LiteralPath ([string]$script:selectedProjectInfo.TargetPath) -PathType Leaf
    }
    $script:btnOpenTarget.Enabled = (-not $script:busy) -and $targetExists
}

function Update-WorkbookRequiredButtonState {
    $canUseWorkbook=(-not $script:busy) -and $null -ne $script:selectedProjectInfo -and [bool]$script:selectedProjectInfo.CanPush
    foreach($button in $workbookRequiredButtons) { $button.Enabled=$canUseWorkbook }

    # Chapter3-8_02: 復元ポイントが存在しない場合は、一般利用者向け復元ボタンを無効化する。
    if ($null -ne $script:btnRestoreLatest) {
        $hasRestorePoint = $false
        if ($null -ne $script:selectedProjectInfo -and $script:selectedProjectInfo.PSObject.Properties['HasRestorePoint']) {
            $hasRestorePoint = [bool]$script:selectedProjectInfo.HasRestorePoint
        }
        $script:btnRestoreLatest.Enabled = $canUseWorkbook -and $hasRestorePoint
        $toolTip.SetToolTip($script:btnRestoreLatest, $(if ($hasRestorePoint) {
            '更新前に自動作成された最新の復元ポイントへ対象ブックを戻します。復元前にも安全バックアップを作成します。'
        } else {
            '復元ポイントはまだありません。最初のブック更新時に自動作成されます。'
        }))
    }

    if ($null -ne $script:btnOpenProjectFolder) {
        $canOpenProjectFolder = (-not $script:busy) -and $null -ne $script:selectedProjectInfo -and
            -not [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.ProjectDirectory) -and
            (Test-Path -LiteralPath ([string]$script:selectedProjectInfo.ProjectDirectory) -PathType Container)
        $script:btnOpenProjectFolder.Enabled = $canOpenProjectFolder
    }

    if ($null -ne $script:btnProjectDetails) {
        $script:btnProjectDetails.Enabled = (-not $script:busy) -and $null -ne $script:selectedProjectInfo
    }
}

function Reset-ProjectInformation {
    $lblProjectNameValue.Text = '-'
    $lblTargetNameValue.Text = '-'
    $lblTargetPathValue.Text = '-'
    $lblTargetWriteValue.Text = '-'
    $lblDirectProjectRootValue.Text = '-'
    $lblSourceFolderValue.Text = '-'
    $lblTargetFolderValue.Text = '-'
    $lblManifestValue.Text = '-'
    $lblWorkbookDefinitionValue.Text = '-'
    $lblGitValue.Text = '-'
    $lblDirectStatusValue.Text = '-'
    $lblSourceWriteValue.Text = '-'
    $lblRestoreValue.Text = '-'
    $lblIntegrityValue.Text = '-'
    $lblDeveloperDiagnosticValue.Text = '-'
    $lblCommandValue.Text = '-'
    $lblElapsedValue.Text = '-'
    $lblInfoMessageValue.Text = '-'
    $script:selectedProjectInfo = $null
    Set-CurrentStatus '未確認'
    Update-OpenTargetButtonState
    Update-WorkbookRequiredButtonState
    Update-GitHubButtonState
}

function Format-GuiDate($Value) {
    if ($null -eq $Value) { return 'なし' }
    return ([DateTime]$Value).ToString('yyyy-MM-dd HH:mm:ss')
}

function Resolve-GuiProjectPath([string]$ProjectDirectory, [string]$PathValue) {
    if ([string]::IsNullOrWhiteSpace($PathValue)) { throw 'project.jsonのパス指定が空です。' }
    if ([System.IO.Path]::IsPathRooted($PathValue)) {
        return [System.IO.Path]::GetFullPath($PathValue)
    }
    return [System.IO.Path]::GetFullPath((Join-Path $ProjectDirectory $PathValue))
}

function Get-LatestPathWriteTime([string]$Path) {
    $item = Get-Item -LiteralPath $Path -Force
    $latest = $item.LastWriteTime
    if ($item.PSIsContainer) {
        foreach ($child in @(Get-ChildItem -LiteralPath $Path -Recurse -Force -ErrorAction Stop)) {
            if ($child.LastWriteTime -gt $latest) { $latest = $child.LastWriteTime }
        }
    }
    return $latest
}

function Get-LatestRestorePointTime([string]$ProjectName) {
    $directory = Join-Path $root (Join-Path 'backups\restore_points' $ProjectName)
    if (-not (Test-Path -LiteralPath $directory -PathType Container)) { return $null }
    $latest = $null
    foreach ($file in @(Get-ChildItem -LiteralPath $directory -Filter '*.json' -File -ErrorAction SilentlyContinue)) {
        try {
            $payload = Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
            $created = $file.LastWriteTime
            if ($payload.PSObject.Properties['createdAt'] -and -not [string]::IsNullOrWhiteSpace([string]$payload.createdAt)) {
                $created = ([DateTimeOffset]::Parse([string]$payload.createdAt)).LocalDateTime
            }
            if ($null -eq $latest -or $created -gt $latest) { $latest = $created }
        }
        catch {
            # 壊れたメタデータは自動情報更新を中断せず読み飛ばす。
        }
    }
    return $latest
}

function Get-LatestIntegrityResult([string]$ProjectName) {
    $logDirectory = Join-Path $root 'logs'
    if (-not (Test-Path -LiteralPath $logDirectory -PathType Container)) { return $null }
    $files = @(Get-ChildItem -LiteralPath $logDirectory -Filter 'project_integrity_*.json' -File -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending)
    foreach ($file in $files) {
        try {
            $payload = Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
            if (-not $payload.PSObject.Properties['project'] -or
                -not [string]::Equals([string]$payload.project, $ProjectName, [System.StringComparison]::OrdinalIgnoreCase)) {
                continue
            }
            $executedAt = $file.LastWriteTime
            if ($payload.PSObject.Properties['timestamp'] -and -not [string]::IsNullOrWhiteSpace([string]$payload.timestamp)) {
                $executedAt = ([DateTimeOffset]::Parse([string]$payload.timestamp)).LocalDateTime
            }
            $errors = 0
            $warnings = 0
            if ($payload.PSObject.Properties['summary'] -and $null -ne $payload.summary) {
                if ($payload.summary.PSObject.Properties['errors']) { $errors = [int]$payload.summary.errors }
                if ($payload.summary.PSObject.Properties['warnings']) { $warnings = [int]$payload.summary.warnings }
            }
            return [PSCustomObject]@{ ExecutedAt=$executedAt; Errors=$errors; Warnings=$warnings; Path=$file.FullName }
        }
        catch {
            # 読めないログがあっても、さらに古い正常なログを探索する。
        }
    }
    return $null
}

function Update-DirectProjectInformationCore([switch]$PreserveStatus) {
    if ($cmbProject.SelectedItem -eq $null) {
        Reset-ProjectInformation
        $lblInfoMessageValue.Text='最初にプロジェクトを選択してください。未登録の場合は「開発プロジェクトを登録」から追加できます。'
        return
    }
    $previousStatus=$script:currentStatus
    if (-not $PreserveStatus) { Set-CurrentStatus '確認中' }
    $selected=[string]$cmbProject.SelectedItem
    if ($null -eq $script:projectRootInfo) { throw 'プロジェクト保存先を取得できません。' }
    $projectDirectory=if($null-ne$script:registeredProjectFolders-and$script:registeredProjectFolders.ContainsKey($selected)){[string]$script:registeredProjectFolders[$selected]}else{Join-Path ([string]$script:projectRootInfo.Path) $selected}
    $workbookPath=''
    $restoredFromPrevious=$false
    if ($script:projectRootInfo.PSObject.Properties['LastProjectRoot'] -and
        -not [string]::IsNullOrWhiteSpace([string]$script:projectRootInfo.LastProjectRoot) -and
        (Test-Path -LiteralPath ([string]$script:projectRootInfo.LastProjectRoot) -PathType Container)) {
        $lastRoot=[string]$script:projectRootInfo.LastProjectRoot
        try {
            $lastProbe=Get-ProjectFolderCheckFromCli -Path $lastRoot
            if ([string]::Equals([string]$lastProbe.ProjectName,$selected,[System.StringComparison]::OrdinalIgnoreCase) -or
                [string]::Equals([System.IO.Path]::GetFileName($lastRoot),$selected,[System.StringComparison]::OrdinalIgnoreCase)) {
                $projectDirectory=$lastRoot
                $restoredFromPrevious=$true
                if ($script:projectRootInfo.PSObject.Properties['LastWorkbookPath'] -and [bool]$script:projectRootInfo.LastWorkbookExists) {
                    $workbookPath=[string]$script:projectRootInfo.LastWorkbookPath
                }
            }
        }
        catch { Append-Log ('[GUI] 最後に開いたプロジェクトの確認に失敗しました: '+$_.Exception.Message) }
    }

    $context=Get-ProjectFolderCheckFromCli -Path $projectDirectory -WorkbookPath $workbookPath
    $script:selectedProjectInfo=[PSCustomObject]@{
        Selection=$selected;ProjectName=[string]$context.ProjectName;ProjectDirectory=[string]$context.ProjectRoot
        ProjectRoot=[string]$context.ProjectRoot;SourcePath=[string]$context.SourcePath;TargetDirectory=[string]$context.TargetDirectory
        TargetName=$(if([string]::IsNullOrWhiteSpace([string]$context.WorkbookPath)){'-'}else{[System.IO.Path]::GetFileName([string]$context.WorkbookPath)})
        TargetPath=$(if([string]::IsNullOrWhiteSpace([string]$context.WorkbookPath)){'-'}else{[string]$context.WorkbookPath})
        ManifestPath=[string]$context.ManifestPath;IsGitRepository=[bool]$context.IsGitRepository
        IsAvailable=[bool]$context.IsAvailable;CanPush=[bool]$context.CanPush;WorkbookCandidates=@($context.WorkbookCandidates)
        RestoredFromPrevious=$restoredFromPrevious
        TargetFingerprint=$(Get-GuiTargetFingerprint -Path ([string]$context.WorkbookPath))
    }
    $lblProjectNameValue.Text=[string]$context.ProjectName
    $lblDirectProjectRootValue.Text=[string]$context.ProjectRoot
    $lblSourceFolderValue.Text=[string]$context.SourcePath
    $lblTargetFolderValue.Text=[string]$context.TargetDirectory
    $lblTargetNameValue.Text=[string]$script:selectedProjectInfo.TargetName
    $lblTargetPathValue.Text=[string]$script:selectedProjectInfo.TargetPath
    $lblManifestValue.Text=[string]$context.ManifestPath
    $lblWorkbookDefinitionValue.Text='なし（従来VBAのみ）'
    try {
        if (Test-Path -LiteralPath ([string]$context.ManifestPath) -PathType Leaf) {
            $projectManifest=Get-Content -LiteralPath ([string]$context.ManifestPath) -Raw -Encoding UTF8|ConvertFrom-Json
            if ($projectManifest.PSObject.Properties['workbook'] -and $null -ne $projectManifest.workbook) {
                $enabled=$true
                if ($projectManifest.workbook.PSObject.Properties['enabled']) { $enabled=[bool]$projectManifest.workbook.enabled }
                if (-not $enabled) { $lblWorkbookDefinitionValue.Text='無効' }
                elseif ($projectManifest.workbook.PSObject.Properties['definition'] -and -not [string]::IsNullOrWhiteSpace([string]$projectManifest.workbook.definition)) {
                    $definitionPath=Join-Path ([string]$context.ProjectRoot) ([string]$projectManifest.workbook.definition)
                    $lblWorkbookDefinitionValue.Text=$(if(Test-Path -LiteralPath $definitionPath -PathType Leaf){'✓ あり'}else{'× 定義ファイルなし'})
                    $toolTip.SetToolTip($lblWorkbookDefinitionValue,$definitionPath)
                }
                else { $lblWorkbookDefinitionValue.Text='× definition未指定' }
            }
        }
    }
    catch { $lblWorkbookDefinitionValue.Text='× 定義確認エラー' }
    $lblGitValue.Text=$(if([bool]$context.IsGitRepository){'✓ Git管理あり（開発者向けからGitHub操作可能）'}else{'－ Git管理なし'})
    $lblDirectStatusValue.Text=$(if([bool]$context.CanPush){$(if($restoredFromPrevious){'▲ 前回選択を復元（更新時に再検証）'}else{'✓ 利用可能'})}elseif([bool]$context.IsAvailable){'▲ プロジェクト選択済み／対象ブック未選択'}else{'× 利用不可'})
    foreach($label in @($lblDirectProjectRootValue,$lblSourceFolderValue,$lblTargetFolderValue,$lblTargetPathValue,$lblManifestValue)) { $toolTip.SetToolTip($label,$label.Text) }
    $lblTargetWriteValue.Text='-'
    if ([string]$script:selectedProjectInfo.TargetPath -ne '-' -and (Test-Path -LiteralPath ([string]$script:selectedProjectInfo.TargetPath) -PathType Leaf)) {
        $lblTargetWriteValue.Text=Format-GuiDate (Get-Item -LiteralPath ([string]$script:selectedProjectInfo.TargetPath)).LastWriteTime
    }
    $lblSourceWriteValue.Text='-'
    if (Test-Path -LiteralPath ([string]$context.SourcePath) -PathType Container) { $lblSourceWriteValue.Text=Format-GuiDate (Get-LatestPathWriteTime -Path ([string]$context.SourcePath)) }
    $restoreTime=Get-LatestRestorePointTime -ProjectName ([string]$context.ProjectName)
    $script:selectedProjectInfo | Add-Member -NotePropertyName HasRestorePoint -NotePropertyValue ($null -ne $restoreTime) -Force
    $lblRestoreValue.Text=$(if($null -eq $restoreTime){'なし'}else{Format-GuiDate $restoreTime})
    $integrity=Get-LatestIntegrityResult -ProjectName ([string]$context.ProjectName)
    $lblIntegrityValue.Text=$(if($null -eq $integrity){'未実行'}else{("{0} (E={1}/W={2})" -f (Format-GuiDate $integrity.ExecutedAt),$integrity.Errors,$integrity.Warnings)})
    $details=@(@($context.Errors)+@($context.Warnings)+@($context.Messages)|Where-Object{-not [string]::IsNullOrWhiteSpace([string]$_)}|Select-Object -Unique)
    $lblDeveloperDiagnosticValue.Text=$(if($details.Count -eq 0){'CLI共通判定でファイルシステム情報を確認しました。'}else{$details -join ' / '})
    $toolTip.SetToolTip($lblDeveloperDiagnosticValue,$lblDeveloperDiagnosticValue.Text)
    if (@($context.Errors).Count -gt 0) {
        $lblInfoMessageValue.Text='プロジェクトフォルダーの構成を確認してください。'
        if (-not $PreserveStatus) { Set-CurrentStatus 'エラーあり' }
    }
    elseif (-not [bool]$context.CanPush) {
        $lblInfoMessageValue.Text=$(if([string]$context.WorkbookSelectionStatus -eq 'Multiple'){'対象ブックが複数あります。「プロジェクトフォルダを開く」から選択してください。'}else{'対象ブックは未登録です。プロジェクト選択は保存されています。'})
        if (-not $PreserveStatus) { Set-CurrentStatus '警告あり' }
    }
    else {
        $lblInfoMessageValue.Text='準備完了です。「ブックを更新する」を押すと、安全確認→復元ポイント作成→更新→検証まで自動実行します。'
        if (-not $PreserveStatus) { Set-CurrentStatus '正常' }
    }
    if ($PreserveStatus) { Set-CurrentStatus $previousStatus }
    Update-OpenTargetButtonState
    Update-WorkbookRequiredButtonState
}

function Update-ProjectInformation([switch]$PreserveStatus) {
    Update-DirectProjectInformationCore -PreserveStatus:$PreserveStatus
    return
    if ($cmbProject.SelectedItem -eq $null) {
        Reset-ProjectInformation
        $lblInfoMessageValue.Text = 'プロジェクトを選択してください。'
        return
    }

    $previousStatus = $script:currentStatus
    if (-not $PreserveStatus) { Set-CurrentStatus '確認中' }
    $selected = [string]$cmbProject.SelectedItem
    if ($null -eq $script:projectRootInfo) { throw 'プロジェクト保存先を取得できません。' }
    $projectDirectory = Join-Path ([string]$script:projectRootInfo.Path) $selected
    $manifestPath = Join-Path $projectDirectory 'project.json'
    $errors = New-Object 'System.Collections.Generic.List[string]'
    $warnings = New-Object 'System.Collections.Generic.List[string]'
    $userWarnings = New-Object 'System.Collections.Generic.List[string]'

    $lblProjectNameValue.Text = $selected
    $lblTargetNameValue.Text = '-'
    $lblTargetPathValue.Text = '-'
    $lblTargetWriteValue.Text = '-'
    $lblSourceWriteValue.Text = '-'
    $lblRestoreValue.Text = 'なし'
    $lblIntegrityValue.Text = '未実行'
    $lblInfoMessageValue.Text = '-'

    try {
        if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
            throw "project.jsonが見つかりません: $manifestPath"
        }
        $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $manifestProjectName = $selected
        if ($manifest.PSObject.Properties['projectName'] -and -not [string]::IsNullOrWhiteSpace([string]$manifest.projectName)) {
            $manifestProjectName = [string]$manifest.projectName
        }
        else {
            [void]$warnings.Add('project.jsonにprojectNameがありません。フォルダー名を表示します。')
        }
        $lblProjectNameValue.Text = $manifestProjectName

        $targetPath = $null
        if (-not $manifest.PSObject.Properties['target'] -or $null -eq $manifest.target) {
            [void]$errors.Add('project.jsonにtarget設定がありません。')
        }
        else {
            $targetDirectoryValue = if ($manifest.target.PSObject.Properties['directory']) { [string]$manifest.target.directory } else { '' }
            $targetFileValue = if ($manifest.target.PSObject.Properties['file']) { [string]$manifest.target.file } else { '' }
            if ([string]::IsNullOrWhiteSpace($targetFileValue)) {
                [void]$errors.Add('project.jsonのtarget.fileが空です。')
            }
            else {
                $targetDirectory = if ([string]::IsNullOrWhiteSpace($targetDirectoryValue)) {
                    $projectDirectory
                }
                else {
                    Resolve-GuiProjectPath -ProjectDirectory $projectDirectory -PathValue $targetDirectoryValue
                }
                $targetPath = Join-Path $targetDirectory $targetFileValue
                $lblTargetNameValue.Text = [System.IO.Path]::GetFileName($targetPath)
                $lblTargetPathValue.Text = $targetPath
            $toolTip.SetToolTip($lblTargetPathValue, $targetPath)

                if (-not (Test-Path -LiteralPath $targetPath -PathType Leaf)) {
                    $autoDetect = $false
                    if ($manifest.target.PSObject.Properties['autoDetectWhenMissing']) { $autoDetect = [bool]$manifest.target.autoDetectWhenMissing }
                    if ($autoDetect -and (Test-Path -LiteralPath $targetDirectory -PathType Container)) {
                        $candidates = @(Get-ChildItem -LiteralPath $targetDirectory -File -ErrorAction SilentlyContinue |
                            Where-Object { $_.Extension.ToLowerInvariant() -in @('.xlsm','.xlsb','.xlam') })
                        if ($candidates.Count -eq 1) {
                            $targetPath = $candidates[0].FullName
                            $lblTargetNameValue.Text = $candidates[0].Name
                            $lblTargetPathValue.Text = $targetPath
            $toolTip.SetToolTip($lblTargetPathValue, $targetPath)
                            [void]$warnings.Add("target.fileの対象がないため候補を表示しています: $targetPath")
                            [void]$userWarnings.Add('設定上のファイル名とは異なる候補を表示しています。開発者に確認してください。')
                        }
                    }
                }

                if (Test-Path -LiteralPath $targetPath -PathType Leaf) {
                    $lblTargetWriteValue.Text = Format-GuiDate (Get-Item -LiteralPath $targetPath).LastWriteTime
                }
                else {
                    [void]$errors.Add("対象ブックが見つかりません: $targetPath")
                }
            }
        }

        if (-not $manifest.PSObject.Properties['source'] -or $null -eq $manifest.source -or
            -not $manifest.source.PSObject.Properties['root']) {
            [void]$errors.Add('project.jsonにsource.root設定がありません。')
        }
        else {
            $sourcePath = Resolve-GuiProjectPath -ProjectDirectory $projectDirectory -PathValue ([string]$manifest.source.root)
            if (Test-Path -LiteralPath $sourcePath -PathType Container) {
                $lblSourceWriteValue.Text = Format-GuiDate (Get-LatestPathWriteTime -Path $sourcePath)
            }
            else {
                [void]$errors.Add("sourceフォルダーが見つかりません: $sourcePath")
            }
        }

        $restoreTime = Get-LatestRestorePointTime -ProjectName $manifestProjectName
        if ($null -ne $restoreTime) {
            $lblRestoreValue.Text = Format-GuiDate $restoreTime
        }
        else {
            [void]$warnings.Add('復元ポイントはまだありません。')
            [void]$userWarnings.Add('復元ポイントはまだありません。更新時に新しい復元ポイントを作成します。')
        }

        $integrity = Get-LatestIntegrityResult -ProjectName $manifestProjectName
        if ($null -ne $integrity) {
            $integrityState = if ($integrity.Errors -gt 0) { 'エラーあり' } elseif ($integrity.Warnings -gt 0) { '警告あり' } else { '正常' }
            $lblIntegrityValue.Text = ('{0} ({1}, E={2}/W={3})' -f $integrityState, (Format-GuiDate $integrity.ExecutedAt), $integrity.Errors, $integrity.Warnings)
            if ($integrity.Errors -gt 0) { [void]$errors.Add('直近のIntegrity実行結果にエラーがあります。') }
            elseif ($integrity.Warnings -gt 0) { [void]$warnings.Add('直近のIntegrity実行結果に警告があります。') }
        }
        else {
            [void]$warnings.Add('Integrityはまだ実行されていません。')
        }

        $script:selectedProjectInfo = [PSCustomObject]@{
            Selection=$selected
            ProjectName=$manifestProjectName
            ProjectDirectory=$projectDirectory
            TargetName=$lblTargetNameValue.Text
            TargetPath=$lblTargetPathValue.Text
        }
    }
    catch {
        [void]$errors.Add($_.Exception.Message)
        $script:selectedProjectInfo = [PSCustomObject]@{
            Selection=$selected
            ProjectName=$selected
            ProjectDirectory=$projectDirectory
            TargetName=$lblTargetNameValue.Text
            TargetPath=$lblTargetPathValue.Text
        }
    }

    if ($errors.Count -gt 0) {
        $lblDeveloperDiagnosticValue.Text = ($errors -join ' / ')
        $toolTip.SetToolTip($lblDeveloperDiagnosticValue, ($errors -join ' / '))
        $lblInfoMessageValue.Text = '対象ブックまたは更新元データを確認できません。開発者向け画面で設定を確認してください。'
        $toolTip.SetToolTip($lblInfoMessageValue, '')
        if (-not $PreserveStatus) { Set-CurrentStatus 'エラーあり' }
    }
    elseif ($userWarnings.Count -gt 0) {
        $lblDeveloperDiagnosticValue.Text = ($warnings -join ' / ')
        $toolTip.SetToolTip($lblDeveloperDiagnosticValue, ($warnings -join ' / '))
        $lblInfoMessageValue.Text = ($userWarnings -join ' / ')
        $toolTip.SetToolTip($lblInfoMessageValue, '')
        if (-not $PreserveStatus) { Set-CurrentStatus '警告あり' }
    }
    else {
        $lblDeveloperDiagnosticValue.Text = $(if ($warnings.Count -gt 0) { $warnings -join ' / ' } else { 'ファイルシステム情報を確認しました。' })
        $toolTip.SetToolTip($lblDeveloperDiagnosticValue, $lblDeveloperDiagnosticValue.Text)
        $lblInfoMessageValue.Text = '更新前の安全確認を行った後、対象ブックを最新版へ更新します。'
        $toolTip.SetToolTip($lblInfoMessageValue, '')
        if (-not $PreserveStatus) { Set-CurrentStatus '正常' }
    }

    if ($PreserveStatus) { Set-CurrentStatus $previousStatus }
    Update-OpenTargetButtonState
}

function Get-GuiLogDirectory {
    if($null-eq$script:settingsInfo){try{$script:settingsInfo=Get-SettingsInfoFromCli}catch{Write-Verbose ('CLIから設定情報を取得できませんでした: '+$_.Exception.Message)}}
    $directory=if($null-ne$script:settingsInfo-and$script:settingsInfo.PSObject.Properties['LogsFolder']){Join-Path ([string]$script:settingsInfo.LogsFolder) 'gui'}else{Join-Path $root 'logs\gui'}
    if (-not (Test-Path -LiteralPath $directory -PathType Container)) {
        [void](New-Item -ItemType Directory -Path $directory -Force)
    }
    return $directory
}

function Get-VBAUpdaterBuildVersion {
    $path = Join-Path $root 'BUILD_VERSION.txt'
    if (Test-Path -LiteralPath $path -PathType Leaf) {
        try {
            $value = ([System.IO.File]::ReadAllText($path)).Trim()
            if (-not [string]::IsNullOrWhiteSpace($value)) { return $value }
        } catch {
            Append-Log ('[GUI] BUILD_VERSION.txtを読み取れませんでした: ' + $_.Exception.Message)
        }
    }
    return '不明'
}

function Get-InstallerHistoryPath {
    return (Join-Path $env:LOCALAPPDATA 'VBAUpdater\installer-history\InstallHistory.tsv')
}

function Get-Utf8TextLines([string]$path) {
    if ([string]::IsNullOrWhiteSpace($path) -or -not (Test-Path -LiteralPath $path -PathType Leaf)) { return @() }
    try {
        $utf8 = New-Object System.Text.UTF8Encoding($false, $true)
        $text = [System.IO.File]::ReadAllText($path, $utf8)
        if ([string]::IsNullOrEmpty($text)) { return @() }
        return @($text -split "`r?`n" | Where-Object { $_ -ne '' })
    } catch {
        Append-Log ('[GUI] UTF-8テキスト読み込みに失敗しました: ' + $_.Exception.Message)
        return @()
    }
}

function Get-Utf8TailLines([string]$path, [int]$count) {
    $all = @(Get-Utf8TextLines $path)
    if ($all.Count -le $count) { return $all }
    return @($all[($all.Count - $count)..($all.Count - 1)])
}

function Show-VBAUpdaterInstallerHistory {
    $historyPath = Get-InstallerHistoryPath
    if (-not (Test-Path -LiteralPath $historyPath -PathType Leaf)) {
        Show-GuiMessage 'インストール履歴はまだありません。' 'インストール履歴'
        return
    }

    $rawLines = @(Get-Utf8TailLines $historyPath 20)
    if ($rawLines.Count -eq 0) {
        Show-GuiMessage 'インストール履歴はまだありません。' 'インストール履歴'
        return
    }

    $display = New-Object 'System.Collections.Generic.List[string]'
    [void]$display.Add('最近のインストール履歴（最大20件）')
    [void]$display.Add('')
    foreach ($line in $rawLines) {
        $parts = @([string]$line -split "`t", 6)
        if ($parts.Count -ge 5) {
            $resultText = switch ($parts[1]) {
                'SUCCESS' { '成功' }
                'FAILED'  { '失敗' }
                'CANCEL'  { '中止' }
                default   { $parts[1] }
            }
            [void]$display.Add(('{0}  [{1}]  {2}' -f $parts[0], $resultText, $parts[2]))
            [void]$display.Add(('  {0} → {1}' -f $parts[3], $parts[4]))
            if ($parts.Count -ge 6 -and -not [string]::IsNullOrWhiteSpace($parts[5])) {
                [void]$display.Add(('  ' + $parts[5]))
            }
            [void]$display.Add('')
        } else {
            [void]$display.Add([string]$line)
        }
    }
    [void]$display.Add(('保存先: ' + $historyPath))
    Show-GuiMessage ($display -join [Environment]::NewLine) 'インストール履歴'
}

function Get-GuiOperationalSafetySnapshot {
    $userRoot=Get-VBAUpdaterUserDataRoot
    $projectDir=''
    $targetPath=''
    if($null-ne$script:selectedProjectInfo){
        $projectDir=[string]$script:selectedProjectInfo.ProjectDirectory
        $targetPath=[string]$script:selectedProjectInfo.TargetPath
    }
    $previousUnclean=$false
    if($null-ne$script:operationalSession){$previousUnclean=[bool]$script:operationalSession.PreviousUnclean}
    return Get-VBAUpdaterOperationalSafetySnapshot -UserDataRoot $userRoot -InstallRoot $root -ProjectDirectory $projectDir -TargetPath $targetPath -PreviousSessionUnclean $previousUnclean
}

function Add-OperationalSafetyLines {
    param([Parameter(Mandatory=$true)]$Lines,[Parameter(Mandatory=$true)]$Snapshot)
    [void]$Lines.Add('[運用安全診断]')
    [void]$Lines.Add(('総合: '+[string]$Snapshot.Overall))
    foreach($item in @($Snapshot.Errors)){[void]$Lines.Add(('ERROR: '+[string]$item))}
    foreach($item in @($Snapshot.Warnings)){[void]$Lines.Add(('WARN : '+[string]$item))}
    foreach($item in @($Snapshot.Ok)){[void]$Lines.Add(('OK   : '+[string]$item))}
}


function Get-VBAUpdaterUpdateConfig {
    $path=Join-Path $root 'update.config.json'
    if(-not(Test-Path -LiteralPath $path -PathType Leaf)){
        throw 'update.config.json が見つかりません。'
    }
    try { return (Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json) }
    catch { throw ('update.config.json を読み込めません: '+$_.Exception.Message) }
}

function Get-VBAUpdaterCurrentProductVersion {
    return $script:ProductVersion
}

function Show-VBAUpdaterUpdateCheck {
    try {
        $config=Get-VBAUpdaterUpdateConfig
        if(-not [bool]$config.enabled){
            Show-GuiMessage '更新確認機能はまだ有効化されていません。正式な配布先設定後に利用可能になります。' 'VBAUpdater 更新確認'
            return
        }
        $manifestUri=[string]$config.manifestUrl
        if([string]::IsNullOrWhiteSpace($manifestUri)){
            Show-GuiMessage '更新情報URLが設定されていません。' 'VBAUpdater 更新確認'
            return
        }

        Set-CurrentStatus '更新確認中'
        $manifest=Get-VBAUpdaterUpdateManifest -ManifestUri $manifestUri
        $current=Get-VBAUpdaterCurrentProductVersion
        $available=Test-VBAUpdaterUpdateAvailable -CurrentVersion $current -Manifest $manifest

        if(-not $available){
            Show-GuiMessage ('現在のバージョン '+$current+' が最新です。') 'VBAUpdater 更新確認'
            Set-CurrentStatus '最新です'
            return
        }

        $lines=New-Object 'System.Collections.Generic.List[string]'
        [void]$lines.Add('新しい更新プログラムがあります。')
        [void]$lines.Add('')
        [void]$lines.Add(('現在: '+$current))
        [void]$lines.Add(('最新版: '+[string]$manifest.version))
        if(-not[string]::IsNullOrWhiteSpace([string]$manifest.releaseNotes)){
            [void]$lines.Add('')
            [void]$lines.Add('更新内容:')
            [void]$lines.Add([string]$manifest.releaseNotes)
        }
        [void]$lines.Add('')
        [void]$lines.Add('ダウンロードしますか？')
        $answer=[System.Windows.Forms.MessageBox]::Show(
            $form,
            ($lines -join [Environment]::NewLine),
            'VBAUpdater 更新確認',
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Information,
            [System.Windows.Forms.MessageBoxDefaultButton]::Button2
        )
        if($answer -ne [System.Windows.Forms.DialogResult]::Yes){
            Set-CurrentStatus '更新は見送りました'
            return
        }

        $stageRoot=Join-Path (Get-VBAUpdaterUserDataRoot) 'UpdateStage'
        if(-not(Test-Path -LiteralPath $stageRoot -PathType Container)){
            [void](New-Item -ItemType Directory -Path $stageRoot -Force)
        }
        $package=Join-Path $stageRoot ('VBAUpdater_Update_'+[string]$manifest.version+'.zip')
        Set-CurrentStatus '更新をダウンロード中'
        Invoke-WebRequest -Uri ([string]$manifest.downloadUrl) -OutFile $package -UseBasicParsing -TimeoutSec 60
        if(-not(Test-VBAUpdaterDownloadedPackage -Path $package -ExpectedSha256 ([string]$manifest.sha256))){
            Remove-Item -LiteralPath $package -Force -ErrorAction SilentlyContinue
            throw '更新パッケージのSHA-256検証に失敗しました。'
        }

        $msg=@(
            '更新パッケージのダウンロードと検証が完了しました。',
            '',
            ('バージョン: '+[string]$manifest.version),
            '',
            '登録プロジェクト・設定・履歴などのユーザーデータを保持したまま、',
            'VBAUpdater本体を更新します。',
            '',
            '今すぐ更新しますか？'
        ) -join [Environment]::NewLine
        $installAnswer=[System.Windows.Forms.MessageBox]::Show(
            $form,$msg,'VBAUpdater 更新',
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Information,
            [System.Windows.Forms.MessageBoxDefaultButton]::Button2
        )
        if($installAnswer -ne [System.Windows.Forms.DialogResult]::Yes){
            Set-CurrentStatus '更新パッケージ準備完了'
            return
        }

        $selfUpdater=Join-Path $root 'SelfUpdate.ps1'
        if(-not(Test-Path -LiteralPath $selfUpdater -PathType Leaf)){throw 'SelfUpdate.ps1 が見つかりません。'}
        $installRoot=[IO.Path]::GetFullPath($root)
        $restartPath=Join-Path $installRoot 'gui.cmd'
        $args=@(
            '-NoProfile','-ExecutionPolicy','Bypass',
            '-File',('"{0}"' -f $selfUpdater),
            '-PackagePath',('"{0}"' -f $package),
            '-InstallRoot',('"{0}"' -f $installRoot),
            '-ExpectedSha256',('"{0}"' -f [string]$manifest.sha256),
            '-RestartPath',('"{0}"' -f $restartPath)
        )
        Start-Process -FilePath 'powershell.exe' -ArgumentList $args
        Set-CurrentStatus '更新処理を開始しました'
        $form.Close()
    } catch {
        Append-Log ('[GUI] 更新確認に失敗しました: '+$_.Exception.Message)
        Show-GuiMessage $_.Exception.Message 'VBAUpdater 更新確認エラー' ([System.Windows.Forms.MessageBoxIcon]::Error)
        Set-CurrentStatus '更新確認エラー'
    }
}

function Show-VBAUpdaterEnvironmentCheck {
    $ok = New-Object 'System.Collections.Generic.List[string]'
    $warnings = New-Object 'System.Collections.Generic.List[string]'
    $errors = New-Object 'System.Collections.Generic.List[string]'

    foreach ($relative in @('gui.ps1','vba.ps1','BUILD_VERSION.txt','tools\WorkbookUpdate.psm1','tools\ProjectRegistration.psm1','addin\VBAUpdater.xlam')) {
        $candidate = Join-Path $root $relative
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            [void]$ok.Add(('必須ファイル: ' + $relative))
        } else {
            [void]$errors.Add(('必須ファイルがありません: ' + $relative))
        }
    }

    $userRoot = Join-Path $env:LOCALAPPDATA 'VBAUpdater'
    try {
        if (-not (Test-Path -LiteralPath $userRoot -PathType Container)) { [void](New-Item -ItemType Directory -Path $userRoot -Force) }
        $probe = Join-Path $userRoot ('.write_test_' + [Guid]::NewGuid().ToString('N') + '.tmp')
        [System.IO.File]::WriteAllText($probe, 'ok', (New-Object System.Text.UTF8Encoding($false)))
        Remove-Item -LiteralPath $probe -Force
        [void]$ok.Add('登録情報・ログ保存先: 書き込み可能')
    } catch {
        [void]$errors.Add(('登録情報・ログ保存先へ書き込めません: ' + $_.Exception.Message))
    }

    if ($null -ne $script:selectedProjectInfo) {
        $projectDir = [string]$script:selectedProjectInfo.ProjectDirectory
        if ([string]::IsNullOrWhiteSpace($projectDir) -or -not (Test-Path -LiteralPath $projectDir -PathType Container)) {
            [void]$errors.Add('選択中プロジェクトのフォルダーが見つかりません。')
        } else {
            [void]$ok.Add('選択中プロジェクト: フォルダー確認済み')
            $projectJson = Join-Path $projectDir 'project.json'
            if (Test-Path -LiteralPath $projectJson -PathType Leaf) { [void]$ok.Add('project.json: 確認済み') }
            else { [void]$warnings.Add('project.json がプロジェクト直下にありません。登録構成を確認してください。') }
        }
        $targetPath = [string]$script:selectedProjectInfo.TargetPath
        if (-not [string]::IsNullOrWhiteSpace($targetPath)) {
            if (Test-Path -LiteralPath $targetPath -PathType Leaf) { [void]$ok.Add('対象ブック: 確認済み') }
            else { [void]$errors.Add('対象ブックが見つかりません。') }
        }
    } else {
        [void]$warnings.Add('プロジェクトが選択されていません。プロジェクト固有の確認は省略しました。')
    }

    try {
        $safety=Get-GuiOperationalSafetySnapshot
        foreach($item in @($safety.Errors)){[void]$errors.Add([string]$item)}
        foreach($item in @($safety.Warnings)){[void]$warnings.Add([string]$item)}
        foreach($item in @($safety.Ok)){[void]$ok.Add([string]$item)}
    } catch {
        [void]$warnings.Add(('運用安全診断を完了できません: '+$_.Exception.Message))
    }

    $lines = New-Object 'System.Collections.Generic.List[string]'
    [void]$lines.Add(('製品ビルド: ' + (Get-VBAUpdaterBuildVersion)))
    [void]$lines.Add(('PowerShell: ' + $PSVersionTable.PSVersion.ToString()))
    [void]$lines.Add('')
    if ($errors.Count -eq 0) { [void]$lines.Add('総合結果: 正常') }
    else { [void]$lines.Add(('総合結果: 要確認（エラー ' + $errors.Count + '件）')) }
    [void]$lines.Add('')
    if ($errors.Count -gt 0) {
        [void]$lines.Add('[エラー]')
        foreach ($item in $errors) { [void]$lines.Add(('・' + $item)) }
        [void]$lines.Add('')
    }
    if ($warnings.Count -gt 0) {
        [void]$lines.Add('[注意]')
        foreach ($item in $warnings) { [void]$lines.Add(('・' + $item)) }
        [void]$lines.Add('')
    }
    [void]$lines.Add(('[正常項目] ' + $ok.Count + '件'))
    try {
        $retry=Get-VBAUpdaterOperationalRetryAssessment -Snapshot $safety
        [void]$lines.Add('')
        [void]$lines.Add(('再実行判定: ' + [string]$retry.Status))
        [void]$lines.Add([string]$retry.Message)
    } catch {}
    [void]$lines.Add('問題がある場合は「ログを見る」→「診断情報を保存」を利用してください。')
    Show-GuiMessage ($lines -join [Environment]::NewLine) 'VBAUpdater 環境チェック'
}

function Export-VBAUpdaterSupportInfo {
    $dialog = New-Object System.Windows.Forms.SaveFileDialog
    $dialog.Title = 'サポート用診断情報を保存'
    $dialog.Filter = 'テキストファイル (*.txt)|*.txt|すべてのファイル (*.*)|*.*'
    $dialog.FileName = 'VBAUpdater_Support_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.txt'
    $dialog.InitialDirectory = [Environment]::GetFolderPath('Desktop')
    try {
        if ($dialog.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { return }
        $latest = Get-ChildItem -LiteralPath (Get-GuiLogDirectory) -Filter '*.log' -File -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending | Select-Object -First 1
        $lines = New-Object 'System.Collections.Generic.List[string]'
        [void]$lines.Add('VBAUpdater サポート用診断情報')
        [void]$lines.Add(('作成日時: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')))
        [void]$lines.Add((('GUI: Ver' + $script:ProductVersion)))
        [void]$lines.Add(('製品ビルド: ' + (Get-VBAUpdaterBuildVersion)))
        [void]$lines.Add(('PowerShell: ' + $PSVersionTable.PSVersion.ToString()))
        [void]$lines.Add(('Windows: ' + [Environment]::OSVersion.VersionString))
        [void]$lines.Add(('インストール先: ' + [string]$root))
        [void]$lines.Add(('登録情報・ログ: ' + (Join-Path $env:LOCALAPPDATA 'VBAUpdater')))
        [void]$lines.Add(('インストール履歴: ' + (Get-InstallerHistoryPath)))
        [void]$lines.Add(('設定安全バックアップ: ' + (Join-Path (Get-VBAUpdaterUserDataRoot) 'config-backups')))
        $configBackupRoot = Join-Path (Get-VBAUpdaterUserDataRoot) 'config-backups'
        $configBackupItems = @()
        if (Test-Path -LiteralPath $configBackupRoot -PathType Container) { $configBackupItems = @(Get-ChildItem -LiteralPath $configBackupRoot -Directory -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending) }
        [void]$lines.Add(('設定安全バックアップ数: ' + $configBackupItems.Count))
        if ($configBackupItems.Count -gt 0) { [void]$lines.Add(('最新設定安全バックアップ: ' + $configBackupItems[0].FullName)) }
        [void]$lines.Add(('画面状態: ' + [string]$script:currentStatus))
        [void]$lines.Add('')
        try { Add-OperationalSafetyLines -Lines $lines -Snapshot (Get-GuiOperationalSafetySnapshot) }
        catch { [void]$lines.Add(('運用安全診断: 取得失敗 / '+$_.Exception.Message)) }
        [void]$lines.Add('')
        [void]$lines.Add('[選択中プロジェクト]')
        [void]$lines.Add(('プロジェクト名: ' + $(if ($null -ne $script:selectedProjectInfo) { [string]$script:selectedProjectInfo.ProjectName } else { '-' })))
        [void]$lines.Add(('プロジェクトルート: ' + [string]$lblDirectProjectRootValue.Text))
        [void]$lines.Add(('対象ブック: ' + [string]$lblTargetPathValue.Text))
        [void]$lines.Add(('利用状態: ' + [string]$lblDirectStatusValue.Text))
        [void]$lines.Add('')
        [void]$lines.Add('[最近のインストール履歴]')
        $installerHistory = Get-InstallerHistoryPath
        if (Test-Path -LiteralPath $installerHistory -PathType Leaf) {
            foreach ($historyLine in @(Get-Utf8TailLines $installerHistory 10)) { [void]$lines.Add([string]$historyLine) }
        } else {
            [void]$lines.Add('インストール履歴はまだありません。')
        }
        [void]$lines.Add('')
        [void]$lines.Add('[最新GUIログ]')
        if ($null -eq $latest) {
            [void]$lines.Add('GUIログはまだありません。')
        } else {
            [void]$lines.Add(('ファイル: ' + $latest.FullName))
            [void]$lines.Add('--- 最新80行 ---')
            foreach ($line in @(Get-Content -LiteralPath $latest.FullName -Tail 80 -ErrorAction SilentlyContinue)) { [void]$lines.Add([string]$line) }
        }
        [System.IO.File]::WriteAllLines($dialog.FileName, $lines.ToArray(), (New-Object System.Text.UTF8Encoding($false)))
        Append-Log ('[GUI] サポート用診断情報を保存しました: ' + $dialog.FileName)
        Show-GuiMessage ("診断情報を保存しました。`r`n`r`n" + $dialog.FileName) '診断情報を保存'
    }
    finally { $dialog.Dispose() }
}


function Export-VBAUpdaterSupportPackage {
    $dialog = New-Object System.Windows.Forms.SaveFileDialog
    $dialog.Title = 'サポート用ZIPを保存'
    $dialog.Filter = 'ZIPファイル (*.zip)|*.zip'
    $dialog.FileName = 'VBAUpdater_SupportPackage_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.zip'
    $dialog.InitialDirectory = [Environment]::GetFolderPath('Desktop')
    $tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('VBAUpdaterSupport_' + [Guid]::NewGuid().ToString('N'))
    try {
        if ($dialog.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { return }
        [void](New-Item -ItemType Directory -Path $tempRoot -Force)

        $summary = New-Object 'System.Collections.Generic.List[string]'
        [void]$summary.Add('VBAUpdater サポートパッケージ')
        [void]$summary.Add(('作成日時: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')))
        [void]$summary.Add((('GUI: Ver' + $script:ProductVersion)))
        [void]$summary.Add(('製品ビルド: ' + (Get-VBAUpdaterBuildVersion)))
        [void]$summary.Add(('PowerShell: ' + $PSVersionTable.PSVersion.ToString()))
        [void]$summary.Add(('Windows: ' + [Environment]::OSVersion.VersionString))
        [void]$summary.Add(('インストール先: ' + [string]$root))
        [void]$summary.Add(('画面状態: ' + [string]$script:currentStatus))
        [void]$summary.Add('')
        try {
            $safetySnapshot=Get-GuiOperationalSafetySnapshot
            Add-OperationalSafetyLines -Lines $summary -Snapshot $safetySnapshot
            $retryAssessment=Get-VBAUpdaterOperationalRetryAssessment -Snapshot $safetySnapshot
            [void]$summary.Add(('再実行判定: '+[string]$retryAssessment.Status))
            [void]$summary.Add(('再実行案内: '+[string]$retryAssessment.Message))
            $projectName=$(if($null-ne$script:selectedProjectInfo){[string]$script:selectedProjectInfo.ProjectName}else{''})
            $supportRecord=Get-VBAUpdaterOperationalSupportRecord -Snapshot $safetySnapshot -RetryAssessment $retryAssessment -Build (Get-VBAUpdaterBuildVersion) -ProjectName $projectName -TargetPath ([string]$lblTargetPathValue.Text)
            [IO.File]::WriteAllText((Join-Path $tempRoot 'OperationalSafety.json'),($supportRecord|ConvertTo-Json -Depth 6),(New-Object Text.UTF8Encoding($false)))
            [IO.File]::WriteAllLines((Join-Path $tempRoot 'RecoveryGuidance.txt'),(Get-VBAUpdaterOperationalGuidanceLines -Snapshot $safetySnapshot -RetryAssessment $retryAssessment),(New-Object Text.UTF8Encoding($false)))
        } catch {
            [void]$summary.Add(('運用安全診断: 取得失敗 / '+$_.Exception.Message))
        }
        [void]$summary.Add('')
        [void]$summary.Add('[選択中プロジェクト]')
        [void]$summary.Add(('プロジェクト名: ' + $(if ($null -ne $script:selectedProjectInfo) { [string]$script:selectedProjectInfo.ProjectName } else { '-' })))
        [void]$summary.Add(('プロジェクトルート: ' + [string]$lblDirectProjectRootValue.Text))
        [void]$summary.Add(('対象ブック: ' + [string]$lblTargetPathValue.Text))
        [void]$summary.Add(('利用状態: ' + [string]$lblDirectStatusValue.Text))
        [System.IO.File]::WriteAllLines((Join-Path $tempRoot 'SupportSummary.txt'), $summary.ToArray(), (New-Object System.Text.UTF8Encoding($false)))

        $history = Get-InstallerHistoryPath
        if (Test-Path -LiteralPath $history -PathType Leaf) {
            Copy-Item -LiteralPath $history -Destination (Join-Path $tempRoot 'installer-history.log') -Force
        }

        $logDestination = Join-Path $tempRoot 'logs'
        [void](New-Item -ItemType Directory -Path $logDestination -Force)
        $logs = @(Get-ChildItem -LiteralPath (Get-GuiLogDirectory) -Filter '*.log' -File -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending | Select-Object -First 5)
        foreach ($log in $logs) {
            Copy-Item -LiteralPath $log.FullName -Destination (Join-Path $logDestination $log.Name) -Force
        }
        if ($logs.Count -eq 0) {
            [System.IO.File]::WriteAllText((Join-Path $logDestination 'README.txt'), 'GUIログはまだありません。', (New-Object System.Text.UTF8Encoding($false)))
        }

        $backupRoot = Join-Path (Get-VBAUpdaterUserDataRoot) 'config-backups'
        $backupSummary = New-Object 'System.Collections.Generic.List[string]'
        [void]$backupSummary.Add('設定安全バックアップ一覧')
        if (Test-Path -LiteralPath $backupRoot -PathType Container) {
            foreach ($backup in @(Get-ChildItem -LiteralPath $backupRoot -Directory -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 5)) {
                [void]$backupSummary.Add(('{0:yyyy-MM-dd HH:mm:ss}  {1}' -f $backup.LastWriteTime,$backup.Name))
            }
        }
        if ($backupSummary.Count -eq 1) { [void]$backupSummary.Add('自動安全バックアップはまだありません。') }
        [System.IO.File]::WriteAllLines((Join-Path $tempRoot 'ConfigBackupSummary.txt'), $backupSummary.ToArray(), (New-Object System.Text.UTF8Encoding($false)))

        [System.IO.File]::WriteAllText((Join-Path $tempRoot 'PRIVACY_NOTE.txt'), 'このZIPには診断情報、運用安全診断、インストール履歴、直近GUIログ、バックアップ一覧のみを含みます。settings.json / projects.json / Excelブック本体は含みません。', (New-Object System.Text.UTF8Encoding($false)))

        if (Test-Path -LiteralPath $dialog.FileName -PathType Leaf) { Remove-Item -LiteralPath $dialog.FileName -Force }
        Compress-Archive -Path (Join-Path $tempRoot '*') -DestinationPath $dialog.FileName -CompressionLevel Optimal -Force
        Append-Log ('[GUI] サポート用ZIPを保存しました: ' + $dialog.FileName)
        Show-GuiMessage ("サポート用ZIPを保存しました。`r`n`r`n" + $dialog.FileName + "`r`n`r`n不具合調査時はこのZIPをそのまま送付できます。") 'サポート用ZIP'
    }
    finally {
        if (Test-Path -LiteralPath $tempRoot) { Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue }
        $dialog.Dispose()
    }
}


function Get-VBAUpdaterUserDataRoot {
    $local = [Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)
    if ([string]::IsNullOrWhiteSpace($local)) { $local = $env:LOCALAPPDATA }
    if ([string]::IsNullOrWhiteSpace($local)) { throw 'LOCALAPPDATAの場所を取得できません。' }
    return (Join-Path $local 'VBAUpdater')
}

function New-VBAUpdaterConfigSafetyBackup {
    $userRoot = Get-VBAUpdaterUserDataRoot
    $backupRoot = Join-Path $userRoot 'config-backups'
    if (-not (Test-Path -LiteralPath $backupRoot -PathType Container)) { [void](New-Item -ItemType Directory -Path $backupRoot -Force) }
    $destination = Join-Path $backupRoot ('BeforeRestore_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
    [void](New-Item -ItemType Directory -Path $destination -Force)
    $copied = 0
    foreach ($name in @('settings.json','projects.json')) {
        $source = Join-Path $userRoot $name
        if (Test-Path -LiteralPath $source -PathType Leaf) {
            Copy-Item -LiteralPath $source -Destination (Join-Path $destination $name) -Force
            $copied++
        }
    }
    [System.IO.File]::WriteAllText((Join-Path $destination 'backup-info.txt'), ('Created=' + (Get-Date -Format 'o') + [Environment]::NewLine + 'Build=' + (Get-VBAUpdaterBuildVersion) + [Environment]::NewLine), (New-Object System.Text.UTF8Encoding($false)))
    $folders = @(Get-ChildItem -LiteralPath $backupRoot -Directory -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
    foreach ($old in @($folders | Select-Object -Skip 5)) { try { Remove-Item -LiteralPath $old.FullName -Recurse -Force } catch { Write-Verbose $_.Exception.Message } }
    return [PSCustomObject]@{ Path=$destination; Copied=$copied }
}

function Export-VBAUpdaterConfigBackup {
    $userRoot = Get-VBAUpdaterUserDataRoot
    $dialog = New-Object System.Windows.Forms.SaveFileDialog
    $dialog.Title = 'VBAUpdater 設定バックアップを保存'
    $dialog.Filter = 'VBAUpdater設定バックアップ (*.zip)|*.zip'
    $dialog.FileName = 'VBAUpdater_Settings_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.zip'
    $dialog.InitialDirectory = [Environment]::GetFolderPath('Desktop')
    $tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('VBAUpdaterConfigExport_' + [Guid]::NewGuid().ToString('N'))
    try {
        if ($dialog.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { return }
        [void](New-Item -ItemType Directory -Path $tempRoot -Force)
        $copied = 0
        foreach ($name in @('settings.json','projects.json')) {
            $source = Join-Path $userRoot $name
            if (Test-Path -LiteralPath $source -PathType Leaf) {
                Copy-Item -LiteralPath $source -Destination (Join-Path $tempRoot $name) -Force
                $copied++
            }
        }
        if ($copied -eq 0) { throw 'バックアップできる設定情報がありません。' }
        $manifest = @(
            'VBAUpdaterConfigBackup=1',
            ('Created=' + (Get-Date -Format 'o')),
            ('Build=' + (Get-VBAUpdaterBuildVersion)),
            ('Files=' + $copied)
        ) -join [Environment]::NewLine
        [System.IO.File]::WriteAllText((Join-Path $tempRoot 'VBAUpdaterConfigBackup.txt'), $manifest + [Environment]::NewLine, (New-Object System.Text.UTF8Encoding($false)))
        if (Test-Path -LiteralPath $dialog.FileName -PathType Leaf) { Remove-Item -LiteralPath $dialog.FileName -Force }
        Compress-Archive -Path (Join-Path $tempRoot '*') -DestinationPath $dialog.FileName -CompressionLevel Optimal -Force
        Append-Log ('[GUI] 設定バックアップを保存しました: ' + $dialog.FileName)
        Show-GuiMessage ("設定バックアップを保存しました。`r`n`r`n" + $dialog.FileName) '設定バックアップ'
    }
    finally {
        if (Test-Path -LiteralPath $tempRoot) { Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue }
        $dialog.Dispose()
    }
}

function Import-VBAUpdaterConfigBackup {
    $userRoot = Get-VBAUpdaterUserDataRoot
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title = 'VBAUpdater 設定バックアップを復元'
    $dialog.Filter = 'VBAUpdater設定バックアップ (*.zip)|*.zip'
    $dialog.Multiselect = $false
    $tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('VBAUpdaterConfigImport_' + [Guid]::NewGuid().ToString('N'))
    try {
        if ($dialog.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { return }
        [void](New-Item -ItemType Directory -Path $tempRoot -Force)
        Expand-Archive -LiteralPath $dialog.FileName -DestinationPath $tempRoot -Force
        $manifest = Join-Path $tempRoot 'VBAUpdaterConfigBackup.txt'
        if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { throw 'VBAUpdaterの設定バックアップとして確認できません。' }
        $manifestText = [System.IO.File]::ReadAllText($manifest)
        if ($manifestText -notmatch '(?m)^VBAUpdaterConfigBackup=1\s*$') { throw '設定バックアップの形式が正しくありません。' }
        $restoreNames = New-Object 'System.Collections.Generic.List[string]'
        foreach ($name in @('settings.json','projects.json')) {
            $candidate = Join-Path $tempRoot $name
            if (Test-Path -LiteralPath $candidate -PathType Leaf) {
                try { [void]([System.IO.File]::ReadAllText($candidate) | ConvertFrom-Json) }
                catch { throw ($name + ' が有効なJSONではありません: ' + $_.Exception.Message) }
                [void]$restoreNames.Add($name)
            }
        }
        if ($restoreNames.Count -eq 0) { throw '復元できる設定ファイルがバックアップ内にありません。' }
        $message = @(
            'VBAUpdaterの登録情報・設定を復元します。', '',
            ('バックアップ: ' + $dialog.FileName),
            ('復元対象: ' + ($restoreNames -join '、')), '',
            '現在の設定は復元直前に自動バックアップします。',
            'プロジェクトフォルダーやExcelブック自体は変更しません。', '',
            '復元しますか？'
        ) -join [Environment]::NewLine
        if ([System.Windows.Forms.MessageBox]::Show($form,$message,'設定バックアップから復元',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question,[System.Windows.Forms.MessageBoxDefaultButton]::Button2) -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        $safety = New-VBAUpdaterConfigSafetyBackup
        if (-not (Test-Path -LiteralPath $userRoot -PathType Container)) { [void](New-Item -ItemType Directory -Path $userRoot -Force) }
        foreach ($name in $restoreNames) { Copy-Item -LiteralPath (Join-Path $tempRoot $name) -Destination (Join-Path $userRoot $name) -Force }
        $script:settingsInfo = $null
        Refresh-ProjectRootAndProjects
        Append-Log ('[GUI] 設定バックアップから復元しました: ' + $dialog.FileName + ' / SafetyBackup=' + $safety.Path)
        Show-GuiMessage ("設定を復元しました。`r`n`r`n安全バックアップ:`r`n" + $safety.Path) '設定バックアップから復元'
    }
    finally {
        if (Test-Path -LiteralPath $tempRoot) { Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue }
        $dialog.Dispose()
    }
}


function Get-VBAUpdaterConfigSafetyBackups {
    $backupRoot = Join-Path (Get-VBAUpdaterUserDataRoot) 'config-backups'
    if (-not (Test-Path -LiteralPath $backupRoot -PathType Container)) { return @() }
    return @(Get-ChildItem -LiteralPath $backupRoot -Directory -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
}

function Test-VBAUpdaterConfigIntegrity {
    $userRoot = Get-VBAUpdaterUserDataRoot
    $messages = New-Object 'System.Collections.Generic.List[string]'
    $ok = $true
    foreach ($name in @('settings.json','projects.json')) {
        $path = Join-Path $userRoot $name
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            [void]$messages.Add(($name + ': 未作成（必要になった時点で自動作成されます）'))
            continue
        }
        try {
            $text = [System.IO.File]::ReadAllText($path)
            [void]($text | ConvertFrom-Json)
            [void]$messages.Add(($name + ': 正常'))
        }
        catch {
            $ok = $false
            [void]$messages.Add(($name + ': 異常 - ' + $_.Exception.Message))
        }
    }
    $backups = @(Get-VBAUpdaterConfigSafetyBackups)
    [void]$messages.Add(('自動安全バックアップ: ' + $backups.Count + '件'))
    if ($backups.Count -gt 0) { [void]$messages.Add(('最新: ' + $backups[0].Name)) }
    $title = if ($ok) { '設定の整合性：正常' } else { '設定の整合性：要確認' }
    $icon = if ($ok) { [System.Windows.Forms.MessageBoxIcon]::Information } else { [System.Windows.Forms.MessageBoxIcon]::Warning }
    Show-GuiMessage (($title + "`r`n`r`n" + ($messages -join "`r`n"))) '設定の整合性を確認' $icon
}

function Restore-VBAUpdaterConfigSafetyBackup([string]$backupPath) {
    if ([string]::IsNullOrWhiteSpace($backupPath) -or -not (Test-Path -LiteralPath $backupPath -PathType Container)) { throw '選択した安全バックアップが見つかりません。' }
    $restoreNames = New-Object 'System.Collections.Generic.List[string]'
    foreach ($name in @('settings.json','projects.json')) {
        $candidate = Join-Path $backupPath $name
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            try { [void]([System.IO.File]::ReadAllText($candidate) | ConvertFrom-Json) }
            catch { throw ($name + ' が有効なJSONではありません: ' + $_.Exception.Message) }
            [void]$restoreNames.Add($name)
        }
    }
    if ($restoreNames.Count -eq 0) { throw '選択した安全バックアップには復元できる設定がありません。' }
    $message = @(
        '自動安全バックアップから設定を復元します。','',
        ('バックアップ: ' + $backupPath),
        ('復元対象: ' + ($restoreNames -join '、')),'',
        '現在の設定も復元直前に新しい安全バックアップへ保存します。','',
        '復元しますか？'
    ) -join [Environment]::NewLine
    if ([System.Windows.Forms.MessageBox]::Show($form,$message,'自動安全バックアップから復元',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question,[System.Windows.Forms.MessageBoxDefaultButton]::Button2) -ne [System.Windows.Forms.DialogResult]::Yes) { return $false }
    $safety = New-VBAUpdaterConfigSafetyBackup
    $userRoot = Get-VBAUpdaterUserDataRoot
    if (-not (Test-Path -LiteralPath $userRoot -PathType Container)) { [void](New-Item -ItemType Directory -Path $userRoot -Force) }
    foreach ($name in $restoreNames) { Copy-Item -LiteralPath (Join-Path $backupPath $name) -Destination (Join-Path $userRoot $name) -Force }
    $script:settingsInfo = $null
    Refresh-ProjectRootAndProjects
    Append-Log ('[GUI] 自動安全バックアップから設定を復元しました: ' + $backupPath + ' / BeforeRestore=' + $safety.Path)
    Show-GuiMessage ("自動安全バックアップから設定を復元しました。`r`n`r`n復元直前バックアップ:`r`n" + $safety.Path) '設定の復元'
    return $true
}

function Show-VBAUpdaterConfigSafetyBackupList {
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = '自動安全バックアップ一覧'
    $dialog.StartPosition = 'CenterParent'
    $dialog.Size = New-Object System.Drawing.Size(760, 420)
    $dialog.MinimumSize = New-Object System.Drawing.Size(680, 360)
    $dialog.Font = $form.Font

    $layout = New-Object System.Windows.Forms.TableLayoutPanel
    $layout.Dock = 'Fill'; $layout.Padding = New-Object System.Windows.Forms.Padding(12)
    $layout.RowCount = 3; $layout.ColumnCount = 1
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent,100)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))

    $intro = New-Object System.Windows.Forms.Label
    $intro.Text = '設定復元前・インストール前に自動作成されたバックアップです。最大5世代を保持します。'
    $intro.AutoSize = $true; $intro.Margin = New-Object System.Windows.Forms.Padding(4,4,4,10)
    $layout.Controls.Add($intro,0,0)

    $list = New-Object System.Windows.Forms.ListBox
    $list.Dock = 'Fill'; $list.HorizontalScrollbar = $true
    $backups = @(Get-VBAUpdaterConfigSafetyBackups)
    foreach ($backup in $backups) {
        $reason = if ($backup.Name -like 'BeforeInstall_*') { 'インストール前' } elseif ($backup.Name -like 'BeforeRestore_*') { '復元前' } else { '自動' }
        [void]$list.Items.Add(('{0:yyyy-MM-dd HH:mm:ss}  [{1}]  {2}' -f $backup.LastWriteTime,$reason,$backup.FullName))
    }
    if ($list.Items.Count -eq 0) { [void]$list.Items.Add('自動安全バックアップはまだありません。'); $list.Enabled=$false }
    $layout.Controls.Add($list,0,1)

    $buttons = New-Object System.Windows.Forms.FlowLayoutPanel
    $buttons.AutoSize=$true; $buttons.FlowDirection='LeftToRight'; $buttons.WrapContents=$false
    $btnRestore = New-Object System.Windows.Forms.Button; $btnRestore.Text='選択したバックアップへ復元'; $btnRestore.Size=New-Object System.Drawing.Size(220,36); $btnRestore.Enabled=($backups.Count -gt 0)
    $btnOpen = New-Object System.Windows.Forms.Button; $btnOpen.Text='保存フォルダーを開く'; $btnOpen.Size=New-Object System.Drawing.Size(180,36)
    $btnClose = New-Object System.Windows.Forms.Button; $btnClose.Text='閉じる'; $btnClose.Size=New-Object System.Drawing.Size(100,36)
    $btnRestore.Add_Click({
        try {
            if ($list.SelectedIndex -lt 0) { Show-GuiMessage '復元するバックアップを選択してください。' '自動安全バックアップ'; return }
            $selected = $backups[$list.SelectedIndex]
            if (Restore-VBAUpdaterConfigSafetyBackup -backupPath $selected.FullName) { $dialog.Close() }
        } catch { Append-Log ('[GUI] 自動安全バックアップ復元に失敗しました: '+$_.Exception.Message); Show-GuiMessage $_.Exception.Message '設定の復元' ([System.Windows.Forms.MessageBoxIcon]::Error) }
    })
    $btnOpen.Add_Click({ $path=Join-Path (Get-VBAUpdaterUserDataRoot) 'config-backups'; if(-not(Test-Path -LiteralPath $path -PathType Container)){[void](New-Item -ItemType Directory -Path $path -Force)}; Start-Process explorer.exe -ArgumentList ('"'+$path+'"') })
    $btnClose.Add_Click({ $dialog.Close() })
    $buttons.Controls.Add($btnRestore); $buttons.Controls.Add($btnOpen); $buttons.Controls.Add($btnClose)
    $layout.Controls.Add($buttons,0,2)
    $dialog.Controls.Add($layout)
    [void]$dialog.ShowDialog($form)
    $dialog.Dispose()
}

function Show-VBAUpdaterConfigBackupDialog {
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = '設定バックアップ・復元'
    $dialog.StartPosition = 'CenterParent'
    $dialog.Size = New-Object System.Drawing.Size(540, 390)
    $dialog.MinimumSize = New-Object System.Drawing.Size(500, 350)
    $dialog.Font = $form.Font
    $panel = New-Object System.Windows.Forms.FlowLayoutPanel
    $panel.Dock = 'Fill'; $panel.FlowDirection = 'TopDown'; $panel.WrapContents = $false
    $panel.Padding = New-Object System.Windows.Forms.Padding(16); $panel.AutoScroll = $true
    $intro = New-Object System.Windows.Forms.Label
    $intro.Text = '登録済みProjectとVBAUpdater設定をZIPでバックアップ／復元します。ProjectフォルダーやExcelブック自体は含みません。'
    $intro.AutoSize = $true; $intro.MaximumSize = New-Object System.Drawing.Size(470,0); $intro.Margin = New-Object System.Windows.Forms.Padding(4,4,4,12)
    $panel.Controls.Add($intro)
    $specs = @(
        @('設定をバックアップ', { Export-VBAUpdaterConfigBackup }),
        @('バックアップから復元', { Import-VBAUpdaterConfigBackup }),
        @('自動安全バックアップ一覧', { Show-VBAUpdaterConfigSafetyBackupList }),
        @('設定の整合性を確認', { Test-VBAUpdaterConfigIntegrity }),
        @('設定保存フォルダーを開く', { $path=Get-VBAUpdaterUserDataRoot; if(-not(Test-Path -LiteralPath $path -PathType Container)){[void](New-Item -ItemType Directory -Path $path -Force)}; Start-Process explorer.exe -ArgumentList ('"'+$path+'"') })
    )
    foreach ($item in $specs) {
        $button = New-Object System.Windows.Forms.Button
        $button.Text=[string]$item[0]; $button.Size=New-Object System.Drawing.Size(320,38)
        $action=[scriptblock]$item[1]
        $button.Add_Click({ try { & $action } catch { Append-Log ('[GUI] 設定バックアップ操作に失敗しました: '+$_.Exception.Message); Show-GuiMessage $_.Exception.Message '設定バックアップ' ([System.Windows.Forms.MessageBoxIcon]::Error) } }.GetNewClosure())
        $panel.Controls.Add($button)
    }
    $dialog.Controls.Add($panel)
    [void]$dialog.ShowDialog($form)
    $dialog.Dispose()
}

function Trim-GuiLogs {
    $directory = Get-GuiLogDirectory
    $files = @(Get-ChildItem -LiteralPath $directory -Filter '*.log' -File -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending)
    foreach ($file in @($files | Select-Object -Skip $script:GuiLogRetentionCount)) {
        try {
            Remove-Item -LiteralPath $file.FullName -Force
        }
        catch {
            Append-Log ('[GUI] 警告: 古いGUIログを削除できませんでした: ' + $file.FullName + ' / ' + $_.Exception.Message)
        }
    }
}

function Update-ElapsedDisplay {
    if (-not $script:busy -or $null -eq $script:commandStartedAt) { return }
    $elapsed = [DateTime]::Now - [DateTime]$script:commandStartedAt
    $lblElapsedValue.Text = '経過時間：' + (Format-GuiElapsed $elapsed)
}

function Set-Busy([bool]$Value, [string]$Command = '') {
    $script:busy = $Value
    $cmbProject.Enabled = -not $Value
    $btnRefresh.Enabled = -not $Value
    foreach ($button in $operationButtons) { $button.Enabled = -not $Value }
    Update-OpenTargetButtonState
    $form.UseWaitCursor = $Value
    if ($Value) {
        $script:commandStartedAt = [DateTime]::Now
        $script:currentCommand = $Command
        $lblCommandCaption.Text = '処理状況'
        $lblCommandValue.Text = Get-GuiCommandDisplayName $Command
        $lblElapsedValue.Text = '経過時間：00:00:00'
        Set-CurrentStatus '処理実行中'
        $lblInfoMessageValue.Text = $(if ($Command -eq 'project-sync') {
            '安全な更新処理を実行しています。この画面を閉じずにお待ちください。'
        }
        elseif ($Command -eq 'project-create') {
            '開発プロジェクトへExcelブックを登録し、初期ソースを作成しています。この画面を閉じずにお待ちください。'
        }
        elseif ($Command -in @('project-root-set','project-root-reset')) {
            '設定を保存し、プロジェクト一覧を読み直しています。'
        }
        elseif ($Command -eq 'codex-export') {
            'Codex用ZIPを作成しています。この画面を閉じずにお待ちください。'
        }
        elseif ($Command -eq 'codex-import-preview') {
            'Codex納品ZIPを安全に検証し、差分を確認しています。'
        }
        elseif ($Command -eq 'codex-import') {
            'バックアップを作成してCodex納品ZIPを取り込んでいます。'
        }
        else { '処理を実行しています。この画面を閉じずにお待ちください。' })
    }
    else {
        $script:commandStartedAt = $null
        $script:currentCommand = $null
    }
    Update-GitHubButtonState
    Update-WorkbookRequiredButtonState
}

function Set-OperationResult([string]$Command, [string]$ResultStatus, [DateTime]$CompletedAt, [TimeSpan]$Elapsed) {
    Set-CurrentStatus $ResultStatus
    $targetName = if ($null -ne $script:selectedProjectInfo -and
        -not [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.TargetName)) {
        [string]$script:selectedProjectInfo.TargetName
    }
    else { '<不明>' }
    $elapsedText = Format-GuiElapsed $Elapsed
    $lblCommandCaption.Text = '完了情報'
    $lblCommandValue.Text = '完了日時：' + $CompletedAt.ToString('yyyy-MM-dd HH:mm:ss')
    $lblElapsedValue.Text = '処理時間：' + $elapsedText

    if ($Command -eq 'project-sync') {
        switch ($ResultStatus) {
            '処理成功' {
                $lblStateValue.Text = '✓ ブックの更新が完了しました'
                $lblInfoMessageValue.Text = '対象ブック：' + $targetName
            }
            '警告付き成功' {
                $lblStateValue.Text = '▲ ブックの更新は完了しました'
                $lblInfoMessageValue.Text = '更新処理は正常に完了しましたが、確認事項があります。詳細ログを確認してください。対象ブック：' + $targetName
            }
            default {
                $lblStateValue.Text = '× ブックを更新できませんでした'
                $lblInfoMessageValue.Text = '対象ブックは更新完了扱いにしていません。詳細ログを確認してください。対象ブック：' + $targetName
            }
        }
    }
    elseif ($Command -eq 'project-create') {
        switch ($ResultStatus) {
            '処理成功' {
                $lblStateValue.Text = '✓ 開発プロジェクトの登録が完了しました'
                $lblInfoMessageValue.Text = 'Excelブックを登録し、初期ソースを作成しました。今後は「ブックを更新する」から安全に更新できます。'
            }
            '警告付き成功' {
                $lblStateValue.Text = '▲ 開発プロジェクトの登録は完了しました'
                $lblInfoMessageValue.Text = '登録は完了しましたが、確認事項があります。詳細ログを確認してください。'
            }
            default {
                $lblStateValue.Text = '× プロジェクトを作成できませんでした'
                $lblInfoMessageValue.Text = '作成に失敗しました。クリーンアップ結果と残存場所を詳細ログで確認してください。元のExcelブックは変更していません。'
            }
        }
    }
    elseif ($Command -in @('project-root-set','project-root-reset')) {
        switch ($ResultStatus) {
            '処理成功' {
                $lblStateValue.Text = '✓ プロジェクト保存先を変更しました'
                $lblInfoMessageValue.Text = '新しい保存先からプロジェクト一覧を読み直しました。既存フォルダーの自動移動や削除は行っていません。'
            }
            '警告付き成功' {
                $lblStateValue.Text = '▲ プロジェクト保存先を変更しました'
                $lblInfoMessageValue.Text = '保存先は変更されましたが、確認事項があります。詳細ログを確認してください。'
            }
            default {
                $lblStateValue.Text = '× プロジェクト保存先を変更できませんでした'
                $lblInfoMessageValue.Text = '以前の保存先設定は維持されています。詳細ログを確認してください。'
            }
        }
    }
    else {
        $lblInfoMessageValue.Text = (Get-GuiCommandDisplayName $Command) + ' / ExitCodeに基づく実行結果です。'
    }
}

function Copy-NewCliOutputToLog([bool]$FinalRead = $false) {
    if ([string]::IsNullOrWhiteSpace($script:guiOutputPath) -or
        -not (Test-Path -LiteralPath $script:guiOutputPath -PathType Leaf)) {
        if ($FinalRead) { throw 'CLIログファイルを取得できませんでした。' }
        return
    }

    try {
        $text = [System.IO.File]::ReadAllText($script:guiOutputPath, [System.Text.Encoding]::UTF8)
    }
    catch {
        # Out-Fileが書き込み中の一時的な競合は次回のTimer Tickで再試行する。
        if ($FinalRead) { throw }
        return
    }

    if ($text.Length -lt $script:lastOutputLength) { $script:lastOutputLength = 0 }
    if ($text.Length -le $script:lastOutputLength) { return }
    $chunk = $text.Substring($script:lastOutputLength)
    $script:lastOutputLength = $text.Length
    Append-LogText $chunk
}

function Remove-GuiRunnerFile {
    if (-not [string]::IsNullOrWhiteSpace($script:guiRunnerPath) -and (Test-Path -LiteralPath $script:guiRunnerPath)) {
        Remove-Item -LiteralPath $script:guiRunnerPath -Force -ErrorAction SilentlyContinue
    }
}

function Clear-CliRuntime([bool]$StopProcess) {
    $script:pollTimer.Stop()
    try {
        if ($null -ne $script:process) {
            if ($StopProcess -and -not $script:process.HasExited) {
                $script:process.Kill()
                $script:process.WaitForExit()
            }
            elseif ($script:process.HasExited) {
                $script:process.WaitForExit()
            }
            $script:process.Dispose()
        }
    }
    catch {
        # 後始末エラーでGUIを終了させない。
    }
    try { Remove-GuiRunnerFile } catch { Write-Verbose ('GUI runner一時ファイルを削除できませんでした: ' + $_.Exception.Message) }
    Release-GuiProjectSyncLock
    $script:process = $null
    $script:guiOutputPath = $null
    $script:guiRunnerPath = $null
    $script:lastOutputLength = 0
}

function Get-SelectedProject {
    if ($cmbProject.SelectedItem -eq $null) {
        Show-GuiMessage 'プロジェクトを選択してください。' '確認'
        return $null
    }
    return [string]$cmbProject.SelectedItem
}

function New-DangerousOperationMessage([string]$Operation, [string]$ChangeTarget, [switch]$RollbackWarning) {
    $selected = Get-SelectedProject
    if ($null -eq $selected) { return $null }
    $projectName = $selected
    $targetName = '<不明>'
    if ($null -ne $script:selectedProjectInfo -and $script:selectedProjectInfo.Selection -eq $selected) {
        $projectName = [string]$script:selectedProjectInfo.ProjectName
        if (-not [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.TargetName) -and $script:selectedProjectInfo.TargetName -ne '-') {
            $targetName = [string]$script:selectedProjectInfo.TargetName
        }
    }
    $lines = New-Object 'System.Collections.Generic.List[string]'
    $lines.Add('選択中プロジェクト名：' + $projectName)
    $lines.Add('対象ブック名：' + $targetName)
    $lines.Add('実行する操作：' + $Operation)
    $lines.Add('変更される対象：' + $ChangeTarget)
    if ($RollbackWarning) {
        $lines.Add('')
        $lines.Add('対象ブックが復元ポイント作成時の状態へ戻ります。現在のブック内容は上書きされる可能性があります。')
    }
    $lines.Add('')
    $lines.Add('この操作を実行しますか？')
    return $lines -join [Environment]::NewLine
}

function New-BookUpdateConfirmationMessage {
    $selected = Get-SelectedProject
    if ($null -eq $selected) { return $null }
    $projectName = $selected
    $targetName = '<不明>'
    if ($null -ne $script:selectedProjectInfo -and $script:selectedProjectInfo.Selection -eq $selected) {
        $projectName = [string]$script:selectedProjectInfo.ProjectName
        if (-not [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.TargetName) -and
            [string]$script:selectedProjectInfo.TargetName -ne '-') {
            $targetName = [string]$script:selectedProjectInfo.TargetName
        }
    }
    return @(
        'ブック更新の確認',
        '',
        'プロジェクト：' + $projectName,
        '対象ブック：' + $targetName,
        '',
        '次の処理を行います。',
        '',
        '・更新前の安全確認',
        '・復元ポイントの作成',
        '・最新版との差分確認',
        '・必要な部分だけを更新',
        '・更新後の確認',
        '・更新履歴の記録',
        '',
        'ブックを更新しますか？'
    ) -join [Environment]::NewLine
}


function Get-GuiProjectSyncLockPath {
    if ($null -eq $script:selectedProjectInfo -or [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.TargetPath)) {
        return $null
    }
    $normalized = [System.IO.Path]::GetFullPath([string]$script:selectedProjectInfo.TargetPath).ToLowerInvariant()
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($normalized)
        $hash = [System.BitConverter]::ToString($sha.ComputeHash($bytes)).Replace('-','').ToLowerInvariant()
    }
    finally { $sha.Dispose() }
    return Join-Path (Get-GuiLogDirectory) ('project-sync-' + $hash.Substring(0,16) + '.lock')
}

function Release-GuiProjectSyncLock {
    if ($null -ne $script:projectSyncLockStream) {
        try { $script:projectSyncLockStream.Dispose() } catch { Write-Verbose ('更新ロックを解放できませんでした: ' + $_.Exception.Message) }
    }
    if (-not [string]::IsNullOrWhiteSpace([string]$script:projectSyncLockPath)) {
        try { Remove-Item -LiteralPath $script:projectSyncLockPath -Force -ErrorAction SilentlyContinue } catch { Write-Verbose ('更新ロックファイルを削除できませんでした: ' + $_.Exception.Message) }
    }
    $script:projectSyncLockStream = $null
    $script:projectSyncLockPath = $null
}

function Try-AcquireGuiProjectSyncLock {
    Release-GuiProjectSyncLock
    $lockPath = Get-GuiProjectSyncLockPath
    if ([string]::IsNullOrWhiteSpace([string]$lockPath)) { return $false }
    try {
        $stream = New-Object System.IO.FileStream(
            $lockPath,
            [System.IO.FileMode]::OpenOrCreate,
            [System.IO.FileAccess]::ReadWrite,
            [System.IO.FileShare]::None)
        $payload = [System.Text.Encoding]::UTF8.GetBytes(('PID={0}; StartedAt={1:O}; Target={2}' -f $PID,[DateTime]::Now,[string]$script:selectedProjectInfo.TargetPath))
        $stream.SetLength(0)
        $stream.Write($payload,0,$payload.Length)
        $stream.Flush()
        $script:projectSyncLockStream = $stream
        $script:projectSyncLockPath = $lockPath
        return $true
    }
    catch {
        Append-Log ('[GUI] 同じ対象ブックの更新ロックを取得できませんでした: ' + $_.Exception.Message)
        return $false
    }
}

function Test-WorkbookExclusiveWriteAccess([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path) -or -not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    $stream = $null
    try {
        $stream = New-Object System.IO.FileStream(
            $Path,
            [System.IO.FileMode]::Open,
            [System.IO.FileAccess]::ReadWrite,
            [System.IO.FileShare]::None)
        return $true
    }
    catch { return $false }
    finally { if ($null -ne $stream) { $stream.Dispose() } }
}

function Confirm-GuiProjectSyncPreflight {
    if ($null -eq $script:selectedProjectInfo) {
        Show-GuiMessage '更新対象プロジェクトの情報を確認できません。プロジェクトを選び直してください。' 'ブック更新前の確認' ([System.Windows.Forms.MessageBoxIcon]::Warning)
        return $false
    }
    $targetPath = [string]$script:selectedProjectInfo.TargetPath
    if ([string]::IsNullOrWhiteSpace($targetPath) -or $targetPath -eq '-' -or -not (Test-Path -LiteralPath $targetPath -PathType Leaf)) {
        Show-GuiMessage '対象ブックが見つかりません。「詳細情報」で登録先を確認してください。' 'ブック更新前の確認' ([System.Windows.Forms.MessageBoxIcon]::Warning)
        return $false
    }
    if (-not (Test-WorkbookExclusiveWriteAccess -Path $targetPath)) {
        Show-GuiMessage ('更新対象のExcelブックが開かれているか、ほかの処理で使用されています。' + [Environment]::NewLine + [Environment]::NewLine + '対象ブックを閉じてから、もう一度「ブックを更新する」を実行してください。' + [Environment]::NewLine + [Environment]::NewLine + '対象ブック：' + [System.IO.Path]::GetFileName($targetPath)) '対象ブックが使用中です' ([System.Windows.Forms.MessageBoxIcon]::Warning)
        Append-Log ('[GUI] 更新前確認で対象ブックの排他書き込み確認に失敗しました: ' + $targetPath)
        return $false
    }
    if (-not (Try-AcquireGuiProjectSyncLock)) {
        Show-GuiMessage ('同じ対象ブックの更新処理がすでに実行中の可能性があります。' + [Environment]::NewLine + [Environment]::NewLine + '実行中の更新が完了してから、もう一度「ブックを更新する」を実行してください。') 'ブック更新前の確認' ([System.Windows.Forms.MessageBoxIcon]::Warning)
        return $false
    }
    Append-Log ('[GUI] 更新前安全確認OK: 対象ブックは閉じられており、更新ロックを取得しました。')
    return $true
}

function Get-FriendlyProjectSyncResultMessage {
    param(
        [string]$ResultStatus,
        [string]$OutputText,
        [string]$TargetName
    )
    if ([string]::IsNullOrWhiteSpace($TargetName)) { $TargetName = '<不明>' }
    if ($ResultStatus -eq '処理成功') {
        return @('ブックの更新が完了しました。','','対象ブック：' + $TargetName,'','「対象ブックを開く」から更新結果を確認できます。') -join [Environment]::NewLine
    }
    if ($ResultStatus -eq '警告付き成功') {
        return @('ブックの更新は完了しましたが、確認事項があります。','','対象ブック：' + $TargetName,'','「ログを見る」で詳細を確認してください。') -join [Environment]::NewLine
    }

    $action = '「ログを見る」で詳細を確認してください。対象ブックは更新完了扱いにしていません。'
    if (-not [string]::IsNullOrWhiteSpace($OutputText)) {
        if ($OutputText -match '(?i)(excel.+使用中|workbook.+open|file.+used by another process|sharing violation|ロック|開かれている)') {
            $action = '対象ブックがExcelなどで開かれている可能性があります。対象ブックを閉じてから、もう一度「ブックを更新する」を実行してください。'
        }
        elseif ($OutputText -match '(?i)(project\.json.+(not found|見つか)|source.+(not found|見つか)|target.+(not found|見つか))') {
            $action = 'プロジェクトの構成ファイルまたは更新対象が見つかりません。「詳細情報」で登録先を確認し、必要に応じて「詳細設定」から登録先を修正してください。'
        }
        elseif ($OutputText -match '(?i)(access.+denied|unauthorized|permission|アクセス.+拒否|権限)') {
            $action = 'ファイルまたはフォルダーへのアクセス権限を確認してください。解決しない場合は「ログを見る」で失敗箇所を確認してください。'
        }
        elseif ($OutputText -match '(?i)(compile|コンパイル)') {
            $action = '更新後のVBA検証で問題が見つかった可能性があります。対象ブックは更新完了扱いにしていません。「ログを見る」で検証結果を確認してください。'
        }
    }
    $recovery = '更新処理がブック変更開始後に失敗した場合は、「直前の状態に戻す」から更新前の復元ポイントへ戻せます。'
    return @('ブックを更新できませんでした。','','対象ブック：' + $TargetName,'',$action,'',$recovery) -join [Environment]::NewLine
}

function Get-FriendlyRollbackResultMessage {
    param(
        [string]$ResultStatus,
        [string]$TargetName
    )
    if ([string]::IsNullOrWhiteSpace($TargetName)) { $TargetName = '<不明>' }
    if ($ResultStatus -eq '処理成功') {
        return @(
            '直前の状態への復元が完了しました。',
            '',
            '対象ブック：' + $TargetName,
            '',
            '復元前にも安全バックアップを自動作成しています。',
            '必要であれば、もう一度「ブックを更新する」を実行できます。'
        ) -join [Environment]::NewLine
    }
    if ($ResultStatus -eq '警告付き成功') {
        return @(
            '復元処理は完了しましたが、確認事項があります。',
            '',
            '対象ブック：' + $TargetName,
            '',
            '「ログを見る」で詳細を確認してください。'
        ) -join [Environment]::NewLine
    }
    return @(
        '直前の状態へ戻せませんでした。',
        '',
        '対象ブック：' + $TargetName,
        '',
        '現在のブックをこれ以上変更せず、「ログを見る」で詳細を確認してください。'
    ) -join [Environment]::NewLine
}

function Start-CliCommand {
    param(
        [Parameter(Mandatory=$true)][string]$Command,
        [string[]]$Arguments = @(),
        [string]$ConfirmMessage
    )

    if ($script:busy) { return }
    if (-not [string]::IsNullOrWhiteSpace($ConfirmMessage)) {
        $answer = [System.Windows.Forms.MessageBox]::Show(
            $ConfirmMessage,
            '実行確認',
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Warning)
        if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
            Append-Log '[GUI] 操作をキャンセルしました。'
            return
        }
    }
    # project-sync の更新前安全確認は Invoke-ProjectCommand 側で、
    # 対象ブックのハッシュ再確認より前に一度だけ実行する。

    Append-Log ''
    Append-Log ('> .\vba.cmd ' + $Command + $(if ($Arguments.Count -gt 0) { ' ' + ($Arguments -join ' ') } else { '' }))
    Set-Busy $true $Command

    try {
        $runId = [DateTime]::Now.ToString('yyyyMMdd_HHmmss_fff')
        $guiLogDir = Get-GuiLogDirectory
        $outputPath = Join-Path $guiLogDir ('gui_' + $runId + '.log')
        $runnerPath = Join-Path $guiLogDir ('gui_' + $runId + '.ps1')
        $script:guiOutputPath = $outputPath
        $script:guiRunnerPath = $runnerPath
        $script:lastOutputLength = 0
        $allArgs = @($Command) + @($Arguments)
        $runner = New-CliRunnerContent -CliScriptPath $cliPath -CliArguments ([string[]]$allArgs) -OutputPath $outputPath
        [System.IO.File]::WriteAllText($runnerPath, $runner, (New-Object System.Text.UTF8Encoding($true)))

        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = 'powershell.exe'
        $psi.Arguments = '-NoProfile -ExecutionPolicy Bypass -File ' + (Quote-ProcessArgument $runnerPath)
        $psi.WorkingDirectory = $root
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true

        $process = New-Object System.Diagnostics.Process
        $process.StartInfo = $psi
        $script:process = $process
        [void]$process.Start()
        $script:pollTimer.Start()
    }
    catch {
        Append-Log ('[GUI] 起動準備または起動に失敗しました: ' + $_.Exception.Message)
        $failedCommand = $script:currentCommand
        $failedStartedAt = $script:commandStartedAt
        $failedAt = [DateTime]::Now
        Clear-CliRuntime $true
        Set-Busy $false
        $failedElapsed = if ($null -ne $failedStartedAt) { $failedAt - [DateTime]$failedStartedAt } else { [TimeSpan]::Zero }
        Set-OperationResult -Command $failedCommand -ResultStatus '処理失敗' -CompletedAt $failedAt -Elapsed $failedElapsed
        if ($failedCommand -eq 'project-create') {
            $script:pendingCreatedProject = $null
            $script:pendingCreatedWorkbook = $null
        }
    }
}

$script:pollTimer.Add_Tick({
    try {
        Update-ElapsedDisplay
        Copy-NewCliOutputToLog
        if ($null -eq $script:process -or -not $script:process.HasExited) { return }

        $exitCode = $null
        $resultStatus = '処理失敗'
        $completedOutput = ''
        $completedCommand = $script:currentCommand
        $completedStartedAt = $script:commandStartedAt
        try {
            $script:pollTimer.Stop()
            $script:process.WaitForExit()
            Copy-NewCliOutputToLog $true
            $exitCode = $script:process.ExitCode
            if (-not [string]::IsNullOrWhiteSpace($script:guiOutputPath) -and (Test-Path -LiteralPath $script:guiOutputPath -PathType Leaf)) {
                $completedOutput = [System.IO.File]::ReadAllText($script:guiOutputPath, [System.Text.Encoding]::UTF8)
            }
            if ($exitCode -eq 0) {
                Append-Log '[GUI] コマンドは正常終了しました。'
                $resultStatus = '処理成功'
                if ($completedOutput.IndexOf('[WARNING]', [System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
                    $resultStatus = '警告付き成功'
                    Append-Log '[GUI] ブック更新は完了しましたが、確認事項があります。詳細ログを確認してください。'
                }
            }
            else {
                Append-Log ('[GUI] コマンドが失敗しました。ExitCode=' + $exitCode)
                $resultStatus = '処理失敗'
            }
        }
        catch {
            Append-Log ('[GUI] 結果取得に失敗しました: ' + $_.Exception.Message)
            $resultStatus = '処理失敗'
        }
        finally {
            $completedAt = [DateTime]::Now
            $completedElapsed = if ($null -ne $completedStartedAt) { $completedAt - [DateTime]$completedStartedAt } else { [TimeSpan]::Zero }
            $completedProject = $script:pendingCreatedProject
            $completedWorkbook = $script:pendingCreatedWorkbook
            $previousRootProject = $script:projectRootPreviousSelection
            Clear-CliRuntime $false
            Set-Busy $false
            try {
                if ($completedCommand -eq 'project-create' -and $resultStatus -in @('処理成功','警告付き成功') -and -not [string]::IsNullOrWhiteSpace($completedProject)) {
                    Select-RegisteredProject -ProjectName $completedProject
                }
                elseif ($completedCommand -in @('project-root-set','project-root-reset') -and $resultStatus -in @('処理成功','警告付き成功')) {
                    Refresh-ProjectRootAndProjects -PreferredProject $previousRootProject -StrictSelection
                }
                else {
                    Update-ProjectInformation -PreserveStatus
                }
            }
            catch { Append-Log ('[GUI] 作成後のプロジェクト再読込に失敗しました: ' + $_.Exception.Message) }
            Set-OperationResult -Command $completedCommand -ResultStatus $resultStatus -CompletedAt $completedAt -Elapsed $completedElapsed
            if ($completedCommand -eq 'project-sync') {
                $syncOutput = [string]$completedOutput
                $syncTarget = if ($null -ne $script:selectedProjectInfo) { [string]$script:selectedProjectInfo.TargetName } else { '<不明>' }
                $syncMessage = Get-FriendlyProjectSyncResultMessage -ResultStatus $resultStatus -OutputText $syncOutput -TargetName $syncTarget
                $syncIcon = if ($resultStatus -eq '処理失敗') { [System.Windows.Forms.MessageBoxIcon]::Error } elseif ($resultStatus -eq '警告付き成功') { [System.Windows.Forms.MessageBoxIcon]::Warning } else { [System.Windows.Forms.MessageBoxIcon]::Information }
                Show-GuiMessage $syncMessage 'ブック更新結果' $syncIcon
            }
            if ($completedCommand -eq 'rollback') {
                $rollbackTarget = if ($null -ne $script:selectedProjectInfo) { [string]$script:selectedProjectInfo.TargetName } else { '<不明>' }
                $rollbackMessage = Get-FriendlyRollbackResultMessage -ResultStatus $resultStatus -TargetName $rollbackTarget
                $rollbackIcon = if ($resultStatus -eq '処理失敗') { [System.Windows.Forms.MessageBoxIcon]::Error } elseif ($resultStatus -eq '警告付き成功') { [System.Windows.Forms.MessageBoxIcon]::Warning } else { [System.Windows.Forms.MessageBoxIcon]::Information }
                Show-GuiMessage $rollbackMessage '復元結果' $rollbackIcon
            }
            if ($completedCommand -eq 'project-create') {
                if ($resultStatus -in @('処理成功','警告付き成功')) {
                    Show-GuiMessage ("開発プロジェクトの登録が完了しました。`r`n`r`nプロジェクト：{0}`r`n対象ブック：{1}`r`n`r`nExcelブックを登録し、初期ソースを作成しました。" -f $completedProject,$completedWorkbook) '開発プロジェクトを登録'
                }
                else {
                    Show-GuiMessage '開発プロジェクトを登録できませんでした。詳細ログでエラーとクリーンアップ結果を確認してください。元のExcelブックと既存の開発ファイルは変更していません。' '開発プロジェクトを登録' ([System.Windows.Forms.MessageBoxIcon]::Error)
                }
                $script:pendingCreatedProject = $null
                $script:pendingCreatedWorkbook = $null
            }
            if ($completedCommand -in @('project-root-set','project-root-reset')) {
                $script:projectRootPreviousSelection = $null
            }
        }
    }
    catch {
        Append-Log ('[GUI] 実行監視に失敗しました: ' + $_.Exception.Message)
        $failedCommand = $script:currentCommand
        $failedStartedAt = $script:commandStartedAt
        $failedAt = [DateTime]::Now
        Clear-CliRuntime $true
        Set-Busy $false
        $failedElapsed = if ($null -ne $failedStartedAt) { $failedAt - [DateTime]$failedStartedAt } else { [TimeSpan]::Zero }
        Set-OperationResult -Command $failedCommand -ResultStatus '処理失敗' -CompletedAt $failedAt -Elapsed $failedElapsed
    }
})

function Add-OperationButton([System.Windows.Forms.Control]$Parent, [string]$Text, [scriptblock]$OnClick, [int]$Width = 150) {
    $button = New-Object System.Windows.Forms.Button
    $button.Text = $Text
    $button.Size = New-Object System.Drawing.Size($Width, 40)
    $button.MinimumSize = New-Object System.Drawing.Size($Width, 40)
    $button.AutoEllipsis = $false
    $button.UseCompatibleTextRendering = $true
    $button.TextAlign = 'MiddleCenter'
    $button.Margin = New-Object System.Windows.Forms.Padding(4)
    $handler = {
        try { & $OnClick }
        catch {
            Append-Log ('[GUI] 操作に失敗しました: ' + $_.Exception.Message)
            Show-GuiMessage $_.Exception.Message 'GUI操作エラー' ([System.Windows.Forms.MessageBoxIcon]::Error)
        }
    }.GetNewClosure()
    $button.Add_Click($handler)
    $Parent.Controls.Add($button)
    $operationButtons.Add($button)
    return $button
}

function Set-VBAUpdaterSafetyGateCancelledResult {
    param(
        [Parameter(Mandatory=$true)][string]$Command,
        [Parameter(Mandatory=$true)][string]$OperationName
    )
    # This is a pre-execution cancellation, not a completed CLI operation.
    # Do not call Set-OperationResult because no CompletedAt / Elapsed exists yet.
    Set-CurrentStatus '操作中止'
    $lblCommandCaption.Text='操作情報'
    $lblCommandValue.Text='実行されませんでした'
    $lblElapsedValue.Text='処理時間：00:00:00'
    $lblInfoMessageValue.Text=($OperationName + 'はSafety Gateにより開始されませんでした。対象ブック・Sourceは変更していません。')
    Append-Log ('[GUI] Safety Gate: ' + $OperationName + 'を処理開始前に中止しました。Command=' + $Command)
}

function Invoke-ProjectCommand([string]$Command, [string[]]$Extra = @(), [string]$ConfirmMessage) {
    $selected = Get-SelectedProject
    if ($null -eq $selected) { return }

    # Chapter5-2_04 HotFix1:
    # Central safety gate. All GUI entry points (Home and Developer) ultimately pass here,
    # so dangerous commands cannot bypass READY / REVIEW / BLOCK enforcement.
    $dangerousCommands=@('project-sync','project-push','rollback')
    if($dangerousCommands -contains $Command){
        $operationName=Get-VBAUpdaterDangerousOperationName -Command $Command
        if(-not (Confirm-VBAUpdaterDangerousOperationSafety -Command $Command -OperationName $operationName)){
            Set-VBAUpdaterSafetyGateCancelledResult -Command $Command -OperationName $operationName
            return
        }
    }

    # Chapter3-7_03:
    # project-sync は SHA-256 再確認より先に排他アクセス確認を行う。
    # Excelで開いているブックに Get-FileHash が触れて生のIOExceptionを出すのを防ぎ、
    # 利用者向けの「対象ブックが使用中です」案内で安全に停止する。
    if ($Command -eq 'project-sync') {
        if (-not (Confirm-GuiProjectSyncPreflight)) { return }
    }

    if ($Command -in @('project-push','project-pull','project-sync','rollback','codex-import','workbook-apply')) {
        Assert-GuiProjectSelectionSafe -Command $Command
    }
    $arguments = @('-Project', $selected)
    if ($null -ne $script:selectedProjectInfo -and -not [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.ProjectRoot)) {
        $arguments += @('-ProjectRoot',[string]$script:selectedProjectInfo.ProjectRoot)
        if (-not [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.TargetPath) -and [string]$script:selectedProjectInfo.TargetPath -ne '-') {
            $arguments += @('-WorkbookPath',[string]$script:selectedProjectInfo.TargetPath)
        }
    }
    $arguments += $Extra
    Start-CliCommand -Command $Command -Arguments $arguments -ConfirmMessage $ConfirmMessage
}



function Get-VBAUpdaterSafetyGateAssessmentForGui {
    $snapshot=Get-GuiOperationalSafetySnapshot
    $assessment=Get-VBAUpdaterOperationalRetryAssessment -Snapshot $snapshot

    switch([string]$script:SafetyGateTestMode){
        'READY' {
            $assessment=[PSCustomObject]@{
                AssessedAt=(Get-Date).ToString('o'); Status='READY'
                Message='Safety Gate Test ModeによりREADYを模擬しています。実環境の診断結果は変更していません。'
                ErrorCount=0; WarningCount=0; IsTestMode=$true
            }
        }
        'REVIEW' {
            $snapshot=[PSCustomObject]@{
                Overall='TEST_REVIEW'; Ok=@()
                Warnings=@('Safety Gate Test Mode: REVIEW模擬警告です。実環境の障害ではありません。')
                Errors=@()
            }
            $assessment=[PSCustomObject]@{
                AssessedAt=(Get-Date).ToString('o'); Status='REVIEW'
                Message='Safety Gate Test ModeによりREVIEWを模擬しています。'
                ErrorCount=0; WarningCount=1; IsTestMode=$true
            }
        }
        'BLOCK' {
            $snapshot=[PSCustomObject]@{
                Overall='TEST_BLOCK'; Ok=@(); Warnings=@()
                Errors=@('Safety Gate Test Mode: BLOCK模擬エラーです。実環境の障害ではありません。')
            }
            $assessment=[PSCustomObject]@{
                AssessedAt=(Get-Date).ToString('o'); Status='BLOCK'
                Message='Safety Gate Test ModeによりBLOCKを模擬しています。'
                ErrorCount=1; WarningCount=0; IsTestMode=$true
            }
        }
    }

    return [PSCustomObject]@{
        Snapshot=$snapshot
        Assessment=$assessment
        TestMode=[string]$script:SafetyGateTestMode
    }
}

function Show-VBAUpdaterSafetyGateTestDialog {
    $dialog=New-Object System.Windows.Forms.Form
    $dialog.Text='Safety Gate テスト'
    $dialog.StartPosition='CenterParent'
    $dialog.FormBorderStyle='FixedDialog'
    $dialog.MaximizeBox=$false
    $dialog.MinimizeBox=$false
    $dialog.ClientSize=New-Object System.Drawing.Size(520,260)
    $dialog.Font=$form.Font

    $label=New-Object System.Windows.Forms.Label
    $label.Text='実環境を変更せず、危険操作入口のSafety Gate判定だけを模擬します。'
    $label.Location=New-Object System.Drawing.Point(20,20)
    $label.Size=New-Object System.Drawing.Size(470,42)
    $dialog.Controls.Add($label)

    $current=New-Object System.Windows.Forms.Label
    $current.Text=('現在: '+[string]$script:SafetyGateTestMode)
    $current.Location=New-Object System.Drawing.Point(20,68)
    $current.Size=New-Object System.Drawing.Size(470,25)
    $dialog.Controls.Add($current)

    $x=20
    foreach($mode in @('OFF','READY','REVIEW','BLOCK')){
        $b=New-Object System.Windows.Forms.Button
        $b.Text=$mode
        $b.Size=New-Object System.Drawing.Size(105,36)
        $b.Location=New-Object System.Drawing.Point($x,105)
        $b.Add_Click({
            $script:SafetyGateTestMode=[string]$this.Text
            $current.Text=('現在: '+[string]$script:SafetyGateTestMode)
        })
        $dialog.Controls.Add($b)
        $x+=115
    }

    $note=New-Object System.Windows.Forms.Label
    $note.Text='REVIEWではNoを選べば更新処理は開始されません。BLOCKでは必ず処理開始前に停止します。テストモードは保存されず、再起動するとOFFへ戻ります。'
    $note.Location=New-Object System.Drawing.Point(20,155)
    $note.Size=New-Object System.Drawing.Size(470,55)
    $dialog.Controls.Add($note)

    $close=New-Object System.Windows.Forms.Button
    $close.Text='閉じる'
    $close.Size=New-Object System.Drawing.Size(100,32)
    $close.Location=New-Object System.Drawing.Point(390,215)
    $close.Add_Click({$dialog.Close()})
    $dialog.Controls.Add($close)

    [void]$dialog.ShowDialog($form)
    $dialog.Dispose()
}

function Confirm-VBAUpdaterDangerousOperationSafety {
    param(
        [Parameter(Mandatory=$true)][string]$Command,
        [string]$OperationName='危険操作'
    )

    try {
        $gateContext=Get-VBAUpdaterSafetyGateAssessmentForGui
        $snapshot=$gateContext.Snapshot
        $assessment=$gateContext.Assessment
    } catch {
        Show-GuiMessage ('安全診断を実行できないため、操作を開始できません。' + [Environment]::NewLine + $_.Exception.Message) 'VBAUpdater 安全確認'
        return $false
    }

    switch([string]$assessment.Status){
        'READY' { return $true }
        'BLOCK' {
            $lines=New-Object 'System.Collections.Generic.List[string]'
            [void]$lines.Add($OperationName + 'を開始できません。')
            [void]$lines.Add('')
            [void]$lines.Add([string]$assessment.Message)
            if(@($snapshot.Errors).Count -gt 0){
                [void]$lines.Add('')
                [void]$lines.Add('[エラー]')
                foreach($item in @($snapshot.Errors)){[void]$lines.Add(('・'+[string]$item))}
            }
            [void]$lines.Add('')
            [void]$lines.Add('「環境チェック」「ログを見る」「診断情報を保存」を利用して原因を確認してください。')
            Show-GuiMessage ($lines -join [Environment]::NewLine) 'VBAUpdater 安全確認'
            return $false
        }
        'REVIEW' {
            $lines=New-Object 'System.Collections.Generic.List[string]'
            [void]$lines.Add($OperationName + 'の前に確認が必要です。')
            [void]$lines.Add('')
            [void]$lines.Add([string]$assessment.Message)
            if(@($snapshot.Warnings).Count -gt 0){
                [void]$lines.Add('')
                [void]$lines.Add('[注意]')
                foreach($item in @($snapshot.Warnings)){[void]$lines.Add(('・'+[string]$item))}
            }
            [void]$lines.Add('')
            [void]$lines.Add('内容を確認したうえで続行しますか？')
            $result=[System.Windows.Forms.MessageBox]::Show(
                $form,
                ($lines -join [Environment]::NewLine),
                'VBAUpdater 安全確認',
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Warning,
                [System.Windows.Forms.MessageBoxDefaultButton]::Button2
            )
            return ($result -eq [System.Windows.Forms.DialogResult]::Yes)
        }
        default {
            Show-GuiMessage ('安全診断結果を判定できないため、操作を開始できません。Status=' + [string]$assessment.Status) 'VBAUpdater 安全確認'
            return $false
        }
    }
}

function Get-VBAUpdaterDangerousOperationName {
    param([string]$Command)
    switch($Command){
        'project-sync' { return 'ブック更新' }
        'project-push' { return 'ソースをブックへ反映' }
        'rollback' { return '復元' }
        default { return '危険操作' }
    }
}

function Invoke-DangerousProjectCommand {
    param(
        [string]$Command,
        [string]$Operation,
        [string]$ChangeTarget,
        [string[]]$Extra = @(),
        [switch]$RollbackWarning
    )

    $message = New-DangerousOperationMessage -Operation $Operation -ChangeTarget $ChangeTarget -RollbackWarning:$RollbackWarning
    if ($null -eq $message) { return }
    Invoke-ProjectCommand -Command $Command -Extra $Extra -ConfirmMessage $message
}

function Invoke-ProjectRootSettingCliSynchronously {
    param([Parameter(Mandatory=$true)][string]$Command,[string[]]$Arguments=@())
    $cliArguments = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$cliPath,$Command) + @($Arguments) + @(Get-GuiTestPropagationArguments)
    Append-Log ('> .\vba.cmd ' + $Command + $(if ($Arguments.Count -gt 0) { ' ' + ($Arguments -join ' ') } else { '' }))
    $outputLines = @(& powershell.exe @cliArguments 2>&1)
    $exitCode = $LASTEXITCODE
    foreach ($line in $outputLines) { Append-Log ([string]$line) }
    if ($exitCode -ne 0) { throw "保存先設定コマンドに失敗しました。Command=$Command ExitCode=$exitCode" }
}

function Select-ProjectRootMigrationCandidate {
    $picker = New-Object System.Windows.Forms.FolderBrowserDialog
    $picker.Description = 'プロジェクトの保存先フォルダーを選択してください。'
    $picker.ShowNewFolderButton = $true
    if ($null -ne $script:projectRootInfo -and [bool]$script:projectRootInfo.Exists) {
        $picker.SelectedPath = [string]$script:projectRootInfo.Path
    }
    try {
        if ($picker.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { return $null }
        $check = Get-ProjectRootCheckFromCli -Path ([string]$picker.SelectedPath)
        if ([string]$check.Status -ne 'OK') {
            Show-GuiMessage ("選択した保存先を使用できません。`r`n`r`n保存先：{0}`r`n状態：{1}`r`n詳細：{2}" -f $check.Path,$check.Status,$check.Message) 'プロジェクト保存先' ([System.Windows.Forms.MessageBoxIcon]::Error)
            return $null
        }

        $names = @($check.ProjectNames)
        $detectionText = if ([int]$check.Projects -eq 0) {
            @(
                'プロジェクトは見つかりませんでした。',
                '登録済みプロジェクトはありませんが、Project Rootとして使用できます。'
            ) -join [Environment]::NewLine
        }
        else {
            $displayNames = @($names | Select-Object -First 20)
            $moreText = if ($names.Count -gt 20) { [Environment]::NewLine + ("ほか{0}件" -f ($names.Count-20)) } else { '' }
            (("{0}件のプロジェクトが見つかりました。" -f [int]$check.Projects) + [Environment]::NewLine + [Environment]::NewLine + ($displayNames -join [Environment]::NewLine) + $moreText)
        }
        $currentPath = if ($null -ne $script:projectRootInfo) { [string]$script:projectRootInfo.Path } else { '-' }
        $message = @(
            'プロジェクト保存先を変更します。',
            '',
            '変更前：' + $currentPath,
            '変更後：' + [string]$check.Path,
            '',
            $detectionText,
            '',
            '既存プロジェクトは自動移動・コピー・削除されません。',
            '',
            'この保存先を使用しますか？'
        ) -join [Environment]::NewLine
        $answer = [System.Windows.Forms.MessageBox]::Show($message,'プロジェクト保存先の確認',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question)
        if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { return $null }
        return $check
    }
    finally { $picker.Dispose() }
}

function Show-MissingProjectRootRecoveryDialog {
    param([Parameter(Mandatory=$true)][string]$CurrentPath)
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = 'プロジェクト保存先が見つかりません'
    $dialog.StartPosition = 'CenterScreen'
    $dialog.Size = New-Object System.Drawing.Size(680,330)
    $dialog.MinimumSize = New-Object System.Drawing.Size(620,300)
    $dialog.Font = $form.Font
    $dialog.FormBorderStyle = 'FixedDialog'
    $dialog.MaximizeBox = $false
    $dialog.MinimizeBox = $false
    $dialog.Tag = 'Exit'

    $layout = New-Object System.Windows.Forms.TableLayoutPanel
    $layout.Dock = 'Fill'
    $layout.Padding = New-Object System.Windows.Forms.Padding(20)
    $layout.RowCount = 4
    $layout.ColumnCount = 1
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute',55)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute',78)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent',100)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute',58)))
    $dialog.Controls.Add($layout)

    $heading = New-Object System.Windows.Forms.Label
    $heading.Text = 'プロジェクト保存先が見つかりません。'
    $heading.Font = New-Object System.Drawing.Font('Yu Gothic UI',13,[System.Drawing.FontStyle]::Bold)
    $heading.Dock = 'Fill'
    $heading.TextAlign = 'MiddleLeft'
    $layout.Controls.Add($heading,0,0)

    $pathText = New-Object System.Windows.Forms.TextBox
    $pathText.Multiline = $true
    $pathText.ReadOnly = $true
    $pathText.Dock = 'Fill'
    $pathText.Text = "現在の設定`r`n$CurrentPath"
    $layout.Controls.Add($pathText,0,1)

    $message = New-Object System.Windows.Forms.Label
    $message.Text = 'このフォルダーは存在しません。保存先を変更してください。'
    $message.Dock = 'Fill'
    $message.TextAlign = 'MiddleLeft'
    $message.ForeColor = [System.Drawing.Color]::DarkRed
    $layout.Controls.Add($message,0,2)

    $buttons = New-Object System.Windows.Forms.FlowLayoutPanel
    $buttons.Dock = 'Fill'
    $buttons.FlowDirection = 'RightToLeft'
    $buttons.WrapContents = $false
    $layout.Controls.Add($buttons,0,3)
    foreach ($definition in @(
        [PSCustomObject]@{ Text='終了'; Choice='Exit'; Width=100 },
        [PSCustomObject]@{ Text='既定へ戻す'; Choice='Reset'; Width=130 },
        [PSCustomObject]@{ Text='保存先を変更'; Choice='Change'; Width=150 }
    )) {
        $button = New-Object System.Windows.Forms.Button
        $button.Text = $definition.Text
        $button.Size = New-Object System.Drawing.Size($definition.Width,38)
        $choice = [string]$definition.Choice
        $button.Add_Click({ $dialog.Tag=$choice; $dialog.DialogResult=[System.Windows.Forms.DialogResult]::OK; $dialog.Close() }.GetNewClosure())
        $buttons.Controls.Add($button)
    }
    [void]$dialog.ShowDialog()
    $result = [string]$dialog.Tag
    $dialog.Dispose()
    return $result
}

function Invoke-ProjectRootStartupRecovery {
    while ($null -ne $script:projectRootInfo -and [bool]$script:projectRootInfo.RecoveryRequired) {
        $missingPath=if($script:projectRootInfo.PSObject.Properties['LastProjectRoot'] -and -not [string]::IsNullOrWhiteSpace([string]$script:projectRootInfo.LastProjectRoot) -and -not [bool]$script:projectRootInfo.LastProjectExists){[string]$script:projectRootInfo.LastProjectRoot}else{[string]$script:projectRootInfo.Path}
        $choice = Show-MissingProjectRootRecoveryDialog -CurrentPath $missingPath
        switch ($choice) {
            'Change' {
                if ($script:projectRootInfo.PSObject.Properties['LastProjectRoot'] -and -not [string]::IsNullOrWhiteSpace([string]$script:projectRootInfo.LastProjectRoot)) {
                    if (Show-DirectProjectFolderOpenDialog) { return $true }
                    continue
                }
                $candidate = Select-ProjectRootMigrationCandidate
                if ($null -eq $candidate) { continue }
                try {
                    Invoke-ProjectRootSettingCliSynchronously -Command 'project-root-set' -Arguments @('-Path',[string]$candidate.Path)
                    Refresh-ProjectRootAndProjects
                    $script:startupFailure = $null
                    return $true
                }
                catch { Show-GuiMessage $_.Exception.Message '保存先を変更できません' ([System.Windows.Forms.MessageBoxIcon]::Error) }
            }
            'Reset' {
                try {
                    Invoke-ProjectRootSettingCliSynchronously -Command 'project-root-reset'
                    Refresh-ProjectRootAndProjects
                    $script:startupFailure = $null
                    return $true
                }
                catch { Show-GuiMessage $_.Exception.Message '既定へ戻せません' ([System.Windows.Forms.MessageBoxIcon]::Error) }
            }
            default { return $false }
        }
    }
    return $true
}

function Invoke-LegacyProjectMigrationWizard {
    $check = Get-LegacyProjectMigrationCheckFromCli
    if (-not [bool]$check.RequiresMigration) { return $true }
    $names = @($check.ProjectNames)
    $displayNames = @($names | Select-Object -First 20)
    $more = if ($names.Count -gt 20) { "`r`nほか$($names.Count - 20)件" } else { '' }
    $message = @(
        'Ver4.17以前のVBAUpdater専用プロジェクトを検出しました。',
        '',
        '移行元：' + [string]$check.SourceRoot,
        '対象：' + [string]$check.Projects + '件',
        ($displayNames -join [Environment]::NewLine) + $more,
        '',
        'GitHub・VBAUpdaterで共有するDevelopmentフォルダーへ安全にコピーします。',
        '移行後に必須ファイルを検証し、移行元は削除しません。',
        '',
        '移行ウィザードを開始しますか？'
    ) -join [Environment]::NewLine
    $answer = [System.Windows.Forms.MessageBox]::Show($message,'旧形式プロジェクトの移行',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Information)
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
        Append-Log '[GUI] 旧形式プロジェクトの移行は今回実行しませんでした。'
        return $true
    }

    $picker = New-Object System.Windows.Forms.FolderBrowserDialog
    try {
        $picker.Description = '既に存在するDevelopmentフォルダーを選択してください。移行先は自動作成しません。'
        $picker.ShowNewFolderButton = $false
        if ($null -ne $script:projectRootInfo -and [bool]$script:projectRootInfo.Exists -and
            -not [string]::Equals([string]$script:projectRootInfo.Path,[string]$check.SourceRoot,[System.StringComparison]::OrdinalIgnoreCase)) {
            $picker.SelectedPath = [string]$script:projectRootInfo.Path
        }
        if ($picker.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { return $true }
        $destination = [string]$picker.SelectedPath
        $destinationCheck = Get-ProjectRootCheckFromCli -Path $destination
        if ([string]$destinationCheck.Status -ne 'OK') {
            throw "移行先Project Rootを使用できません: $($destinationCheck.Message)"
        }
        Invoke-ProjectRootSettingCliSynchronously -Command 'project-migrate' -Arguments @('-SourceRoot',[string]$check.SourceRoot,'-DestinationRoot',$destination)
        Refresh-ProjectRootAndProjects
        $script:startupFailure = $null
        Append-Log ("[GUI] 旧形式プロジェクトを移行しました。移行先: {0}" -f $destination)
        Show-GuiMessage ("旧形式プロジェクトの移行が完了しました。`r`n`r`n移行先：$destination`r`n対象：$($check.Projects)件`r`n`r`n移行元は安全のため残しています。") '移行完了'
        return $true
    }
    catch {
        Append-Log ('[GUI] 旧形式プロジェクトの移行に失敗しました: ' + $_.Exception.Message)
        Show-GuiMessage $_.Exception.Message '移行できません' ([System.Windows.Forms.MessageBoxIcon]::Error)
        return $false
    }
    finally { $picker.Dispose() }
}

function Show-ProjectRootChangeDialog {
    if ($script:busy) { return }
    $candidate = Select-ProjectRootMigrationCandidate
    if ($null -eq $candidate) { return }
    $currentPath = if ($null -ne $script:projectRootInfo) { [string]$script:projectRootInfo.Path } else { '-' }
    if ([string]::Equals($currentPath,[string]$candidate.Path,[System.StringComparison]::OrdinalIgnoreCase)) {
        Show-GuiMessage '現在と同じ保存先が選択されています。' 'プロジェクト保存先'
        return
    }
    $script:projectRootPreviousSelection = if ($cmbProject.SelectedItem -ne $null) { [string]$cmbProject.SelectedItem } else { $null }
    Start-CliCommand -Command 'project-root-set' -Arguments @('-Path',[string]$candidate.Path)
}

function Reset-ProjectRootFromGui {
    if ($script:busy) { return }
    $currentPath = if ($null -ne $script:projectRootInfo) { [string]$script:projectRootInfo.Path } else { '-' }
    $defaultPath = if ($null -ne $script:projectRootInfo -and $script:projectRootInfo.PSObject.Properties['DefaultPath']) {
        [string]$script:projectRootInfo.DefaultPath
    }
    else { Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::UserProfile)) 'Development' }
    $message = @(
        'プロジェクト保存先を既定に戻します。',
        '',
        '変更前：' + $currentPath,
        '変更後：' + $defaultPath,
        '',
        '既存のプロジェクトフォルダーは自動で移動・コピー・削除されません。',
        '',
        '既定に戻しますか？'
    ) -join [Environment]::NewLine
    $answer = [System.Windows.Forms.MessageBox]::Show($message,'プロジェクト保存先を既定に戻す',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Warning)
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { return }
    $script:projectRootPreviousSelection = if ($cmbProject.SelectedItem -ne $null) { [string]$cmbProject.SelectedItem } else { $null }
    Start-CliCommand -Command 'project-root-reset'
}

function Update-GitHubButtonState {
    $enabled = $false
    if (-not $script:busy -and $null -ne $script:selectedProjectInfo) {
        $rootPath = [string]$script:selectedProjectInfo.ProjectRoot
        if (-not [string]::IsNullOrWhiteSpace($rootPath) -and (Test-Path -LiteralPath $rootPath -PathType Container)) {
            try {
                $git = Get-Command git.exe -ErrorAction SilentlyContinue
                if ($null -eq $git) { $git = Get-Command git -ErrorAction SilentlyContinue }
                if ($null -ne $git) {
                    $probe = & $git.Source -C $rootPath rev-parse --is-inside-work-tree 2>$null
                    $enabled = ($LASTEXITCODE -eq 0 -and ([string]$probe).Trim() -eq 'true')
                }
            } catch { $enabled = $false }
        }
    }
    foreach ($button in @($script:btnGitCommit,$script:btnGitPush,$script:btnGitPull,$script:btnGitStatus,$script:btnGitRefresh)) {
        if ($null -ne $button) { $button.Enabled = $enabled }
    }
    try { Update-MainGitHubStatusDisplay } catch {}
}


function Get-GitExecutablePath {
    $git = Get-Command git.exe -ErrorAction SilentlyContinue
    if ($null -eq $git) { $git = Get-Command git -ErrorAction SilentlyContinue }
    if ($null -eq $git) { throw 'Gitが見つかりません。Git for Windowsをインストールし、git.exeをPATHへ追加してください。' }
    return [string]$git.Source
}

function Get-GitProjectRoot {
    if ($null -eq $script:selectedProjectInfo) { throw 'プロジェクトを選択してください。' }
    $rootPath = [string]$script:selectedProjectInfo.ProjectRoot
    if ([string]::IsNullOrWhiteSpace($rootPath) -or -not (Test-Path -LiteralPath $rootPath -PathType Container)) {
        throw '選択Projectのフォルダーが見つかりません。'
    }
    $git = Get-GitExecutablePath
    $inside = @(& $git -C $rootPath rev-parse --is-inside-work-tree 2>&1)
    if ($LASTEXITCODE -ne 0 -or (($inside -join '').Trim() -ne 'true')) { throw '選択ProjectはGitリポジトリではありません。' }
    return $rootPath
}

function Invoke-GitCapture {
    param([Parameter(Mandatory=$true)][string]$ProjectRoot,[Parameter(Mandatory=$true)][string[]]$Arguments,[switch]$AllowFailure)
    $git = Get-GitExecutablePath
    $display = 'git -C "' + $ProjectRoot + '" ' + ($Arguments -join ' ')
    Append-Log ('[GitHub] ' + $display)
    $lines = @(& $git -C $ProjectRoot @Arguments 2>&1)
    $exitCode = $LASTEXITCODE
    foreach ($line in $lines) { if (-not [string]::IsNullOrWhiteSpace([string]$line)) { Append-Log ('[Git] ' + [string]$line) } }
    if ($exitCode -ne 0 -and -not $AllowFailure) {
        throw (('Gitコマンドに失敗しました。ExitCode={0}' -f $exitCode) + [Environment]::NewLine + ($lines -join [Environment]::NewLine))
    }
    return [PSCustomObject]@{ ExitCode=$exitCode; Lines=@($lines); Text=($lines -join [Environment]::NewLine) }
}

function Get-GitHubContext {
    $rootPath = Get-GitProjectRoot
    $branchResult = Invoke-GitCapture -ProjectRoot $rootPath -Arguments @('rev-parse','--abbrev-ref','HEAD')
    $branch = ([string]$branchResult.Text).Trim()
    if ([string]::IsNullOrWhiteSpace($branch) -or $branch -eq 'HEAD') { throw '現在のGitブランチを特定できません。detached HEADではGitHub操作を実行しません。' }
    $remoteResult = Invoke-GitCapture -ProjectRoot $rootPath -Arguments @('remote','get-url','origin') -AllowFailure
    $remote = ([string]$remoteResult.Text).Trim()
    if ($remoteResult.ExitCode -ne 0 -or [string]::IsNullOrWhiteSpace($remote)) { throw 'Git remote「origin」が設定されていません。GitHubリポジトリのoriginを設定してください。' }
    $isGitHub = $remote -match '(?i)(^git@github\.com:|https?://github\.com/|ssh://git@github\.com/)'
    if (-not $isGitHub) { throw ('originがGitHubを指していません。' + [Environment]::NewLine + 'origin: ' + $remote) }
    $upstreamResult = Invoke-GitCapture -ProjectRoot $rootPath -Arguments @('rev-parse','--abbrev-ref','--symbolic-full-name','@{u}') -AllowFailure
    $upstream = if ($upstreamResult.ExitCode -eq 0) { ([string]$upstreamResult.Text).Trim() } else { '' }
    return [PSCustomObject]@{ Root=$rootPath; Branch=$branch; Remote=$remote; Upstream=$upstream }
}

function Update-MainGitHubStatusDisplay {
    if ($null -eq $script:lblGitConnectionStatus) { return }
    try {
        if ($null -eq $script:selectedProjectInfo) { throw 'プロジェクト未選択' }
        $rootPath = [string]$script:selectedProjectInfo.ProjectRoot
        if ([string]::IsNullOrWhiteSpace($rootPath) -or -not (Test-Path -LiteralPath $rootPath -PathType Container)) { throw 'Projectフォルダーなし' }
        $git = Get-GitExecutablePath
        $inside = @(& $git -C $rootPath rev-parse --is-inside-work-tree 2>$null)
        if ($LASTEXITCODE -ne 0 -or (($inside -join '').Trim() -ne 'true')) { throw 'Git未設定' }
        $branch = ((@(& $git -C $rootPath rev-parse --abbrev-ref HEAD 2>$null)) -join '').Trim()
        $remote = ((@(& $git -C $rootPath remote get-url origin 2>$null)) -join '').Trim()
        if ([string]::IsNullOrWhiteSpace($remote)) { throw 'origin未設定' }
        $repo = $remote
        if ($remote -match '(?i)github\.com[:/](.+?)(?:\.git)?$') { $repo = $matches[1].TrimEnd('/') -replace '\.git$','' }
        $upstream = ((@(& $git -C $rootPath rev-parse --abbrev-ref --symbolic-full-name '@{u}' 2>$null)) -join '').Trim()
        $ahead=0; $behind=0
        if (-not [string]::IsNullOrWhiteSpace($upstream)) {
            $counts = ((@(& $git -C $rootPath rev-list --left-right --count 'HEAD...@{u}' 2>$null)) -join '').Trim()
            if ($counts -match '^\s*(\d+)\s+(\d+)\s*$') { $ahead=[int]$matches[1]; $behind=[int]$matches[2] }
        }
        $porcelain = @(& $git -C $rootPath status --porcelain 2>$null)
        $changed = @($porcelain | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) }).Count
        $staged = @($porcelain | Where-Object { ([string]$_).Length -ge 1 -and ([string]$_)[0] -notin @(' ','?') }).Count
        $script:lblGitConnectionStatus.Text = '● 接続済み'
        $script:lblGitConnectionStatus.ForeColor = [System.Drawing.Color]::ForestGreen
        $script:lblGitRepository.Text = 'リポジトリ: ' + $repo
        $script:lblGitBranch.Text = 'ブランチ: ' + $branch + '    リモート: origin'
        $script:lblGitCounts.Text = ('Ahead: {0}    Behind: {1}    変更ファイル: {2}    ステージ済み: {3}' -f $ahead,$behind,$changed,$staged)
    }
    catch {
        $script:lblGitConnectionStatus.Text = '● 未設定 / 未接続'
        $script:lblGitConnectionStatus.ForeColor = [System.Drawing.Color]::Firebrick
        $script:lblGitRepository.Text = 'リポジトリ: -'
        $script:lblGitBranch.Text = 'ブランチ: -    リモート: -'
        $script:lblGitCounts.Text = 'Ahead: -    Behind: -    変更ファイル: -    ステージ済み: -'
    }
}

function Get-AutoGitCommitMessage {
    param([Parameter(Mandatory=$true)][string]$ProjectRoot)

    $status = Invoke-GitCapture -ProjectRoot $ProjectRoot -Arguments @('status','--porcelain')
    $lines = @([string]$status.Text -split "`r?`n" | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    if ($lines.Count -eq 0) { return 'Update project files' }

    $items = New-Object System.Collections.Generic.List[object]
    foreach ($line in $lines) {
        if ($line.Length -lt 4) { continue }
        $code = $line.Substring(0,2)
        $pathText = $line.Substring(3).Trim()
        if ($pathText -match ' -> ') { $pathText = ($pathText -split ' -> ')[-1] }
        $pathText = $pathText.Trim('"')
        $items.Add([PSCustomObject]@{ Code=$code; Path=$pathText })
    }
    if ($items.Count -eq 0) { return 'Update project files' }

    function Get-GitActionWord([string]$code) {
        if ($code -match 'A|\?') { return 'Add' }
        if ($code -match 'D') { return 'Remove' }
        if ($code -match 'R') { return 'Rename' }
        return 'Update'
    }

    function Get-GitArea([string]$pathText) {
        $lower = $pathText.ToLowerInvariant()
        $ext = [IO.Path]::GetExtension($lower)
        if ($ext -in @('.bas','.cls','.frm','.frx')) { return 'VBA source' }
        if ($lower -match '(^|[\\/])source[\\/]workbook[\\/]' -or [IO.Path]::GetFileName($lower) -in @('workbook.json','project.json')) { return 'workbook definitions' }
        if ($lower -match 'gui\.ps1$|setup\.ps1$|buildinstaller|verifypackage|runrcvalidation|vba\.ps1$') { return 'VBAUpdater tooling' }
        if ($ext -in @('.md','.txt','.rst')) { return 'documentation' }
        if ($ext -in @('.xlsm','.xlam','.xlsx')) { return 'Excel workbooks' }
        return 'project files'
    }

    if ($items.Count -eq 1) {
        $item = $items[0]
        $action = Get-GitActionWord ([string]$item.Code)
        $name = [IO.Path]::GetFileName([string]$item.Path)
        if ([string]::IsNullOrWhiteSpace($name)) { $name = [string]$item.Path }
        return ($action + ' ' + $name)
    }

    $areas = @($items | ForEach-Object { Get-GitArea ([string]$_.Path) } | Select-Object -Unique)
    if ($areas.Count -eq 1) {
        return ('Update ' + $areas[0] + ' (' + $items.Count + ' files)')
    }

    $priority = @('VBA source','workbook definitions','VBAUpdater tooling','Excel workbooks','documentation','project files')
    $primary = $null
    foreach ($candidate in $priority) {
        if ($areas -contains $candidate) { $primary = $candidate; break }
    }
    if ([string]::IsNullOrWhiteSpace($primary)) { $primary = 'project files' }
    return ('Update ' + $primary + ' and related files (' + $items.Count + ' changes)')
}

function Show-GitStatusFromGui {
    $ctx = Get-GitHubContext
    $status = Invoke-GitCapture -ProjectRoot $ctx.Root -Arguments @('status','--short','--branch')
    $ahead=0;$behind=0
    if (-not [string]::IsNullOrWhiteSpace($ctx.Upstream)) {
        $counts=Invoke-GitCapture -ProjectRoot $ctx.Root -Arguments @('rev-list','--left-right','--count','HEAD...@{u}') -AllowFailure
        if ($counts.ExitCode -eq 0 -and $counts.Text -match '^\s*(\d+)\s+(\d+)\s*$') { $ahead=[int]$matches[1];$behind=[int]$matches[2] }
    }
    $body=@(
        'GitHub連携状態','',
        ('Project: ' + [string]$cmbProject.SelectedItem),
        ('Branch: ' + $ctx.Branch),
        ('Upstream: ' + $(if([string]::IsNullOrWhiteSpace($ctx.Upstream)){'未設定'}else{$ctx.Upstream})),
        ('Ahead / Behind: ' + $ahead + ' / ' + $behind),
        ('origin: ' + $ctx.Remote),'','変更状態:',
        $(if([string]::IsNullOrWhiteSpace($status.Text)){'変更なし（clean）'}else{$status.Text})
    ) -join [Environment]::NewLine
    Show-GuiMessage $body 'Git状態表示'
}

function Invoke-GitCommitFromGui {
    $ctx=Get-GitHubContext
    $changes=Invoke-GitCapture -ProjectRoot $ctx.Root -Arguments @('status','--porcelain')
    if ([string]::IsNullOrWhiteSpace($changes.Text)) { Show-GuiMessage 'コミット対象の変更はありません。' 'Git Commit'; return }
    $message=Get-AutoGitCommitMessage -ProjectRoot $ctx.Root
    $answer=[System.Windows.Forms.MessageBox]::Show(('変更内容からコミットメッセージを自動作成しました。'+[Environment]::NewLine+[Environment]::NewLine+'Project: '+[string]$cmbProject.SelectedItem+[Environment]::NewLine+'Branch: '+$ctx.Branch+[Environment]::NewLine+[Environment]::NewLine+'自動作成メッセージ:'+[Environment]::NewLine+$message+[Environment]::NewLine+[Environment]::NewLine+'変更をすべてステージしてCommitしますか？'),'Git Commit',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question)
    if($answer-ne[System.Windows.Forms.DialogResult]::Yes){return}
    [void](Invoke-GitCapture -ProjectRoot $ctx.Root -Arguments @('add','-A'))
    $result=Invoke-GitCapture -ProjectRoot $ctx.Root -Arguments @('commit','-m',$message)
    try { Update-MainGitHubStatusDisplay } catch {}
    Show-GuiMessage ('Commitが完了しました。'+[Environment]::NewLine+[Environment]::NewLine+'Message: '+$message+[Environment]::NewLine+[Environment]::NewLine+$result.Text) 'Git Commit'
}

function Invoke-GitPushFromGui {
    $ctx=Get-GitHubContext
    $answer=[System.Windows.Forms.MessageBox]::Show(('GitHubへPushします。'+[Environment]::NewLine+[Environment]::NewLine+'Branch: '+$ctx.Branch+[Environment]::NewLine+'origin: '+$ctx.Remote+[Environment]::NewLine+[Environment]::NewLine+'続行しますか？'),'Git Push',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question)
    if($answer-ne[System.Windows.Forms.DialogResult]::Yes){return}
    if([string]::IsNullOrWhiteSpace($ctx.Upstream)){$result=Invoke-GitCapture -ProjectRoot $ctx.Root -Arguments @('push','-u','origin',$ctx.Branch)}else{$result=Invoke-GitCapture -ProjectRoot $ctx.Root -Arguments @('push')}
    try { Update-MainGitHubStatusDisplay } catch {}
    Show-GuiMessage ('Pushが完了しました。'+[Environment]::NewLine+[Environment]::NewLine+$result.Text) 'Git Push'
}

function Invoke-GitPullFromGui {
    $ctx=Get-GitHubContext
    $changes=Invoke-GitCapture -ProjectRoot $ctx.Root -Arguments @('status','--porcelain')
    if(-not [string]::IsNullOrWhiteSpace($changes.Text)){Show-GuiMessage '未Commitの変更があります。安全のためPullを開始しません。先にCommitするか、変更を整理してください。' 'Git Pull' ([System.Windows.Forms.MessageBoxIcon]::Warning);return}
    $answer=[System.Windows.Forms.MessageBox]::Show(('GitHubからPullします。'+[Environment]::NewLine+'競合を自動マージしないため --ff-only で実行します。'+[Environment]::NewLine+[Environment]::NewLine+'Branch: '+$ctx.Branch+[Environment]::NewLine+'origin: '+$ctx.Remote+[Environment]::NewLine+[Environment]::NewLine+'続行しますか？'),'Git Pull',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question)
    if($answer-ne[System.Windows.Forms.DialogResult]::Yes){return}
    if([string]::IsNullOrWhiteSpace($ctx.Upstream)){$result=Invoke-GitCapture -ProjectRoot $ctx.Root -Arguments @('pull','--ff-only','origin',$ctx.Branch)}else{$result=Invoke-GitCapture -ProjectRoot $ctx.Root -Arguments @('pull','--ff-only')}
    try { Update-MainGitHubStatusDisplay } catch {}
    Show-GuiMessage ('Pullが完了しました。'+[Environment]::NewLine+[Environment]::NewLine+$result.Text) 'Git Pull'
    try{Update-ProjectInformation -PreserveStatus}catch{}
}

function Invoke-CodexCliJson {
    param(
        [Parameter(Mandatory=$true)][string]$Command,
        [Parameter(Mandatory=$true)][AllowEmptyString()][string]$ProjectName,
        [AllowEmptyString()][string]$ZipPath,
        [string[]]$ExtraArguments=@()
    )
    if ([string]::IsNullOrWhiteSpace($ProjectName)) { return $null }
    if ($Command -in @('codex-import-preview','codex-import') -and [string]::IsNullOrWhiteSpace($ZipPath)) { return $null }
    $arguments = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$cliPath,$Command,'-Project',$ProjectName)
    if ($null -ne $script:selectedProjectInfo -and -not [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.ProjectRoot)) {
        $arguments += @('-ProjectRoot',[string]$script:selectedProjectInfo.ProjectRoot)
    }
    if (-not [string]::IsNullOrWhiteSpace($ZipPath)) { $arguments += @('-ZipPath',$ZipPath) }
    $arguments += @($ExtraArguments)
    $arguments += '-Json'
    $arguments += @(Get-GuiTestPropagationArguments)
    $outputLines = @(& powershell.exe @arguments 2>&1)
    $exitCode = $LASTEXITCODE
    $output = $outputLines -join [Environment]::NewLine
    if ([string]::IsNullOrWhiteSpace($output)) { throw "Codex連携CLIから応答がありません。Command=$Command / ExitCode=$exitCode" }
    try { $result = $output | ConvertFrom-Json }
    catch { throw "Codex連携CLIのJSON応答を解析できません: $($_.Exception.Message) / 応答: $output" }
    if ($exitCode -ne 0 -or -not [bool]$result.success) {
        $details = @($result.errors) -join ' / '
        if ([string]::IsNullOrWhiteSpace($details)) { $details = "ExitCode=$exitCode" }
        throw $details
    }
    return $result
}

function Get-CodexPreviewDisplayText {
    param([Parameter(Mandatory=$true)]$Result)
    $lines = New-Object 'System.Collections.Generic.List[string]'
    $lines.Add('Codex Import Preview')
    $lines.Add('')
    $lines.Add('Project: ' + [string]$Result.project)
    $lines.Add('Project Match: ' + [string]$Result.projectMatch)
    foreach ($group in @(
        [PSCustomObject]@{Name='追加';Items=@($Result.added)},
        [PSCustomObject]@{Name='変更';Items=@($Result.modified)},
        [PSCustomObject]@{Name='削除候補（既定では反映しません）';Items=@($Result.deleted)},
        [PSCustomObject]@{Name='変更なし';Items=@($Result.unchanged)},
        [PSCustomObject]@{Name='反映対象外';Items=@($Result.ignored)},
        [PSCustomObject]@{Name='危険なファイル';Items=@($Result.dangerous)},
        [PSCustomObject]@{Name='構造異常';Items=@($Result.structuralErrors)},
        [PSCustomObject]@{Name='警告';Items=@($Result.warnings)},
        [PSCustomObject]@{Name='エラー';Items=@($Result.errors)})) {
        $lines.Add('')
        $lines.Add($group.Name + ': ' + $group.Items.Count + '件')
        foreach ($item in $group.Items) { $lines.Add('  ' + [string]$item) }
    }
    return $lines.ToArray() -join [Environment]::NewLine
}

function Show-CodexPreviewResultDialog {
    param([Parameter(Mandatory=$true)]$Result)
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = 'Codex納品ZIPの確認'
    $dialog.StartPosition = 'CenterParent'
    $dialog.Size = New-Object System.Drawing.Size(860,650)
    $dialog.MinimumSize = New-Object System.Drawing.Size(700,500)
    $dialog.Font = $form.Font
    $layout = New-Object System.Windows.Forms.TableLayoutPanel
    $layout.Dock='Fill';$layout.RowCount=2;$layout.ColumnCount=1;$layout.Padding=New-Object System.Windows.Forms.Padding(10)
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent',100)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute',46)))
    $dialog.Controls.Add($layout)
    $textBox=New-Object System.Windows.Forms.RichTextBox
    $textBox.Dock='Fill';$textBox.ReadOnly=$true;$textBox.WordWrap=$false;$textBox.Font=New-Object System.Drawing.Font('Consolas',9)
    $textBox.Text=Get-CodexPreviewDisplayText -Result $Result
    $layout.Controls.Add($textBox,0,0)
    $close=New-Object System.Windows.Forms.Button
    $close.Text='閉じる';$close.Size=New-Object System.Drawing.Size(110,32);$close.Anchor='Right';$close.DialogResult=[System.Windows.Forms.DialogResult]::OK
    $layout.Controls.Add($close,0,1);$dialog.AcceptButton=$close;$dialog.CancelButton=$close
    [void]$dialog.ShowDialog($form)
    $dialog.Dispose()
}

function Show-CodexExportFromGui {
    $picker = $null
    try {
        $projectName = Get-SelectedProject
        if ([string]::IsNullOrWhiteSpace($projectName) -or $null -eq $script:projectRootInfo -or -not [bool]$script:projectRootInfo.Exists) { return }
        $picker = New-Object System.Windows.Forms.SaveFileDialog
        $picker.Filter = 'ZIPファイル (*.zip)|*.zip'
        $picker.DefaultExt = 'zip'
        $picker.AddExtension = $true
        $picker.OverwritePrompt = $true
        $picker.FileName = $projectName + '_Codex_' + [DateTime]::Now.ToString('yyyyMMdd_HHmmss') + '.zip'
        if ($picker.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { return }
        $outputPath = [string]$picker.FileName
        if ([string]::IsNullOrWhiteSpace($outputPath)) { return }
        if (Test-Path -LiteralPath $outputPath) {
            Show-GuiMessage '既存ZIPは上書きしません。別のファイル名を指定してください。' 'Codex用ZIPを作成'
            return
        }
        $message = @(
            'Codex用ZIPを作成します。','',
            '対象プロジェクト：' + $projectName,
            'プロジェクト保存先：' + [string]$script:projectRootInfo.Path,
            'ZIP出力先：' + $outputPath,'',
            '含まれる主な内容：project.json、source、README、docs、tests、tools、templates',
            '除外される主な内容：target、backups、history、logs、tmp、個人設定、認証情報','',
            '作成しますか？') -join [Environment]::NewLine
        $answer=[System.Windows.Forms.MessageBox]::Show($message,'Codex用ZIPを作成',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question)
        if($answer -ne [System.Windows.Forms.DialogResult]::Yes){return}
        Set-Busy $true 'codex-export'
        try { $result=Invoke-CodexCliJson -Command 'codex-export' -ProjectName $projectName -ZipPath '' -ExtraArguments @('-OutputPath',$outputPath) }
        finally { Set-Busy $false }
        Append-Log ('[GUI] Codex用ZIPを作成しました: ' + [string]$result.zipPath)
        $open=[System.Windows.Forms.MessageBox]::Show(('Codex用ZIPを作成しました。'+[Environment]::NewLine+[Environment]::NewLine+'ファイル：'+[Environment]::NewLine+[string]$result.zipPath+[Environment]::NewLine+[Environment]::NewLine+'保存フォルダーを開きますか？'),'Codex用ZIPを作成',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Information)
        if($open -eq [System.Windows.Forms.DialogResult]::Yes){Start-Process -FilePath 'explorer.exe' -ArgumentList (Quote-ProcessArgument (Split-Path -Parent ([string]$result.zipPath))) | Out-Null}
    }
    catch { Append-Log ('[GUI] Codex用ZIP作成に失敗しました: '+$_.Exception.Message); Show-GuiMessage ('Codex用ZIPを作成できませんでした。'+[Environment]::NewLine+$_.Exception.Message) 'Codex用ZIPを作成' }
    finally { if($null -ne $picker){$picker.Dispose()}; Update-GitHubButtonState }
}

function Show-CodexImportPreviewFromGui {
    $picker=$null
    try {
        $projectName=Get-SelectedProject
        if([string]::IsNullOrWhiteSpace($projectName)){return}
        $picker=New-Object System.Windows.Forms.OpenFileDialog
        $picker.Filter='ZIPファイル (*.zip)|*.zip';$picker.CheckFileExists=$true;$picker.Multiselect=$false
        if($picker.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK){return}
        $zipPath=[string]$picker.FileName
        if([string]::IsNullOrWhiteSpace($zipPath)){return}
        Set-Busy $true 'codex-import-preview'
        try{$result=Invoke-CodexCliJson -Command 'codex-import-preview' -ProjectName $projectName -ZipPath $zipPath}
        finally{Set-Busy $false}
        $script:lastCodexPreview=$result;$script:lastCodexZipPath=$zipPath
        Append-Log ('[GUI] Codex納品ZIPを確認しました: '+$zipPath)
        Update-GitHubButtonState
        Show-CodexPreviewResultDialog -Result $result
    }
    catch { $script:lastCodexPreview=$null;$script:lastCodexZipPath=$null;Append-Log ('[GUI] Codex納品ZIPの確認に失敗しました: '+$_.Exception.Message);Show-GuiMessage ('Codex納品ZIPを確認できませんでした。'+[Environment]::NewLine+$_.Exception.Message) 'Codex納品ZIPの確認' }
    finally { if($null -ne $picker){$picker.Dispose()};Update-GitHubButtonState }
}

function Import-CodexZipFromGui {
    try {
        $projectName=Get-SelectedProject
        if([string]::IsNullOrWhiteSpace($projectName) -or $null -eq $script:lastCodexPreview -or [string]::IsNullOrWhiteSpace([string]$script:lastCodexZipPath)){return}
        if(-not (Test-Path -LiteralPath $script:lastCodexZipPath -PathType Leaf)){Show-GuiMessage '確認済みのCodex納品ZIPが見つかりません。もう一度「Codex納品ZIPを確認」を実行してください。' 'Codex納品ZIPを取り込む';return}
        $message=@('Codex納品ZIPを取り込みます。','','対象：'+$projectName,'','追加：'+@($script:lastCodexPreview.added).Count+'件','変更：'+@($script:lastCodexPreview.modified).Count+'件','削除候補：'+@($script:lastCodexPreview.deleted).Count+'件','','既存sourceと開発文書のバックアップを作成してから反映します。','削除候補は既定では反映しません。','','取り込みますか？') -join [Environment]::NewLine
        $answer=[System.Windows.Forms.MessageBox]::Show($message,'Codex納品ZIPを取り込む',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Warning)
        if($answer -ne [System.Windows.Forms.DialogResult]::Yes){return}
        Set-Busy $true 'codex-import'
        try{$result=Invoke-CodexCliJson -Command 'codex-import' -ProjectName $projectName -ZipPath $script:lastCodexZipPath -ExtraArguments @('-Confirm')}
        finally{Set-Busy $false}
        Append-Log ('[GUI] Codex納品ZIPを取り込みました。Backup='+[string]$result.backupPath)
        $script:lastCodexPreview=$null;$script:lastCodexZipPath=$null;Update-GitHubButtonState
        Show-GuiMessage ('Codex納品ZIPを取り込みました。'+[Environment]::NewLine+[Environment]::NewLine+'ブックを更新するには「ブックを更新する」を実行してください。'+[Environment]::NewLine+[Environment]::NewLine+'バックアップ：'+[Environment]::NewLine+[string]$result.backupPath) 'Codex納品ZIPを取り込む'
        Update-ProjectInformation -PreserveStatus
    }
    catch { Append-Log ('[GUI] Codex納品ZIPの取り込みに失敗しました: '+$_.Exception.Message);Show-GuiMessage ('Codex納品ZIPを取り込めませんでした。'+[Environment]::NewLine+$_.Exception.Message) 'Codex納品ZIPを取り込む' }
    finally { Update-GitHubButtonState }
}

function Get-SampleReturnStatePath {
    $settingsFolder = if ($null -ne $script:projectRootInfo -and $script:projectRootInfo.PSObject.Properties['SettingsFolder']) {
        [string]$script:projectRootInfo.SettingsFolder
    }
    else { Join-Path $env:LOCALAPPDATA 'VBAUpdater' }
    if (-not (Test-Path -LiteralPath $settingsFolder -PathType Container)) {
        [void](New-Item -ItemType Directory -Path $settingsFolder -Force)
    }
    return (Join-Path $settingsFolder 'sample-return.json')
}

function Get-VBAUpdaterSampleRoot {
    return (Join-Path $root 'Sample')
}

function Update-SampleGuideButtonState {
    $returnPath = Get-SampleReturnStatePath
    if (Get-Variable -Name btnReturnFromSample -Scope Script -ErrorAction SilentlyContinue) {
        $script:btnReturnFromSample.Enabled = (Test-Path -LiteralPath $returnPath -PathType Leaf) -and (-not $script:busy)
    }
}

function Start-VBAUpdaterSampleFromGui {
    if ($script:busy) { return }
    $sampleRoot = Get-VBAUpdaterSampleRoot
    $sampleProject = Join-Path $sampleRoot 'WorkbookMinimal'
    $sampleManifest = Join-Path $sampleProject 'project.json'
    if (-not (Test-Path -LiteralPath $sampleManifest -PathType Leaf)) {
        throw "練習用サンプルが見つかりません: $sampleManifest"
    }
    $currentRoot = if ($null -ne $script:projectRootInfo) { [string]$script:projectRootInfo.Path } else { '' }
    if (-not [string]::Equals($currentRoot,$sampleRoot,[System.StringComparison]::OrdinalIgnoreCase)) {
        $returnState = [ordered]@{ ProjectRoot=$currentRoot; SavedAt=(Get-Date).ToString('o') }
        $returnState | ConvertTo-Json | Set-Content -LiteralPath (Get-SampleReturnStatePath) -Encoding UTF8
    }
    $message = @(
        '練習用サンプルを開きます。',
        '',
        '実際の業務ブックは変更しません。',
        '練習用のWorkbookMinimalSample.xlsmだけを使用します。',
        '',
        'サンプル終了後は「サンプルを終了して元に戻す」で元の保存先へ戻せます。',
        '',
        'サンプルを開始しますか？'
    ) -join [Environment]::NewLine
    if ([System.Windows.Forms.MessageBox]::Show($message,'サンプルを試す',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question) -ne [System.Windows.Forms.DialogResult]::Yes) { return }
    Invoke-ProjectRootSettingCliSynchronously -Command 'project-root-set' -Arguments @('-Path',$sampleRoot)
    Refresh-ProjectRootAndProjects -PreferredProject 'WorkbookMinimalSample'
    $index = $cmbProject.Items.IndexOf('WorkbookMinimalSample')
    if ($index -ge 0) {
        $cmbProject.SelectedIndex = $index
        Update-ProjectInformation -PreserveStatus
    }
    Update-SampleGuideButtonState
    $lblInfoMessageValue.Text = '練習用サンプルを選択しました。「ブックを更新する」で安全な更新を体験できます。'
    Set-CurrentStatus 'サンプル準備完了'
    Append-Log ('[GUI] 練習用サンプルを開始しました: '+$sampleProject)
}

function Restore-ProjectRootAfterSampleFromGui {
    if ($script:busy) { return }
    $returnPath = Get-SampleReturnStatePath
    if (-not (Test-Path -LiteralPath $returnPath -PathType Leaf)) {
        Show-GuiMessage '元のプロジェクト保存先の退避情報がありません。必要に応じて「プロジェクト保存先を変更」から選択してください。' 'サンプル終了' ([System.Windows.Forms.MessageBoxIcon]::Information)
        return
    }
    try {
        $state = Get-Content -LiteralPath $returnPath -Raw | ConvertFrom-Json
        $previousRoot = [string]$state.ProjectRoot
        if ([string]::IsNullOrWhiteSpace($previousRoot) -or -not (Test-Path -LiteralPath $previousRoot -PathType Container)) {
            throw "元のプロジェクト保存先が見つかりません: $previousRoot"
        }
        Invoke-ProjectRootSettingCliSynchronously -Command 'project-root-set' -Arguments @('-Path',$previousRoot)
        Remove-Item -LiteralPath $returnPath -Force -ErrorAction SilentlyContinue
        Refresh-ProjectRootAndProjects
        Update-SampleGuideButtonState
        $lblInfoMessageValue.Text = 'サンプルを終了し、元のプロジェクト保存先へ戻しました。'
        Set-CurrentStatus '待機中'
        Append-Log ('[GUI] サンプル終了。Project Rootを復元しました: '+$previousRoot)
    }
    catch {
        Append-Log ('[GUI] サンプル終了時の復元に失敗しました: '+$_.Exception.Message)
        Show-GuiMessage $_.Exception.Message '元の保存先へ戻せません' ([System.Windows.Forms.MessageBoxIcon]::Error)
    }
}

function Show-DirectProjectFolderOpenDialog {
    if ($script:busy) { return $false }
    $picker=New-Object System.Windows.Forms.FolderBrowserDialog
    $picker.Description='GitHubで管理しているプロジェクトフォルダーを選択してください。sourceまたはtargetを選んだ場合は親へ補正します。'
    $picker.ShowNewFolderButton=$false
    if ($null -ne $script:selectedProjectInfo -and (Test-Path -LiteralPath ([string]$script:selectedProjectInfo.ProjectDirectory) -PathType Container)) {
        $picker.SelectedPath=[string]$script:selectedProjectInfo.ProjectDirectory
    }
    try {
        if ($picker.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { return $false }
        $check=Get-ProjectFolderCheckFromCli -Path ([string]$picker.SelectedPath)
        if (-not [bool]$check.IsAvailable) {
            Show-GuiMessage ((@('選択したフォルダーをプロジェクトとして利用できません。','',('選択：'+[string]$check.RequestedPath),('判定：'+[string]$check.ProjectRoot),'')+@($check.Errors)) -join [Environment]::NewLine) 'プロジェクトフォルダー' ([System.Windows.Forms.MessageBoxIcon]::Error)
            return $false
        }
        $selectedWorkbook=''
        if ([string]$check.WorkbookSelectionStatus -eq 'Multiple') {
            $bookPicker=New-Object System.Windows.Forms.OpenFileDialog
            try {
                $bookPicker.Title='対象ブックを選択してください'
                $bookPicker.InitialDirectory=[string]$check.TargetDirectory
                $bookPicker.Filter='Excel VBAブック (*.xlsm;*.xlam;*.xlsb)|*.xlsm;*.xlam;*.xlsb'
                $bookPicker.Multiselect=$false
                if ($bookPicker.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { return $false }
                $selectedWorkbook=[string]$bookPicker.FileName
                $check=Get-ProjectFolderCheckFromCli -Path ([string]$check.ProjectRoot) -WorkbookPath $selectedWorkbook
            }
            finally { $bookPicker.Dispose() }
        }
        $workbookText=if([string]::IsNullOrWhiteSpace([string]$check.WorkbookPath)){'（対象ブックなし。選択だけ保存します）'}else{[string]$check.WorkbookPath}
        $correctionText=if([bool]$check.Corrected){[Environment]::NewLine+[Environment]::NewLine+[string]$check.CorrectionMessage}else{''}
        $message=@(
            'このプロジェクトフォルダーを開きますか？','',
            ('プロジェクト：'+[string]$check.ProjectName),
            ('ルート：'+[string]$check.ProjectRoot),
            ('source：'+[string]$check.SourcePath),
            ('target：'+[string]$check.TargetDirectory),
            ('対象ブック：'+$workbookText),
            ('manifest：'+[string]$check.ManifestPath),
            ('Git管理：'+$(if([bool]$check.IsGitRepository){'あり'}else{'なし'})),
            $correctionText,'','フォルダーやファイルの移動、コピー、Git操作は行いません。'
        ) -join [Environment]::NewLine
        $answer=[System.Windows.Forms.MessageBox]::Show($message,'プロジェクトフォルダーを開く',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question)
        if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { return $false }
        $arguments=@('-Path',[string]$check.ProjectRoot)
        if (-not [string]::IsNullOrWhiteSpace([string]$check.WorkbookPath)) { $arguments += @('-WorkbookPath',[string]$check.WorkbookPath) }
        Invoke-ProjectRootSettingCliSynchronously -Command 'project-folder-set' -Arguments $arguments
        Refresh-ProjectRootAndProjects -PreferredProject ([System.IO.Path]::GetFileName([string]$check.ProjectRoot)) -StrictSelection
        $script:startupFailure=$null
        Append-Log ('[GUI] プロジェクトフォルダーを直接開きました: '+[string]$check.ProjectRoot)
        if ([bool]$check.Corrected) { Append-Log ('[GUI] '+[string]$check.CorrectionMessage) }
        return $true
    }
    catch {
        Append-Log ('[GUI] プロジェクトフォルダーを開けませんでした: '+$_.Exception.Message)
        Show-GuiMessage $_.Exception.Message 'プロジェクトフォルダーを開けません' ([System.Windows.Forms.MessageBoxIcon]::Error)
        return $false
    }
    finally { $picker.Dispose() }
}

function Unregister-SelectedProjectFromGui {
    if($cmbProject.SelectedItem-eq$null){throw '登録解除するプロジェクトを選択してください。'}
    $name=[string]$cmbProject.SelectedItem
    $folder=if($null-ne$script:selectedProjectInfo){[string]$script:selectedProjectInfo.ProjectDirectory}else{[string]$script:registeredProjectFolders[$name]}
    $message="登録情報だけを解除します。`r`n`r`nプロジェクト：$name`r`nフォルダー：$folder`r`n`r`nプロジェクトフォルダーとファイルは削除しません。"
    if([System.Windows.Forms.MessageBox]::Show($message,'プロジェクトの登録解除',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Warning)-ne[System.Windows.Forms.DialogResult]::Yes){return}
    Invoke-ProjectRootSettingCliSynchronously -Command 'project-unregister' -Arguments @('-Project',$name)
    Refresh-ProjectRootAndProjects
    Show-GuiMessage '登録情報を解除しました。プロジェクトフォルダーは削除していません。' '登録解除'
}

function Relocate-SelectedProjectFromGui {
    $name=if($cmbProject.SelectedItem-ne$null){[string]$cmbProject.SelectedItem}else{''}
    $oldFolder=if($null-ne$script:selectedProjectInfo){[string]$script:selectedProjectInfo.ProjectDirectory}elseif(-not[string]::IsNullOrWhiteSpace($name)){[string]$script:registeredProjectFolders[$name]}else{''}
    $picker=New-Object System.Windows.Forms.FolderBrowserDialog
    try{
        $picker.Description='移動後の開発プロジェクトフォルダーを選択してください。VBAUpdaterはフォルダーを移動しません。'
        $picker.ShowNewFolderButton=$false
        if(Test-Path -LiteralPath $oldFolder -PathType Container){$picker.SelectedPath=$oldFolder}
        if($picker.ShowDialog($form)-ne[System.Windows.Forms.DialogResult]::OK){return}
        $newFolder=[string]$picker.SelectedPath
        $check=Get-ProjectFolderCheckFromCli -Path $newFolder
        if(-not[bool]$check.IsAvailable){throw ('移動後のプロジェクトフォルダーを利用できません: '+(@($check.Errors)-join ' / '))}
        if([string]::IsNullOrWhiteSpace($name)){$name=[string]$check.ProjectName}
        $message="projects.jsonの登録先を変更します。`r`n`r`nプロジェクト：$name`r`n現在：$oldFolder`r`n変更後：$newFolder`r`n`r`nフォルダーやファイルの移動は行いません。"
        if([System.Windows.Forms.MessageBox]::Show($message,'登録先を変更',[System.Windows.Forms.MessageBoxButtons]::YesNo,[System.Windows.Forms.MessageBoxIcon]::Question)-ne[System.Windows.Forms.DialogResult]::Yes){return}
        Invoke-ProjectRootSettingCliSynchronously -Command 'project-relocate' -Arguments @('-Project',$name,'-ProjectFolder',$newFolder)
        Refresh-ProjectRootAndProjects -PreferredProject $name -StrictSelection
        Show-GuiMessage '移動後のフォルダーへ登録先を変更しました。' '登録先を変更'
    }
    finally{$picker.Dispose()}
}


function Show-VBAUpdaterProjectDetailsDialog {
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = 'プロジェクト詳細情報'
    $dialog.StartPosition = 'CenterParent'
    $dialog.Size = New-Object System.Drawing.Size(820, 520)
    $dialog.MinimumSize = New-Object System.Drawing.Size(680, 420)
    $dialog.Font = $form.Font

    $box = New-Object System.Windows.Forms.TextBox
    $box.Multiline = $true
    $box.ReadOnly = $true
    $box.ScrollBars = 'Both'
    $box.WordWrap = $false
    $box.Dock = 'Fill'
    $box.Font = New-Object System.Drawing.Font('Consolas', 9)

    $lines = @(
        ('プロジェクト名      : ' + $(if ($null -ne $script:selectedProjectInfo) { [string]$script:selectedProjectInfo.ProjectName } else { '-' })),
        ('プロジェクトルート  : ' + [string]$lblDirectProjectRootValue.Text),
        ('sourceフォルダー    : ' + [string]$lblSourceFolderValue.Text),
        ('targetフォルダー    : ' + [string]$lblTargetFolderValue.Text),
        ('対象ブック          : ' + [string]$lblTargetPathValue.Text),
        ('manifest            : ' + [string]$lblManifestValue.Text),
        ('Git管理             : ' + [string]$lblGitValue.Text),
        ('利用状態            : ' + [string]$lblDirectStatusValue.Text),
        ('Workbook定義        : ' + [string]$lblWorkbookDefinitionValue.Text),
        '',
        ('Project Root        : ' + [string]$lblProjectRootValue.Text),
        ('登録情報の保存場所  : ' + [string]$lblSettingsFolderValue.Text)
    )
    $box.Text = ($lines -join [Environment]::NewLine)

    $bottom = New-Object System.Windows.Forms.FlowLayoutPanel
    $bottom.Dock = 'Bottom'
    $bottom.Height = 50
    $bottom.FlowDirection = 'RightToLeft'
    $bottom.Padding = New-Object System.Windows.Forms.Padding(6)

    $close = New-Object System.Windows.Forms.Button
    $close.Text = '閉じる'
    $close.Size = New-Object System.Drawing.Size(100, 32)
    $close.Add_Click({ $dialog.Close() })
    $bottom.Controls.Add($close)

    $dialog.Controls.Add($box)
    $dialog.Controls.Add($bottom)
    [void]$dialog.ShowDialog($form)
    $dialog.Dispose()
}

function Show-VBAUpdaterLogDialog {
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = 'VBAUpdater ログ'
    $dialog.StartPosition = 'CenterParent'
    $dialog.Size = New-Object System.Drawing.Size(1040, 620)
    $dialog.MinimumSize = New-Object System.Drawing.Size(860, 480)
    $dialog.Font = $form.Font

    $layout = New-Object System.Windows.Forms.TableLayoutPanel
    $layout.Dock = 'Fill'
    $layout.RowCount = 2
    $layout.ColumnCount = 1
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent', 100)))
    [void]$layout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute', 54)))

    $box = New-Object System.Windows.Forms.RichTextBox
    $box.Dock = 'Fill'
    $box.ReadOnly = $true
    $box.WordWrap = $false
    $box.Font = New-Object System.Drawing.Font('Consolas', 9)
    $box.Text = $logBox.Text
    $layout.Controls.Add($box,0,0)

    $buttons = New-Object System.Windows.Forms.FlowLayoutPanel
    $buttons.Dock = 'Fill'
    $buttons.FlowDirection = 'LeftToRight'
    $buttons.WrapContents = $false
    $buttons.Padding = New-Object System.Windows.Forms.Padding(6)

    foreach ($spec in @(
        @('更新', 90),
        @('コピー', 100),
        @('ログフォルダーを開く', 170),
        @('最新ログを開く', 140),
        @('診断情報を保存', 150),
        @('サポートZIPを作成', 170),
        @('閉じる', 90)
    )) {
        $b = New-Object System.Windows.Forms.Button
        $b.Text = [string]$spec[0]
        $b.Size = New-Object System.Drawing.Size([int]$spec[1], 32)
        switch ([string]$spec[0]) {
            '更新' { $b.Add_Click({ $box.Text = $logBox.Text; $box.SelectionStart = $box.TextLength; $box.ScrollToCaret() }) }
            'コピー' { $b.Add_Click({
                if ([string]::IsNullOrEmpty($box.Text)) {
                    Show-GuiMessage 'コピーするログがありません。' 'ログ'
                } else {
                    [System.Windows.Forms.Clipboard]::SetText($box.Text)
                }
            }) }
            'ログフォルダーを開く' { $b.Add_Click({
                $directory = Get-GuiLogDirectory
                Start-Process -FilePath 'explorer.exe' -ArgumentList (Quote-ProcessArgument $directory) | Out-Null
            }) }
            '最新ログを開く' { $b.Add_Click({
                $directory = Get-GuiLogDirectory
                $latest = Get-ChildItem -LiteralPath $directory -Filter '*.log' -File -ErrorAction SilentlyContinue |
                    Sort-Object LastWriteTime -Descending | Select-Object -First 1
                if ($null -eq $latest) { Show-GuiMessage 'GUIログはまだありません。' 'ログ' }
                else { Start-Process -FilePath $latest.FullName | Out-Null }
            }) }
            '診断情報を保存' { $b.Add_Click({ Export-VBAUpdaterSupportInfo }) }
            'サポートZIPを作成' { $b.Add_Click({ Export-VBAUpdaterSupportPackage }) }
            '閉じる' { $b.Add_Click({ $dialog.Close() }) }
        }
        $buttons.Controls.Add($b)
    }
    $layout.Controls.Add($buttons,0,1)
    $dialog.Controls.Add($layout)
    [void]$dialog.ShowDialog($form)
    $dialog.Dispose()
}


function Get-VBAUpdaterReleaseReadinessLines {
    $ok = New-Object 'System.Collections.Generic.List[string]'
    $warnings = New-Object 'System.Collections.Generic.List[string]'
    $errors = New-Object 'System.Collections.Generic.List[string]'

    $required = @('gui.ps1','vba.ps1','BUILD_VERSION.txt','tools\WorkbookUpdate.psm1','tools\ProjectRegistration.psm1','addin\VBAUpdater.xlam')
    foreach ($relative in $required) {
        $candidate = Join-Path $root $relative
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { [void]$ok.Add(('必須ファイル: ' + $relative)) }
        else { [void]$errors.Add(('必須ファイルがありません: ' + $relative)) }
    }

    $userRoot = Get-VBAUpdaterUserDataRoot
    try {
        if (-not (Test-Path -LiteralPath $userRoot -PathType Container)) { [void](New-Item -ItemType Directory -Path $userRoot -Force) }
        $probe = Join-Path $userRoot ('.release_check_' + [Guid]::NewGuid().ToString('N') + '.tmp')
        [System.IO.File]::WriteAllText($probe, 'ok', (New-Object System.Text.UTF8Encoding($false)))
        Remove-Item -LiteralPath $probe -Force
        [void]$ok.Add('ユーザーデータ保存先: 書き込み可能')
    } catch { [void]$errors.Add(('ユーザーデータ保存先へ書き込めません: ' + $_.Exception.Message)) }

    foreach ($name in @('settings.json','projects.json')) {
        $path = Join-Path $userRoot $name
        if (Test-Path -LiteralPath $path -PathType Leaf) {
            try {
                $text = [System.IO.File]::ReadAllText($path)
                if ([string]::IsNullOrWhiteSpace($text)) { [void]$warnings.Add(($name + ' が空です。')) }
                else { [void]($text | ConvertFrom-Json -ErrorAction Stop); [void]$ok.Add(($name + ': JSON正常')) }
            } catch { [void]$errors.Add(($name + ' を解析できません: ' + $_.Exception.Message)) }
        } else {
            [void]$warnings.Add(($name + ' はまだ作成されていません。'))
        }
    }

    $historyPath = Get-InstallerHistoryPath
    if (Test-Path -LiteralPath $historyPath -PathType Leaf) {
        $last = @(Get-Utf8TailLines $historyPath 1)
        if ($last.Count -gt 0) {
            if ([string]$last[0] -match "`tSUCCESS`t") { [void]$ok.Add('最新インストール履歴: 成功') }
            elseif ([string]$last[0] -match "`tFAILED`t") { [void]$warnings.Add('最新インストール履歴が失敗です。履歴を確認してください。') }
            else { [void]$warnings.Add('最新インストール履歴を確認してください。') }
        }
    } else { [void]$warnings.Add('インストール履歴はまだありません。') }

    $backupRoot = Join-Path $userRoot 'config-backups'
    $backupCount = 0
    if (Test-Path -LiteralPath $backupRoot -PathType Container) { $backupCount = @(Get-ChildItem -LiteralPath $backupRoot -Directory -ErrorAction SilentlyContinue).Count }
    if ($backupCount -gt 0) { [void]$ok.Add(('設定安全バックアップ: ' + $backupCount + '件')) }
    else { [void]$warnings.Add('設定安全バックアップはまだありません。') }

    if ($null -ne $script:selectedProjectInfo) {
        $projectDir = [string]$script:selectedProjectInfo.ProjectDirectory
        if (-not [string]::IsNullOrWhiteSpace($projectDir) -and (Test-Path -LiteralPath $projectDir -PathType Container)) { [void]$ok.Add('選択Project: フォルダー確認済み') }
        else { [void]$errors.Add('選択Projectのフォルダーが見つかりません。') }
        $targetPath = [string]$script:selectedProjectInfo.TargetPath
        if (-not [string]::IsNullOrWhiteSpace($targetPath)) {
            if (Test-Path -LiteralPath $targetPath -PathType Leaf) { [void]$ok.Add('対象ブック: 確認済み') }
            else { [void]$errors.Add('対象ブックが見つかりません。') }
        }
    } else { [void]$warnings.Add('Project未選択のため、Project固有の確認は省略しました。') }

    $lines = New-Object 'System.Collections.Generic.List[string]'
    [void]$lines.Add('VBAUpdater 総合セルフチェック')
    [void]$lines.Add(('実行日時: ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')))
    [void]$lines.Add(('製品ビルド: ' + (Get-VBAUpdaterBuildVersion)))
    [void]$lines.Add(('PowerShell: ' + $PSVersionTable.PSVersion.ToString()))
    [void]$lines.Add('')
    if ($errors.Count -eq 0 -and $warnings.Count -eq 0) { [void]$lines.Add('総合結果: 正常') }
    elseif ($errors.Count -eq 0) { [void]$lines.Add(('総合結果: 正常（注意 ' + $warnings.Count + '件）')) }
    else { [void]$lines.Add(('総合結果: 要確認（エラー ' + $errors.Count + '件 / 注意 ' + $warnings.Count + '件）')) }
    [void]$lines.Add('')
    if ($errors.Count -gt 0) { [void]$lines.Add('[エラー]'); foreach ($item in $errors) { [void]$lines.Add(('・' + $item)) }; [void]$lines.Add('') }
    if ($warnings.Count -gt 0) { [void]$lines.Add('[注意]'); foreach ($item in $warnings) { [void]$lines.Add(('・' + $item)) }; [void]$lines.Add('') }
    [void]$lines.Add(('[正常項目] ' + $ok.Count + '件'))
    foreach ($item in $ok) { [void]$lines.Add(('・' + $item)) }
    return @($lines)
}

function Show-VBAUpdaterReleaseReadinessCheck {
    $lines = @(Get-VBAUpdaterReleaseReadinessLines)
    Show-GuiMessage ($lines -join [Environment]::NewLine) 'VBAUpdater 総合セルフチェック'
}

function Export-VBAUpdaterReleaseReadinessReport {
    $dialog = New-Object System.Windows.Forms.SaveFileDialog
    $dialog.Title = '総合確認レポートを保存'
    $dialog.Filter = 'テキストファイル (*.txt)|*.txt|すべてのファイル (*.*)|*.*'
    $dialog.FileName = 'VBAUpdater_ReleaseCheck_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.txt'
    $dialog.InitialDirectory = [Environment]::GetFolderPath('Desktop')
    try {
        if ($dialog.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { return }
        $lines = @(Get-VBAUpdaterReleaseReadinessLines)
        [System.IO.File]::WriteAllText($dialog.FileName, ($lines -join [Environment]::NewLine) + [Environment]::NewLine, (New-Object System.Text.UTF8Encoding($false)))
        Append-Log ('[GUI] 総合確認レポートを保存しました: ' + $dialog.FileName)
        Show-GuiMessage ('総合確認レポートを保存しました。' + [Environment]::NewLine + [Environment]::NewLine + $dialog.FileName) '総合確認レポート'
    } finally { $dialog.Dispose() }
}

function Open-VBAUpdaterInstallFolder {
    if (-not (Test-Path -LiteralPath $root -PathType Container)) { throw 'VBAUpdaterのインストール先が見つかりません。' }
    Start-Process explorer.exe -ArgumentList ('"' + $root + '"') | Out-Null
}

function Show-VBAUpdaterProjectCommandOutput([string]$Command,[string]$Title) {
    $selected = Get-SelectedProject
    if ($null -eq $selected) {
        Show-GuiMessage 'プロジェクトを選択してください。' $Title ([System.Windows.Forms.MessageBoxIcon]::Information)
        return
    }
    $arguments = @('-Project', $selected)
    if ($null -ne $script:selectedProjectInfo -and -not [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.ProjectRoot)) {
        $arguments += @('-ProjectRoot',[string]$script:selectedProjectInfo.ProjectRoot)
        if (-not [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.TargetPath) -and [string]$script:selectedProjectInfo.TargetPath -ne '-') {
            $arguments += @('-WorkbookPath',[string]$script:selectedProjectInfo.TargetPath)
        }
    }
    $cliArguments = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$cliPath,$Command) + @($arguments) + @(Get-GuiTestPropagationArguments)
    Append-Log ('> .\\vba.cmd ' + $Command + ' ' + ($arguments -join ' '))
    $outputLines = @(& powershell.exe @cliArguments 2>&1)
    $exitCode = $LASTEXITCODE
    foreach ($line in $outputLines) { Append-Log ([string]$line) }

    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = $Title
    $dialog.StartPosition = 'CenterParent'
    $dialog.Size = New-Object System.Drawing.Size(760, 560)
    $dialog.MinimumSize = New-Object System.Drawing.Size(640, 460)
    $dialog.Font = $form.Font
    $box = New-Object System.Windows.Forms.RichTextBox
    $box.Dock = 'Fill'
    $box.ReadOnly = $true
    $box.WordWrap = $false
    $box.Font = New-Object System.Drawing.Font('Consolas', 9)
    if ($outputLines.Count -eq 0) {
        $box.Text = if ($exitCode -eq 0) { '表示する履歴はありません。' } else { 'コマンドの実行に失敗しました。詳細ログを確認してください。' }
    } else {
        $box.Text = ($outputLines | ForEach-Object { [string]$_ }) -join [Environment]::NewLine
    }
    $dialog.Controls.Add($box)
    [void]$dialog.ShowDialog($form)
    $dialog.Dispose()
}

function Show-VBAUpdaterReferenceDialog {
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = '確認・参照'
    $dialog.StartPosition = 'CenterParent'
    $dialog.Size = New-Object System.Drawing.Size(560, 540)
    $dialog.MinimumSize = New-Object System.Drawing.Size(520, 500)
    $dialog.Font = $form.Font

    $panel = New-Object System.Windows.Forms.FlowLayoutPanel
    $panel.Dock = 'Fill'
    $panel.FlowDirection = 'TopDown'
    $panel.WrapContents = $false
    $panel.Padding = New-Object System.Windows.Forms.Padding(16)
    $panel.AutoScroll = $true

    $intro = New-Object System.Windows.Forms.Label
    $intro.Text = 'VBAUpdaterの状態や履歴を確認します。設定内容は変更しません。'
    $intro.AutoSize = $true
    $intro.MaximumSize = New-Object System.Drawing.Size(450, 0)
    $intro.Margin = New-Object System.Windows.Forms.Padding(4,4,4,12)
    $panel.Controls.Add($intro)

    $specs = @(
        @('総合セルフチェック', { Show-VBAUpdaterReleaseReadinessCheck }),
        @('総合確認レポートを保存', { Export-VBAUpdaterReleaseReadinessReport }),
        @('環境チェック', { Show-VBAUpdaterEnvironmentCheck }),
        @('インストール履歴', { Show-VBAUpdaterInstallerHistory }),
        @('プロジェクト詳細情報', { Show-VBAUpdaterProjectDetailsDialog }),
        @('インストール先を開く', { Open-VBAUpdaterInstallFolder }),
        @('ログを見る', { Show-VBAUpdaterLogDialog }),
        @('サポートZIPを作成', { Export-VBAUpdaterSupportPackage })
    )
    foreach ($item in $specs) {
        $button = New-Object System.Windows.Forms.Button
        $button.Text = [string]$item[0]
        $button.Size = New-Object System.Drawing.Size(320, 38)
        $action = [scriptblock]$item[1]
        $button.Add_Click({
            try { & $action }
            catch {
                Append-Log ('[GUI] 確認・参照の操作に失敗しました: ' + $_.Exception.Message)
                Show-GuiMessage $_.Exception.Message 'GUI操作エラー' ([System.Windows.Forms.MessageBoxIcon]::Error)
            }
        }.GetNewClosure())
        $panel.Controls.Add($button)
    }

    $dialog.Controls.Add($panel)
    [void]$dialog.ShowDialog($form)
    $dialog.Dispose()
}

function Show-VBAUpdaterSettingsDialog {
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = '詳細設定'
    $dialog.StartPosition = 'CenterParent'
    $dialog.Size = New-Object System.Drawing.Size(620, 400)
    $dialog.MinimumSize = New-Object System.Drawing.Size(560, 360)
    $dialog.Font = $form.Font

    $panel = New-Object System.Windows.Forms.FlowLayoutPanel
    $panel.Dock = 'Fill'
    $panel.FlowDirection = 'TopDown'
    $panel.WrapContents = $false
    $panel.Padding = New-Object System.Windows.Forms.Padding(16)
    $panel.AutoScroll = $true

    $intro = New-Object System.Windows.Forms.Label
    $intro.Text = 'プロジェクト保存先や登録情報を変更するときだけ使用します。通常のブック更新では操作不要です。'
    $intro.AutoSize = $true
    $intro.MaximumSize = New-Object System.Drawing.Size(560, 0)
    $intro.Margin = New-Object System.Windows.Forms.Padding(4,4,4,12)
    $panel.Controls.Add($intro)

    # HotFix5: 詳細設定ダイアログのボタンは、メイン画面上で非表示にした
    # 元ボタンの PerformClick() を経由しない。WinForms の PerformClick() は
    # Visible/CanSelect 状態に依存するため、非表示ボタンでは Click が発火しない。
    # 各操作を直接呼び出すことで、詳細設定から確実に実行できるようにする。
    $settingsSpecs = @(
        @('確認・参照', { Show-VBAUpdaterReferenceDialog }),
        @('設定バックアップ・復元', { Show-VBAUpdaterConfigBackupDialog }),
        @('プロジェクト保存先を変更', { Show-ProjectRootChangeDialog }),
        @('プロジェクトフォルダを開く', { [void](Show-DirectProjectFolderOpenDialog) }),
        @('選択Projectの登録先を変更', { Relocate-SelectedProjectFromGui }),
        @('登録解除', { Unregister-SelectedProjectFromGui }),
        @('既定に戻す', { Reset-ProjectRootFromGui })
    )
    foreach ($item in $settingsSpecs) {
        $button = New-Object System.Windows.Forms.Button
        $button.Text = [string]$item[0]
        $button.Size = New-Object System.Drawing.Size(320, 38)
        $action = [scriptblock]$item[1]
        $button.Add_Click({
            try { & $action }
            catch {
                Append-Log ('[GUI] 詳細設定の操作に失敗しました: ' + $_.Exception.Message)
                Show-GuiMessage $_.Exception.Message 'GUI操作エラー' ([System.Windows.Forms.MessageBoxIcon]::Error)
            }
        }.GetNewClosure())
        $panel.Controls.Add($button)
    }

    $dialog.Controls.Add($panel)
    [void]$dialog.ShowDialog($form)
    $dialog.Dispose()
}

$btnChangeProjectRoot = Add-OperationButton $projectPanel 'プロジェクト保存先を変更' {
    Show-ProjectRootChangeDialog
} 190
$btnChangeProjectRoot.Height = 36
$toolTip.SetToolTip($btnChangeProjectRoot,'プロジェクト保存先を選択します。既存プロジェクトは自動移動しません。')

$btnOpenDirectProject = Add-OperationButton $projectPanel 'プロジェクトフォルダを開く' {
    [void](Show-DirectProjectFolderOpenDialog)
} 210
$btnOpenDirectProject.Height=36
$toolTip.SetToolTip($btnOpenDirectProject,'project.json、source、targetを持つ個別プロジェクトフォルダーを直接選択します。')

$btnRelocateProject = Add-OperationButton $projectPanel '選択Projectの登録先を変更' {
    Relocate-SelectedProjectFromGui
} 215
$btnRelocateProject.Height=36
$toolTip.SetToolTip($btnRelocateProject,'プロジェクトを外部で移動した後、projects.jsonの登録先だけを変更します。')

$btnUnregisterProject = Add-OperationButton $projectPanel '登録解除' {
    Unregister-SelectedProjectFromGui
} 105
$btnUnregisterProject.Height=36
$toolTip.SetToolTip($btnUnregisterProject,'projects.jsonから登録情報だけを削除します。プロジェクトフォルダーは削除しません。')

$btnResetProjectRoot = Add-OperationButton $projectPanel '既定に戻す' {
    Reset-ProjectRootFromGui
} 110
$btnResetProjectRoot.Height = 36
$toolTip.SetToolTip($btnResetProjectRoot,'%USERPROFILE%\Developmentを既定のProject Rootとしてsettings.jsonへ保存します。登録一覧は保持します。')
$btnTrySample = Add-OperationButton $projectPanel 'サンプルを試す' {
    try { Start-VBAUpdaterSampleFromGui }
    catch {
        Append-Log ('[GUI] サンプル開始に失敗しました: '+$_.Exception.Message)
        Show-GuiMessage $_.Exception.Message 'サンプルを開始できません' ([System.Windows.Forms.MessageBoxIcon]::Error)
    }
} 150
$btnTrySample.Height=36
$toolTip.SetToolTip($btnTrySample,'実際の業務ブックを触らず、同梱サンプルでVBAUpdaterの基本操作を体験します。')

$script:btnReturnFromSample = Add-OperationButton $projectPanel 'サンプルを終了して元に戻す' {
    Restore-ProjectRootAfterSampleFromGui
} 210
$script:btnReturnFromSample.Height=36
$toolTip.SetToolTip($script:btnReturnFromSample,'サンプル開始前に使用していたプロジェクト保存先へ戻します。')
$projectPanel.SetFlowBreak($script:btnReturnFromSample,$true)





$lblProjectRootStatusCaption = New-Object System.Windows.Forms.Label
$lblProjectRootStatusCaption.Text = '状態'
$lblProjectRootStatusCaption.AutoSize = $true
$lblProjectRootStatusCaption.Margin = New-Object System.Windows.Forms.Padding(4,8,8,0)
$projectPanel.Controls.Add($lblProjectRootStatusCaption)

$lblProjectRootStatusValue = New-Object System.Windows.Forms.Label
$lblProjectRootStatusValue.Text = '-'
$lblProjectRootStatusValue.AutoSize = $true
$lblProjectRootStatusValue.Margin = New-Object System.Windows.Forms.Padding(0,8,0,0)
$projectPanel.Controls.Add($lblProjectRootStatusValue)

# Standard screen keeps only everyday actions visible.
foreach ($controlName in @(
    'lblProjectRootCaption','lblProjectRootValue',
    'lblSettingsFolderCaption','lblSettingsFolderValue',
    'lblProjectRootStatusCaption','lblProjectRootStatusValue',
    'btnChangeProjectRoot','btnOpenDirectProject','btnRelocateProject','btnUnregisterProject','btnResetProjectRoot'
)) {
    $variable = Get-Variable -Name $controlName -ErrorAction SilentlyContinue
    if ($null -ne $variable -and $null -ne $variable.Value) {
        $variable.Value.Visible = $false
    }
}

$script:btnProjectDetails = Add-OperationButton $projectPanel '詳細情報' {
    Show-VBAUpdaterProjectDetailsDialog
} 120
$script:btnProjectDetails.Height = 36

$btnAdvancedSettings = Add-OperationButton $projectPanel '詳細設定' {
    Show-VBAUpdaterSettingsDialog
} 120
$btnAdvancedSettings.Height = 36
$projectPanel.SetFlowBreak($btnAdvancedSettings,$true)

$btnUpdateBook = Add-OperationButton $primaryPanel 'ブックを更新する' {
    $message = New-BookUpdateConfirmationMessage
    if ($null -ne $message) {
        Invoke-ProjectCommand -Command 'project-sync' -ConfirmMessage $message
    }
} 220
$btnUpdateBook.Height = 52
$btnUpdateBook.Font = New-Object System.Drawing.Font('Yu Gothic UI', 11, [System.Drawing.FontStyle]::Bold)
$toolTip.SetToolTip($btnUpdateBook, '更新前の安全確認、復元ポイント作成、必要部分の更新、更新後の確認、履歴記録を自動で行います。')
$workbookRequiredButtons.Add($btnUpdateBook)

$script:btnRestoreLatest = Add-OperationButton $primaryPanel '直前の状態に戻す' {
    Invoke-DangerousProjectCommand -Command 'rollback' -Operation '直前の状態に戻す' -ChangeTarget '対象ブック' -Extra @('-RestorePoint','latest','-Apply') -RollbackWarning
} 190
$script:btnRestoreLatest.Height = 44
$toolTip.SetToolTip($script:btnRestoreLatest, '復元ポイントはまだありません。最初のブック更新時に自動作成されます。')
$workbookRequiredButtons.Add($script:btnRestoreLatest)

$btnCreateProject = Add-OperationButton $primaryPanel '開発プロジェクトを登録' {
    Show-ProjectRegistrationWizard
} 230
$btnCreateProject.Height = 44
$toolTip.SetToolTip($btnCreateProject, 'GitHubと共有する既存フォルダーとExcelブックを登録します。')

$script:btnOpenTarget = Add-OperationButton $primaryPanel '対象ブックを開く' {
    if ($null -eq $script:selectedProjectInfo -or [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.TargetPath)) {
        throw '対象ブックが選択されていません。'
    }
    if (-not (Test-Path -LiteralPath $script:selectedProjectInfo.TargetPath -PathType Leaf)) {
        throw "対象ブックが見つかりません: $($script:selectedProjectInfo.TargetPath)"
    }
    Start-Process -FilePath $script:selectedProjectInfo.TargetPath | Out-Null
} 170
$script:btnOpenTarget.Height = 44

$script:btnOpenProjectFolder = Add-OperationButton $primaryPanel 'フォルダーを開く' {
    if ($null -ne $script:selectedProjectInfo) {
        $path = [string]$script:selectedProjectInfo.ProjectDirectory
        if (-not (Test-Path -LiteralPath $path -PathType Container)) { throw "プロジェクトフォルダーが見つかりません: $path" }
        Start-Process -FilePath 'explorer.exe' -ArgumentList (Quote-ProcessArgument $path) | Out-Null
    }
} 150
$script:btnOpenProjectFolder.Height = 44

$btnOpenLogDialog = Add-OperationButton $primaryPanel 'ログを見る' {
    Show-VBAUpdaterLogDialog
} 140
$btnOpenLogDialog.Height = 44
$toolTip.SetToolTip($btnOpenLogDialog,'実行ログを別画面で確認します。')

$btnAbout = Add-OperationButton $primaryPanel 'バージョン情報' {
    # Event handlers do not reliably expose MyInvocation.MyCommand.Path under StrictMode.
    # $root is resolved once when gui.ps1 starts and is the authoritative application directory.
    $installPath = [string]$root
    if ([string]::IsNullOrWhiteSpace($installPath)) {
        $installPath = [System.AppDomain]::CurrentDomain.BaseDirectory.TrimEnd('\')
    }
    $settingsPath = Join-Path $env:LOCALAPPDATA 'VBAUpdater'
    $message = @(
        'VBAUpdater',
        ('GUI: Ver' + $script:ProductVersion),
        ('製品ビルド: ' + (Get-VBAUpdaterBuildVersion)),
        '',
        'インストール先:',
        $installPath,
        '',
        '登録情報・ログ:',
        $settingsPath,
        '',
        'インストール履歴:',
        (Get-InstallerHistoryPath),
        '',
        'この情報はサポート時の環境確認に利用できます。'
    ) -join [Environment]::NewLine
    [System.Windows.Forms.MessageBox]::Show($message,'VBAUpdater バージョン情報',[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
} 150
$btnAbout.Height = 44
$toolTip.SetToolTip($btnAbout,'VBAUpdaterのバージョン、インストール先、登録情報の保存場所を確認します。')


foreach($supportSpec in @(
    @('環境チェック', { Show-VBAUpdaterEnvironmentCheck }),
    @('総合セルフチェック', { Show-VBAUpdaterReleaseReadinessCheck }),
    @('Safety Gateテスト', { Show-VBAUpdaterSafetyGateTestDialog }),
    @('診断情報を保存', { Export-VBAUpdaterSupportInfo }),
    @('サポートZIPを作成', { Export-VBAUpdaterSupportPackage })
)) {
    $supportButton=Add-OperationButton $supportPanel ([string]$supportSpec[0]) ([scriptblock]$supportSpec[1]) 250
    $supportButton.Height=36
    $supportButton.Margin=New-Object System.Windows.Forms.Padding(4,3,4,4)
}

# Chapter4-2 HotFix5: keep the Developer page focused on developer diagnostics.
# History/restore-point and project-folder entry points remain available from the dedicated
# History / Settings pages and from the existing confirmation/reference dialog, so no feature
# is removed while duplicate buttons no longer force this frame to scroll.
[void](Add-OperationButton $referencePanel '確認・参照を開く' { Show-VBAUpdaterReferenceDialog } 250)
[void](Add-OperationButton $referencePanel '状態確認' { Invoke-ProjectCommand 'status' } 250)
[void](Add-OperationButton $referencePanel '整合性検証' { Invoke-ProjectCommand 'integrity' } 250)
[void](Add-OperationButton $referencePanel '差分確認' { Invoke-ProjectCommand 'project-diff' } 250)

$btnDeveloperPull=Add-OperationButton $sourcePanel 'ブックからソースを取得' {
    Invoke-DangerousProjectCommand -Command 'project-pull' -Operation 'ブックからソースを取得' -ChangeTarget 'sourceフォルダー'
} 190
$workbookRequiredButtons.Add($btnDeveloperPull)

$btnDeveloperPush=Add-OperationButton $bookPanel 'ソースをブックへ反映' {
    Invoke-DangerousProjectCommand -Command 'project-push' -Operation 'ソースをブックへ反映' -ChangeTarget '対象ブック'
} 190
$workbookRequiredButtons.Add($btnDeveloperPush)
$btnDeveloperSync=Add-OperationButton $bookPanel '安全なブック更新' {
    Invoke-DangerousProjectCommand -Command 'project-sync' -Operation '安全なブック更新' -ChangeTarget '対象ブック'
} 190
$workbookRequiredButtons.Add($btnDeveloperSync)
$btnDeveloperRollback=Add-OperationButton $bookPanel '最新復元ポイントへ戻す' {
    Invoke-DangerousProjectCommand -Command 'rollback' -Operation '最新復元ポイントへ戻す' -ChangeTarget '対象ブック' -Extra @('-RestorePoint','latest','-Apply') -RollbackWarning
} 224
$workbookRequiredButtons.Add($btnDeveloperRollback)

# Chapter4-2 HotFix6: all buttons inside the four developer frames share one size/spacing rule.
foreach($panel in @($supportPanel,$referencePanel,$sourcePanel,$bookPanel)) {
    foreach($button in @($panel.Controls | Where-Object { $_ -is [System.Windows.Forms.Button] })) {
        $button.Width = 250
        $button.Height = 36
        $button.MinimumSize = New-Object System.Drawing.Size(250,36)
        $button.Margin = New-Object System.Windows.Forms.Padding(4,2,4,3)
    }
}

$script:btnGitCommit = Add-OperationButton $githubPanel 'Commit（自動）' { Invoke-GitCommitFromGui } 150
$script:btnGitPush = Add-OperationButton $githubPanel 'Push' { Invoke-GitPushFromGui } 120
$script:btnGitPull = Add-OperationButton $githubPanel 'Pull' { Invoke-GitPullFromGui } 120
$script:btnGitStatus = Add-OperationButton $githubPanel 'Git状態表示' { Show-GitStatusFromGui } 145
$toolTip.SetToolTip($script:btnGitCommit,'変更内容からコミットメッセージを自動作成し、確認後に git add -A とCommitを実行します。')
$toolTip.SetToolTip($script:btnGitPush,'現在ブランチのCommitをGitHubのupstreamへPushします。')
$toolTip.SetToolTip($script:btnGitPull,'GitHubから現在ブランチへ fast-forward only でPullします。')
$toolTip.SetToolTip($script:btnGitStatus,'ブランチ、remote、ahead/behind、変更ファイルを表示します。')
$script:btnGitRefresh = Add-OperationButton $githubPanel '最新状態へ更新' { try { Update-MainGitHubStatusDisplay } catch {} } 150
$toolTip.SetToolTip($script:btnGitRefresh,'GitHub連携状態を再取得します。')
Update-GitHubButtonState

$btnToggleLog = Add-OperationButton $logPanel '▼ 詳細ログを折りたたむ' {
    $show = -not $logBox.Visible
    $logBox.Visible = $show
    $detailLogLayout.RowStyles[1].Height = $(if($show){100}else{0})
    $detailLogLayout.RowStyles[1].SizeType = $(if($show){[System.Windows.Forms.SizeType]::Percent}else{[System.Windows.Forms.SizeType]::Absolute})
    $btnToggleLog.Text = $(if ($show) { '▼ 詳細ログを折りたたむ' } else { '▶ 詳細ログを表示' })
} 190
[void](Add-OperationButton $logPanel 'ログをコピー' {
    if ([string]::IsNullOrEmpty($logBox.Text)) {
        Show-GuiMessage 'コピーするログがありません。' 'ログをコピー'
        return
    }
    [System.Windows.Forms.Clipboard]::SetText($logBox.Text)
    Show-GuiMessage '画面ログをクリップボードへコピーしました。' 'ログをコピー'
} 120)
[void](Add-OperationButton $logPanel 'ログフォルダーを開く' {
    $directory = Get-GuiLogDirectory
    Start-Process -FilePath 'explorer.exe' -ArgumentList (Quote-ProcessArgument $directory) | Out-Null
} 160)
[void](Add-OperationButton $logPanel '最新ログを開く' {
    $directory = Get-GuiLogDirectory
    $latest = Get-ChildItem -LiteralPath $directory -Filter '*.log' -File -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1
    if ($null -eq $latest) {
        Show-GuiMessage 'GUIログはまだありません。' '最新ログを開く'
        return
    }
    Start-Process -FilePath $latest.FullName | Out-Null
} 140)

# Chapter4-1_06: startup recovery.
# The Chapter4-1_06 replacement block is intentionally disabled because it could fail
# during form construction before Application.Run. Keep the last stable standard-tab
# control tree and existing GitHub functions until the replacement form is rebuilt as
# an isolated constructor in the next UI revision.

[void](Add-OperationButton $developerLogPanel 'ログをクリア' {
    $logBox.Clear()
    $developerLogBox.Clear()
} 130)
[void](Add-OperationButton $developerLogPanel 'ログをコピー' {
    if ([string]::IsNullOrEmpty($developerLogBox.Text)) {
        Show-GuiMessage 'コピーするログがありません。' 'ログをコピー'
        return
    }
    [System.Windows.Forms.Clipboard]::SetText($developerLogBox.Text)
    Show-GuiMessage '画面ログをクリップボードへコピーしました。' 'ログをコピー'
} 130)
[void](Add-OperationButton $developerLogPanel 'ログフォルダーを開く' {
    $directory = Get-GuiLogDirectory
    Start-Process -FilePath 'explorer.exe' -ArgumentList (Quote-ProcessArgument $directory) | Out-Null
} 170)
[void](Add-OperationButton $developerLogPanel '最新ログを開く' {
    $directory = Get-GuiLogDirectory
    $latest = Get-ChildItem -LiteralPath $directory -Filter '*.log' -File -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1
    if ($null -eq $latest) {
        Show-GuiMessage 'GUIログはまだありません。' '最新ログを開く'
        return
    }
    Start-Process -FilePath $latest.FullName | Out-Null
} 140)

function Select-RegisteredProject {
    param([Parameter(Mandatory=$true)][string]$ProjectName)
    Refresh-ProjectRootAndProjects -PreferredProject $ProjectName -StrictSelection
    $index = $cmbProject.Items.IndexOf($ProjectName)
    if ($index -lt 0) { throw "作成したプロジェクトを一覧から選択できません: $ProjectName" }
    $cmbProject.SelectedIndex = $index
    Update-ProjectInformation -PreserveStatus
}

function Refresh-ProjectRootInfo {
    $script:projectRootInfo = Get-ProjectRootInfoFromCli
    $lblProjectRootValue.Text = [string]$script:projectRootInfo.Path
    $toolTip.SetToolTip($lblProjectRootValue,[string]$script:projectRootInfo.Path)
    $lblSettingsFolderValue.Text=[string]$script:projectRootInfo.SettingsFolder
    $toolTip.SetToolTip($lblSettingsFolderValue,[string]$script:projectRootInfo.SettingsFolder)
    if ([bool]$script:projectRootInfo.Exists) {
        $lblProjectRootStatusValue.Text = '✓ 利用可能'
        $lblProjectRootStatusValue.ForeColor = [System.Drawing.Color]::DarkGreen
    }
    else {
        $lblProjectRootStatusValue.Text = '× 保存先が見つかりません'
        $lblProjectRootStatusValue.ForeColor = [System.Drawing.Color]::DarkRed
    }
    if (-not [string]::IsNullOrWhiteSpace([string]$script:projectRootInfo.Warning)) {
        Append-Log ('[GUI] 警告: ' + [string]$script:projectRootInfo.Warning)
    }
    if ($script:projectRootInfo.PSObject.Properties['LegacyMigrationRequired'] -and [bool]$script:projectRootInfo.LegacyMigrationRequired) {
        Append-Log ("[GUI] Ver4.17以前のVBAUpdater専用projectフォルダーに{0}件あります。移行ウィザードの対象です。" -f [int]$script:projectRootInfo.InternalProjectCount)
    }
    Update-SampleGuideButtonState
    return $script:projectRootInfo
}

function Refresh-ProjectRootAndProjects {
    param([string]$PreferredProject,[switch]$StrictSelection)
    $script:lastCodexPreview = $null
    $script:lastCodexZipPath = $null
    [void](Refresh-ProjectRootInfo)
    Refresh-Projects -PreferredProject $PreferredProject -StrictSelection:$StrictSelection
    Update-GitHubButtonState
}

function Refresh-Projects {
    param([string]$PreferredProject,[switch]$StrictSelection)
    $previous = if (-not [string]::IsNullOrWhiteSpace($PreferredProject)) {
        $PreferredProject
    }
    elseif ($cmbProject.SelectedItem -ne $null) {
        [string]$cmbProject.SelectedItem
    }
    elseif ($null -ne $script:projectRootInfo -and $script:projectRootInfo.PSObject.Properties['LastProjectRoot'] -and
        -not [string]::IsNullOrWhiteSpace([string]$script:projectRootInfo.LastProjectRoot) -and [bool]$script:projectRootInfo.LastProjectExists) {
        [System.IO.Path]::GetFileName([string]$script:projectRootInfo.LastProjectRoot)
    }
    else { $Project }
    $script:refreshingProjects = $true
    try {
        $cmbProject.Items.Clear()
        foreach ($name in @(Get-ProjectNames)) { [void]$cmbProject.Items.Add($name) }
        $lblProjectCount.Text = ($cmbProject.Items.Count.ToString() + '件')
        if ($cmbProject.Items.Count -eq 0) {
            Reset-ProjectInformation
            $lblInfoMessageValue.Text = 'projects.jsonに利用可能な登録済みプロジェクトがありません。「開発プロジェクトを登録」から追加できます。'
            Set-CurrentStatus '警告あり'
            return
        }
        $index = -1
        if (-not [string]::IsNullOrWhiteSpace($previous)) { $index = $cmbProject.Items.IndexOf($previous) }
        if ($index -ge 0) { $cmbProject.SelectedIndex = $index }
        elseif ($StrictSelection) {
            $cmbProject.SelectedIndex = -1
            Reset-ProjectInformation
            $lblInfoMessageValue.Text = '以前選択していたプロジェクトは新しい保存先にありません。'
        }
        else { $cmbProject.SelectedIndex = 0 }
    }
    finally {
        $script:refreshingProjects = $false
    }
    if ($cmbProject.SelectedIndex -ge 0) { Update-ProjectInformation }
}

$btnRefresh.Add_Click({
    try {
        $preferred = if ($cmbProject.SelectedItem -ne $null) { [string]$cmbProject.SelectedItem } else { $null }
        Refresh-ProjectRootAndProjects -PreferredProject $preferred
    }
    catch {
        Append-Log ('[GUI] プロジェクト再読込に失敗しました: ' + $_.Exception.Message)
        Set-CurrentStatus 'エラーあり'
        $lblInfoMessageValue.Text = $_.Exception.Message
    }
})

$cmbProject.Add_SelectedIndexChanged({
    if ($script:refreshingProjects -or $script:busy) { return }
    try {
        $script:lastCodexPreview = $null
        $script:lastCodexZipPath = $null
        Update-ProjectInformation
        Update-GitHubButtonState
    }
    catch {
        Append-Log ('[GUI] プロジェクト情報更新に失敗しました: ' + $_.Exception.Message)
        Set-CurrentStatus 'エラーあり'
        $lblInfoMessageValue.Text = $_.Exception.Message
    }
})

function Apply-PersistedGuiSettings {
    # Chapter4-2 Windows Standard UI: use a stable desktop-oriented default size.
    # Legacy compact/vertical window settings are ignored so the navigation shell remains readable.
    $width=[Math]::Min(1100,[Math]::Max(900,$workingArea.Width-80))
    $height=[Math]::Min(760,[Math]::Max(650,$workingArea.Height-80))
    $form.Size=New-Object System.Drawing.Size($width,$height)
    $form.WindowState=[System.Windows.Forms.FormWindowState]::Normal
}

function Save-PersistedGuiSettings {
    $bounds=if($form.WindowState-eq[System.Windows.Forms.FormWindowState]::Normal){$form.Bounds}else{$form.RestoreBounds}
    $state=if($form.WindowState-eq[System.Windows.Forms.FormWindowState]::Maximized){'Maximized'}else{'Normal'}
    Invoke-ProjectRootSettingCliSynchronously -Command 'settings-gui-set' -Arguments @('-Width',[string]$bounds.Width,'-Height',[string]$bounds.Height,'-WindowState',$state)
}

$form.Add_FormClosing({
    param($sender, $eventArgs)
    if ($script:busy -and $null -ne $script:process -and -not $script:process.HasExited) {
        # Chapter3-7_05:
        # ブックを書き換える処理をGUI終了で強制Killすると、更新途中のブックを残す危険がある。
        # project-sync / rollback は完了まで終了不可とし、CLI側の復元・検証処理を最後まで走らせる。
        if ($script:currentCommand -in @('project-sync','rollback','workbook-apply')) {
            Append-Log ('[GUI] 安全保護: ブック変更処理中の終了要求を拒否しました。Command=' + [string]$script:currentCommand)
            Show-GuiMessage (
                "対象ブックの安全処理を実行中です。`r`n`r`n途中で終了するとブックが不完全な状態になる可能性があるため、現在はVBAUpdaterを終了できません。`r`n`r`n処理完了後に終了してください。"
            ) '処理完了までお待ちください' ([System.Windows.Forms.MessageBoxIcon]::Warning)
            $eventArgs.Cancel = $true
            return
        }
        $answer = [System.Windows.Forms.MessageBox]::Show(
            '処理が実行中です。終了すると実行中の処理を中断します。GUIを終了しますか？',
            '終了確認',
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Warning)
        if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) {
            $eventArgs.Cancel = $true
            return
        }
        Clear-CliRuntime $true
    }
    else {
        Clear-CliRuntime $false
    }
    try{Save-PersistedGuiSettings}catch{Append-Log ('[GUI] GUI設定を保存できませんでした: '+$_.Exception.Message)}
    $script:pollTimer.Stop()
    $script:pollTimer.Dispose()
    try { Stop-VBAUpdaterOperationalSession -UserDataRoot (Get-VBAUpdaterUserDataRoot) }
    catch { Append-Log ('[GUI] セッション終了マーカーを削除できませんでした: '+$_.Exception.Message) }
})

Reset-ProjectInformation
try {
    $script:operationalSession=Start-VBAUpdaterOperationalSession -UserDataRoot (Get-VBAUpdaterUserDataRoot) -Build (Get-VBAUpdaterBuildVersion)
    if($script:operationalSession.PreviousUnclean){Append-Log '[GUI] 運用安全診断: 前回セッションの正常終了記録がありません。環境チェックを推奨します。'}
} catch { Append-Log ('[GUI] 運用セッションマーカーを開始できませんでした: '+$_.Exception.Message) }
Append-Log 'VBA Project Update System GUI Ver4.18.0 / Chapter5-2 Operational Safety Guard'
Append-Log 'プロジェクトを選択し、「ブックを更新する」をクリックしてください。'
try { Trim-GuiLogs } catch { Append-Log ('[GUI] 警告: GUIログ整理に失敗しました: ' + $_.Exception.Message) }
$script:startupFailure = $null
try { Refresh-ProjectRootAndProjects } catch {
    $script:startupFailure = $_.Exception.Message
    Append-Log ('[GUI] 初期情報の読込に失敗しました: ' + $_.Exception.Message)
    if ($null -eq $script:projectRootInfo) {
        $lblProjectRootStatusValue.Text = '× 保存先を確認できません'
        $lblProjectRootStatusValue.ForeColor = [System.Drawing.Color]::DarkRed
    }
    Set-CurrentStatus 'エラーあり'
    $lblInfoMessageValue.Text = $_.Exception.Message
}
$skipStartupRecovery = $RenewalSelfTest -or $RegistrationSelfTest -or $RegistrationHotFixSelfTest -or
    $ProjectRootSelfTest -or $ProjectRootMigrationSelfTest -or $CodexIntegrationSelfTest -or $DirectReferenceSelfTest -or $UsabilitySelfTest
if (-not $skipStartupRecovery -and $null -ne $script:projectRootInfo -and [bool]$script:projectRootInfo.RecoveryRequired) {
    $recovered = Invoke-ProjectRootStartupRecovery
    if (-not $recovered) {
        $script:pollTimer.Stop()
        $script:pollTimer.Dispose()
        $form.Dispose()
        exit 0
    }
}
try{Apply-PersistedGuiSettings}catch{Append-Log ('[GUI] GUI設定を復元できませんでした: '+$_.Exception.Message)}
if (-not $skipStartupRecovery -and $null -ne $script:projectRootInfo -and
    $script:projectRootInfo.PSObject.Properties['LegacyMigrationRequired'] -and [bool]$script:projectRootInfo.LegacyMigrationRequired) {
    [void](Invoke-LegacyProjectMigrationWizard)
}
if ($DirectReferenceSelfTest) {
    $selfTestExitCode=0
    try {
        if (-not [string]::IsNullOrWhiteSpace($script:startupFailure)) { throw ('直接参照GUIの初期読込に失敗しました: '+$script:startupFailure) }
        if ($lblVersion.Text -ne ('V' + $script:ProductVersion)) { throw '直接参照GUIのバージョン表示が一致しません。' }
        if ($null -eq $btnOpenDirectProject -or $btnOpenDirectProject.Text -ne 'プロジェクトフォルダを開く' -or $operationButtons.IndexOf($btnOpenDirectProject) -lt 0) { throw '直接参照ボタンを初期化できませんでした。' }
        if ($null -eq $script:selectedProjectInfo -or [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.ProjectRoot)) { throw '保存済みの直接プロジェクトを復元できませんでした。' }
        if ($lblDirectProjectRootValue.Text -ne [string]$script:selectedProjectInfo.ProjectRoot -or $lblSourceFolderValue.Text -ne [string]$script:selectedProjectInfo.SourcePath -or $lblTargetFolderValue.Text -ne [string]$script:selectedProjectInfo.TargetDirectory) { throw '直接プロジェクトの共通判定結果がGUI表示と一致しません。' }
        if ($lblGitValue.Text -notmatch 'Git管理あり' -or $lblDirectStatusValue.Text -notmatch '利用可能|前回選択を復元') { throw 'Git管理または利用可否表示が一致しません。' }
        if ($null-eq$script:selectedProjectInfo.TargetFingerprint -or [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.TargetFingerprint.Sha256)) { throw '対象ブックの選択時fingerprintを保持できませんでした。' }
        if (-not $btnUpdateBook.Enabled -or -not $script:btnOpenTarget.Enabled) { throw '利用可能な直接プロジェクトの操作ボタンが有効ではありません。' }
        Write-Host '  [OK] Windows PowerShell 5.1で直接プロジェクトの起動復元、詳細表示、ボタン状態を確認しました。'
    }
    catch { Write-Error $_.Exception.Message;$selfTestExitCode=1 }
    finally { $script:pollTimer.Stop();$script:pollTimer.Dispose();$form.Dispose() }
    exit $selfTestExitCode
}
if ($CodexIntegrationSelfTest) {
    Write-Host '  [SKIP] Codex GUI連携はChapter4-1で廃止され、GitHub連携へ移行しました。'
    $script:pollTimer.Stop(); $script:pollTimer.Dispose(); $form.Dispose()
    exit 0
}
if ($RenewalSelfTest) {
    $selfTestExitCode = 0
    try {
        Invoke-GuiRenewalSelfTest
        if ($tabs.SelectedIndex -ne 0 -or $tabs.SelectedTab -ne $standardTab) {
            throw '初期表示が「ブック更新」タブではありません。'
        }
        if ($btnUpdateBook.Text -ne 'ブックを更新する') {
            throw '一般利用者向け主ボタンを初期化できませんでした。'
        }
        if ($logBox.Visible) {
            throw '一般利用者向け詳細ログが初期状態で折りたたまれていません。'
        }
        if ($cmbProject.Items.Count -gt 0 -and $cmbProject.SelectedIndex -lt 0) {
            throw 'プロジェクトが自動選択されていません。'
        }
        if (-not [string]::IsNullOrWhiteSpace($Project) -and
            -not [string]::Equals([string]$cmbProject.SelectedItem, $Project, [System.StringComparison]::OrdinalIgnoreCase)) {
            throw "起動引数で指定したプロジェクトが選択されていません: $Project"
        }
        $targetExists = $false
        if ($null -ne $script:selectedProjectInfo -and
            -not [string]::IsNullOrWhiteSpace([string]$script:selectedProjectInfo.TargetPath) -and
            [string]$script:selectedProjectInfo.TargetPath -ne '-') {
            $targetExists = Test-Path -LiteralPath ([string]$script:selectedProjectInfo.TargetPath) -PathType Leaf
            if ($toolTip.GetToolTip($lblTargetPathValue) -ne [string]$script:selectedProjectInfo.TargetPath) {
                throw '対象ブックのフルパスを確認するToolTipが設定されていません。'
            }
        }
        if ($script:btnOpenTarget.Enabled -ne $targetExists) {
            throw '「対象ブックを開く」ボタンの有効状態がファイル存在状態と一致しません。'
        }
        Write-Host '  [OK] Windows PowerShell 5.1でGUI構成、初期タブ、自動選択、ログ初期状態を確認しました。'
    }
    catch {
        Write-Error $_.Exception.Message
        $selfTestExitCode = 1
    }
    finally {
        $script:pollTimer.Stop()
        $script:pollTimer.Dispose()
        $form.Dispose()
    }
    exit $selfTestExitCode
}
if ($RegistrationSelfTest) {
    $selfTestExitCode = 0
    try {
        Invoke-GuiRegistrationSelfTest
        if ($btnCreateProject.Text -ne '開発プロジェクトを登録') {
            throw '一般利用者向け画面に新規登録ボタンを初期化できませんでした。'
        }
        if ($operationButtons.IndexOf($btnCreateProject) -lt 0) {
            throw '新規登録ボタンが操作中ロック対象に登録されていません。'
        }
        Write-Host '  [OK] Windows PowerShell 5.1で初回登録GUIを初期化しました。'
    }
    catch {
        Write-Error $_.Exception.Message
        $selfTestExitCode = 1
    }
    finally {
        $script:pollTimer.Stop()
        $script:pollTimer.Dispose()
        $form.Dispose()
    }
    exit $selfTestExitCode
}
if ($RegistrationHotFixSelfTest) {
    $selfTestExitCode = 0
    try {
        Invoke-GuiRegistrationHotFixSelfTest
        Write-Host '  [OK] Windows PowerShell 5.1でChapter12-1 HotFix GUIテストを完了しました。'
    }
    catch {
        Write-Error $_.Exception.Message
        $selfTestExitCode = 1
    }
    finally {
        $script:pollTimer.Stop()
        $script:pollTimer.Dispose()
        $form.Dispose()
    }
    exit $selfTestExitCode
}
if ($ProjectRootMigrationSelfTest) {
    $selfTestExitCode = 0
    try {
        Invoke-GuiProjectRootMigrationSelfTest
        if ($operationButtons.IndexOf($btnChangeProjectRoot) -lt 0 -or $operationButtons.IndexOf($btnResetProjectRoot) -lt 0) {
            throw '保存先変更操作が操作中ロック対象に登録されていません。'
        }
        if ($ExpectedMigrationStatus -eq 'Missing') {
            if ($null -eq $script:projectRootInfo -or [bool]$script:projectRootInfo.Exists) { throw 'GUIが保存先喪失状態を保持していません。' }
            if ($lblProjectRootStatusValue.Text -ne '× 保存先が見つかりません') { throw 'GUIの保存先喪失表示が一致しません。' }
            if ($cmbProject.Items.Count -ne 0 -or $null -ne $script:selectedProjectInfo) { throw '保存先喪失時に古いプロジェクト選択が残っています。' }
        }
        elseif ($ExpectedMigrationStatus -eq 'OK') {
            if ($null -eq $script:projectRootInfo -or -not [bool]$script:projectRootInfo.Exists) { throw 'GUIが利用可能な保存先を認識していません。' }
            if ($lblProjectRootStatusValue.Text -ne '✓ 利用可能') { throw 'GUIの利用可能表示が一致しません。' }
        }
        Write-Host '  [OK] Windows PowerShell 5.1でProject Root Migration GUIを初期化しました。'
    }
    catch {
        Write-Error $_.Exception.Message
        $selfTestExitCode = 1
    }
    finally {
        $script:pollTimer.Stop()
        $script:pollTimer.Dispose()
        $form.Dispose()
    }
    exit $selfTestExitCode
}
if ($ProjectRootSelfTest) {
    $selfTestExitCode = 0
    try {
        if (-not [string]::IsNullOrWhiteSpace($script:startupFailure)) {
            throw ('外部プロジェクトルートの初期読込に失敗しました: ' + $script:startupFailure)
        }
        Invoke-GuiProjectRootSelfTest
        if ($null -eq $script:projectRootInfo -or [string]$lblProjectRootValue.Text -ne [string]$script:projectRootInfo.Path) {
            throw 'CLIで解決したプロジェクト保存先がGUIに表示されていません。'
        }
        if ($operationButtons.IndexOf($btnChangeProjectRoot) -lt 0 -or $operationButtons.IndexOf($btnResetProjectRoot) -lt 0) {
            throw '保存先変更ボタンが操作中ロック対象に登録されていません。'
        }
        $expectedNames = @(Get-ProjectNames)
        if ($cmbProject.Items.Count -ne $expectedNames.Count) {
            throw 'GUIのプロジェクト一覧が現在の保存先と一致しません。'
        }
        Write-Host ("  [OK] Windows PowerShell 5.1で外部プロジェクトルートGUIを初期化しました: {0}" -f $script:projectRootInfo.Path)
    }
    catch {
        Write-Error $_.Exception.Message
        $selfTestExitCode = 1
    }
    finally {
        $script:pollTimer.Stop()
        $script:pollTimer.Dispose()
        $form.Dispose()
    }
    exit $selfTestExitCode
}
if ($UsabilitySelfTest) {
    $script:pollTimer.Stop()
    $script:pollTimer.Dispose()
    $form.Dispose()
    if (-not [string]::IsNullOrWhiteSpace($script:startupFailure)) {
        Write-Error ('GUI Usabilityランタイムセルフテストに失敗しました: ' + $script:startupFailure)
        exit 1
    }
    Write-Host 'GUI Usabilityランタイムセルフテストに成功しました。'
    exit 0
}

# Chapter4-2_01 HotFix1: Windows Standard UI shell.
# The legacy tab-based control tree is kept alive for compatibility/self-tests, but the normal
# interactive session uses a left-navigation shell. Existing controls are re-parented rather than
# recreated so update/rollback/GitHub event handlers remain the proven Chapter4-1 implementations.
function Initialize-WindowsStandardUiShell {
    $tabs.Visible = $false
    $rootLayout.Controls.Remove($tabs)

    $shell = New-Object System.Windows.Forms.TableLayoutPanel
    $shell.Dock = 'Fill'
    $shell.ColumnCount = 2
    $shell.RowCount = 1
    $shell.Margin = New-Object System.Windows.Forms.Padding(0)
    [void]$shell.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Absolute', 180)))
    [void]$shell.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle('Percent', 100)))
    $rootLayout.Controls.Add($shell,0,1)

    $nav = New-Object System.Windows.Forms.Panel
    $nav.Dock = 'Fill'
    $nav.BackColor = [System.Drawing.Color]::FromArgb(246,247,249)
    $nav.Padding = New-Object System.Windows.Forms.Padding(10,14,10,10)
    $shell.Controls.Add($nav,0,0)

    $content = New-Object System.Windows.Forms.Panel
    $content.Dock = 'Fill'
    $content.Padding = New-Object System.Windows.Forms.Padding(14,10,10,10)
    $shell.Controls.Add($content,1,0)

    $script:standardUiPages = @{}
    foreach($name in @('Home','GitHub','History','Settings','Developer')) {
        $page = New-Object System.Windows.Forms.Panel
        $page.Dock = 'Fill'
        $page.Visible = $false
        $page.AutoScroll = $true
        $content.Controls.Add($page)
        $script:standardUiPages[$name] = $page
    }

    function New-NavButton([string]$text,[int]$top,[string]$pageName) {
        $b = New-Object System.Windows.Forms.Button
        $b.Text = $text
        $b.Width = 154
        $b.Height = 44
        $b.Left = 8
        $b.Top = $top
        $b.FlatStyle = 'Flat'
        $b.TextAlign = 'MiddleLeft'
        $b.Padding = New-Object System.Windows.Forms.Padding(14,0,0,0)
        $b.Tag = $pageName
        $b.Add_Click({
            param($sender,$eventArgs)
            foreach($k in $script:standardUiPages.Keys){ $script:standardUiPages[$k].Visible = $false }
            $targetPage = $script:standardUiPages[[string]$sender.Tag]
            if ($null -ne $targetPage) {
                $targetPage.Visible = $true
                $targetPage.BringToFront()
            }
        })
        $nav.Controls.Add($b)
        return $b
    }

    $navTitle = New-Object System.Windows.Forms.Label
    $navTitle.Text = 'メニュー'
    $navTitle.Font = New-Object System.Drawing.Font('Yu Gothic UI',10,[System.Drawing.FontStyle]::Bold)
    $navTitle.AutoSize = $true
    $navTitle.Left = 14
    $navTitle.Top = 6
    $nav.Controls.Add($navTitle)
    $btnHome = New-NavButton 'ホーム' 38 'Home'
    $btnGitHubNav = New-NavButton 'GitHub' 88 'GitHub'
    $btnHistoryNav = New-NavButton '履歴' 138 'History'
    $btnSettingsNav = New-NavButton '設定' 188 'Settings'
    $btnDeveloperNav = New-NavButton '開発者' 238 'Developer'

    # HOME: everyday operations only.
    $homeLayout = New-Object System.Windows.Forms.TableLayoutPanel
    $homeLayout.Dock = 'Fill'
    $homeLayout.ColumnCount = 1
    $homeLayout.RowCount = 4
    $homeLayout.Padding = New-Object System.Windows.Forms.Padding(0)
    # HotFix1: reserve enough height for project selector, sample controls, Details and Settings rows.
    [void]$homeLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute',160)))
    [void]$homeLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute',110)))
    [void]$homeLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Absolute',195)))
    [void]$homeLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle('Percent',100)))
    $script:standardUiPages['Home'].Controls.Add($homeLayout)
    foreach($ctl in @($projectPanel,$statusGroup,$primaryGroup,$statusLogGroup)) {
        if($null-ne$ctl -and $null-ne$ctl.Parent){ $ctl.Parent.Controls.Remove($ctl) }
    }
    $projectPanel.Dock='Fill'; $projectPanel.AutoScroll=$false
    # Chapter4-2_01 HotFix2: avoid duplicate navigation. Settings/history are available from the left menu.
    if ($null -ne $btnAdvancedSettings) { $btnAdvancedSettings.Visible = $false }
    if ($null -ne $script:btnProjectDetails) { $script:btnProjectDetails.Visible = $false }
    $statusGroup.Dock='Fill'; $primaryGroup.Dock='Fill'; $statusLogGroup.Dock='Fill'
    $homeLayout.Controls.Add($projectPanel,0,0)
    $homeLayout.Controls.Add($statusGroup,0,1)
    $homeLayout.Controls.Add($primaryGroup,0,2)
    $homeLayout.Controls.Add($statusLogGroup,0,3)

    # GitHub page: one authoritative location for repository operations.
    if($null-ne$mainGitHubGroup -and $null-ne$mainGitHubGroup.Parent){$mainGitHubGroup.Parent.Controls.Remove($mainGitHubGroup)}
    $mainGitHubGroup.Dock='Top'; $mainGitHubGroup.Height=210
    $script:standardUiPages['GitHub'].Controls.Add($mainGitHubGroup)
    $ghIntro=New-Object System.Windows.Forms.Label
    $ghIntro.Text='選択中ProjectのGitリポジトリ状態を確認し、Commit / Push / Pullを実行します。'
    $ghIntro.AutoSize=$true; $ghIntro.Top=225; $ghIntro.Left=6
    $script:standardUiPages['GitHub'].Controls.Add($ghIntro)

    # History page: safe read-only history/restore-point entry points.
    $historyTitle=New-Object System.Windows.Forms.Label
    $historyTitle.Text='履歴と復元ポイント'; $historyTitle.Font=New-Object System.Drawing.Font('Yu Gothic UI',14,[System.Drawing.FontStyle]::Bold)
    $historyTitle.AutoSize=$true; $historyTitle.Left=8; $historyTitle.Top=8; $script:standardUiPages['History'].Controls.Add($historyTitle)
    $historyPanel=New-Object System.Windows.Forms.FlowLayoutPanel
    $historyPanel.Left=8; $historyPanel.Top=52; $historyPanel.Width=420; $historyPanel.Height=260
    $historyPanel.FlowDirection='TopDown'; $historyPanel.WrapContents=$false; $historyPanel.AutoScroll=$true
    $historyPanel.Padding=New-Object System.Windows.Forms.Padding(8)
    $script:standardUiPages['History'].Controls.Add($historyPanel)
    foreach($historySpec in @(
        @('インストール履歴', { Show-VBAUpdaterInstallerHistory }),
        @('更新履歴', { Show-VBAUpdaterProjectCommandOutput 'history' '更新履歴' }),
        @('復元ポイント一覧', { Show-VBAUpdaterProjectCommandOutput 'rollback-list' '復元ポイント一覧' }),
        @('ログを見る', { Show-VBAUpdaterLogDialog })
    )) {
        $historyButton=Add-OperationButton $historyPanel ([string]$historySpec[0]) ([scriptblock]$historySpec[1]) 340
        $historyButton.Height=42; $historyButton.Margin=New-Object System.Windows.Forms.Padding(4,4,4,8)
    }

    # Settings page: keep advanced configuration out of the daily home screen.
    $settingsTitle=New-Object System.Windows.Forms.Label
    $settingsTitle.Text='設定'; $settingsTitle.Font=New-Object System.Drawing.Font('Yu Gothic UI',14,[System.Drawing.FontStyle]::Bold)
    $settingsTitle.AutoSize=$true; $settingsTitle.Left=8; $settingsTitle.Top=8; $script:standardUiPages['Settings'].Controls.Add($settingsTitle)
    $settingsPanel=New-Object System.Windows.Forms.FlowLayoutPanel
    $settingsPanel.Left=8; $settingsPanel.Top=52; $settingsPanel.Width=440; $settingsPanel.Height=480
    $settingsPanel.FlowDirection='TopDown'; $settingsPanel.WrapContents=$false; $settingsPanel.AutoScroll=$true
    $settingsPanel.Padding=New-Object System.Windows.Forms.Padding(8)
    $script:standardUiPages['Settings'].Controls.Add($settingsPanel)
    foreach($settingSpec in @(
        @('プロジェクト保存先を変更', { Show-ProjectRootChangeDialog }),
        @('プロジェクトフォルダを開く', { [void](Show-DirectProjectFolderOpenDialog) }),
        @('選択Projectの登録先を変更', { Relocate-SelectedProjectFromGui }),
        @('登録解除', { Unregister-SelectedProjectFromGui }),
        @('既定に戻す', { Reset-ProjectRootFromGui }),
        @('設定の整合性を確認', { Test-VBAUpdaterConfigIntegrity }),
        @('設定バックアップ・復元', { Show-VBAUpdaterConfigBackupDialog }),
        @('更新プログラムを確認', { Show-VBAUpdaterUpdateCheck })
    )) {
        $settingButton=Add-OperationButton $settingsPanel ([string]$settingSpec[0]) ([scriptblock]$settingSpec[1]) 360
        $settingButton.Height=42; $settingButton.Margin=New-Object System.Windows.Forms.Padding(4,4,4,8)
    }

    # Developer page reuses the existing diagnostic control tree, without duplicate GitHub controls.
    if($null-ne$developerLayout -and $null-ne$developerLayout.Parent){$developerLayout.Parent.Controls.Remove($developerLayout)}
    $developerLayout.Dock='Fill'
    $script:standardUiPages['Developer'].Controls.Add($developerLayout)

    # Developer diagnostics/support are integrated into the developer action grid above.
    $script:standardUiPages['Home'].Visible=$true
    $script:standardUiPages['Home'].BringToFront()
    $form.Text=('VBAプロジェクト更新システム V' + $script:ProductVersion)
}

Initialize-WindowsStandardUiShell

[void]$form.ShowDialog()
