﻿VBAUpdater Ver1.0

Windows Standard UI
- ホーム
- GitHub
- 履歴
- 設定
- 開発者

Chapter5-1_01ではRelease Candidate検証工程を整理しています。
アプリ本体の機能基準はChapter4-2 FINALから変更ありません。

初めて利用する場合は START_HERE.txt を確認してください。

Build ID: MVP_Release05_HotFix4_TestLiteralCompliance_4.18.1
