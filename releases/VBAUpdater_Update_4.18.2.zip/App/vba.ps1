﻿param(
    [Parameter(Position = 0)]
    [string]$Command,

    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$RemainingArgs
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$script:ToolName = "VBA Project Update System"
$script:ToolVersion = "4.18.0"
$script:Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:ProjectRootOverride = $null
$script:DirectProjectPathOverride = $null
$script:DirectWorkbookPathOverride = $null
$script:ProjectRootCorrectionMessage = ''
$script:DefaultProjectRootTestOverride = $null
$script:ProjectRootSettingsEnvironmentVariable = 'VBAUPDATER_SETTINGS_PATH'
$script:TestExecutionContext = $null
$script:RuntimeLogRootOverride = $null
$script:RuntimeBackupRootOverride = $null
$script:CurrentTestProjectRoot = $null
$script:LegacyTestRootOverride = $null
$script:PackageAddinPath = Join-Path $script:Root "addin\VBAUpdater.xlam"
$script:EngineSourcePath = Join-Path $script:Root "engine\modVBAUpdaterEngine.bas"
$script:AddinConfigPath = Join-Path $script:Root "addin\installed-addin.json"
$script:NormalizerModulePath = Join-Path $script:Root "tools\CodeNormalizer.psm1"
$script:PrepareSourceModulePath = Join-Path $script:Root "tools\PrepareSource.psm1"
$script:ProjectRegistrationModulePath = Join-Path $script:Root "tools\ProjectRegistration.psm1"
$script:WorkbookUpdateModulePath = Join-Path $script:Root "tools\WorkbookUpdate.psm1"
$script:CodexImportFailureTestHook = $null
$script:JsonOutputRequested = $false

if (-not (Test-Path -LiteralPath $script:ProjectRegistrationModulePath -PathType Leaf)) {
    throw "共通Project Registrationモジュールが見つかりません: $script:ProjectRegistrationModulePath"
}
Import-Module $script:ProjectRegistrationModulePath -Force -ErrorAction Stop
if (-not (Test-Path -LiteralPath $script:WorkbookUpdateModulePath -PathType Leaf)) {
    throw "Workbook更新モジュールが見つかりません: $script:WorkbookUpdateModulePath"
}
Import-Module $script:WorkbookUpdateModulePath -Force -DisableNameChecking -ErrorAction Stop

function Write-Info([string]$Message) { Write-Host $Message -ForegroundColor Cyan }
function Write-Success([string]$Message) { Write-Host $Message -ForegroundColor Green }
function Write-Warn([string]$Message) { Write-Host $Message -ForegroundColor Yellow }
function Write-Failure([string]$Message) { Write-Host $Message -ForegroundColor Red }

function Show-Usage {
@"
$script:ToolName Ver$script:ToolVersion

Usage:
  .\vba.cmd version
  .\vba.cmd gui [-Project <name>]
  .\vba.cmd addin-build
  .\vba.cmd addin-doctor
  .\vba.cmd preflight -TargetDir "<target-folder>" [-WorkbookPath "<xlsm>"]
  .\vba.cmd compile-check -WorkbookPath "<xlsm>" [-MacroName "<macro>"]
  .\vba.cmd preflight-test
  .\vba.cmd project-preflight -Project <name> [-ProjectRoot "<absolute-folder>"]
  .\vba.cmd project-root
  .\vba.cmd project-root-check [-Path "<absolute-folder>"] [-Json]
  .\vba.cmd project-root-set -Path "<absolute-folder>"
  .\vba.cmd project-root-reset
  .\vba.cmd settings [-Json]
  .\vba.cmd projects [-Json]
  .\vba.cmd project-unregister -Project <name>
  .\vba.cmd project-relocate -Project <name> -ProjectFolder "<moved-folder>"
  .\vba.cmd project-migration-check [-SourceRoot "<Ver4.17-root>"] [-Json]
  .\vba.cmd project-migrate -DestinationRoot "<Development>" [-SourceRoot "<Ver4.17-root>"] [-Project <name>]
  .\vba.cmd project-folder-check -Path "<project-folder>" [-WorkbookPath "<xlsm|xlam|xlsb>"] [-Json]
  .\vba.cmd project-folder-set -Path "<project-folder>" [-WorkbookPath "<xlsm|xlam|xlsb>"] [-Json]
  .\vba.cmd project-registration-validate -ProjectFolder "<existing-project-folder>" -WorkbookPath "<xlsm|xlsb|xlam>" [-Json]
  .\vba.cmd project-create -ProjectFolder "<existing-project-folder>" -WorkbookPath "<xlsm|xlsb|xlam>"
  .\vba.cmd project-push [-Project <name>] [-ProjectRoot "<parent-or-project-folder>"]
  .\vba.cmd workbook-validate [-Project <name>] [-Json]
  .\vba.cmd workbook-diff [-Project <name>] [-Json]
  .\vba.cmd workbook-apply [-Project <name>] [-Json]
  .\vba.cmd workbook-verify [-Project <name>] [-Json]
  .\vba.cmd workbook-test
  .\vba.cmd workbook-integration-test
  .\vba.cmd test-isolation-test
  .\vba.cmd regression-test
  .\vba.cmd isolated-excel-regression-test
  .\vba.cmd project-pull [-Project <name>] [-ProjectRoot "<parent-or-project-folder>"]
  .\vba.cmd project-sync -Project <name> [-ApplyDeletes] [-ProjectRoot "<absolute-folder>"]
  .\vba.cmd codex-export -Project <name> [-OutputDir "<folder>" | -OutputPath "<zip>"] [-Json]
  .\vba.cmd codex-import-preview -Project <name> -ZipPath "<zip>" [-Json]
  .\vba.cmd codex-import -Project <name> -ZipPath "<zip>" [-Preview] [-Confirm] [-ApplyDeletes -ConfirmDelete] [-Json]
  .\vba.cmd status [-Project <name>]
  .\vba.cmd history [-Project <name>] [-Limit <count>]
  .\vba.cmd cli-core-test
  .\vba.cmd gui-process-test
  .\vba.cmd gui-usability-test
  .\vba.cmd gui-renewal-test
  .\vba.cmd project-registration-test
  .\vba.cmd project-registration-hotfix-test
  .\vba.cmd project-create-test
  .\vba.cmd project-registration-v418-test
  .\vba.cmd settings-persistence-test
  .\vba.cmd project-root-test
  .\vba.cmd project-root-migration-test
  .\vba.cmd codex-integration-test
  .\vba.cmd project-folder-direct-reference-test
  .\vba.cmd compile-gate-optional-test
  .\vba.cmd code-read-test -Project <name>
  .\vba.cmd rollback-list -Project <name>
  .\vba.cmd rollback -Project <name> [-RestorePoint <id|latest>] [-Apply]
  .\vba.cmd rollback-test
  .\vba.cmd integrity -Project <name> [-SkipHooks]
  .\vba.cmd integrity-test
  .\vba.cmd project-compile -Project <name>
  .\vba.cmd manifest-test
  .\vba.cmd normalize-test
  .\vba.cmd prepare-source-test
  .\vba.cmd prepare-source -Project <name>
  .\vba.cmd project-diff -Project <name>
  .\vba.cmd standalone-diff-test
  .\vba.cmd differential-push-test
  .\vba.cmd test-create
  .\vba.cmd push-standard -WorkbookPath "<xlsm>" -SourcePath "<bas>" -ComponentName "<name>"
  .\vba.cmd push-class -WorkbookPath "<xlsm>" -SourcePath "<cls>" -ComponentName "<name>"
  .\vba.cmd push-document -WorkbookPath "<xlsm>" -SourcePath "<cls>" -ComponentName "<name>"
  .\vba.cmd push-userform -WorkbookPath "<xlsm>" -SourcePath "<frm>" -ComponentName "<name>"
  .\vba.cmd class-test-create
  .\vba.cmd class-test-run
  .\vba.cmd document-test-create
  .\vba.cmd document-test-push
  .\vba.cmd document-test-run
  .\vba.cmd userform-test-create
  .\vba.cmd userform-test-push
  .\vba.cmd userform-test-run
  .\vba.cmd test-run
  .\vba.cmd help

Commands:
  version       Display the installed version.
  gui           Open the Windows GUI.
  addin-build   Build VBAUpdater.xlam from the engine source.
  addin-doctor  Open the add-in in a fresh Excel process and call Ping.
  preflight     Validate target workbook discovery and source safety before push.
  compile-check Reopen a workbook and execute a compile-gate macro.
  preflight-test Run abnormal-case regression tests for target discovery.
  project-preflight Validate a project.json manifest and resolve all paths.
  project-root      Display the active project root and settings source.
  project-root-check Check root availability and detect complete project folders.
  project-root-set  Save one external project root in the user settings file.
  project-root-reset Remove the saved setting and use the default %USERPROFILE%\Development root.
  settings          Display the persistent settings folder, Project Root, and registered project count.
  projects          Display projects restored from projects.json.
  project-unregister Remove one projects.json entry without deleting its project folder.
  project-relocate  Update one registered project after its folder has been moved externally.
  project-migration-check Detect Ver4.17 and earlier projects that need shared-folder migration.
  project-migrate Safely copy and verify legacy projects under an existing Development root.
  project-folder-check Inspect one direct project folder without changing settings.
  project-folder-set Save the last successfully opened direct project folder.
  project-registration-validate Validate an existing development folder and workbook without changing them.
  project-create    Register an existing development folder, copy the workbook, then run project-pull.
  project-push      Prepare sources, compare, update changed components only, then compile.
  workbook-validate Validate the optional Workbook definition without changing Excel.
  workbook-diff     Compare explicitly managed Workbook targets without changing Excel.
  workbook-apply    Preflight, back up, apply, save, verify, and restore on failure.
  workbook-verify   Verify that the Workbook definition has no remaining differences.
  workbook-test     Run non-COM Workbook schema and safety regression tests.
  workbook-integration-test Create a dedicated workbook and test diff, apply, idempotency, restore, and cleanup.
  test-isolation-test Verify explicit Test Mode, denied roots, Canary hashes, and Workbook Open auditing.
  regression-test Run the non-business isolated regression suite with a Canary file.
  isolated-excel-regression-test Run Excel integration only against fresh fixture copies.
  project-pull      Export manifest components from the workbook and safely replace source files.
  project-sync      Apply changed/added components and report or apply safe managed deletions.
  codex-export      Create a direct-root, filtered project ZIP for Codex development.
  codex-import-preview Safely validate a returned ZIP and classify changes without writing.
  codex-import      Back up and transactionally apply a validated Codex ZIP (no automatic sync).
  status            Display read-only synchronization status for one or all projects.
  history           Display operation history from JSON logs for one or all projects.
  cli-core-test     Run CLI argument parser and project discovery regression tests.
  gui-process-test  Run GUI child-process output and exit-code regression tests.
  gui-usability-test Run GUI usability and safety regression tests.
  gui-renewal-test  Run Chapter11-1 GUI renewal regression tests.
  project-registration-test Run Chapter11-2 GUI registration-wizard regression tests.
  project-registration-hotfix-test Run Chapter12-1 registration-name-edit HotFix tests.
  project-create-test Run initial-project creation and cleanup regression tests.
  project-registration-v418-test Run shared-folder registration, GUI enablement, path, migration, and CLI compatibility tests.
  settings-persistence-test Run Chapter2 LocalAppData settings/projects persistence regression tests.
  project-root-test Run Chapter12-1 external-project-root regression tests.
  project-root-migration-test Run Chapter12-2 missing-root recovery and candidate-detection tests.
  codex-integration-test Run Chapter12-3 export/import, ZIP safety, GUI, and rollback tests.
  project-folder-direct-reference-test Run Chapter12-4 direct-folder, compatibility, and safety tests.
  compile-gate-optional-test Run optional/required compile-gate regression tests.
  code-read-test    Verify VBA CodeModule text acquisition, including export fallback.
  rollback-list     List restore points created before project updates.
  rollback          Preview or apply restoration of a target workbook.
  rollback-test     Run non-COM rollback file-operation regression tests.
  integrity         Validate manifest, sources, target, package files, and restore points.
  integrity-test    Run non-COM integrity-check regression tests.
  project-compile   Run the compile gate defined by project.json.
  manifest-test     Run manifest validation regression tests.
  normalize-test    Run code-normalization regression tests.
  prepare-source-test Run PrepareSource regression tests.
  prepare-source     Run hooks and validate generated source files.
  project-diff      Compare manifest sources with workbook components without updating.
  standalone-diff-test Run non-COM regression tests for diff result generation.
  differential-push-test Run non-COM regression tests for update-plan selection.
  test-create   Create a dedicated standard-module update test.
  push-standard    Update one standard module through VBAUpdater.xlam.
  push-class       Update one class module through VBAUpdater.xlam.
  push-document    Update one ThisWorkbook/Sheet/ChartSheet module.
  push-userform    Replace one UserForm using its .frm and .frx files.
  class-test-create Create a dedicated class-module update test.
  class-test-run   Verify that the class-module update returns CLASS_NEW_VALUE.
  document-test-create Create the Document Module test workbook and sources.
  document-test-push Update ThisWorkbook and Sheet1 in the test workbook.
  document-test-run Verify both Document Module update results.
  userform-test-create Create a UserForm update test workbook and source pair.
  userform-test-push Replace the test UserForm through VBAUpdater.xlam.
  userform-test-run Verify UserForm code, Caption, and label design.
  test-run         Verify that the standard-module test returns NEW_VALUE.
"@ | Write-Host
}

function ConvertTo-CliArgumentList {
    param([AllowNull()][object]$Arguments)

    $list = New-Object 'System.Collections.Generic.List[string]'
    if ($null -ne $Arguments) {
        foreach ($value in $Arguments) {
            if ($null -ne $value) { $list.Add([string]$value) }
        }
    }
    return ,$list
}

function Parse-CliArguments {
    param([AllowNull()][object]$Arguments)

    $values = ConvertTo-CliArgumentList -Arguments $Arguments
    $options = @{}
    $switches = @{}
    $positionals = New-Object 'System.Collections.Generic.List[string]'

    $i = 0
    while ($i -lt $values.Count) {
        $token = [string]$values[$i]
        if ($token.StartsWith('-')) {
            $equalsIndex = $token.IndexOf('=')
            if ($equalsIndex -gt 0) {
                $name = $token.Substring(0,$equalsIndex).ToLowerInvariant()
                $options[$name] = $token.Substring($equalsIndex + 1)
            }
            elseif (($i + 1) -lt $values.Count -and -not ([string]$values[$i + 1]).StartsWith('-')) {
                $options[$token.ToLowerInvariant()] = [string]$values[$i + 1]
                $i++
            }
            else {
                $switches[$token.ToLowerInvariant()] = $true
            }
        }
        else {
            $positionals.Add($token)
        }
        $i++
    }

    return [PSCustomObject]@{
        Values = $values
        Options = $options
        Switches = $switches
        Positionals = $positionals
    }
}

function Get-CliOption {
    param([Parameter(Mandatory=$true)]$Parsed,[Parameter(Mandatory=$true)][string]$Name)
    $key=$Name.ToLowerInvariant()
    if($Parsed.Options.ContainsKey($key)){return [string]$Parsed.Options[$key]}
    return $null
}

function Test-CliSwitch {
    param([Parameter(Mandatory=$true)]$Parsed,[Parameter(Mandatory=$true)][string]$Name)
    return $Parsed.Switches.ContainsKey($Name.ToLowerInvariant())
}

function Get-NamedArgument {
    param([AllowNull()][object]$Arguments, [string]$Name)
    $parsed=Parse-CliArguments -Arguments $Arguments
    return Get-CliOption -Parsed $parsed -Name $Name
}

function Get-DefaultProjectRoot {
    if (-not [string]::IsNullOrWhiteSpace($script:DefaultProjectRootTestOverride)) {
        return [System.IO.Path]::GetFullPath($script:DefaultProjectRootTestOverride)
    }
    $userProfile = [Environment]::GetFolderPath([Environment+SpecialFolder]::UserProfile)
    if ([string]::IsNullOrWhiteSpace($userProfile)) { $userProfile = $env:USERPROFILE }
    if ([string]::IsNullOrWhiteSpace($userProfile)) { throw 'ユーザープロファイルの場所を取得できません。' }
    return [System.IO.Path]::GetFullPath((Join-Path $userProfile 'Development'))
}

function Get-LegacyInternalProjectRoot {
    return [System.IO.Path]::GetFullPath((Join-Path $script:Root 'project'))
}

function Get-ProjectRootSettingsPaths {
    $override = [Environment]::GetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable)
    if (-not [string]::IsNullOrWhiteSpace($override)) {
        $expandedOverride = [Environment]::ExpandEnvironmentVariables($override.Trim('"'))
        if (-not [System.IO.Path]::IsPathRooted($expandedOverride)) {
            throw "$($script:ProjectRootSettingsEnvironmentVariable)には絶対パスを指定してください: $expandedOverride"
        }
        return [PSCustomObject]@{
            User=[System.IO.Path]::GetFullPath($expandedOverride)
            Folder=Split-Path -Parent ([System.IO.Path]::GetFullPath($expandedOverride))
            Projects=Join-Path (Split-Path -Parent ([System.IO.Path]::GetFullPath($expandedOverride))) 'projects.json'
            Logs=Join-Path (Split-Path -Parent ([System.IO.Path]::GetFullPath($expandedOverride))) 'logs'
            Cache=Join-Path (Split-Path -Parent ([System.IO.Path]::GetFullPath($expandedOverride))) 'cache'
            Legacy=(Join-Path $script:Root 'config\settings.json')
            IsTestOverride=$true
        }
    }

    $localAppData = [Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)
    if ([string]::IsNullOrWhiteSpace($localAppData)) { $localAppData = $env:LOCALAPPDATA }
    if ([string]::IsNullOrWhiteSpace($localAppData)) { throw 'LOCALAPPDATAの場所を取得できません。' }
    $settingsFolder=Join-Path $localAppData 'VBAUpdater'
    return [PSCustomObject]@{
        User=(Join-Path $settingsFolder 'settings.json')
        Folder=$settingsFolder
        Projects=(Join-Path $settingsFolder 'projects.json')
        Logs=(Join-Path $settingsFolder 'logs')
        Cache=(Join-Path $settingsFolder 'cache')
        Legacy=(Join-Path $script:Root 'config\settings.json')
        IsTestOverride=$false
    }
}

function ConvertTo-AbsoluteProjectRootPath {
    param([AllowEmptyString()][string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { throw 'プロジェクトルートのパスを指定してください。' }
    $expanded = [Environment]::ExpandEnvironmentVariables($Path.Trim('"'))
    if (-not [System.IO.Path]::IsPathRooted($expanded)) { throw "プロジェクトルートは絶対パスで指定してください: $expanded" }
    if ($expanded.IndexOfAny([System.IO.Path]::GetInvalidPathChars()) -ge 0) { throw "無効なWindowsパスです: $expanded" }
    try { return [System.IO.Path]::GetFullPath($expanded).TrimEnd([System.IO.Path]::DirectorySeparatorChar,[System.IO.Path]::AltDirectorySeparatorChar) }
    catch { throw "無効なWindowsパスです: $expanded / 詳細: $($_.Exception.Message)" }
}

function Test-PathsEqual {
    param([AllowNull()][string]$First,[AllowNull()][string]$Second)
    if ([string]::IsNullOrWhiteSpace($First) -or [string]::IsNullOrWhiteSpace($Second)) { return $false }
    try {
        $left=[System.IO.Path]::GetFullPath($First).TrimEnd('\','/')
        $right=[System.IO.Path]::GetFullPath($Second).TrimEnd('\','/')
        return [string]::Equals($left,$right,[System.StringComparison]::OrdinalIgnoreCase)
    }
    catch { return $false }
}

function Get-DirectProjectPathResolution {
    param([Parameter(Mandatory=$true)][string]$Path)
    $requested=ConvertTo-AbsoluteProjectRootPath -Path $Path
    $resolved=$requested
    $correction=''
    $leaf=[System.IO.Path]::GetFileName($requested)
    if ($leaf -in @('source','target')) {
        $parent=Split-Path -Parent $requested
        if (-not [string]::IsNullOrWhiteSpace($parent) -and (Test-Path -LiteralPath (Join-Path $parent 'project.json') -PathType Leaf)) {
            $resolved=[System.IO.Path]::GetFullPath($parent)
            $correction=("{0}フォルダーが選択されたため、親のプロジェクトフォルダーへ補正しました: {1}" -f $leaf,$resolved)
        }
    }
    return [PSCustomObject]@{RequestedPath=$requested;Path=$resolved;Corrected=(-not (Test-PathsEqual $requested $resolved));CorrectionMessage=$correction}
}

function Test-IsDirectProjectPath {
    param([AllowNull()][string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { return $false }
    try {
        $resolution=Get-DirectProjectPathResolution -Path $Path
        return (Test-Path -LiteralPath (Join-Path $resolution.Path 'project.json') -PathType Leaf)
    }
    catch { return $false }
}

function Test-DirectProjectToolSafety {
    param([Parameter(Mandatory=$true)][string]$Path)
    $toolRoot=[System.IO.Path]::GetFullPath($script:Root)
    if (Test-PathsEqual $Path $toolRoot) { throw 'VBAUpdater本体フォルダーはプロジェクトフォルダーに指定できません。' }
    foreach($reservedName in @('addin','engine','tools','tests','test','config','logs','backups')) {
        if (Test-PathsEqual $Path (Join-Path $toolRoot $reservedName)) {
            throw "VBAUpdater本体の重要フォルダーはプロジェクトフォルダーに指定できません: $Path"
        }
    }
}

function Get-ManifestPropertyText {
    param([AllowNull()]$Object,[Parameter(Mandatory=$true)][string]$Name)
    if ($null -eq $Object -or $null -eq $Object.PSObject.Properties[$Name]) { return '' }
    return [string]$Object.$Name
}

function Get-DirectWorkbookSelection {
    param(
        [Parameter(Mandatory=$true)][string]$TargetDirectory,
        [AllowNull()]$Manifest,
        [AllowNull()][string]$WorkbookPath
    )
    $configuredPath=''
    if ($null -ne $Manifest -and $null -ne $Manifest.PSObject.Properties['target']) {
        $configuredFile=Get-ManifestPropertyText -Object $Manifest.target -Name 'file'
        if (-not [string]::IsNullOrWhiteSpace($configuredFile)) {
            $configuredPath=if([System.IO.Path]::IsPathRooted($configuredFile)){[System.IO.Path]::GetFullPath($configuredFile)}else{[System.IO.Path]::GetFullPath((Join-Path $TargetDirectory $configuredFile))}
        }
    }

    if (-not [string]::IsNullOrWhiteSpace($WorkbookPath)) {
        $explicit=ConvertTo-AbsoluteProjectRootPath -Path $WorkbookPath
        if (-not (Test-Path -LiteralPath $explicit -PathType Leaf)) { throw "指定された対象ブックが見つかりません: $explicit" }
        if ([System.IO.Path]::GetExtension($explicit).ToLowerInvariant() -notin @('.xlsm','.xlam','.xlsb')) { throw "対象ブックの拡張子が対応外です: $explicit" }
        if (-not (Test-PathsEqual (Split-Path -Parent $explicit) $TargetDirectory)) { throw "対象ブックはtargetフォルダー直下から選択してください: $explicit" }
        return [PSCustomObject]@{WorkbookPath=$explicit;Candidates=@($explicit);Status='Explicit';ConfiguredPath=$configuredPath;Message='指定された対象ブックを使用します。'}
    }
    if (-not [string]::IsNullOrWhiteSpace($configuredPath) -and (Test-Path -LiteralPath $configuredPath -PathType Leaf)) {
        return [PSCustomObject]@{WorkbookPath=$configuredPath;Candidates=@($configuredPath);Status='Configured';ConfiguredPath=$configuredPath;Message='project.jsonで指定された対象ブックを使用します。'}
    }
    if (-not (Test-Path -LiteralPath $TargetDirectory -PathType Container)) {
        return [PSCustomObject]@{WorkbookPath='';Candidates=@();Status='TargetMissing';ConfiguredPath=$configuredPath;Message='targetフォルダーが見つかりません。'}
    }
    foreach($extension in @('.xlsm','.xlam','.xlsb')) {
        $candidates=@(Get-ChildItem -LiteralPath $TargetDirectory -File -ErrorAction Stop | Where-Object {$_.Extension.ToLowerInvariant() -eq $extension} | Sort-Object Name | ForEach-Object {$_.FullName})
        if ($candidates.Count -eq 1) {
            return [PSCustomObject]@{WorkbookPath=[string]$candidates[0];Candidates=$candidates;Status='AutoDetected';ConfiguredPath=$configuredPath;Message=("対象ブックを自動検出しました: {0}" -f [System.IO.Path]::GetFileName($candidates[0]))}
        }
        if ($candidates.Count -gt 1) {
            return [PSCustomObject]@{WorkbookPath='';Candidates=$candidates;Status='Multiple';ConfiguredPath=$configuredPath;Message=("対象ブックが複数あります。{0}から選択してください。" -f $extension)}
        }
    }
    return [PSCustomObject]@{WorkbookPath='';Candidates=@();Status='Missing';ConfiguredPath=$configuredPath;Message='targetフォルダーに対象ブックがありません。プロジェクト選択は保存できます。'}
}

function Get-ProjectFolderCheckResult {
    param([Parameter(Mandatory=$true)][string]$Path,[AllowNull()][string]$WorkbookPath)
    $errors=New-Object 'System.Collections.Generic.List[string]'
    $warnings=New-Object 'System.Collections.Generic.List[string]'
    $messages=New-Object 'System.Collections.Generic.List[string]'
    $resolution=Get-DirectProjectPathResolution -Path $Path
    $root=$resolution.Path
    if (-not [string]::IsNullOrWhiteSpace($resolution.CorrectionMessage)) { $messages.Add($resolution.CorrectionMessage) }
    try { Test-DirectProjectToolSafety -Path $root } catch { $errors.Add($_.Exception.Message) }

    $exists=Test-Path -LiteralPath $root -PathType Container
    $manifestPath=Join-Path $root 'project.json'
    $manifest=$null
    if (-not $exists) { $errors.Add("プロジェクトフォルダーが見つかりません: $root") }
    elseif (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) { $errors.Add("project.jsonが見つかりません: $manifestPath") }
    else {
        try { $manifest=Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json }
        catch { $errors.Add("project.jsonを読み込めません: $($_.Exception.Message)") }
    }

    $projectName=if($null -ne $manifest){Get-ManifestPropertyText -Object $manifest -Name 'projectName'}else{''}
    if ([string]::IsNullOrWhiteSpace($projectName)) { $projectName=[System.IO.Path]::GetFileName($root) }
    $sourceValue='source'
    if ($null -ne $manifest -and $null -eq $manifest.PSObject.Properties['source']) { $errors.Add('project.jsonにsource設定がありません。') }
    if ($null -ne $manifest -and $null -ne $manifest.PSObject.Properties['source']) {
        $configuredSource=Get-ManifestPropertyText -Object $manifest.source -Name 'root'
        if (-not [string]::IsNullOrWhiteSpace($configuredSource)) { $sourceValue=$configuredSource }
    }
    $targetValue='target'
    if ($null -ne $manifest -and $null -eq $manifest.PSObject.Properties['target']) { $errors.Add('project.jsonにtarget設定がありません。') }
    if ($null -ne $manifest -and $null -ne $manifest.PSObject.Properties['target']) {
        $configuredTarget=Get-ManifestPropertyText -Object $manifest.target -Name 'directory'
        if (-not [string]::IsNullOrWhiteSpace($configuredTarget)) { $targetValue=$configuredTarget }
    }
    $sourcePath=if([System.IO.Path]::IsPathRooted($sourceValue)){[System.IO.Path]::GetFullPath($sourceValue)}else{[System.IO.Path]::GetFullPath((Join-Path $root $sourceValue))}
    $targetDirectory=if([System.IO.Path]::IsPathRooted($targetValue)){[System.IO.Path]::GetFullPath($targetValue)}else{[System.IO.Path]::GetFullPath((Join-Path $root $targetValue))}
    $sourceExists=Test-Path -LiteralPath $sourcePath -PathType Container
    $targetExists=Test-Path -LiteralPath $targetDirectory -PathType Container
    if (-not $sourceExists) { $errors.Add("sourceフォルダーが見つかりません: $sourcePath") }
    if (-not $targetExists) { $errors.Add("targetフォルダーが見つかりません: $targetDirectory") }
    if (Test-PathsEqual $sourcePath $targetDirectory) { $errors.Add('sourceとtargetに同じフォルダーは指定できません。') }

    $selection=[PSCustomObject]@{WorkbookPath='';Candidates=@();Status='Unavailable';ConfiguredPath='';Message='対象ブックを判定できません。'}
    if ($targetExists) {
        try { $selection=Get-DirectWorkbookSelection -TargetDirectory $targetDirectory -Manifest $manifest -WorkbookPath $WorkbookPath }
        catch { $errors.Add($_.Exception.Message) }
    }
    if (-not [string]::IsNullOrWhiteSpace($selection.Message)) { $messages.Add($selection.Message) }
    if ($selection.Status -in @('Missing','Multiple')) { $warnings.Add($selection.Message) }
    $structuralAvailable=$exists -and ($null -ne $manifest) -and $sourceExists -and $targetExists -and -not (Test-PathsEqual $sourcePath $targetDirectory) -and @($errors).Count -eq 0
    $canPush=$structuralAvailable -and -not [string]::IsNullOrWhiteSpace([string]$selection.WorkbookPath)
    $state=if($canPush){'Available'}else{'Unavailable'}
    return [PSCustomObject]@{
        SchemaVersion='1.0';ProjectName=$projectName;ProjectRoot=$root;RequestedPath=$resolution.RequestedPath
        Corrected=[bool]$resolution.Corrected;CorrectionMessage=$resolution.CorrectionMessage
        SourcePath=$sourcePath;TargetDirectory=$targetDirectory;WorkbookPath=[string]$selection.WorkbookPath
        WorkbookCandidates=@($selection.Candidates);WorkbookSelectionStatus=[string]$selection.Status
        ConfiguredWorkbookPath=[string]$selection.ConfiguredPath;ManifestPath=$manifestPath
        IsGitRepository=(Test-Path -LiteralPath (Join-Path $root '.git') -PathType Container)
        Exists=$exists;IsAvailable=$structuralAvailable;CanSaveSelection=$structuralAvailable;CanPush=$canPush;Status=$state
        Messages=@($messages.ToArray());Warnings=@($warnings.ToArray());Errors=@($errors.ToArray())
    }
}

function Test-ProjectRootCandidate {
    param(
        [AllowEmptyString()][string]$Path,
        [switch]$CreateIfMissing,
        [switch]$SkipWriteTest,
        [scriptblock]$WriteProbe
    )

    $resolved = ConvertTo-AbsoluteProjectRootPath -Path $Path
    if (Test-Path -LiteralPath $resolved -PathType Leaf) { throw "プロジェクトルートにファイルは指定できません: $resolved" }
    $toolRoot = [System.IO.Path]::GetFullPath($script:Root)
    if ([string]::Equals($resolved,$toolRoot,[System.StringComparison]::OrdinalIgnoreCase)) {
        throw 'VBAUpdater本体フォルダーそのものはプロジェクトルートに指定できません。'
    }
    foreach ($reservedName in @('addin','engine','tools','tests','test','config','logs','backups')) {
        $reservedPath = [System.IO.Path]::GetFullPath((Join-Path $toolRoot $reservedName))
        if ([string]::Equals($resolved,$reservedPath,[System.StringComparison]::OrdinalIgnoreCase)) {
            throw "VBAUpdater本体の重要フォルダーはプロジェクトルートに指定できません: $resolved"
        }
    }
    if (Test-Path -LiteralPath (Join-Path $resolved 'project.json') -PathType Leaf) {
        throw "個別のプロジェクトフォルダーが指定されています。複数プロジェクトを格納する親フォルダーを指定してください: $resolved"
    }

    if (-not (Test-Path -LiteralPath $resolved -PathType Container)) {
        if (-not $CreateIfMissing) { throw "プロジェクトルートが見つかりません: $resolved" }
        try { New-Item -ItemType Directory -Path $resolved -ErrorAction Stop | Out-Null }
        catch { throw "プロジェクトルートを作成できません: $resolved / 詳細: $($_.Exception.Message)" }
    }

    if (-not $SkipWriteTest) {
        if ($null -ne $WriteProbe) {
            try { & $WriteProbe $resolved }
            catch { throw "プロジェクトルートへ書き込めません: $resolved / 詳細: $($_.Exception.Message)" }
        }
        else {
            $probePath = Join-Path $resolved ('.vbaupdater_write_probe_' + [guid]::NewGuid().ToString('N') + '.tmp')
            $stream = $null
            try {
                $stream = [System.IO.File]::Open($probePath,[System.IO.FileMode]::CreateNew,[System.IO.FileAccess]::Write,[System.IO.FileShare]::None)
                $stream.WriteByte(1)
            }
            catch { throw "プロジェクトルートへ書き込めません: $resolved / 詳細: $($_.Exception.Message)" }
            finally {
                if ($null -ne $stream) { $stream.Dispose() }
                if (Test-Path -LiteralPath $probePath -PathType Leaf) { Remove-Item -LiteralPath $probePath -Force -ErrorAction SilentlyContinue }
            }
        }
    }
    return $resolved
}

function Read-ProjectRootSettingsFile {
    param([Parameter(Mandatory=$true)][string]$Path)
    try { $settings = Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json }
    catch { throw "設定JSONを読み込めません: $($_.Exception.Message)" }
    if ($null -eq $settings.PSObject.Properties['schemaVersion'] -or [string]$settings.schemaVersion -ne '1.0') {
        throw '設定ファイルのschemaVersionは1.0である必要があります。'
    }
    if ($null -eq $settings.PSObject.Properties['projectRoot'] -or [string]::IsNullOrWhiteSpace([string]$settings.projectRoot)) {
        throw '設定ファイルにprojectRootがありません。'
    }
    $rootPath = ConvertTo-AbsoluteProjectRootPath -Path ([string]$settings.projectRoot)
    if (Test-Path -LiteralPath $rootPath -PathType Leaf) { throw "設定されたprojectRootがファイルを指しています: $rootPath" }
    return [PSCustomObject]@{ ProjectRoot=$rootPath; Settings=$settings }
}

function New-PersistentSettingsPayload {
    param(
        [Parameter(Mandatory=$true)][string]$ProjectRoot,
        [AllowNull()]$ExistingSettings,
        [AllowNull()][string]$LastProjectRoot,
        [AllowNull()][string]$LastWorkbookPath,
        [switch]$ClearRecentProject,
        [AllowNull()]$GuiSettings
    )
    $map=[ordered]@{}
    if ($null -ne $ExistingSettings) {
        foreach($property in @($ExistingSettings.PSObject.Properties)) { $map[$property.Name]=$property.Value }
    }
    $map['schemaVersion']='1.0'
    $map['version']=$script:ToolVersion
    $map['projectRoot']=$ProjectRoot
    if ($ClearRecentProject) {
        [void]$map.Remove('lastProjectRoot')
        [void]$map.Remove('lastWorkbookPath')
    }
    else {
        if (-not [string]::IsNullOrWhiteSpace($LastProjectRoot)) { $map['lastProjectRoot']=$LastProjectRoot }
        if (-not [string]::IsNullOrWhiteSpace($LastWorkbookPath)) { $map['lastWorkbookPath']=$LastWorkbookPath }
    }
    if ($null -ne $GuiSettings) { $map['gui']=$GuiSettings }
    elseif (-not $map.Contains('gui')) {
        $map['gui']=[PSCustomObject]@{windowWidth=1060;windowHeight=930;windowState='Normal'}
    }
    if (-not $map.Contains('logging')) { $map['logging']=[PSCustomObject]@{enabled=$true;retentionCount=100} }
    $map['updatedAt']=[DateTime]::Now.ToString('o')
    return [PSCustomObject]$map
}

function Write-SettingsPayloadAtomic {
    param([Parameter(Mandatory=$true)][string]$Path,[Parameter(Mandatory=$true)]$Payload)
    $directory=Split-Path -Parent $Path
    New-Item -ItemType Directory -Path $directory -Force -ErrorAction Stop|Out-Null
    $tempPath=$Path+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
    $backupPath=$Path+'.'+[guid]::NewGuid().ToString('N')+'.bak'
    try {
        [System.IO.File]::WriteAllText($tempPath,($Payload|ConvertTo-Json -Depth 10),(New-Object System.Text.UTF8Encoding($false)))
        [void](Read-ProjectRootSettingsFile -Path $tempPath)
        if (Test-Path -LiteralPath $Path -PathType Leaf) {
            [System.IO.File]::Replace($tempPath,$Path,$backupPath,$true)
            if (Test-Path -LiteralPath $backupPath -PathType Leaf) { Remove-Item -LiteralPath $backupPath -Force }
        }
        else { [System.IO.File]::Move($tempPath,$Path) }
    }
    finally {
        if (Test-Path -LiteralPath $tempPath -PathType Leaf) { Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue }
        if (Test-Path -LiteralPath $backupPath -PathType Leaf) { Remove-Item -LiteralPath $backupPath -Force -ErrorAction SilentlyContinue }
    }
    return $Path
}

function Get-ProjectRegistryNameFromFolder {
    param([Parameter(Mandatory=$true)][string]$ProjectFolder)
    $name=[System.IO.Path]::GetFileName($ProjectFolder.TrimEnd('\','/'))
    $manifestPath=Join-Path $ProjectFolder 'project.json'
    if (Test-Path -LiteralPath $manifestPath -PathType Leaf) {
        try {
            $manifest=Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8|ConvertFrom-Json
            if ($manifest.PSObject.Properties['projectName'] -and -not [string]::IsNullOrWhiteSpace([string]$manifest.projectName)) { $name=[string]$manifest.projectName }
        }
        catch { throw "project.jsonを読み込めません: $manifestPath / 詳細: $($_.Exception.Message)" }
    }
    return $name
}

function Get-ProjectRegistryEntriesFromRoot {
    param([AllowNull()][string]$ProjectRoot)
    $result=New-Object 'System.Collections.Generic.List[object]'
    if ([string]::IsNullOrWhiteSpace($ProjectRoot) -or -not (Test-Path -LiteralPath $ProjectRoot -PathType Container)) { return ,$result }
    foreach($directory in @(Get-ChildItem -LiteralPath $ProjectRoot -Directory -ErrorAction SilentlyContinue|Sort-Object Name)) {
        if (-not (Test-Path -LiteralPath (Join-Path $directory.FullName 'project.json') -PathType Leaf)) { continue }
        $result.Add([PSCustomObject]@{Name=(Get-ProjectRegistryNameFromFolder -ProjectFolder $directory.FullName);ProjectFolder=$directory.FullName;RegisteredAt=[DateTime]::Now.ToString('o');UpdatedAt=[DateTime]::Now.ToString('o')})
    }
    return ,$result
}

function Read-ProjectsRegistryFile {
    param([Parameter(Mandatory=$true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return @() }
    try { $payload=Get-Content -LiteralPath $Path -Raw -Encoding UTF8|ConvertFrom-Json }
    catch { throw "projects.jsonを読み込めません: $($_.Exception.Message)" }
    $valid=New-Object 'System.Collections.Generic.List[object]'
    $seen=New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach($item in @($payload)) {
        if ($null -eq $item -or $null -eq $item.PSObject.Properties['ProjectFolder']) { continue }
        try { $folder=ConvertTo-AbsoluteProjectRootPath -Path ([string]$item.ProjectFolder) } catch { continue }
        if (-not (Test-Path -LiteralPath (Join-Path $folder 'project.json') -PathType Leaf)) { continue }
        if (-not $seen.Add($folder)) { continue }
        $name=if($item.PSObject.Properties['Name'] -and -not [string]::IsNullOrWhiteSpace([string]$item.Name)){[string]$item.Name}else{Get-ProjectRegistryNameFromFolder -ProjectFolder $folder}
        $registeredAt=if($item.PSObject.Properties['RegisteredAt']){[string]$item.RegisteredAt}else{[DateTime]::Now.ToString('o')}
        $updatedAt=if($item.PSObject.Properties['UpdatedAt']){[string]$item.UpdatedAt}else{$registeredAt}
        $valid.Add([PSCustomObject]@{Name=$name;ProjectFolder=$folder;RegisteredAt=$registeredAt;UpdatedAt=$updatedAt})
    }
    return @($valid.ToArray())
}

function Write-ProjectsRegistryFile {
    param([Parameter(Mandatory=$true)][AllowEmptyCollection()][object[]]$Projects)
    $paths=Get-ProjectRootSettingsPaths
    New-Item -ItemType Directory -Path $paths.Folder -Force -ErrorAction Stop|Out-Null
    $normalized=New-Object 'System.Collections.Generic.List[object]'
    $seen=New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach($item in @($Projects)) {
        if ($null -eq $item) { continue }
        $folder=ConvertTo-AbsoluteProjectRootPath -Path ([string]$item.ProjectFolder)
        if (-not (Test-Path -LiteralPath (Join-Path $folder 'project.json') -PathType Leaf)) { continue }
        if (-not $seen.Add($folder)) { continue }
        $name=if(-not [string]::IsNullOrWhiteSpace([string]$item.Name)){[string]$item.Name}else{Get-ProjectRegistryNameFromFolder -ProjectFolder $folder}
        $registeredAt=if($item.PSObject.Properties['RegisteredAt'] -and -not [string]::IsNullOrWhiteSpace([string]$item.RegisteredAt)){[string]$item.RegisteredAt}else{[DateTime]::Now.ToString('o')}
        $normalized.Add([PSCustomObject]@{Name=$name;ProjectFolder=$folder;RegisteredAt=$registeredAt;UpdatedAt=[DateTime]::Now.ToString('o')})
    }
    $json=ConvertTo-Json -InputObject @($normalized.ToArray()|Sort-Object Name,ProjectFolder) -Depth 6
    $tempPath=$paths.Projects+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
    $backupPath=$paths.Projects+'.'+[guid]::NewGuid().ToString('N')+'.bak'
    try {
        [System.IO.File]::WriteAllText($tempPath,$json,(New-Object System.Text.UTF8Encoding($false)))
        [void](Get-Content -LiteralPath $tempPath -Raw -Encoding UTF8|ConvertFrom-Json)
        if (Test-Path -LiteralPath $paths.Projects -PathType Leaf) {
            [System.IO.File]::Replace($tempPath,$paths.Projects,$backupPath,$true)
            if (Test-Path -LiteralPath $backupPath -PathType Leaf) { Remove-Item -LiteralPath $backupPath -Force }
        }
        else { [System.IO.File]::Move($tempPath,$paths.Projects) }
    }
    finally {
        if (Test-Path -LiteralPath $tempPath -PathType Leaf) { Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue }
        if (Test-Path -LiteralPath $backupPath -PathType Leaf) { Remove-Item -LiteralPath $backupPath -Force -ErrorAction SilentlyContinue }
    }
    return $paths.Projects
}

function Initialize-PersistentSettingsStore {
    $paths=Get-ProjectRootSettingsPaths
    foreach($directory in @($paths.Folder,$paths.Logs,$paths.Cache)) { New-Item -ItemType Directory -Path $directory -Force -ErrorAction Stop|Out-Null }
    if (-not (Test-Path -LiteralPath $paths.User -PathType Leaf)) {
        $existing=$null
        $root=Get-DefaultProjectRoot
        if (Test-Path -LiteralPath $paths.Legacy -PathType Leaf) {
            try { $legacy=Read-ProjectRootSettingsFile -Path $paths.Legacy;$existing=$legacy.Settings;$root=$legacy.ProjectRoot } catch { Write-Verbose ('旧Project Root設定を読み込めませんでした: ' + $_.Exception.Message) }
        }
        $payload=New-PersistentSettingsPayload -ProjectRoot $root -ExistingSettings $existing
        [void](Write-SettingsPayloadAtomic -Path $paths.User -Payload $payload)
    }
    if (-not (Test-Path -LiteralPath $paths.Projects -PathType Leaf)) {
        $loaded=Read-ProjectRootSettingsFile -Path $paths.User
        $initial=@((Get-ProjectRegistryEntriesFromRoot -ProjectRoot $loaded.ProjectRoot).ToArray())
        [void](Write-ProjectsRegistryFile -Projects $initial)
    }
    return $paths
}

function Get-InternalRegisteredProjectCount {
    $legacyRoot = Get-LegacyInternalProjectRoot
    if (-not (Test-Path -LiteralPath $legacyRoot -PathType Container)) { return 0 }
    return @((Get-ChildItem -LiteralPath $legacyRoot -Directory -ErrorAction SilentlyContinue | Where-Object {
        Test-Path -LiteralPath (Join-Path $_.FullName 'project.json') -PathType Leaf
    })).Count
}

function New-ProjectRootInfo {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$Source,
        [string]$SettingsPath,
        [string]$Warning='',
        [string]$LastProjectRoot='',
        [string]$LastWorkbookPath='',
        [AllowNull()]$Settings
    )
    $defaultRoot = Get-DefaultProjectRoot
    $external = -not [string]::Equals($Path,$defaultRoot,[System.StringComparison]::OrdinalIgnoreCase)
    $legacyRoot = Get-LegacyInternalProjectRoot
    $internalCount = Get-InternalRegisteredProjectCount
    $settingsPaths=Get-ProjectRootSettingsPaths
    $registeredCount=0
    if (Test-Path -LiteralPath $settingsPaths.Projects -PathType Leaf) {
        try { $registeredCount=@(Read-ProjectsRegistryFile -Path $settingsPaths.Projects).Count } catch { Write-Verbose ('登録Project件数を読み込めませんでした: ' + $_.Exception.Message) }
    }
    return [PSCustomObject]@{
        SchemaVersion='1.0'
        Path=$Path
        Source=$Source
        SettingsPath=$SettingsPath
        SettingsFolder=$settingsPaths.Folder
        ProjectsPath=$settingsPaths.Projects
        LogsFolder=$settingsPaths.Logs
        CacheFolder=$settingsPaths.Cache
        RegisteredProjects=$registeredCount
        Gui=$(if($null -ne $Settings -and $Settings.PSObject.Properties['gui']){$Settings.gui}else{[PSCustomObject]@{windowWidth=1060;windowHeight=930;windowState='Normal'}})
        Logging=$(if($null -ne $Settings -and $Settings.PSObject.Properties['logging']){$Settings.logging}else{[PSCustomObject]@{enabled=$true;retentionCount=100}})
        DefaultPath=$defaultRoot
        External=$external
        Exists=(Test-Path -LiteralPath $Path -PathType Container)
        Warning=$Warning
        InternalProjectCount=$internalCount
        LegacyProjectRoot=$legacyRoot
        LegacyMigrationRequired=($internalCount -gt 0)
        LastProjectRoot=$LastProjectRoot
        LastProjectExists=(-not [string]::IsNullOrWhiteSpace($LastProjectRoot) -and (Test-Path -LiteralPath $LastProjectRoot -PathType Container))
        LastWorkbookPath=$LastWorkbookPath
        LastWorkbookExists=(-not [string]::IsNullOrWhiteSpace($LastWorkbookPath) -and (Test-Path -LiteralPath $LastWorkbookPath -PathType Leaf))
        RecoveryRequired=((-not (Test-Path -LiteralPath $Path -PathType Container)) -or (-not [string]::IsNullOrWhiteSpace($LastProjectRoot) -and -not (Test-Path -LiteralPath $LastProjectRoot -PathType Container)))
    }
}

function Get-ProjectRootInfo {
    if (-not [string]::IsNullOrWhiteSpace($script:ProjectRootOverride)) {
        $overrideRoot = Test-ProjectRootCandidate -Path $script:ProjectRootOverride -SkipWriteTest
        return New-ProjectRootInfo -Path $overrideRoot -Source 'CliArgument'
    }

    $paths = Initialize-PersistentSettingsStore
    $settingsPath = $null
    $source = $null
    if (Test-Path -LiteralPath $paths.User -PathType Leaf) { $settingsPath=$paths.User; $source='UserSettings' }
    elseif (Test-Path -LiteralPath $paths.Legacy -PathType Leaf) { $settingsPath=$paths.Legacy; $source='LegacySettings' }

    if ($null -ne $settingsPath) {
        try {
            $loaded = Read-ProjectRootSettingsFile -Path $settingsPath
            $warning = ''
            if (-not (Test-Path -LiteralPath $loaded.ProjectRoot -PathType Container)) {
                $warning = "設定されたプロジェクトルートが見つかりません: $($loaded.ProjectRoot)"
            }
            $lastProjectRoot=''
            $lastWorkbookPath=''
            if ($loaded.Settings.PSObject.Properties['lastProjectRoot'] -and -not [string]::IsNullOrWhiteSpace([string]$loaded.Settings.lastProjectRoot)) {
                try { $lastProjectRoot=ConvertTo-AbsoluteProjectRootPath -Path ([string]$loaded.Settings.lastProjectRoot) }
                catch { $warning=("{0} 最後に開いたプロジェクト設定が無効です: {1}" -f $warning,$_.Exception.Message).Trim() }
            }
            if ($loaded.Settings.PSObject.Properties['lastWorkbookPath'] -and -not [string]::IsNullOrWhiteSpace([string]$loaded.Settings.lastWorkbookPath)) {
                try { $lastWorkbookPath=ConvertTo-AbsoluteProjectRootPath -Path ([string]$loaded.Settings.lastWorkbookPath) }
                catch { $warning=("{0} 最後に選択した対象ブック設定が無効です: {1}" -f $warning,$_.Exception.Message).Trim() }
            }
            if (-not [string]::IsNullOrWhiteSpace($lastProjectRoot) -and -not (Test-Path -LiteralPath $lastProjectRoot -PathType Container)) {
                $warning=("{0} 最後に開いたプロジェクトフォルダーが見つかりません: {1}" -f $warning,$lastProjectRoot).Trim()
            }
            return New-ProjectRootInfo -Path $loaded.ProjectRoot -Source $source -SettingsPath $settingsPath -Warning $warning -LastProjectRoot $lastProjectRoot -LastWorkbookPath $lastWorkbookPath -Settings $loaded.Settings
        }
        catch {
            $warning = "プロジェクト保存先設定を読み込めませんでした。既定の保存先を使用します。設定ファイル: $settingsPath / 詳細: $($_.Exception.Message)"
            return New-ProjectRootInfo -Path (Get-DefaultProjectRoot) -Source 'DefaultFallback' -SettingsPath $settingsPath -Warning $warning
        }
    }
    return New-ProjectRootInfo -Path (Get-DefaultProjectRoot) -Source 'Default' -SettingsPath $paths.User
}

function Resolve-ProjectRoot {
    return [string](Get-ProjectRootInfo).Path
}

function Find-CurrentProjectDirectory {
    $current=[IO.Path]::GetFullPath((Get-Location).Path)
    while(-not[string]::IsNullOrWhiteSpace($current)){
        if(Test-Path -LiteralPath (Join-Path $current 'project.json') -PathType Leaf){return $current}
        $parent=Split-Path -Parent $current
        if([string]::IsNullOrWhiteSpace($parent)-or(Test-PathsEqual $parent $current)){break}
        $current=$parent
    }
    return ''
}

function Resolve-ProjectPath {
    param([AllowEmptyString()][string]$Project)
    if (-not [string]::IsNullOrWhiteSpace($script:DirectProjectPathOverride)) {
        $direct=[System.IO.Path]::GetFullPath($script:DirectProjectPathOverride)
        if (-not [string]::IsNullOrWhiteSpace($Project)) {
            $folderName=[System.IO.Path]::GetFileName($direct)
            $manifestName=''
            $manifestPath=Join-Path $direct 'project.json'
            if (Test-Path -LiteralPath $manifestPath -PathType Leaf) {
                try { $manifestName=[string](Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json).projectName } catch { Write-Verbose ('Project名をManifestから読み込めませんでした: ' + $_.Exception.Message) }
            }
            if (-not [string]::Equals($Project,$folderName,[System.StringComparison]::OrdinalIgnoreCase) -and
                -not [string]::Equals($Project,$manifestName,[System.StringComparison]::OrdinalIgnoreCase)) {
                throw "-Projectと直接指定されたProjectRootが一致しません。Project=$Project ProjectRoot=$direct"
            }
        }
        return $direct
    }
    if ([string]::IsNullOrWhiteSpace($Project)) { throw '-Project または個別プロジェクトを指す -ProjectRoot を指定してください。' }
    if ([System.IO.Path]::IsPathRooted($Project)) { return [System.IO.Path]::GetFullPath($Project) }
    if ($Project -in @('.','..') -or [System.IO.Path]::GetFileName($Project) -ne $Project) {
        throw "プロジェクト名にパスを指定できません。絶対パスまたは単一のプロジェクト名を指定してください: $Project"
    }
    $registered=@(Get-RegisteredProjects|Where-Object{[string]::Equals([string]$_.Name,$Project,[System.StringComparison]::OrdinalIgnoreCase)})
    if($registered.Count-gt 1){throw "同名の登録済みプロジェクトが複数あります。ProjectFolderを確認してください: $Project"}
    if($registered.Count-eq 1){return [System.IO.Path]::GetFullPath([string]$registered[0].ProjectFolder)}
    return [System.IO.Path]::GetFullPath((Join-Path (Resolve-ProjectRoot) $Project))
}

function Write-ProjectRootSettings {
    param(
        [Parameter(Mandatory=$true)][string]$ProjectRoot,
        [AllowNull()][string]$LastProjectRoot,
        [AllowNull()][string]$LastWorkbookPath,
        [switch]$ClearRecentProject,
        [AllowNull()]$GuiSettings
    )
    $paths = Get-ProjectRootSettingsPaths
    $settingsPath = $paths.User
    $existing=$null
    if (Test-Path -LiteralPath $settingsPath -PathType Leaf) {
        try { $existing=(Read-ProjectRootSettingsFile -Path $settingsPath).Settings } catch { Write-Verbose ('既存Project Root設定を読み込めませんでした: ' + $_.Exception.Message) }
    }
    $payload=New-PersistentSettingsPayload -ProjectRoot $ProjectRoot -ExistingSettings $existing -LastProjectRoot $LastProjectRoot -LastWorkbookPath $LastWorkbookPath -ClearRecentProject:$ClearRecentProject -GuiSettings $GuiSettings
    return Write-SettingsPayloadAtomic -Path $settingsPath -Payload $payload
}

function Invoke-ProjectRoot {
    param([string[]]$Arguments)
    $json = Test-ArgumentSwitch -Arguments $Arguments -Name '-Json'
    $info = Get-ProjectRootInfo
    if ($json) { Write-Output ($info | ConvertTo-Json -Depth 5); return }
    Write-Host 'Project Root:'
    Write-Host $info.Path
    Write-Host ''
    Write-Host 'Source:'
    Write-Host $info.Source
    Write-Host ''
    Write-Host 'Settings:'
    Write-Host $(if ([string]::IsNullOrWhiteSpace([string]$info.SettingsPath)) {'<none>'}else{$info.SettingsPath})
    if (-not [string]::IsNullOrWhiteSpace([string]$info.Warning)) { Write-Warn $info.Warning }
    if ([bool]$info.LegacyMigrationRequired) {
        Write-Warn ("Ver4.17以前のVBAUpdater専用projectフォルダーに{0}件あります。GUIの移行ウィザード、またはproject-migrateを使用してください。" -f $info.InternalProjectCount)
    }
    if (-not [string]::IsNullOrWhiteSpace([string]$info.LastProjectRoot)) {
        Write-Host ''
        Write-Host 'Last Project Folder:'
        Write-Host $info.LastProjectRoot
    }
}

function Test-CompleteProjectFolder {
    param([Parameter(Mandatory=$true)][string]$Path)
    return (Test-Path -LiteralPath (Join-Path $Path 'project.json') -PathType Leaf -ErrorAction Stop) -and
        (Test-Path -LiteralPath (Join-Path $Path 'source') -PathType Container -ErrorAction Stop) -and
        (Test-Path -LiteralPath (Join-Path $Path 'target') -PathType Container -ErrorAction Stop)
}

function Get-ProjectRootCandidateNames {
    param([Parameter(Mandatory=$true)][string]$Path)
    $names = New-Object 'System.Collections.Generic.List[string]'
    foreach ($directory in @(Get-ChildItem -LiteralPath $Path -Directory -ErrorAction Stop | Sort-Object Name)) {
        if (Test-CompleteProjectFolder -Path $directory.FullName) { $names.Add([string]$directory.Name) }
    }
    return ,$names
}

function Get-ProjectRootCheckResult {
    param([AllowNull()][string]$Path)

    $info = $null
    $source = 'CliPath'
    $warning = ''
    if ([string]::IsNullOrWhiteSpace($Path)) {
        $info = Get-ProjectRootInfo
        $resolved = [string]$info.Path
        $source = [string]$info.Source
        $warning = [string]$info.Warning
    }
    else {
        $resolved = ConvertTo-AbsoluteProjectRootPath -Path $Path
    }

    $status = 'Missing'
    $message = 'プロジェクト保存先が見つかりません。'
    $names = New-Object 'System.Collections.Generic.List[string]'
    try {
        if (Test-Path -LiteralPath $resolved -PathType Leaf -ErrorAction Stop) {
            $status = 'Invalid'
            $message = '指定パスはフォルダーではなくファイルです。'
        }
        elseif (-not (Test-Path -LiteralPath $resolved -PathType Container -ErrorAction Stop)) {
            $status = 'Missing'
            $message = 'プロジェクト保存先が見つかりません。'
        }
        else {
            if (-not [string]::IsNullOrWhiteSpace($Path)) {
                try { [void](Test-ProjectRootCandidate -Path $resolved -SkipWriteTest) }
                catch {
                    $status = 'Invalid'
                    $message = $_.Exception.Message
                    return [PSCustomObject]@{
                        SchemaVersion='1.0'; Path=$resolved; Source=$source; Status=$status; Projects=0
                        ProjectNames=@(); Message=$message; Warning=$warning
                    }
                }
            }
            $names = Get-ProjectRootCandidateNames -Path $resolved
            $status = 'OK'
            $message = if ($names.Count -eq 0) {
                '利用可能です。登録済みプロジェクトはありません。Project Rootとして使用できます。'
            }
            else { "利用可能です。$($names.Count)件のプロジェクトが見つかりました。" }
        }
    }
    catch {
        $status = 'Error'
        $message = "プロジェクト保存先を確認できません: $($_.Exception.Message)"
    }
    return [PSCustomObject]@{
        SchemaVersion='1.0'
        Path=$resolved
        Source=$source
        Status=$status
        Projects=[int]$names.Count
        ProjectNames=@($names.ToArray())
        Message=$message
        Warning=$warning
    }
}

function Invoke-ProjectRootCheck {
    param([string[]]$Arguments)
    $path = Get-NamedArgument -Arguments $Arguments -Name '-Path'
    $json = Test-ArgumentSwitch -Arguments $Arguments -Name '-Json'
    $result = Get-ProjectRootCheckResult -Path $path
    if ($json) { Write-Output ($result | ConvertTo-Json -Depth 6); return }
    Write-Host 'Project Root'
    Write-Host $result.Path
    Write-Host ''
    Write-Host 'Status'
    Write-Host $result.Status
    Write-Host ''
    Write-Host 'Projects'
    Write-Host $result.Projects
    if ($result.Projects -gt 0) {
        Write-Host ''
        Write-Host 'Project Names'
        foreach ($name in @($result.ProjectNames)) { Write-Host $name }
    }
    if (-not [string]::IsNullOrWhiteSpace([string]$result.Message)) { Write-Host ''; Write-Host $result.Message }
    if (-not [string]::IsNullOrWhiteSpace([string]$result.Warning)) { Write-Warn $result.Warning }
}

function Invoke-ProjectRootSet {
    param([string[]]$Arguments)
    $path = Get-NamedArgument -Arguments $Arguments -Name '-Path'
    $resolved = Test-ProjectRootCandidate -Path $path
    $settingsPath = Write-ProjectRootSettings -ProjectRoot $resolved
    $previousOverride = $script:ProjectRootOverride
    try {
        $script:ProjectRootOverride = $null
        $reloaded = Get-ProjectRootInfo
    }
    finally { $script:ProjectRootOverride = $previousOverride }
    if (-not [string]::Equals($reloaded.Path,$resolved,[System.StringComparison]::OrdinalIgnoreCase)) {
        throw "保存後のプロジェクトルートが一致しません。Expected=$resolved Actual=$($reloaded.Path)"
    }
    [void](Register-ProjectsFromRoot -ProjectRoot $resolved)
    Write-Success 'Project Root（開発フォルダー）を変更しました。既存プロジェクトは自動移動していません。'
    Write-Host ("Project Root: {0}" -f $resolved)
    Write-Host ("Settings    : {0}" -f $settingsPath)
}

function Write-ProjectFolderCheckResult {
    param([Parameter(Mandatory=$true)]$Result)
    Write-Host 'Project Folder'
    Write-Host $Result.ProjectRoot
    Write-Host ''
    Write-Host 'Project'
    Write-Host $Result.ProjectName
    Write-Host ''
    Write-Host 'Status'
    Write-Host $Result.Status
    Write-Host ''
    Write-Host ("Source   : {0}" -f $Result.SourcePath)
    Write-Host ("Target   : {0}" -f $Result.TargetDirectory)
    Write-Host ("Workbook : {0}" -f $(if([string]::IsNullOrWhiteSpace([string]$Result.WorkbookPath)){'<not selected>'}else{$Result.WorkbookPath}))
    Write-Host ("Manifest : {0}" -f $Result.ManifestPath)
    Write-Host ("Git      : {0}" -f $(if($Result.IsGitRepository){'Yes'}else{'No'}))
    if ($Result.Corrected) { Write-Warn $Result.CorrectionMessage }
    foreach($message in @($Result.Messages)) { if ($message -ne $Result.CorrectionMessage) { Write-Host $message } }
    foreach($warning in @($Result.Warnings)) { Write-Warn $warning }
    foreach($errorMessage in @($Result.Errors)) { Write-Failure $errorMessage }
    if (@($Result.WorkbookCandidates).Count -gt 1) {
        Write-Host 'Workbook Candidates'
        foreach($candidate in @($Result.WorkbookCandidates)) { Write-Host ("  {0}" -f $candidate) }
    }
}

function Invoke-ProjectFolderCheck {
    param([string[]]$Arguments)
    $path=Get-NamedArgument -Arguments $Arguments -Name '-Path'
    if ([string]::IsNullOrWhiteSpace($path)) { $path=Get-NamedArgument -Arguments $Arguments -Name '-ProjectRoot' }
    if ([string]::IsNullOrWhiteSpace($path)) { throw '-Path を指定してください。' }
    $workbookPath=Get-NamedArgument -Arguments $Arguments -Name '-WorkbookPath'
    $result=Get-ProjectFolderCheckResult -Path $path -WorkbookPath $workbookPath
    if (Test-ArgumentSwitch -Arguments $Arguments -Name '-Json') { Write-Output ($result|ConvertTo-Json -Depth 8); return }
    Write-ProjectFolderCheckResult -Result $result
}

function Invoke-ProjectFolderSet {
    param([string[]]$Arguments)
    $path=Get-NamedArgument -Arguments $Arguments -Name '-Path'
    if ([string]::IsNullOrWhiteSpace($path)) { throw '-Path を指定してください。' }
    $workbookPath=Get-NamedArgument -Arguments $Arguments -Name '-WorkbookPath'
    $result=Get-ProjectFolderCheckResult -Path $path -WorkbookPath $workbookPath
    if (-not $result.IsAvailable) {
        throw ("プロジェクトフォルダーを保存できません: {0}" -f (@($result.Errors) -join ' / '))
    }
    $parent=Split-Path -Parent $result.ProjectRoot
    if ([string]::IsNullOrWhiteSpace($parent)) { $parent=[System.IO.Path]::GetPathRoot($result.ProjectRoot) }
    $parent=Test-ProjectRootCandidate -Path $parent -SkipWriteTest
    $settingsPath=Write-ProjectRootSettings -ProjectRoot $parent -LastProjectRoot $result.ProjectRoot -LastWorkbookPath $result.WorkbookPath
    [void](Add-OrUpdateRegisteredProject -ProjectFolder $result.ProjectRoot -Name $result.ProjectName)
    $output=[PSCustomObject]@{
        Success=$true;SettingsPath=$settingsPath;ProjectRoot=$result.ProjectRoot;ProjectName=$result.ProjectName
        WorkbookPath=$result.WorkbookPath;CanPush=$result.CanPush;Status=$result.Status;CorrectionMessage=$result.CorrectionMessage
    }
    if (Test-ArgumentSwitch -Arguments $Arguments -Name '-Json') { Write-Output ($output|ConvertTo-Json -Depth 5); return }
    Write-Success 'プロジェクトフォルダーを保存しました。ファイルの移動やGit操作は行っていません。'
    Write-ProjectFolderCheckResult -Result $result
    Write-Host ("Settings : {0}" -f $settingsPath)
}

function Invoke-ProjectRootReset {
    [void](Write-ProjectRootSettings -ProjectRoot (Get-DefaultProjectRoot) -ClearRecentProject)
    Write-Success 'Project Root設定を解除しました。既定のDevelopmentフォルダーへ戻します。既存プロジェクトは削除していません。'
    Write-Host ("Project Root: {0}" -f (Get-DefaultProjectRoot))
    Write-Host 'Source      : UserSettings (Default path)'
}

function Get-LegacyProjectMigrationCheckResult {
    param([AllowNull()][string]$SourceRoot)
    if ([string]::IsNullOrWhiteSpace($SourceRoot)) { $SourceRoot = Get-LegacyInternalProjectRoot }
    $resolved = ConvertTo-AbsoluteProjectRootPath -Path $SourceRoot
    $names = New-Object 'System.Collections.Generic.List[string]'
    if (Test-Path -LiteralPath $resolved -PathType Container) {
        foreach ($name in @(Get-ProjectRootCandidateNames -Path $resolved)) { $names.Add([string]$name) }
    }
    return [PSCustomObject]@{
        SchemaVersion='1.0';SourceRoot=$resolved;Exists=(Test-Path -LiteralPath $resolved -PathType Container)
        Status=$(if($names.Count -gt 0){'Required'}else{'None'});RequiresMigration=($names.Count -gt 0)
        Projects=$names.Count;ProjectNames=@($names.ToArray())
        Message=$(if($names.Count -gt 0){"Ver4.17以前のプロジェクトを$($names.Count)件検出しました。"}else{'移行対象の旧形式プロジェクトはありません。'})
    }
}

function Invoke-ProjectMigrationCheck {
    param([string[]]$Arguments)
    $sourceRoot = Get-NamedArgument -Arguments $Arguments -Name '-SourceRoot'
    $result = Get-LegacyProjectMigrationCheckResult -SourceRoot $sourceRoot
    if (Test-ArgumentSwitch -Arguments $Arguments -Name '-Json') { Write-Output ($result | ConvertTo-Json -Depth 6); return }
    Write-Host 'Legacy Project Migration Check'
    Write-Host ("Source Root: {0}" -f $result.SourceRoot)
    Write-Host ("Status     : {0}" -f $result.Status)
    Write-Host ("Projects   : {0}" -f $result.Projects)
    foreach ($name in @($result.ProjectNames)) { Write-Host ("  {0}" -f $name) }
    Write-Host $result.Message
}

function Copy-LegacyProjectToDevelopmentRoot {
    param(
        [Parameter(Mandatory=$true)][string]$SourceProjectFolder,
        [Parameter(Mandatory=$true)][string]$DestinationRoot
    )
    $source = ConvertTo-AbsoluteProjectRootPath -Path $SourceProjectFolder
    $destinationParent = Test-ProjectRootCandidate -Path $DestinationRoot
    if (-not (Test-CompleteProjectFolder -Path $source)) { throw "旧形式プロジェクトが完全ではありません: $source" }
    $sourceRootPrefix = $source.TrimEnd('\','/') + [System.IO.Path]::DirectorySeparatorChar
    if ($destinationParent.StartsWith($sourceRootPrefix,[System.StringComparison]::OrdinalIgnoreCase)) {
        throw '移行先Project Rootを移行元プロジェクトの内部に指定できません。'
    }
    $destination = Join-Path $destinationParent ([System.IO.Path]::GetFileName($source))
    if (Test-Path -LiteralPath $destination) { throw "移行先に同名フォルダーが既に存在します。上書きしません: $destination" }
    $created = $false
    try {
        $created = $true
        Copy-Item -LiteralPath $source -Destination $destination -Recurse -Force -ErrorAction Stop
        if (-not (Test-CompleteProjectFolder -Path $destination)) { throw "移行後の必須ファイルを確認できません: $destination" }
        return [PSCustomObject]@{ProjectName=[System.IO.Path]::GetFileName($source);Source=$source;Destination=$destination;Verified=$true}
    }
    catch {
        $failure = $_.Exception.Message
        if ($created -and (Test-Path -LiteralPath $destination -PathType Container)) {
            try { Remove-Item -LiteralPath $destination -Recurse -Force -ErrorAction Stop }
            catch { throw "移行に失敗し、不完全なコピーも削除できませんでした: $failure / Cleanup: $($_.Exception.Message)" }
        }
        throw "移行に失敗しました: $failure"
    }
}

function Invoke-ProjectMigration {
    param([string[]]$Arguments)
    $sourceRoot = Get-NamedArgument -Arguments $Arguments -Name '-SourceRoot'
    if ([string]::IsNullOrWhiteSpace($sourceRoot)) { $sourceRoot = Get-LegacyInternalProjectRoot }
    $destinationRoot = Get-NamedArgument -Arguments $Arguments -Name '-DestinationRoot'
    if ([string]::IsNullOrWhiteSpace($destinationRoot)) { throw '-DestinationRoot を指定してください。' }
    $destinationRoot = Test-ProjectRootCandidate -Path $destinationRoot
    $check = Get-LegacyProjectMigrationCheckResult -SourceRoot $sourceRoot
    if (-not [bool]$check.RequiresMigration) { throw '移行対象の旧形式プロジェクトはありません。' }
    $requestedProject = Get-NamedArgument -Arguments $Arguments -Name '-Project'
    $names = if ([string]::IsNullOrWhiteSpace($requestedProject)) { @($check.ProjectNames) } else { @($requestedProject) }
    $results = New-Object 'System.Collections.Generic.List[object]'
    foreach ($name in $names) {
        if (@($check.ProjectNames) -notcontains $name) { throw "移行元にプロジェクトが見つかりません: $name" }
        $preflightDestination = Join-Path $destinationRoot $name
        if (Test-Path -LiteralPath $preflightDestination) { throw "移行先に同名フォルダーが既に存在します。上書きしません: $preflightDestination" }
    }
    try {
        foreach ($name in $names) {
            $results.Add((Copy-LegacyProjectToDevelopmentRoot -SourceProjectFolder (Join-Path $check.SourceRoot $name) -DestinationRoot $destinationRoot))
        }
    }
    catch {
        $failure = $_.Exception.Message
        $rollbackErrors = New-Object 'System.Collections.Generic.List[string]'
        foreach ($copied in @($results.ToArray())) {
            if (Test-Path -LiteralPath ([string]$copied.Destination) -PathType Container) {
                try { Remove-Item -LiteralPath ([string]$copied.Destination) -Recurse -Force -ErrorAction Stop }
                catch { $rollbackErrors.Add($_.Exception.Message) }
            }
        }
        if ($rollbackErrors.Count -gt 0) { throw "$failure / 移行ロールバックにも失敗しました: $($rollbackErrors -join ' / ')" }
        throw "$failure / 今回コピーした移行先はロールバックしました。"
    }
    $lastProject = [string]$results[$results.Count - 1].Destination
    [void](Write-ProjectRootSettings -ProjectRoot $destinationRoot -LastProjectRoot $lastProject)
    foreach($migrated in @($results.ToArray())){[void](Add-OrUpdateRegisteredProject -ProjectFolder ([string]$migrated.Destination) -Name ([string]$migrated.ProjectName))}
    $timestamp = [DateTime]::Now
    $logRoot = Get-RuntimeLogDirectory
    New-Item -ItemType Directory -Path $logRoot -Force | Out-Null
    $payload=[PSCustomObject]@{schemaVersion='1.0';version=$script:ToolVersion;operation='project-migration';status='Success';timestamp=$timestamp.ToString('o');sourceRoot=$check.SourceRoot;destinationRoot=$destinationRoot;sourcePreserved=$true;projects=@($results.ToArray())}
    $logPath=Join-Path $logRoot ("project_migration_{0}_{1}.json" -f $timestamp.ToString('yyyyMMdd_HHmmssfff'),[guid]::NewGuid().ToString('N').Substring(0,8))
    [System.IO.File]::WriteAllText($logPath,($payload|ConvertTo-Json -Depth 8),(New-Object System.Text.UTF8Encoding($false)))
    Write-Success ("旧形式プロジェクトを{0}件、安全にコピーして検証しました。移行元は削除していません。" -f $results.Count)
    Write-Host ("Project Root : {0}" -f $destinationRoot)
    Write-Host ("Migration Log: {0}" -f $logPath)
}

function Write-SettingsOperationLog {
    param([Parameter(Mandatory=$true)][string]$Operation,[Parameter(Mandatory=$true)][string]$Status,[AllowNull()]$Details)
    $paths=Initialize-PersistentSettingsStore
    $payload=[PSCustomObject]@{schemaVersion='1.0';version=$script:ToolVersion;operation=$Operation;status=$Status;timestamp=[DateTime]::Now.ToString('o');details=$Details}
    $path=Join-Path $paths.Logs ("settings_{0}_{1}.json" -f [DateTime]::Now.ToString('yyyyMMdd_HHmmssfff'),[guid]::NewGuid().ToString('N').Substring(0,8))
    [System.IO.File]::WriteAllText($path,($payload|ConvertTo-Json -Depth 8),(New-Object System.Text.UTF8Encoding($false)))
    return $path
}

function Get-RegisteredProjects {
    $paths=Initialize-PersistentSettingsStore
    $existing=@(Read-ProjectsRegistryFile -Path $paths.Projects)
    $rawCount=$existing.Count
    try{$raw=Get-Content -LiteralPath $paths.Projects -Raw -Encoding UTF8|ConvertFrom-Json;$rawCount=@($raw).Count}catch{Write-Verbose ('Projects registryの件数を読み込めませんでした: '+$_.Exception.Message)}
    if($rawCount-ne$existing.Count){[void](Write-ProjectsRegistryFile -Projects $existing)}
    return @(Read-ProjectsRegistryFile -Path $paths.Projects|Sort-Object Name,ProjectFolder)
}

function Register-ProjectsFromRoot {
    param([Parameter(Mandatory=$true)][string]$ProjectRoot)
    $existing=@(Get-RegisteredProjects)
    $discovered=Get-ProjectRegistryEntriesFromRoot -ProjectRoot $ProjectRoot
    foreach($entry in @($discovered.ToArray())){[void](Add-OrUpdateRegisteredProject -ProjectFolder ([string]$entry.ProjectFolder) -Name ([string]$entry.Name))}
    return @(Get-RegisteredProjects)
}

function Add-OrUpdateRegisteredProject {
    param([Parameter(Mandatory=$true)][string]$ProjectFolder,[AllowNull()][string]$Name)
    $folder=ConvertTo-AbsoluteProjectRootPath -Path $ProjectFolder
    if(-not(Test-Path -LiteralPath (Join-Path $folder 'project.json') -PathType Leaf)){throw "project.jsonが見つかりません: $folder"}
    if([string]::IsNullOrWhiteSpace($Name)){$Name=Get-ProjectRegistryNameFromFolder -ProjectFolder $folder}
    $paths=Initialize-PersistentSettingsStore
    $entries=New-Object 'System.Collections.Generic.List[object]'
    $registeredAt=[DateTime]::Now.ToString('o')
    foreach($item in @(Read-ProjectsRegistryFile -Path $paths.Projects)){
        if(Test-PathsEqual ([string]$item.ProjectFolder) $folder){$registeredAt=[string]$item.RegisteredAt;continue}
        if([string]::Equals([string]$item.Name,$Name,[System.StringComparison]::OrdinalIgnoreCase)){continue}
        $entries.Add($item)
    }
    $entry=[PSCustomObject]@{Name=$Name;ProjectFolder=$folder;RegisteredAt=$registeredAt;UpdatedAt=[DateTime]::Now.ToString('o')}
    $entries.Add($entry)
    [void](Write-ProjectsRegistryFile -Projects @($entries.ToArray()))
    return $entry
}

function Remove-RegisteredProject {
    param([AllowNull()][string]$Project,[AllowNull()][string]$ProjectFolder)
    $paths=Initialize-PersistentSettingsStore
    $kept=New-Object 'System.Collections.Generic.List[object]'
    $removed=New-Object 'System.Collections.Generic.List[object]'
    foreach($item in @(Read-ProjectsRegistryFile -Path $paths.Projects)){
        $match=(-not [string]::IsNullOrWhiteSpace($Project) -and [string]::Equals([string]$item.Name,$Project,[System.StringComparison]::OrdinalIgnoreCase)) -or
            (-not [string]::IsNullOrWhiteSpace($ProjectFolder) -and (Test-PathsEqual ([string]$item.ProjectFolder) $ProjectFolder))
        if($match){$removed.Add($item)}else{$kept.Add($item)}
    }
    if($removed.Count-eq 0){throw '登録解除するプロジェクトがprojects.jsonに見つかりません。'}
    [void](Write-ProjectsRegistryFile -Projects @($kept.ToArray()))
    return @($removed.ToArray())
}

function Get-RegisteredProjectNames {
    $names=New-Object 'System.Collections.Generic.List[string]'
    foreach($entry in @(Get-RegisteredProjects)){if(-not $names.Contains([string]$entry.Name)){$names.Add([string]$entry.Name)}}
    return ,$names
}

function Invoke-Settings {
    param([string[]]$Arguments)
    $info=Get-ProjectRootInfo
    $projects=@(Get-RegisteredProjects)
    $result=[PSCustomObject]@{SchemaVersion='1.0';Version=$script:ToolVersion;SettingsFolder=$info.SettingsFolder;SettingsPath=$info.SettingsPath;ProjectsPath=$info.ProjectsPath;LogsFolder=$info.LogsFolder;CacheFolder=$info.CacheFolder;ProjectRoot=$info.Path;RecentProject=$info.LastProjectRoot;RegisteredProjects=$projects.Count;Projects=$projects;Gui=$info.Gui;Logging=$info.Logging}
    if(Test-ArgumentSwitch -Arguments $Arguments -Name '-Json'){Write-Output ($result|ConvertTo-Json -Depth 8);return}
    Write-Host 'VBAUpdater Settings';Write-Host ''
    Write-Host 'Settings Folder';Write-Host $result.SettingsFolder;Write-Host ''
    Write-Host 'Project Root';Write-Host $result.ProjectRoot;Write-Host ''
    Write-Host 'Registered Projects';Write-Host $result.RegisteredProjects
}

function Invoke-Projects {
    param([string[]]$Arguments)
    $projects=@(Get-RegisteredProjects)
    if(Test-ArgumentSwitch -Arguments $Arguments -Name '-Json'){Write-Output ($projects|ConvertTo-Json -Depth 6);return}
    foreach($project in $projects){Write-Host ("{0}`t{1}" -f $project.Name,$project.ProjectFolder)}
}

function Invoke-ProjectUnregister {
    param([string[]]$Arguments)
    $project=Get-NamedArgument -Arguments $Arguments -Name '-Project'
    $folder=Get-NamedArgument -Arguments $Arguments -Name '-ProjectFolder'
    if([string]::IsNullOrWhiteSpace($project)-and[string]::IsNullOrWhiteSpace($folder)){throw '-Project または -ProjectFolder を指定してください。'}
    $removed=@(Remove-RegisteredProject -Project $project -ProjectFolder $folder)
    $info=Get-ProjectRootInfo
    $recentRemoved=@($removed|Where-Object{Test-PathsEqual ([string]$_.ProjectFolder) ([string]$info.LastProjectRoot)})
    if($recentRemoved.Count-gt 0){[void](Write-ProjectRootSettings -ProjectRoot $info.Path -ClearRecentProject)}
    $log=Write-SettingsOperationLog -Operation 'project-unregister' -Status 'Success' -Details $removed
    Write-Success 'プロジェクトの登録を解除しました。プロジェクトフォルダーとファイルは削除していません。'
    foreach($item in $removed){Write-Host ("{0}: {1}" -f $item.Name,$item.ProjectFolder)}
    Write-Host ("Log: {0}" -f $log)
}

function Invoke-ProjectRelocate {
    param([string[]]$Arguments)
    $project=Get-NamedArgument -Arguments $Arguments -Name '-Project'
    $folder=Get-NamedArgument -Arguments $Arguments -Name '-ProjectFolder'
    if([string]::IsNullOrWhiteSpace($folder)){throw '-ProjectFolder を指定してください。'}
    $check=Get-ProjectFolderCheckResult -Path $folder
    if(-not $check.IsAvailable){throw ('移動先プロジェクトを登録できません: '+(@($check.Errors)-join ' / '))}
    if([string]::IsNullOrWhiteSpace($project)){$project=[string]$check.ProjectName}
    $old=@(Get-RegisteredProjects|Where-Object{[string]::Equals([string]$_.Name,$project,[System.StringComparison]::OrdinalIgnoreCase)})
    if($old.Count-gt 1){throw "移動元の登録情報を一意に特定できません: $project"}
    if($old.Count-eq 1){[void](Remove-RegisteredProject -ProjectFolder ([string]$old[0].ProjectFolder))}
    $entry=Add-OrUpdateRegisteredProject -ProjectFolder ([string]$check.ProjectRoot) -Name $project
    $info=Get-ProjectRootInfo
    [void](Write-ProjectRootSettings -ProjectRoot $info.Path -LastProjectRoot $entry.ProjectFolder -LastWorkbookPath ([string]$check.WorkbookPath))
    $oldFolder=if($old.Count-eq 1){[string]$old[0].ProjectFolder}else{''}
    $log=Write-SettingsOperationLog -Operation 'project-relocate' -Status 'Success' -Details ([PSCustomObject]@{Name=$project;OldFolder=$oldFolder;NewFolder=$entry.ProjectFolder})
    Write-Success '移動後のプロジェクトフォルダーへ登録先を変更しました。フォルダーやファイルは移動していません。'
    Write-Host ("Project Folder: {0}" -f $entry.ProjectFolder);Write-Host ("Log: {0}" -f $log)
}

function Invoke-GuiSettingsSet {
    param([string[]]$Arguments)
    $width=[int](Get-NamedArgument -Arguments $Arguments -Name '-Width')
    $height=[int](Get-NamedArgument -Arguments $Arguments -Name '-Height')
    $state=Get-NamedArgument -Arguments $Arguments -Name '-WindowState'
    if($width-lt 940-or$height-lt 820){throw 'GUIサイズが最小値未満です。'}
    if($state-notin @('Normal','Maximized')){$state='Normal'}
    $info=Get-ProjectRootInfo
    $gui=[PSCustomObject]@{windowWidth=$width;windowHeight=$height;windowState=$state}
    [void](Write-ProjectRootSettings -ProjectRoot $info.Path -LastProjectRoot $info.LastProjectRoot -LastWorkbookPath $info.LastWorkbookPath -GuiSettings $gui)
    if(Test-ArgumentSwitch -Arguments $Arguments -Name '-Json'){Write-Output ($gui|ConvertTo-Json -Depth 3);return}
    Write-Success 'GUI設定を保存しました。'
}

function Resolve-PathValue {
    param([Parameter(Mandatory = $true)][string]$PathValue)

    $expanded = [Environment]::ExpandEnvironmentVariables($PathValue.Trim('"'))

    if ([System.IO.Path]::IsPathRooted($expanded)) {
        return [System.IO.Path]::GetFullPath($expanded)
    }

    return [System.IO.Path]::GetFullPath((Join-Path (Get-Location).Path $expanded))
}

function Release-ComObject {
    param($Object)

    if ($null -ne $Object) {
        try {
            [void][System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($Object)
        }
        catch {
        }
    }
}

function New-ExcelApplication {
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $excel.EnableEvents = $false
    $excel.AskToUpdateLinks = $false
    return $excel
}

function Close-ExcelApplication {
    param($Excel, $Workbook)

    if ($null -ne $Workbook) {
        try { $Workbook.Close($false) } catch { Write-Warn ('Excelブックの終了処理に失敗しました: ' + $_.Exception.Message) }
        Release-ComObject $Workbook
    }

    if ($null -ne $Excel) {
        try { $Excel.Quit() } catch { Write-Warn ('Excelプロセスの終了処理に失敗しました: ' + $_.Exception.Message) }
        Release-ComObject $Excel
    }

    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}


function Get-InstalledAddinPath {
    param($Excel)

    $candidates = New-Object System.Collections.Generic.List[string]

    function Add-AddinCandidate {
        param([string]$PathValue)

        if ([string]::IsNullOrWhiteSpace($PathValue)) { return }

        $fullPath = $PathValue
        try { $fullPath = [System.IO.Path]::GetFullPath($PathValue) } catch { Write-Verbose ('候補パスを正規化できませんでした: ' + $_.Exception.Message) }

        foreach ($existing in $candidates) {
            if ([string]::Equals($existing, $fullPath, [System.StringComparison]::OrdinalIgnoreCase)) {
                return
            }
        }

        [void]$candidates.Add($fullPath)
    }

    # 1. 前回インストール情報。別ユーザーの固定パスでも候補として記録するが、存在しなければ採用しない。
    if (Test-Path -LiteralPath $script:AddinConfigPath -PathType Leaf) {
        try {
            $config = Get-Content -LiteralPath $script:AddinConfigPath -Raw | ConvertFrom-Json
            Add-AddinCandidate -PathValue ([string]$config.installedAddinPath)
        }
        catch {
            Write-Warn "アドイン設定ファイルを読み取れませんでした。自動検出を続行します: $($_.Exception.Message)"
        }
    }

    # 2. 実行中Excelが返す現在ユーザーの正式なアドインフォルダ。
    if ($null -ne $Excel) {
        try {
            $excelUserLibraryPath = [string]$Excel.UserLibraryPath
            if (-not [string]::IsNullOrWhiteSpace($excelUserLibraryPath)) {
                Add-AddinCandidate -PathValue (Join-Path $excelUserLibraryPath "VBAUpdater.xlam")
            }
        }
        catch {
            Write-Warn "Excel.UserLibraryPathの取得に失敗しました。環境変数による検出を続行します。"
        }
    }

    # 3. 現在のWindowsユーザーの標準アドインフォルダ。
    if (-not [string]::IsNullOrWhiteSpace([string]$env:APPDATA)) {
        Add-AddinCandidate -PathValue (Join-Path $env:APPDATA "Microsoft\AddIns\VBAUpdater.xlam")
    }

    # 4. 配布パッケージ内のアドイン。インストール前でも更新処理を実行できる最終フォールバック。
    Add-AddinCandidate -PathValue $script:PackageAddinPath

    Write-Info "VBAUpdater.xlamを自動検出しています..."
    for ($i = 0; $i -lt $candidates.Count; $i++) {
        $candidate = $candidates[$i]
        $exists = Test-Path -LiteralPath $candidate -PathType Leaf
        Write-Host ("  [CANDIDATE {0}] Exists={1} Path={2}" -f ($i + 1), $exists, $candidate)

        if ($exists) {
            # 古いユーザー名が残った設定を、今回解決できた実パスで自己修復する。
            try {
                $resolvedConfig = [ordered]@{
                    installedAddinPath = $candidate
                    userLibraryPath = Split-Path -Parent $candidate
                    toolVersion = $script:ToolVersion
                    resolvedAt = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ssK")
                    resolutionMode = if ([string]::Equals($candidate, $script:PackageAddinPath, [System.StringComparison]::OrdinalIgnoreCase)) { "package-fallback" } else { "auto-detected" }
                }

                [System.IO.File]::WriteAllText(
                    $script:AddinConfigPath,
                    ($resolvedConfig | ConvertTo-Json -Depth 4),
                    (New-Object System.Text.UTF8Encoding($true))
                )
            }
            catch {
                Write-Warn "アドイン設定の自己修復に失敗しましたが、処理は続行します: $($_.Exception.Message)"
            }

            Write-Success "VBAUpdater.xlamを検出しました: $candidate"
            return $candidate
        }
    }

    $candidateText = [string]::Join([Environment]::NewLine, ($candidates | ForEach-Object { "  - $_" }))
    throw "VBAUpdater.xlamが見つかりません。確認した候補:`n$candidateText`n先に .\vba.cmd addin-build を実行するか、配布物の addin\VBAUpdater.xlam を確認してください。"
}

function Register-InstalledAddin {
    param(
        [Parameter(Mandatory = $true)]$Excel,
        [Parameter(Mandatory = $true)][string]$AddinPath
    )

    $addinObject = $null

    foreach ($existing in $Excel.AddIns) {
        try {
            if ([string]::Equals(
                [string]$existing.FullName,
                $AddinPath,
                [System.StringComparison]::OrdinalIgnoreCase)) {
                $addinObject = $existing
                break
            }
        }
        catch {
        }
    }

    if ($null -eq $addinObject) {
        $addinObject = $Excel.AddIns.Add($AddinPath, $true)
    }

    $addinObject.Installed = $true
    return $addinObject
}

function Invoke-AddinBuild {
    if (-not (Test-Path -LiteralPath $script:EngineSourcePath -PathType Leaf)) {
        throw "更新エンジンのソースが見つかりません: $script:EngineSourcePath"
    }

    $packageFolder = Split-Path -Parent $script:PackageAddinPath
    if (-not (Test-Path -LiteralPath $packageFolder)) {
        New-Item -ItemType Directory -Path $packageFolder -Force | Out-Null
    }

    $excel = $null
    $workbook = $null
    $vbProject = $null
    $imported = $null
    $installedPath = $null

    try {
        Write-Info "Excelのユーザーアドインフォルダを確認しています..."

        $excel = New-ExcelApplication
        $excel.AutomationSecurity = 3

        $userLibraryPath = [string]$excel.UserLibraryPath
        if ([string]::IsNullOrWhiteSpace($userLibraryPath)) {
            throw "Excelのユーザーアドインフォルダを取得できませんでした。"
        }

        if (-not (Test-Path -LiteralPath $userLibraryPath -PathType Container)) {
            New-Item -ItemType Directory -Path $userLibraryPath -Force | Out-Null
        }

        $installedPath = Join-Path $userLibraryPath "VBAUpdater.xlam"

        if (Test-Path -LiteralPath $installedPath -PathType Leaf) {
            $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
            $oldPath = Join-Path $userLibraryPath ("VBAUpdater_before_rebuild_{0}.xlam" -f $timestamp)
            Move-Item -LiteralPath $installedPath -Destination $oldPath -Force
            Write-Warn "既存アドインを退避しました: $oldPath"
        }

        Write-Info "VBAUpdater.xlamを生成しています..."

        $workbook = $excel.Workbooks.Add()
        $vbProject = $workbook.VBProject
        $imported = $vbProject.VBComponents.Import($script:EngineSourcePath)

        if ([string]$imported.Name -ne "modVBAUpdaterEngine") {
            throw "更新エンジンのモジュール名が正しくありません: $($imported.Name)"
        }

        $lineCount = [int]$imported.CodeModule.CountOfLines
        if ($lineCount -le 0) {
            throw "更新エンジンのコードが取り込まれていません。"
        }

        $pingFound = $false
        for ($line = 1; $line -le $lineCount; $line++) {
            $lineText = [string]$imported.CodeModule.Lines($line, 1)
            if ($lineText -match "Public Function Ping") {
                $pingFound = $true
                break
            }
        }

        if (-not $pingFound) {
            throw "更新エンジン内にPing関数が見つかりません。文字コードを確認してください。"
        }

        $workbook.SaveAs($installedPath, 55)
        $workbook.Close($true)
        Release-ComObject $workbook
        $workbook = $null

        Copy-Item -LiteralPath $installedPath -Destination $script:PackageAddinPath -Force

        $config = @{
            installedAddinPath = $installedPath
            userLibraryPath = $userLibraryPath
            toolVersion = $script:ToolVersion
            installedAt = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ssK")
        }

        [System.IO.File]::WriteAllText(
            $script:AddinConfigPath,
            ($config | ConvertTo-Json -Depth 4),
            (New-Object System.Text.UTF8Encoding($true))
        )

        Write-Success "VBAUpdater.xlamをExcelのアドインフォルダへインストールしました。"
        Write-Host "インストール先 : $installedPath"
        Write-Host "パッケージ控え : $script:PackageAddinPath"
        Write-Info "次に実行してください: .\vba.cmd addin-doctor"
    }
    finally {
        Release-ComObject $imported
        Release-ComObject $vbProject
        Close-ExcelApplication -Excel $excel -Workbook $workbook
    }
}

function Open-AddinWorkbook {
    param([Parameter(Mandatory = $true)]$Excel)

    $installedPath = Get-InstalledAddinPath -Excel $Excel

    $Excel.AutomationSecurity = 1
    $addinObject = Register-InstalledAddin -Excel $Excel -AddinPath $installedPath

    $workbook = $null
    foreach ($candidate in $Excel.Workbooks) {
        if ([string]::Equals(
            [string]$candidate.FullName,
            $installedPath,
            [System.StringComparison]::OrdinalIgnoreCase)) {
            $workbook = $candidate
            break
        }
    }

    if ($null -eq $workbook) {
        $workbook = $Excel.Workbooks.Open($installedPath, 0, $true)
    }

    Release-ComObject $addinObject
    return $workbook
}

function Invoke-AddinDoctor {
    $excel = $null
    $addin = $null

    try {
        Write-Info "新しいExcelプロセスでアドインを確認しています..."

        $excel = New-ExcelApplication
        $addin = Open-AddinWorkbook -Excel $excel

        $macroName = "'" + $addin.Name + "'!modVBAUpdaterEngine.Ping"

        $vbProject = $addin.VBProject
        $engineComponent = $vbProject.VBComponents.Item("modVBAUpdaterEngine")
        $engineLineCount = [int]$engineComponent.CodeModule.CountOfLines

        if ($engineLineCount -le 0) {
            throw "アドイン内の更新エンジンにコードがありません。"
        }

        $result = [string]$excel.Run($macroName)

        Release-ComObject $engineComponent
        Release-ComObject $vbProject

        if ($result -ne "VBA_UPDATER_ADDIN_OK") {
            throw "Pingの結果が一致しません: $result"
        }

        Write-Success "VBAUpdater.xlamのマクロを実行できました。"
        Write-Host "結果: $result"
    }
    finally {
        Close-ExcelApplication -Excel $excel -Workbook $addin
    }
}

function Invoke-TestCreate {
    $testRoot = Get-LegacyTestRoot
    if (-not (Test-Path -LiteralPath $testRoot)) {
        New-Item -ItemType Directory -Path $testRoot -Force | Out-Null
    }

    $workbookPath = Join-Path $testRoot "VBAAddinEngineTest.xlsm"
    $sourcePath = Join-Path $testRoot "modAddinTarget.bas"

    if (Test-Path -LiteralPath $workbookPath) {
        Remove-Item -LiteralPath $workbookPath -Force
    }

    $sourceCode = @'
Attribute VB_Name = "modAddinTarget"
Option Explicit

Public Function GetAddinEngineTestValue() As String
    GetAddinEngineTestValue = "NEW_VALUE"
End Function
'@

    [System.IO.File]::WriteAllText(
        $sourcePath,
        $sourceCode,
        (New-Object System.Text.UTF8Encoding($true))
    )

    $excel = $null
    $workbook = $null
    $module = $null
    $codeModule = $null

    try {
        Write-Info "専用テストブックを作成しています..."

        $excel = New-ExcelApplication
        $excel.AutomationSecurity = 3

        $workbook = $excel.Workbooks.Add()
        $sheet = $workbook.Worksheets.Item(1)
        $sheet.Name = "TestSheet"
        $sheet.Range("A1").Value2 = "VBA Add-in Engine Test"
        $sheet.Range("A2").Value2 = "Expected"
        $sheet.Range("B2").Value2 = "NEW_VALUE"

        $module = $workbook.VBProject.VBComponents.Add(1)
        $module.Name = "modAddinTarget"
        $codeModule = $module.CodeModule
        $codeModule.AddFromString(@'
Option Explicit

Public Function GetAddinEngineTestValue() As String
    GetAddinEngineTestValue = "OLD_VALUE"
End Function
'@)

        $workbook.SaveAs($workbookPath, 52)

        Write-Success "専用テスト環境を作成しました。"
        Write-Host "対象ブック : $workbookPath"
        Write-Host "更新ソース : $sourcePath"
    }
    finally {
        Release-ComObject $codeModule
        Release-ComObject $module
        Close-ExcelApplication -Excel $excel -Workbook $workbook
    }
}


function Invoke-EngineComponentUpdate {
    param(
        [Parameter(Mandatory = $true)]
        [string]$MacroProcedure,
        [Parameter(Mandatory = $true)]
        [string]$WorkbookPath,
        [Parameter(Mandatory = $true)]
        [string]$SourcePath,
        [Parameter(Mandatory = $true)]
        [string]$ComponentName,
        [Parameter(Mandatory = $true)]
        [string]$BackupPrefix,
        [Parameter(Mandatory = $true)]
        [string]$ResultPrefix,
        [Parameter(Mandatory = $true)]
        [string]$DisplayName
    )

    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $backupRoot = Get-RuntimeBackupDirectory
    $logRoot = Get-RuntimeLogDirectory

    foreach ($directory in @($backupRoot, $logRoot)) {
        if (-not (Test-Path -LiteralPath $directory)) {
            New-Item -ItemType Directory -Path $directory -Force | Out-Null
        }
    }

    $baseName = [System.IO.Path]::GetFileNameWithoutExtension($WorkbookPath)
    $extension = [System.IO.Path]::GetExtension($WorkbookPath)
    $backupPath = Join-Path $backupRoot ("{0}_{1}_{2}{3}" -f $baseName, $BackupPrefix, $timestamp, $extension)
    $resultPath = Join-Path $logRoot ("{0}_{1}.json" -f $ResultPrefix, $timestamp)

    if($null-ne$script:TestExecutionContext-and[string]::IsNullOrWhiteSpace($script:CurrentTestProjectRoot)){
        $script:CurrentTestProjectRoot=[IO.Path]::GetFullPath((Split-Path -Parent $WorkbookPath))
    }
    Invoke-TestWorkbookOpenAudit -Path $WorkbookPath
    Write-Info "更新前バックアップを作成しています..."
    Copy-Item -LiteralPath $WorkbookPath -Destination $backupPath -Force

    $excel = $null
    $addin = $null

    try {
        Write-Info "新しいExcelプロセスでVBAUpdater.xlamを読み込んでいます..."

        $excel = New-ExcelApplication
        $addin = Open-AddinWorkbook -Excel $excel

        $macroName = "'" + $addin.Name + "'!modVBAUpdaterEngine." + $MacroProcedure

        $excel.Run(
            $macroName,
            $WorkbookPath,
            $SourcePath,
            $ComponentName,
            $resultPath
        )

        if (-not (Test-Path -LiteralPath $resultPath -PathType Leaf)) {
            throw "結果JSONが生成されませんでした。"
        }

        $result = Get-Content -LiteralPath $resultPath -Raw | ConvertFrom-Json

        if (-not [bool]$result.success) {
            throw "更新エンジンが失敗しました。Error=$($result.errorNumber) $($result.errorMessage)"
        }

        Write-Success "$DisplayName 1件の更新が完了しました。"
        Write-Host "対象ブック   : $WorkbookPath"
        Write-Host "コンポーネント: $ComponentName"
        Write-Host "新規作成     : $($result.createdNew)"
        Write-Host "バックアップ : $backupPath"
        Write-Host "結果JSON     : $resultPath"
    }
    catch {
        throw "$DisplayName 更新に失敗しました。バックアップ: $backupPath / 詳細: $($_.Exception.Message)"
    }
    finally {
        Close-ExcelApplication -Excel $excel -Workbook $addin
    }
}

function Invoke-PushStandard {
    param([string[]]$Arguments)

    $workbookArg = Get-NamedArgument -Arguments $Arguments -Name "-WorkbookPath"
    $sourceArg = Get-NamedArgument -Arguments $Arguments -Name "-SourcePath"
    $componentName = Get-NamedArgument -Arguments $Arguments -Name "-ComponentName"

    if ([string]::IsNullOrWhiteSpace($workbookArg)) { throw "WorkbookPathが必要です。" }
    if ([string]::IsNullOrWhiteSpace($sourceArg)) { throw "SourcePathが必要です。" }
    if ([string]::IsNullOrWhiteSpace($componentName)) { throw "ComponentNameが必要です。" }

    $workbookPath = Resolve-PathValue $workbookArg
    $sourcePath = Resolve-PathValue $sourceArg

    if (-not (Test-Path -LiteralPath $workbookPath -PathType Leaf)) {
        throw "対象ブックが見つかりません: $workbookPath"
    }

    if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf)) {
        throw "ソースファイルが見つかりません: $sourcePath"
    }

    Invoke-EngineComponentUpdate `
        -MacroProcedure "UpdateStandardModule" `
        -WorkbookPath $workbookPath `
        -SourcePath $sourcePath `
        -ComponentName $componentName `
        -BackupPrefix "before_standard_push" `
        -ResultPrefix "standard_result" `
        -DisplayName "標準モジュール"
}

function Invoke-PushClass {
    param([string[]]$Arguments)

    $workbookArg = Get-NamedArgument -Arguments $Arguments -Name "-WorkbookPath"
    $sourceArg = Get-NamedArgument -Arguments $Arguments -Name "-SourcePath"
    $componentName = Get-NamedArgument -Arguments $Arguments -Name "-ComponentName"

    if ([string]::IsNullOrWhiteSpace($workbookArg)) { throw "WorkbookPathが必要です。" }
    if ([string]::IsNullOrWhiteSpace($sourceArg)) { throw "SourcePathが必要です。" }
    if ([string]::IsNullOrWhiteSpace($componentName)) { throw "ComponentNameが必要です。" }

    $workbookPath = Resolve-PathValue $workbookArg
    $sourcePath = Resolve-PathValue $sourceArg

    if (-not (Test-Path -LiteralPath $workbookPath -PathType Leaf)) {
        throw "対象ブックが見つかりません: $workbookPath"
    }

    if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf)) {
        throw "ソースファイルが見つかりません: $sourcePath"
    }

    Invoke-EngineComponentUpdate `
        -MacroProcedure "UpdateClassModule" `
        -WorkbookPath $workbookPath `
        -SourcePath $sourcePath `
        -ComponentName $componentName `
        -BackupPrefix "before_class_push" `
        -ResultPrefix "class_result" `
        -DisplayName "クラスモジュール"
}



function Invoke-PushDocument {
    param([string[]]$Arguments)
    $workbookArg = Get-NamedArgument -Arguments $Arguments -Name "-WorkbookPath"
    $sourceArg = Get-NamedArgument -Arguments $Arguments -Name "-SourcePath"
    $componentName = Get-NamedArgument -Arguments $Arguments -Name "-ComponentName"
    if ([string]::IsNullOrWhiteSpace($workbookArg)) { throw "WorkbookPathが必要です。" }
    if ([string]::IsNullOrWhiteSpace($sourceArg)) { throw "SourcePathが必要です。" }
    if ([string]::IsNullOrWhiteSpace($componentName)) { throw "ComponentNameが必要です。" }
    $workbookPath = Resolve-PathValue $workbookArg
    $sourcePath = Resolve-PathValue $sourceArg
    if (-not (Test-Path -LiteralPath $workbookPath -PathType Leaf)) { throw "対象ブックが見つかりません: $workbookPath" }
    if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf)) { throw "ソースファイルが見つかりません: $sourcePath" }
    Invoke-EngineComponentUpdate `
        -MacroProcedure "UpdateDocumentModule" `
        -WorkbookPath $workbookPath `
        -SourcePath $sourcePath `
        -ComponentName $componentName `
        -BackupPrefix "before_document_push" `
        -ResultPrefix "document_result" `
        -DisplayName "Document Module"
}


function Invoke-PushUserForm {
    param([string[]]$Arguments)

    $workbookArg = Get-NamedArgument -Arguments $Arguments -Name "-WorkbookPath"
    $sourceArg = Get-NamedArgument -Arguments $Arguments -Name "-SourcePath"
    $componentName = Get-NamedArgument -Arguments $Arguments -Name "-ComponentName"

    if ([string]::IsNullOrWhiteSpace($workbookArg)) { throw "WorkbookPathが必要です。" }
    if ([string]::IsNullOrWhiteSpace($sourceArg)) { throw "SourcePathが必要です。" }
    if ([string]::IsNullOrWhiteSpace($componentName)) { throw "ComponentNameが必要です。" }

    $workbookPath = Resolve-PathValue $workbookArg
    $sourcePath = Resolve-PathValue $sourceArg
    $frxPath = [System.IO.Path]::ChangeExtension($sourcePath, ".frx")

    if (-not (Test-Path -LiteralPath $workbookPath -PathType Leaf)) {
        throw "対象ブックが見つかりません: $workbookPath"
    }

    if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf)) {
        throw "UserFormソースが見つかりません: $sourcePath"
    }

    if ([System.IO.Path]::GetExtension($sourcePath) -ine ".frm") {
        throw "SourcePathには.frmファイルを指定してください: $sourcePath"
    }

    if (-not (Test-Path -LiteralPath $frxPath -PathType Leaf)) {
        throw "対応する.frxファイルが見つかりません: $frxPath"
    }

    Invoke-EngineComponentUpdate `
        -MacroProcedure "UpdateUserForm" `
        -WorkbookPath $workbookPath `
        -SourcePath $sourcePath `
        -ComponentName $componentName `
        -BackupPrefix "before_userform_push" `
        -ResultPrefix "userform_result" `
        -DisplayName "UserForm"
}

function Invoke-DocumentTestCreate {
    $testRoot = Get-LegacyTestRoot
    if (-not (Test-Path -LiteralPath $testRoot)) { New-Item -ItemType Directory -Path $testRoot -Force | Out-Null }
    $workbookPath = Join-Path $testRoot "VBADocumentEngineTest.xlsm"
    $thisWorkbookSourcePath = Join-Path $testRoot "ThisWorkbook.cls"
    $sheetSourcePath = Join-Path $testRoot "Sheet1.cls"
    if (Test-Path -LiteralPath $workbookPath) { Remove-Item -LiteralPath $workbookPath -Force }
    $thisWorkbookSource = @'
VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "ThisWorkbook"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = True
Option Explicit

Public Function GetThisWorkbookDocumentValue() As String
    GetThisWorkbookDocumentValue = "THISWORKBOOK_NEW_VALUE"
End Function
'@
    $sheetSource = @'
VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "Sheet1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = True
Option Explicit

Public Function GetSheetDocumentValue() As String
    GetSheetDocumentValue = "SHEET_NEW_VALUE"
End Function
'@
    [System.IO.File]::WriteAllText($thisWorkbookSourcePath, $thisWorkbookSource, (New-Object System.Text.UTF8Encoding($true)))
    [System.IO.File]::WriteAllText($sheetSourcePath, $sheetSource, (New-Object System.Text.UTF8Encoding($true)))
    $excel = $null; $workbook = $null; $thisWorkbookComponent = $null; $sheetComponent = $null
    $testModule = $null; $thisWorkbookCode = $null; $sheetCode = $null; $testCode = $null
    try {
        Write-Info "Document Module専用テストブックを作成しています..."
        $excel = New-ExcelApplication
        $excel.AutomationSecurity = 3
        $workbook = $excel.Workbooks.Add()
        $workbook.Worksheets.Item(1).Name = "DocumentTest"
        $thisWorkbookComponent = $workbook.VBProject.VBComponents.Item("ThisWorkbook")
        $sheetComponent = $workbook.VBProject.VBComponents.Item("Sheet1")
        $thisWorkbookCode = $thisWorkbookComponent.CodeModule
        $thisWorkbookCode.AddFromString(@'
Option Explicit

Public Function GetThisWorkbookDocumentValue() As String
    GetThisWorkbookDocumentValue = "THISWORKBOOK_OLD_VALUE"
End Function
'@)
        $sheetCode = $sheetComponent.CodeModule
        $sheetCode.AddFromString(@'
Option Explicit

Public Function GetSheetDocumentValue() As String
    GetSheetDocumentValue = "SHEET_OLD_VALUE"
End Function
'@)
        $testModule = $workbook.VBProject.VBComponents.Add(1)
        $testModule.Name = "modDocumentTest"
        $testCode = $testModule.CodeModule
        $testCode.AddFromString(@'
Option Explicit

Public Function GetDocumentEngineTestValue() As String
    GetDocumentEngineTestValue = _
        ThisWorkbook.GetThisWorkbookDocumentValue() & "|" & _
        Sheet1.GetSheetDocumentValue()
End Function
'@)
        $workbook.SaveAs($workbookPath, 52)
        Write-Success "Document Module専用テスト環境を作成しました。"
        Write-Host "対象ブック        : $workbookPath"
        Write-Host "ThisWorkbookソース: $thisWorkbookSourcePath"
        Write-Host "Sheet1ソース      : $sheetSourcePath"
    }
    finally {
        Release-ComObject $testCode; Release-ComObject $sheetCode; Release-ComObject $thisWorkbookCode
        Release-ComObject $testModule; Release-ComObject $sheetComponent; Release-ComObject $thisWorkbookComponent
        Close-ExcelApplication -Excel $excel -Workbook $workbook
    }
}

function Invoke-DocumentTestPush {
    $testRoot=Get-LegacyTestRoot
    $workbookPath = Join-Path $testRoot "VBADocumentEngineTest.xlsm"
    $thisWorkbookSourcePath = Join-Path $testRoot "ThisWorkbook.cls"
    $sheetSourcePath = Join-Path $testRoot "Sheet1.cls"
    foreach ($path in @($workbookPath, $thisWorkbookSourcePath, $sheetSourcePath)) {
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "先に document-test-create を実行してください: $path" }
    }
    Invoke-EngineComponentUpdate -MacroProcedure "UpdateDocumentModule" -WorkbookPath $workbookPath -SourcePath $thisWorkbookSourcePath -ComponentName "ThisWorkbook" -BackupPrefix "before_thisworkbook_push" -ResultPrefix "thisworkbook_result" -DisplayName "ThisWorkbook"
    Invoke-EngineComponentUpdate -MacroProcedure "UpdateDocumentModule" -WorkbookPath $workbookPath -SourcePath $sheetSourcePath -ComponentName "Sheet1" -BackupPrefix "before_sheet_push" -ResultPrefix "sheet_result" -DisplayName "Sheetモジュール"
    Write-Success "Document Module 2件の更新が完了しました。"
}

function Invoke-DocumentTestRun {
    $workbookPath = Join-Path (Get-LegacyTestRoot) "VBADocumentEngineTest.xlsm"
    if (-not (Test-Path -LiteralPath $workbookPath -PathType Leaf)) { throw "先に document-test-create を実行してください。" }
    $excel = $null; $workbook = $null
    try {
        Write-Info "Document Module更新結果を検証しています..."
        $excel = New-ExcelApplication
        $excel.AutomationSecurity = 1
        Invoke-TestWorkbookOpenAudit -Path $workbookPath
        $workbook = $excel.Workbooks.Open($workbookPath, 0, $true)
        $result = [string]$excel.Run("'" + $workbook.Name + "'!GetDocumentEngineTestValue")
        $expected = "THISWORKBOOK_NEW_VALUE|SHEET_NEW_VALUE"
        if ($result -ne $expected) { throw "更新結果が一致しません。Expected=$expected / Actual=$result" }
        Write-Success "Document Module更新の自動テストに成功しました。"
        Write-Host "結果: $result"
    }
    finally { Close-ExcelApplication -Excel $excel -Workbook $workbook }
}


function Invoke-UserFormTestCreate {
    $testRoot = Get-LegacyTestRoot
    if (-not (Test-Path -LiteralPath $testRoot)) {
        New-Item -ItemType Directory -Path $testRoot -Force | Out-Null
    }

    $workbookPath = Join-Path $testRoot "VBAUserFormEngineTest.xlsm"
    $sourcePath = Join-Path $testRoot "frmUpdaterTest.frm"
    $frxPath = Join-Path $testRoot "frmUpdaterTest.frx"

    foreach ($path in @($workbookPath, $sourcePath, $frxPath)) {
        if (Test-Path -LiteralPath $path) {
            Remove-Item -LiteralPath $path -Force
        }
    }

    $excel = $null
    $targetBook = $null
    $sourceBook = $null
    $targetForm = $null
    $sourceForm = $null
    $targetDesigner = $null
    $sourceDesigner = $null
    $targetLabel = $null
    $sourceLabel = $null
    $targetCode = $null
    $sourceCode = $null
    $testModule = $null
    $testCode = $null

    try {
        Write-Info "UserForm専用テスト環境を作成しています..."

        $excel = New-ExcelApplication
        $excel.AutomationSecurity = 3

        $targetBook = $excel.Workbooks.Add()
        $targetForm = $targetBook.VBProject.VBComponents.Add(3)
        $targetForm.Name = "frmUpdaterTest"
        $targetDesigner = $targetForm.Designer
        $targetForm.Properties.Item("Caption").Value = "USERFORM_OLD_CAPTION"
        $targetForm.Properties.Item("Width").Value = 300
        $targetForm.Properties.Item("Height").Value = 180
        $targetLabel = $targetDesigner.Controls.Add("Forms.Label.1", "lblStatus", $true)
        $targetLabel.Caption = "LABEL_OLD_VALUE"
        $targetLabel.Left = 18
        $targetLabel.Top = 24
        $targetLabel.Width = 160
        $targetCode = $targetForm.CodeModule
        $targetCode.AddFromString(@'
Option Explicit

Public Function GetValue() As String
    GetValue = "USERFORM_OLD_VALUE"
End Function
'@)

        $testModule = $targetBook.VBProject.VBComponents.Add(1)
        $testModule.Name = "modUserFormTest"
        $testCode = $testModule.CodeModule
        $testCode.AddFromString(@'
Option Explicit

Public Function GetUserFormEngineTestValue() As String
    Dim formInstance As Object

    Set formInstance = VBA.UserForms.Add("frmUpdaterTest")

    GetUserFormEngineTestValue = _
        formInstance.GetValue() & "|" & _
        formInstance.Caption & "|" & _
        formInstance.Controls("lblStatus").Caption

    Unload formInstance
    Set formInstance = Nothing
End Function
'@)

        $targetBook.SaveAs($workbookPath, 52)

        $sourceBook = $excel.Workbooks.Add()
        $sourceForm = $sourceBook.VBProject.VBComponents.Add(3)
        $sourceForm.Name = "frmUpdaterTest"
        $sourceDesigner = $sourceForm.Designer
        $sourceForm.Properties.Item("Caption").Value = "USERFORM_NEW_CAPTION"
        $sourceForm.Properties.Item("Width").Value = 360
        $sourceForm.Properties.Item("Height").Value = 210
        $sourceLabel = $sourceDesigner.Controls.Add("Forms.Label.1", "lblStatus", $true)
        $sourceLabel.Caption = "LABEL_NEW_VALUE"
        $sourceLabel.Left = 30
        $sourceLabel.Top = 42
        $sourceLabel.Width = 190
        $sourceCode = $sourceForm.CodeModule
        $sourceCode.AddFromString(@'
Option Explicit

Public Function GetValue() As String
    GetValue = "USERFORM_NEW_VALUE"
End Function
'@)

        $sourceForm.Export($sourcePath)

        # VBIDE環境によってはExport時にUserForm本体のCaptionが既定値へ戻るため、
        # .frmの先頭UserForm CaptionをANSI文字コードのまま明示的に補正する。
        $frmEncoding = [System.Text.Encoding]::Default
        $frmText = [System.IO.File]::ReadAllText($sourcePath, $frmEncoding)
        $captionPattern = '(?m)^(\s*Caption\s*=\s*").*?("\s*)$'
        $frmText = [System.Text.RegularExpressions.Regex]::Replace(
            $frmText,
            $captionPattern,
            '${1}USERFORM_NEW_CAPTION${2}',
            1)
        [System.IO.File]::WriteAllText($sourcePath, $frmText, $frmEncoding)

        if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf)) {
            throw ".frmファイルをエクスポートできませんでした。"
        }

        if (-not (Test-Path -LiteralPath $frxPath -PathType Leaf)) {
            throw ".frxファイルをエクスポートできませんでした。"
        }

        Write-Success "UserForm専用テスト環境を作成しました。"
        Write-Host "対象ブック : $workbookPath"
        Write-Host "更新ソース : $sourcePath"
        Write-Host "バイナリ   : $frxPath"
    }
    finally {
        Release-ComObject $testCode
        Release-ComObject $testModule
        Release-ComObject $sourceCode
        Release-ComObject $targetCode
        Release-ComObject $sourceLabel
        Release-ComObject $targetLabel
        Release-ComObject $sourceDesigner
        Release-ComObject $targetDesigner
        Release-ComObject $sourceForm
        Release-ComObject $targetForm

        if ($null -ne $sourceBook) {
            try { $sourceBook.Close($false) } catch { Write-Warn ('Sourceブックの終了処理に失敗しました: ' + $_.Exception.Message) }
            Release-ComObject $sourceBook
        }

        Close-ExcelApplication -Excel $excel -Workbook $targetBook
    }
}

function Invoke-UserFormTestPush {
    $testRoot=Get-LegacyTestRoot
    $workbookPath = Join-Path $testRoot "VBAUserFormEngineTest.xlsm"
    $sourcePath = Join-Path $testRoot "frmUpdaterTest.frm"
    $frxPath = Join-Path $testRoot "frmUpdaterTest.frx"

    foreach ($path in @($workbookPath, $sourcePath, $frxPath)) {
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            throw "先に userform-test-create を実行してください: $path"
        }
    }

    Invoke-EngineComponentUpdate `
        -MacroProcedure "UpdateUserForm" `
        -WorkbookPath $workbookPath `
        -SourcePath $sourcePath `
        -ComponentName "frmUpdaterTest" `
        -BackupPrefix "before_userform_push" `
        -ResultPrefix "userform_result" `
        -DisplayName "UserForm"
}

function Invoke-UserFormTestRun {
    $workbookPath = Join-Path (Get-LegacyTestRoot) "VBAUserFormEngineTest.xlsm"

    if (-not (Test-Path -LiteralPath $workbookPath -PathType Leaf)) {
        throw "先に userform-test-create を実行してください。"
    }

    $excel = $null
    $workbook = $null

    try {
        Write-Info "UserForm更新結果を検証しています..."

        $excel = New-ExcelApplication
        $excel.AutomationSecurity = 1
        Invoke-TestWorkbookOpenAudit -Path $workbookPath
        $workbook = $excel.Workbooks.Open($workbookPath, 0, $true)

        $result = [string]$excel.Run("'" + $workbook.Name + "'!GetUserFormEngineTestValue")
        $expected = "USERFORM_NEW_VALUE|USERFORM_NEW_CAPTION|LABEL_NEW_VALUE"

        if ($result -ne $expected) {
            throw "更新結果が一致しません。Expected=$expected / Actual=$result"
        }

        Write-Success "UserForm更新の自動テストに成功しました。"
        Write-Host "結果: $result"
    }
    finally {
        Close-ExcelApplication -Excel $excel -Workbook $workbook
    }
}

function Invoke-ClassTestCreate {
    $testRoot = Get-LegacyTestRoot
    if (-not (Test-Path -LiteralPath $testRoot)) {
        New-Item -ItemType Directory -Path $testRoot -Force | Out-Null
    }

    $workbookPath = Join-Path $testRoot "VBAClassEngineTest.xlsm"
    $sourcePath = Join-Path $testRoot "clsAddinTarget.cls"

    if (Test-Path -LiteralPath $workbookPath) {
        Remove-Item -LiteralPath $workbookPath -Force
    }

    $sourceCode = @'
VERSION 1.0 CLASS
BEGIN
  MultiUse = -1  'True
END
Attribute VB_Name = "clsAddinTarget"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit

Public Function GetValue() As String
    GetValue = "CLASS_NEW_VALUE"
End Function
'@

    [System.IO.File]::WriteAllText(
        $sourcePath,
        $sourceCode,
        (New-Object System.Text.UTF8Encoding($true))
    )

    $excel = $null
    $workbook = $null
    $classModule = $null
    $testModule = $null
    $classCodeModule = $null
    $testCodeModule = $null

    try {
        Write-Info "クラスモジュール専用テストブックを作成しています..."

        $excel = New-ExcelApplication
        $excel.AutomationSecurity = 3

        $workbook = $excel.Workbooks.Add()

        $classModule = $workbook.VBProject.VBComponents.Add(2)
        $classModule.Name = "clsAddinTarget"
        $classCodeModule = $classModule.CodeModule
        $classCodeModule.AddFromString(@'
Option Explicit

Public Function GetValue() As String
    GetValue = "CLASS_OLD_VALUE"
End Function
'@)

        $testModule = $workbook.VBProject.VBComponents.Add(1)
        $testModule.Name = "modClassTest"
        $testCodeModule = $testModule.CodeModule
        $testCodeModule.AddFromString(@'
Option Explicit

Public Function GetClassEngineTestValue() As String
    Dim target As clsAddinTarget
    Set target = New clsAddinTarget
    GetClassEngineTestValue = target.GetValue
End Function
'@)

        $workbook.SaveAs($workbookPath, 52)

        Write-Success "クラスモジュール専用テスト環境を作成しました。"
        Write-Host "対象ブック : $workbookPath"
        Write-Host "更新ソース : $sourcePath"
    }
    finally {
        Release-ComObject $testCodeModule
        Release-ComObject $classCodeModule
        Release-ComObject $testModule
        Release-ComObject $classModule
        Close-ExcelApplication -Excel $excel -Workbook $workbook
    }
}

function Invoke-ClassTestRun {
    $workbookPath = Join-Path (Get-LegacyTestRoot) "VBAClassEngineTest.xlsm"

    if (-not (Test-Path -LiteralPath $workbookPath -PathType Leaf)) {
        throw "クラス用テストブックがありません。先に class-test-create を実行してください。"
    }

    $excel = $null
    $workbook = $null

    try {
        Write-Info "クラスモジュール更新結果を検証しています..."

        $excel = New-ExcelApplication
        $excel.AutomationSecurity = 1
        Invoke-TestWorkbookOpenAudit -Path $workbookPath
        $workbook = $excel.Workbooks.Open($workbookPath, 0, $true)

        $result = [string]$excel.Run("'" + $workbook.Name + "'!GetClassEngineTestValue")

        if ($result -ne "CLASS_NEW_VALUE") {
            throw "更新結果が一致しません。Expected=CLASS_NEW_VALUE / Actual=$result"
        }

        Write-Success "クラスモジュール更新の自動テストに成功しました。"
        Write-Host "結果: $result"
    }
    finally {
        Close-ExcelApplication -Excel $excel -Workbook $workbook
    }
}



function Get-TargetWorkbook {
    param(
        [Parameter(Mandatory = $true)][string]$TargetDir,
        [string]$WorkbookPath
    )

    $resolvedTargetDir = Resolve-PathValue $TargetDir
    if (-not (Test-Path -LiteralPath $resolvedTargetDir -PathType Container)) {
        throw "targetフォルダが見つかりません: $resolvedTargetDir"
    }

    if (-not [string]::IsNullOrWhiteSpace($WorkbookPath)) {
        $resolvedWorkbook = Resolve-PathValue $WorkbookPath
        if (-not (Test-Path -LiteralPath $resolvedWorkbook -PathType Leaf)) {
            throw "指定された対象ブックが見つかりません: $resolvedWorkbook"
        }
        $extension = [System.IO.Path]::GetExtension($resolvedWorkbook)
        if ($extension -notin @('.xlsm', '.xlam', '.xlsb')) {
            throw "対象ブックの拡張子が対応外です: $extension"
        }
        return $resolvedWorkbook
    }

    $candidates = @(
        Get-ChildItem -LiteralPath $resolvedTargetDir -File |
            Where-Object { $_.Extension.ToLowerInvariant() -in @('.xlsm', '.xlam', '.xlsb') }
    )

    if ($candidates.Count -eq 0) {
        throw "targetフォルダに対象ブックがありません: $resolvedTargetDir"
    }
    if ($candidates.Count -gt 1) {
        $names = ($candidates | ForEach-Object { $_.Name }) -join ', '
        throw "targetフォルダに対象ブックが複数あります。WorkbookPathを指定してください。候補: $names"
    }

    return $candidates[0].FullName
}

function Test-SourceFileSafety {
    param([Parameter(Mandatory = $true)][string]$SourceRoot)

    $resolvedSourceRoot = Resolve-PathValue $SourceRoot
    if (-not (Test-Path -LiteralPath $resolvedSourceRoot -PathType Container)) {
        throw "sourceフォルダが見つかりません: $resolvedSourceRoot"
    }

    $supported = @('.bas', '.cls', '.frm')
    $files = @(Get-ChildItem -LiteralPath $resolvedSourceRoot -Recurse -File | Where-Object { $_.Extension.ToLowerInvariant() -in $supported })
    $warnings = New-Object System.Collections.Generic.List[string]

    foreach ($file in $files) {
        $raw = [System.IO.File]::ReadAllText($file.FullName, [System.Text.Encoding]::UTF8)
        if ($raw.IndexOf([char]0) -ge 0) {
            throw "ソースにNUL文字が含まれています: $($file.FullName)"
        }
        if ($file.Extension.ToLowerInvariant() -eq '.frm') {
            $frx = [System.IO.Path]::ChangeExtension($file.FullName, '.frx')
            if (-not (Test-Path -LiteralPath $frx -PathType Leaf)) {
                $warnings.Add("UserFormの.frxがありません: $frx")
            }
        }
    }

    return [PSCustomObject]@{
        SourceRoot = $resolvedSourceRoot
        FileCount = $files.Count
        Warnings = @($warnings)
    }
}

function Invoke-Preflight {
    param([string[]]$Arguments)

    $targetDir = Get-NamedArgument -Arguments $Arguments -Name '-TargetDir'
    $workbookPath = Get-NamedArgument -Arguments $Arguments -Name '-WorkbookPath'
    $sourceRoot = Get-NamedArgument -Arguments $Arguments -Name '-SourceRoot'

    if ([string]::IsNullOrWhiteSpace($targetDir)) {
        throw '-TargetDir を指定してください。'
    }

    Write-Info 'Preflightを実行しています...'
    $target = Get-TargetWorkbook -TargetDir $targetDir -WorkbookPath $workbookPath
    Write-Success "対象ブックを確定しました: $target"

    $sourceResult = $null
    if (-not [string]::IsNullOrWhiteSpace($sourceRoot)) {
        $sourceResult = Test-SourceFileSafety -SourceRoot $sourceRoot
        Write-Host "ソースファイル数: $($sourceResult.FileCount)"
        foreach ($warning in $sourceResult.Warnings) { Write-Warn $warning }
    }

    Write-Success 'Preflightに成功しました。'
}

function Invoke-CompileCheck {
    param([string[]]$Arguments)

    $workbookArg = Get-NamedArgument -Arguments $Arguments -Name '-WorkbookPath'
    $macroName = Get-NamedArgument -Arguments $Arguments -Name '-MacroName'
    if ([string]::IsNullOrWhiteSpace($workbookArg)) { throw '-WorkbookPath を指定してください。' }
    $workbookPath = Resolve-PathValue $workbookArg
    if (-not (Test-Path -LiteralPath $workbookPath -PathType Leaf)) { throw "対象ブックが見つかりません: $workbookPath" }

    $excel=$null; $workbook=$null
    try {
        Write-Info '更新後コンパイルゲートを実行しています...'
        $excel = New-ExcelApplication
        $excel.AutomationSecurity = 1
        Invoke-TestWorkbookOpenAudit -Path $workbookPath
        $workbook = $excel.Workbooks.Open($workbookPath, 0, $false)

        if (-not [string]::IsNullOrWhiteSpace($macroName)) {
            [void]$excel.Run("'" + $workbook.Name + "'!" + $macroName)
        } else {
            # VBEのCompileコマンドはUI依存のため、参照解決と全CodeModule読み取りを最低限の共通ゲートとする。
            foreach ($reference in $workbook.VBProject.References) {
                if ($reference.IsBroken) { throw "参照設定が壊れています: $($reference.Name)" }
            }
            foreach ($component in $workbook.VBProject.VBComponents) {
                $null = $component.CodeModule.CountOfLines
            }
        }
        $workbook.Save()
        Write-Success '更新後コンパイルゲートに成功しました。'
    } finally {
        Close-ExcelApplication -Excel $excel -Workbook $workbook
    }
}

function Invoke-PreflightTest {
    $root = Join-Path (Get-LegacyTestRoot) 'preflight'
    if (Test-Path -LiteralPath $root) { Remove-Item -LiteralPath $root -Recurse -Force }
    New-Item -ItemType Directory -Path $root -Force | Out-Null

    Write-Info 'Preflight異常系回帰テストを実行しています...'

    $case1 = Join-Path $root 'single'
    New-Item -ItemType Directory -Path $case1 | Out-Null
    New-Item -ItemType File -Path (Join-Path $case1 'PropertyManagement_Ver1.xlsm') | Out-Null
    $r1 = Get-TargetWorkbook -TargetDir $case1
    if ([System.IO.Path]::GetFileName($r1) -ne 'PropertyManagement_Ver1.xlsm') { throw '単一候補の自動検出に失敗しました。' }

    $case2 = Join-Path $root 'garbled'
    New-Item -ItemType Directory -Path $case2 | Out-Null
    New-Item -ItemType File -Path (Join-Path $case2 '譁�蟄怜喧_target.xlsm') | Out-Null
    $null = Get-TargetWorkbook -TargetDir $case2

    $case3 = Join-Path $root 'multiple'
    New-Item -ItemType Directory -Path $case3 | Out-Null
    New-Item -ItemType File -Path (Join-Path $case3 'A.xlsm') | Out-Null
    New-Item -ItemType File -Path (Join-Path $case3 'B.xlsm') | Out-Null
    $stopped = $false
    try { $null = Get-TargetWorkbook -TargetDir $case3 } catch { $stopped = $true }
    if (-not $stopped) { throw '複数候補時に安全停止しませんでした。' }

    $case4 = Join-Path $root 'none'
    New-Item -ItemType Directory -Path $case4 | Out-Null
    $stopped = $false
    try { $null = Get-TargetWorkbook -TargetDir $case4 } catch { $stopped = $true }
    if (-not $stopped) { throw '候補なし時に安全停止しませんでした。' }

    Write-Success 'Preflight異常系回帰テストに成功しました。'
}


function Test-ProjectCreateName {
    param([AllowEmptyString()][string]$Project)

    if ([string]::IsNullOrWhiteSpace($Project)) { throw 'プロジェクト内部名を入力してください。' }
    if ($Project -notmatch '^[A-Za-z][A-Za-z0-9_-]*$') {
        throw 'プロジェクト内部名は英字で始め、半角英数字、ハイフン、アンダースコアだけで指定してください。'
    }
    $reserved = @('CON','PRN','AUX','NUL','COM1','COM2','COM3','COM4','COM5','COM6','COM7','COM8','COM9','LPT1','LPT2','LPT3','LPT4','LPT5','LPT6','LPT7','LPT8','LPT9')
    if ($reserved -contains $Project.ToUpperInvariant()) {
        throw "Windowsで使用できないプロジェクト内部名です: $Project"
    }
    return $true
}

function Test-ProjectCreateWorkbook {
    param([Parameter(Mandatory=$true)][string]$WorkbookPath)

    if ([string]::IsNullOrWhiteSpace($WorkbookPath)) { throw '-WorkbookPath を指定してください。' }
    $resolved = Resolve-PathValue -PathValue $WorkbookPath
    if (-not (Test-Path -LiteralPath $resolved -PathType Leaf)) { throw "Excelブックが見つかりません: $resolved" }
    $extension = [System.IO.Path]::GetExtension($resolved).ToLowerInvariant()
    if ($extension -notin @('.xlsm','.xlsb','.xlam')) {
        throw "対応していないブック形式です: $extension（対応形式: .xlsm / .xlsb / .xlam）"
    }

    $stream = $null
    try {
        $stream = [System.IO.File]::Open($resolved, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        if ($stream.Length -le 0) { throw "Excelブックのファイルサイズが0です: $resolved" }
    }
    catch {
        throw "Excelブックを読み取れません: $resolved / 詳細: $($_.Exception.Message)"
    }
    finally {
        if ($null -ne $stream) { $stream.Dispose() }
    }
    return $resolved
}

function Get-ProjectCreatePlan {
    param(
        [AllowNull()][AllowEmptyString()][string]$Project,
        [AllowNull()][AllowEmptyString()][string]$ProjectFolder,
        [Parameter(Mandatory=$true)][string]$WorkbookPath
    )

    if ([string]::IsNullOrWhiteSpace($ProjectFolder)) {
        if ([string]::IsNullOrWhiteSpace($Project)) { throw '-ProjectFolder を指定してください。' }
        [void](Test-ProjectCreateName -Project $Project)
        $ProjectFolder = Join-Path (Resolve-ProjectRoot) $Project
    }
    $validation = Get-ProjectRegistrationValidation -ProjectFolder $ProjectFolder -WorkbookPath $WorkbookPath -ToolRoot $script:Root
    if (-not [bool]$validation.IsValid) { throw (@($validation.Errors) -join ' / ') }
    if (-not [string]::IsNullOrWhiteSpace($Project) -and
        -not [string]::Equals($Project,[string]$validation.ProjectName,[System.StringComparison]::OrdinalIgnoreCase)) {
        throw "-Projectと-ProjectFolderのフォルダー名が一致しません。Project=$Project ProjectFolder=$($validation.ProjectFolder)"
    }
    $projectRoot = Split-Path -Parent ([string]$validation.ProjectFolder)
    return [PSCustomObject]@{
        Project=[string]$validation.ProjectName
        WorkbookPath=[string]$validation.WorkbookPath
        ProjectRoot=$projectRoot
        ProjectDir=[string]$validation.ProjectFolder
        TargetDir=[string]$validation.TargetDirectory
        SourceDir=[string]$validation.SourceDirectory
        TargetPath=[string]$validation.TargetPath
        ManifestPath=[string]$validation.ManifestPath
        IsGitRepository=[bool]$validation.IsGitRepository
        IsOneDrive=[bool]$validation.IsOneDrive
    }
}

function Invoke-ProjectRegistrationValidate {
    param([string[]]$Arguments)
    $projectFolder = Get-NamedArgument -Arguments $Arguments -Name '-ProjectFolder'
    $workbookPath = Get-NamedArgument -Arguments $Arguments -Name '-WorkbookPath'
    $result = Get-ProjectRegistrationValidation -ProjectFolder $projectFolder -WorkbookPath $workbookPath -ToolRoot $script:Root
    if (Test-ArgumentSwitch -Arguments $Arguments -Name '-Json') {
        Write-Output ($result | ConvertTo-Json -Depth 8)
        return
    }
    Write-Host 'Development Project Registration Validation'
    Write-Host ("Project Folder: {0}" -f $(if ([string]::IsNullOrWhiteSpace([string]$result.ProjectFolder)) {'<not selected>'} else {$result.ProjectFolder}))
    Write-Host ("Workbook      : {0}" -f $(if ([string]::IsNullOrWhiteSpace([string]$result.WorkbookPath)) {'<not selected>'} else {$result.WorkbookPath}))
    if ([bool]$result.IsValid) { Write-Success '登録できます。'; return }
    foreach ($message in @($result.Errors)) { Write-Failure $message }
    throw '開発プロジェクト登録の入力検証に失敗しました。'
}

function Copy-WorkbookToProjectTarget {
    param(
        [Parameter(Mandatory=$true)][string]$SourcePath,
        [Parameter(Mandatory=$true)][string]$TargetPath
    )

    if (-not (Test-Path -LiteralPath $SourcePath -PathType Leaf)) { throw "コピー元ブックが見つかりません: $SourcePath" }
    if (Test-Path -LiteralPath $TargetPath) { throw "コピー先に同名ファイルが既に存在します。上書きしません: $TargetPath" }
    $targetParent = Split-Path -Parent $TargetPath
    if (-not (Test-Path -LiteralPath $targetParent -PathType Container)) { throw "コピー先フォルダーが見つかりません: $targetParent" }

    [System.IO.File]::Copy($SourcePath, $TargetPath, $false)
    if (-not (Test-Path -LiteralPath $TargetPath -PathType Leaf)) { throw "ブックをコピーできませんでした: $TargetPath" }
    $sourceLength = (Get-Item -LiteralPath $SourcePath).Length
    $targetLength = (Get-Item -LiteralPath $TargetPath).Length
    if ($targetLength -le 0 -or $targetLength -ne $sourceLength) {
        throw "コピー後のファイルサイズが一致しません。Source=$sourceLength Target=$targetLength"
    }
}

function Get-WorkbookManifestComponents {
    param([Parameter(Mandatory=$true)][string]$WorkbookPath)

    $excel = $null
    $workbook = $null
    $vbProject = $null
    $vbComponents = $null
    $definitions = New-Object 'System.Collections.Generic.List[object]'
    try {
        Write-Info 'コピーしたブックからproject.json用のコンポーネント情報を確認しています...'
        $excel = New-ExcelApplication
        $excel.AutomationSecurity = 3
        $workbook = Open-WorkbookReadOnlySafe -Excel $excel -Path $WorkbookPath
        if ($null -eq $workbook) { throw 'コピーしたブックを読み取り専用で開けませんでした。' }
        $vbProject = $workbook.VBProject
        if ($null -eq $vbProject) { throw 'VBProjectを取得できませんでした。Excelの「VBAプロジェクト オブジェクト モデルへのアクセスを信頼する」を確認してください。' }
        $vbComponents = $vbProject.VBComponents
        if ($null -eq $vbComponents) { throw 'VBProject.VBComponentsを取得できませんでした。' }

        for ($index = 1; $index -le [int]$vbComponents.Count; $index++) {
            $component = $null
            try {
                $component = $vbComponents.Item($index)
                $name = [string]$component.Name
                $typeNumber = [int]$component.Type
                $definition = switch ($typeNumber) {
                    1 { [PSCustomObject]@{ type='standard'; name=$name; file=('standard/' + $name + '.bas') } }
                    2 { [PSCustomObject]@{ type='class'; name=$name; file=('class/' + $name + '.cls') } }
                    3 { [PSCustomObject]@{ type='userform'; name=$name; file=('userforms/' + $name + '.frm'); binaryFile=('userforms/' + $name + '.frx') } }
                    100 { [PSCustomObject]@{ type='document'; name=$name; file=('document/' + $name + '.cls') } }
                    default { $null }
                }
                if ($null -eq $definition) {
                    Write-Warn ("未対応のVBAコンポーネントをproject.json対象外にします: {0} (Type={1})" -f $name,$typeNumber)
                    continue
                }
                $definitions.Add($definition)
                Write-Host ("  [OK] {0} ({1})" -f $definition.name,$definition.type)
            }
            finally { Release-ComObject $component }
        }
    }
    catch {
        throw "project.json用のコンポーネント情報を取得できませんでした: $($_.Exception.Message)"
    }
    finally {
        Release-ComObject $vbComponents
        Release-ComObject $vbProject
        Close-ExcelApplication -Excel $excel -Workbook $workbook
    }
    return @($definitions.ToArray())
}

function New-InitialProjectManifest {
    param(
        [Parameter(Mandatory=$true)][string]$Project,
        [Parameter(Mandatory=$true)][string]$TargetFileName,
        [AllowEmptyCollection()][object[]]$Components = @()
    )

    $managed = @($Components | Where-Object { [string]$_.type -ne 'document' } | ForEach-Object {
        [PSCustomObject]@{ type=[string]$_.type; name=[string]$_.name }
    })
    return [PSCustomObject]@{
        schemaVersion='1.0'
        projectName=$Project
        target=[PSCustomObject]@{
            directory='target'
            file=$TargetFileName
            autoDetectWhenMissing=$true
        }
        source=[PSCustomObject]@{
            root='source'
            encoding='utf-8'
        }
        components=@($Components)
        compileGate=[PSCustomObject]@{
            macro=''
            required=$false
        }
        validation=[PSCustomObject]@{
            requireBackup=$true
        }
        sync=[PSCustomObject]@{
            deletePolicy='report-only'
            managedComponents=$managed
        }
    }
}

function Write-InitialProjectManifest {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)]$Manifest
    )
    $json = $Manifest | ConvertTo-Json -Depth 10
    [System.IO.File]::WriteAllText($Path, $json, (New-Object System.Text.UTF8Encoding($false)))
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "project.jsonを生成できませんでした: $Path" }
    try { [void](Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json) }
    catch { throw "生成したproject.jsonを読み込めません: $($_.Exception.Message)" }
}

function Invoke-ProjectPullChildProcess {
    param(
        [Parameter(Mandatory=$true)][string]$Project,
        [Parameter(Mandatory=$true)][string]$ProjectFolder,
        [Parameter(Mandatory=$true)][string]$TargetWorkbookPath
    )

    Write-Info ("既存CLIを呼び出します: .\vba.cmd project-pull -ProjectRoot `"{0}`" -WorkbookPath `"{1}`"" -f $ProjectFolder,$TargetWorkbookPath)
    $scriptPath = Join-Path $script:Root 'vba.ps1'
    # project-createの入力ブックではなく、登録先targetへコピー済みのブックを必ずPullする。
    # 呼び出し元プロセスに残るDirectWorkbookPathOverrideを参照すると、元ブックが再利用されるため禁止する。
    $childArguments = @('-NoProfile','-ExecutionPolicy','Bypass','-File',$scriptPath,'project-pull','-ProjectRoot',$ProjectFolder,'-WorkbookPath',$TargetWorkbookPath)
    $outputLines = @(& powershell.exe @childArguments 2>&1)
    $exitCode = $LASTEXITCODE
    foreach ($line in $outputLines) { Write-Host ([string]$line) }
    if ($exitCode -ne 0) { throw "project-pullが失敗しました。ExitCode=$exitCode" }
}

function Get-DirectoryEntryNames {
    param([Parameter(Mandatory=$true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) { return @() }
    return @(Get-ChildItem -LiteralPath $Path -Force -ErrorAction SilentlyContinue | ForEach-Object { $_.Name })
}

function Remove-ProjectCreateSideArtifacts {
    param(
        [Parameter(Mandatory=$true)][string]$Project,
        [string[]]$BackupNamesBefore = @(),
        [string[]]$LogNamesBefore = @()
    )

    $backupRoot = Get-RuntimeBackupDirectory
    if (Test-Path -LiteralPath $backupRoot -PathType Container) {
        foreach ($item in @(Get-ChildItem -LiteralPath $backupRoot -Force -ErrorAction SilentlyContinue)) {
            if ($BackupNamesBefore -contains $item.Name) { continue }
            if ($item.Name.StartsWith($Project + '_source_before_pull_', [System.StringComparison]::OrdinalIgnoreCase)) {
                Remove-Item -LiteralPath $item.FullName -Recurse -Force -ErrorAction Stop
            }
        }
    }

    $logRoot = Get-RuntimeLogDirectory
    if (Test-Path -LiteralPath $logRoot -PathType Container) {
        foreach ($file in @(Get-ChildItem -LiteralPath $logRoot -Filter 'project_pull_*.json' -File -ErrorAction SilentlyContinue)) {
            if ($LogNamesBefore -contains $file.Name) { continue }
            try {
                $payload = Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
                if ([string]::Equals([string]$payload.project, $Project, [System.StringComparison]::OrdinalIgnoreCase)) {
                    Remove-Item -LiteralPath $file.FullName -Force -ErrorAction Stop
                }
            }
            catch {
                if (Test-Path -LiteralPath $file.FullName -PathType Leaf) { throw }
            }
        }
    }
}

function Write-ProjectRegistrationLog {
    param(
        [Parameter(Mandatory=$true)][string]$Status,
        [AllowNull()][string]$ProjectFolder,
        [AllowNull()][string]$WorkbookPath,
        [AllowNull()][string]$Message
    )
    $logRoot = Get-RuntimeLogDirectory
    New-Item -ItemType Directory -Path $logRoot -Force | Out-Null
    $projectName = if ([string]::IsNullOrWhiteSpace($ProjectFolder)) { 'unknown' } else { [System.IO.Path]::GetFileName($ProjectFolder) }
    $safeName = [System.Text.RegularExpressions.Regex]::Replace($projectName,'[^A-Za-z0-9_-]+','_').Trim('_')
    if ([string]::IsNullOrWhiteSpace($safeName)) { $safeName = 'project' }
    $timestamp = [DateTime]::Now
    $payload = [PSCustomObject]@{
        schemaVersion='1.0'; version=$script:ToolVersion; operation='project-registration'; status=$Status
        timestamp=$timestamp.ToString('o'); project=$projectName; projectFolder=$ProjectFolder
        workbookPath=$WorkbookPath; message=$Message
    }
    $path = Join-Path $logRoot ("project_registration_{0}_{1}_{2}.json" -f $timestamp.ToString('yyyyMMdd_HHmmssfff'),$safeName,[guid]::NewGuid().ToString('N').Substring(0,8))
    [System.IO.File]::WriteAllText($path,($payload | ConvertTo-Json -Depth 6),(New-Object System.Text.UTF8Encoding($false)))
    return $path
}

function Invoke-ProjectCreateCore {
    param(
        [AllowNull()][AllowEmptyString()][string]$Project,
        [AllowNull()][AllowEmptyString()][string]$ProjectFolder,
        [Parameter(Mandatory=$true)][string]$WorkbookPath,
        [scriptblock]$ComponentDiscovery,
        [scriptblock]$ProjectPullInvoker
    )

    $plan = Get-ProjectCreatePlan -Project $Project -ProjectFolder $ProjectFolder -WorkbookPath $WorkbookPath
    $backupRoot = Get-RuntimeBackupDirectory
    $logRoot = Get-RuntimeLogDirectory
    $backupNamesBefore = @(Get-DirectoryEntryNames -Path $backupRoot)
    $logNamesBefore = @(Get-DirectoryEntryNames -Path $logRoot)
    $createdTargetDirectory = $false
    $createdSourceDirectory = $false
    $copiedWorkbook = $false
    $createdManifest = $false
    $previousDirectProjectPath = $script:DirectProjectPathOverride

    try {
        New-Item -ItemType Directory -Path $plan.TargetDir -ErrorAction Stop | Out-Null
        $createdTargetDirectory = $true
        New-Item -ItemType Directory -Path $plan.SourceDir -ErrorAction Stop | Out-Null
        $createdSourceDirectory = $true

        Write-Info '選択したExcelブックを管理対象ブックとしてプロジェクトへコピーしています...'
        Copy-WorkbookToProjectTarget -SourcePath $plan.WorkbookPath -TargetPath $plan.TargetPath
        $copiedWorkbook = $true

        $components = if ($null -ne $ComponentDiscovery) {
            @(& $ComponentDiscovery $plan.TargetPath)
        }
        else {
            @(Get-WorkbookManifestComponents -WorkbookPath $plan.TargetPath)
        }
        $manifest = New-InitialProjectManifest -Project $plan.Project -TargetFileName ([System.IO.Path]::GetFileName($plan.TargetPath)) -Components $components
        Write-InitialProjectManifest -Path $plan.ManifestPath -Manifest $manifest
        $createdManifest = $true
        $script:DirectProjectPathOverride = $plan.ProjectDir

        if ($null -ne $ProjectPullInvoker) { & $ProjectPullInvoker $plan.Project }
        else { Invoke-ProjectPullChildProcess -Project $plan.Project -ProjectFolder $plan.ProjectDir -TargetWorkbookPath $plan.TargetPath }

        if (-not (Test-Path -LiteralPath $plan.ProjectDir -PathType Container)) { throw 'プロジェクトフォルダーが作成されていません。' }
        if (-not (Test-Path -LiteralPath $plan.TargetPath -PathType Leaf)) { throw 'targetブックが作成されていません。' }
        if (-not (Test-Path -LiteralPath $plan.ManifestPath -PathType Leaf)) { throw 'project.jsonが作成されていません。' }
        if (-not (Test-Path -LiteralPath $plan.SourceDir -PathType Container)) { throw 'sourceフォルダーが作成されていません。' }

        $context = Read-ProjectManifest -Project $plan.Project
        [void](Test-ProjectManifestForPull -Context $context)
        foreach ($component in @($context.Manifest.components)) {
            $sourcePath = Resolve-ManifestPath -ProjectDir $context.ProjectDir -PathValue (Join-Path ([string]$context.Manifest.source.root) ([string]$component.file))
            if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf)) { throw "初期ソースが作成されていません: $sourcePath" }
            if (([string]$component.type).ToLowerInvariant() -eq 'userform') {
                $binaryFile = if ($component.PSObject.Properties['binaryFile']) { [string]$component.binaryFile } else { [System.IO.Path]::ChangeExtension([string]$component.file, '.frx') }
                $binaryPath = Resolve-ManifestPath -ProjectDir $context.ProjectDir -PathValue (Join-Path ([string]$context.Manifest.source.root) $binaryFile)
                if (-not (Test-Path -LiteralPath $binaryPath -PathType Leaf)) { throw "UserFormの初期.frxが作成されていません: $binaryPath" }
            }
        }

        return [PSCustomObject]@{
            Project=$plan.Project
            ProjectRoot=$plan.ProjectRoot
            WorkbookPath=$plan.WorkbookPath
            TargetPath=$plan.TargetPath
            ProjectDirectory=$plan.ProjectDir
            ManifestPath=$plan.ManifestPath
            ComponentCount=@($components).Count
        }
    }
    catch {
        $failureMessage = $_.Exception.Message
        $cleanupErrors = New-Object 'System.Collections.Generic.List[string]'
        if ($createdManifest -and (Test-Path -LiteralPath $plan.ManifestPath -PathType Leaf)) {
            try { Remove-Item -LiteralPath $plan.ManifestPath -Force -ErrorAction Stop } catch { $cleanupErrors.Add($_.Exception.Message) }
        }
        if ($createdSourceDirectory -and (Test-Path -LiteralPath $plan.SourceDir -PathType Container)) {
            try { Remove-Item -LiteralPath $plan.SourceDir -Recurse -Force -ErrorAction Stop } catch { $cleanupErrors.Add($_.Exception.Message) }
        }
        if ($createdTargetDirectory -and (Test-Path -LiteralPath $plan.TargetDir -PathType Container)) {
            try { Remove-Item -LiteralPath $plan.TargetDir -Recurse -Force -ErrorAction Stop } catch { $cleanupErrors.Add($_.Exception.Message) }
        }
        elseif ($copiedWorkbook -and (Test-Path -LiteralPath $plan.TargetPath -PathType Leaf)) {
            try { Remove-Item -LiteralPath $plan.TargetPath -Force -ErrorAction Stop } catch { $cleanupErrors.Add($_.Exception.Message) }
        }
        try { Remove-ProjectCreateSideArtifacts -Project $plan.Project -BackupNamesBefore $backupNamesBefore -LogNamesBefore $logNamesBefore }
        catch { $cleanupErrors.Add($_.Exception.Message) }

        $cleanupText = if ($cleanupErrors.Count -eq 0) {
            '今回作成した登録用ファイルだけを削除し、開発プロジェクトフォルダと既存ファイルは保持しました。'
        }
        else {
            '完全に削除できない項目があります: ' + ($cleanupErrors -join ' / ')
        }
        throw "開発プロジェクトを登録できませんでした。$failureMessage $cleanupText 元のExcelブックは変更していません。"
    }
    finally { $script:DirectProjectPathOverride = $previousDirectProjectPath }
}

function Invoke-ProjectCreate {
    param([string[]]$Arguments)

    $project = Get-NamedArgument -Arguments $Arguments -Name '-Project'
    $projectFolder = Get-NamedArgument -Arguments $Arguments -Name '-ProjectFolder'
    $workbookPath = Get-NamedArgument -Arguments $Arguments -Name '-WorkbookPath'
    if ([string]::IsNullOrWhiteSpace($projectFolder) -and [string]::IsNullOrWhiteSpace($project)) { throw '-ProjectFolder を指定してください。' }
    if ([string]::IsNullOrWhiteSpace($workbookPath)) { throw '-WorkbookPath を指定してください。' }
    try {
        $result = Invoke-ProjectCreateCore -Project $project -ProjectFolder $projectFolder -WorkbookPath $workbookPath
        try {
            [void](Write-ProjectRootSettings -ProjectRoot $result.ProjectRoot -LastProjectRoot $result.ProjectDirectory -LastWorkbookPath $result.TargetPath)
            [void](Add-OrUpdateRegisteredProject -ProjectFolder $result.ProjectDirectory -Name $result.Project)
        }
        catch { Write-Warn ("登録は完了しましたが、Project Root設定を更新できませんでした: {0}" -f $_.Exception.Message) }
        $logPath = Write-ProjectRegistrationLog -Status 'Success' -ProjectFolder $result.ProjectDirectory -WorkbookPath $result.WorkbookPath -Message '登録と初回project-pullが完了しました。'
        Write-Host ("Registration Log: {0}" -f $logPath)
    }
    catch {
        try { [void](Write-ProjectRegistrationLog -Status 'Failed' -ProjectFolder $projectFolder -WorkbookPath $workbookPath -Message $_.Exception.Message) } catch { Write-Verbose ('Project登録失敗ログを書き込めませんでした: ' + $_.Exception.Message) }
        throw
    }

    Write-Host ''
    Write-Host '====================================='
    Write-Host 'Development Project Registration Summary'
    Write-Host '====================================='
    Write-Host ("Project       : {0}" -f $result.Project)
    Write-Host ("Target Book   : {0}" -f ([System.IO.Path]::GetFileName($result.TargetPath)))
    Write-Host ("Components    : {0}" -f $result.ComponentCount)
    Write-Host ("Project Folder: {0}" -f $result.ProjectDirectory)
    Write-Host '====================================='
    Write-Success '開発プロジェクトの登録が完了しました。Excelブックを登録し、初期ソースを作成しました。'
    Write-Host '今後はproject-syncから安全にブックを更新できます。'
}


function Get-ProjectDirectory {
    param([AllowEmptyString()][string]$Project)
    $resolved = Resolve-ProjectPath -Project $Project
    if (-not (Test-Path -LiteralPath $resolved -PathType Container)) { throw "プロジェクトフォルダが見つかりません: $resolved" }
    return $resolved
}

function Read-ProjectManifest {
    param([AllowEmptyString()][string]$Project)
    $projectDir = Get-ProjectDirectory -Project $Project
    if($null-ne$script:TestExecutionContext){$projectDir=Assert-TestProjectRootSafety -ProjectRoot $projectDir}
    $manifestPath = Join-Path $projectDir 'project.json'
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) { throw "project.jsonが見つかりません: $manifestPath" }
    try { $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json }
    catch { throw "project.jsonを読み込めません。JSON構文を確認してください: $($_.Exception.Message)" }
    return [PSCustomObject]@{ ProjectDir=$projectDir; ManifestPath=$manifestPath; Manifest=$manifest }
}

function Resolve-ManifestPath {
    param([string]$ProjectDir,[string]$PathValue)
    if ([string]::IsNullOrWhiteSpace($PathValue)) { return $null }
    if ([System.IO.Path]::IsPathRooted($PathValue)) { return [System.IO.Path]::GetFullPath($PathValue) }
    return [System.IO.Path]::GetFullPath((Join-Path $ProjectDir $PathValue))
}

function Test-CompileGateManifestSettings {
    param([Parameter(Mandatory=$true)]$Context)
    $manifest = $Context.Manifest
    if ($null -eq $manifest.PSObject.Properties['compileGate']) { return $true }

    $gate = $manifest.compileGate
    if ($null -eq $gate -or $gate -is [string] -or $gate -is [System.Array] -or $gate -is [System.ValueType]) {
        throw 'compileGateはmacroとrequiredを持つJSONオブジェクトで指定してください。'
    }
    if ($gate.PSObject.Properties['macro'] -and $null -ne $gate.macro -and -not ($gate.macro -is [string])) {
        throw 'compileGate.macroは文字列で指定してください。'
    }
    if ($gate.PSObject.Properties['required'] -and -not ($gate.required -is [bool])) {
        throw 'compileGate.requiredはtrueまたはfalseで指定してください。'
    }

    $required = $false
    if ($gate.PSObject.Properties['required']) { $required = [bool]$gate.required }
    $macro = if ($gate.PSObject.Properties['macro']) { [string]$gate.macro } else { '' }
    if ($required -and [string]::IsNullOrWhiteSpace($macro)) {
        throw 'compileGate.required=trueの場合はcompileGate.macroを指定してください。'
    }
    return $true
}

function Get-ProjectCompileGateSettings {
    param([Parameter(Mandatory=$true)]$Context)
    $manifest = $Context.Manifest
    $macro = ''
    $required = $false
    $source = 'none'

    if ($manifest.PSObject.Properties['compileGate'] -and $null -ne $manifest.compileGate) {
        $gate = $manifest.compileGate
        if ($gate.PSObject.Properties['macro']) { $macro = [string]$gate.macro }
        if ($gate.PSObject.Properties['required']) { $required = [bool]$gate.required }
        $source = 'compileGate'
    }
    elseif ($manifest.PSObject.Properties['validation'] -and $null -ne $manifest.validation) {
        $legacyEnabled = $true
        if ($manifest.validation.PSObject.Properties['compileAfterPush']) {
            $legacyEnabled = [bool]$manifest.validation.compileAfterPush
        }
        if ($legacyEnabled -and $manifest.validation.PSObject.Properties['compileMacro']) {
            $macro = [string]$manifest.validation.compileMacro
            if (-not [string]::IsNullOrWhiteSpace($macro)) { $source = 'validation.compileMacro' }
        }
    }

    return [PSCustomObject]@{
        Macro = $macro.Trim()
        Required = $required
        Configured = -not [string]::IsNullOrWhiteSpace($macro)
        Source = $source
    }
}

function Get-CompileGateExceptionDetails {
    param([Parameter(Mandatory=$true)][System.Exception]$Exception)
    $messages = New-Object 'System.Collections.Generic.List[string]'
    $types = New-Object 'System.Collections.Generic.List[string]'
    $phase = ''
    $current = $Exception
    $depth = 0
    while ($null -ne $current -and $depth -lt 8) {
        if (-not [string]::IsNullOrWhiteSpace($current.Message)) { [void]$messages.Add($current.Message) }
        [void]$types.Add($current.GetType().FullName)
        if ([string]::IsNullOrWhiteSpace($phase) -and $null -ne $current.Data -and $current.Data.Contains('CompileGatePhase')) {
            $phase = [string]$current.Data['CompileGatePhase']
        }
        $current = $current.InnerException
        $depth++
    }
    $message = ($messages -join ' --> ')
    $type = (@($types | Select-Object -Unique) -join ' --> ')

    if ($phase -ne 'RunMacro') {
        return [PSCustomObject]@{ Classification='ExcelComFailure'; Phase=$phase; ExceptionType=$type; ExceptionMessage=$message; Reason=('Excel COM操作に失敗しました。Phase=' + $(if ([string]::IsNullOrWhiteSpace($phase)) { 'Unknown' } else { $phase })) }
    }

    $unavailablePattern = 'マクロ.*実行できません|マクロが使用できない|すべてのマクロが無効|マクロ\s*セキュリティ|セキュリティ.*ブロック|cannot run the macro|macro may not be available|macros may be disabled|macro security|blocked by.*security|public sub|パブリック.*sub|argument not optional|引数.*(必要|指定)'
    if ($message -match $unavailablePattern) {
        return [PSCustomObject]@{ Classification='MacroUnavailable'; Phase=$phase; ExceptionType=$type; ExceptionMessage=$message; Reason='指定されたマクロが対象ブックに存在しないか、外部から実行できません。' }
    }

    $runtimePattern = '実行時エラー|runtime error|application-defined or object-defined|アプリケーション定義またはオブジェクト定義|ユーザー定義|user-defined|subscript out of range|type mismatch|型が一致|object variable|オブジェクト変数'
    if ($message -match $runtimePattern) {
        return [PSCustomObject]@{ Classification='MacroRuntimeError'; Phase=$phase; ExceptionType=$type; ExceptionMessage=$message; Reason='マクロ内部で実行時エラーが発生しました。' }
    }

    return [PSCustomObject]@{ Classification='MacroExecutionError'; Phase=$phase; ExceptionType=$type; ExceptionMessage=$message; Reason='マクロ実行時の例外を安全に分類できませんでした。' }
}

function New-CompileGateResult {
    param(
        [string]$Macro,
        [bool]$Required,
        [string]$Result,
        [string]$Source,
        [string]$Classification = '',
        [string]$ExceptionType = '',
        [string]$ExceptionMessage = ''
    )
    return [PSCustomObject]@{
        Macro=$Macro
        Required=$Required
        Result=$Result
        Source=$Source
        Classification=$Classification
        ExceptionType=$ExceptionType
        ExceptionMessage=$ExceptionMessage
    }
}

function Write-CompileGateDiagnostics {
    param([Parameter(Mandatory=$true)]$Result)
    $message = ([string]$Result.ExceptionMessage) -replace '[\r\n]+',' '
    Write-Host ('CompileGateMacro=' + [string]$Result.Macro)
    Write-Host ('CompileGateRequired=' + ([bool]$Result.Required).ToString().ToLowerInvariant())
    Write-Host ('CompileGateResult=' + [string]$Result.Result)
    Write-Host ('ExceptionType=' + [string]$Result.ExceptionType)
    Write-Host ('ExceptionMessage=' + $message)
}

function Test-ProjectManifest {
    param([Parameter(Mandatory=$true)]$Context)
    $m=$Context.Manifest; $projectDir=$Context.ProjectDir
    foreach($name in @('schemaVersion','projectName','target','source','components','validation')) {
        if ($null -eq $m.PSObject.Properties[$name]) { throw "project.jsonの必須項目がありません: $name" }
    }
    if ([string]$m.schemaVersion -ne '1.0') { throw "未対応のschemaVersionです: $($m.schemaVersion)" }
    if ([string]::IsNullOrWhiteSpace([string]$m.projectName)) { throw 'projectNameが空です。' }
    [void](Test-CompileGateManifestSettings -Context $Context)
    if ($null -eq $m.components -or @($m.components).Count -eq 0) { throw 'componentsを1件以上指定してください。' }
    $supported=@('standard','class','document','userform')
    $seen=@{}
    foreach($c in @($m.components)) {
        foreach($required in @('type','name','file')) { if($null -eq $c.PSObject.Properties[$required] -or [string]::IsNullOrWhiteSpace([string]$c.$required)){ throw "componentの必須項目がありません: $required" } }
        $type=([string]$c.type).ToLowerInvariant()
        if($supported -notcontains $type){ throw "未対応のコンポーネント種別です: $($c.type)" }
        $key=$type+'|'+[string]$c.name
        if($seen.ContainsKey($key)){ throw "コンポーネント定義が重複しています: $key" };$seen[$key]=$true
        $sourcePath=Resolve-ManifestPath -ProjectDir $projectDir -PathValue (Join-Path ([string]$m.source.root) ([string]$c.file))
        if(-not(Test-Path -LiteralPath $sourcePath -PathType Leaf)){ throw "ソースファイルが見つかりません: $sourcePath" }
        if($type -eq 'userform'){
            $binary = if($c.PSObject.Properties['binaryFile'] -and -not [string]::IsNullOrWhiteSpace([string]$c.binaryFile)){ Resolve-ManifestPath -ProjectDir $projectDir -PathValue (Join-Path ([string]$m.source.root) ([string]$c.binaryFile)) } else { [System.IO.Path]::ChangeExtension($sourcePath,'.frx') }
            if(-not(Test-Path -LiteralPath $binary -PathType Leaf)){ throw "UserFormの.frxが見つかりません: $binary" }
        }
    }
    # project.json の workbook は任意。未指定時は従来のVBA-only経路へ影響させない。
    # 指定時だけ、専用モジュールでパス境界・JSON構文・schema・競合を検証する。
    if ($m.PSObject.Properties['workbook']) {
        [void](Get-WorkbookDefinitionContext -ProjectDir $projectDir -ProjectManifest $m)
    }
    return $true
}

function Test-IsIsolatedTestCommand {
    param([AllowEmptyString()][string]$CommandName)
    return $CommandName.ToLowerInvariant() -in @(
        'preflight-test','workbook-test','workbook-integration-test','cli-core-test','gui-process-test','gui-usability-test','gui-renewal-test',
        'project-registration-test','project-registration-hotfix-test','project-create-test','project-registration-v418-test','settings-persistence-test',
        'project-root-test','project-root-migration-test','codex-integration-test','project-folder-direct-reference-test','compile-gate-optional-test',
        'rollback-test','integrity-test','manifest-test','normalize-test','prepare-source-test','standalone-diff-test','differential-push-test',
        'test-isolation-test','regression-test','isolated-excel-regression-test',
        'test-create','test-run','class-test-create','class-test-run','document-test-create','document-test-push','document-test-run',
        'userform-test-create','userform-test-push','userform-test-run'
    )
}

function Get-RuntimeLogDirectory {
    if (-not [string]::IsNullOrWhiteSpace($script:RuntimeLogRootOverride)) { return [string]$script:RuntimeLogRootOverride }
    return (Join-Path $script:Root 'logs')
}

function Get-RuntimeBackupDirectory {
    param([AllowEmptyString()][string]$Child='')
    $root=if(-not [string]::IsNullOrWhiteSpace($script:RuntimeBackupRootOverride)){[string]$script:RuntimeBackupRootOverride}else{Join-Path $script:Root 'backups'}
    if([string]::IsNullOrWhiteSpace($Child)){return $root}
    return (Join-Path $root $Child)
}

function Get-LegacyTestRoot {
    $root=if($null-ne$script:TestExecutionContext){Join-Path $script:TestExecutionContext.Root 'legacy-test'}else{Join-Path $script:Root 'test'}
    if($null-ne$script:TestExecutionContext){
        New-Item -ItemType Directory -Path $root -Force|Out-Null
        $marker=Join-Path $root 'project.json'
        if(-not(Test-Path -LiteralPath $marker -PathType Leaf)){[IO.File]::WriteAllText($marker,'{}',(New-Object Text.UTF8Encoding($false)))}
        $script:CurrentTestProjectRoot=[IO.Path]::GetFullPath($root)
    }
    return $root
}

function Get-TestTempBase {
    if($null-ne$script:TestExecutionContext){return [string]$script:TestExecutionContext.Root}
    return [IO.Path]::GetTempPath()
}

function Test-PathWithinRoot {
    param([Parameter(Mandatory=$true)][string]$Path,[Parameter(Mandatory=$true)][string]$Root)
    $candidate=[IO.Path]::GetFullPath($Path).TrimEnd('\','/')
    $allowed=[IO.Path]::GetFullPath($Root).TrimEnd('\','/')
    return (Test-PathsEqual $candidate $allowed) -or $candidate.StartsWith($allowed+'\',[StringComparison]::OrdinalIgnoreCase)
}

function Assert-NoReparsePoint {
    param([Parameter(Mandatory=$true)][string]$Path)
    $current=[IO.Path]::GetFullPath($Path)
    while(-not[string]::IsNullOrWhiteSpace($current)){
        if(Test-Path -LiteralPath $current){
            $item=Get-Item -LiteralPath $current -Force -ErrorAction Stop
            if(($item.Attributes -band [IO.FileAttributes]::ReparsePoint)-ne0){throw "[SAFE1004] シンボリックリンクまたはジャンクションはテスト対象にできません: $current"}
        }
        $parent=Split-Path -Parent $current
        if([string]::IsNullOrWhiteSpace($parent)-or(Test-PathsEqual $parent $current)){break}
        $current=$parent
    }
}

function Assert-LocalTestPath {
    param([Parameter(Mandatory=$true)][string]$Path,[switch]$AllowNetwork)
    $full=[IO.Path]::GetFullPath($Path)
    if(-not$AllowNetwork){
        if($full.StartsWith('\\')){throw "[SAFE1001] UNCパスはTest Modeでは明示許可なしに使用できません: $full"}
        $driveRoot=[IO.Path]::GetPathRoot($full)
        try{if((New-Object IO.DriveInfo($driveRoot)).DriveType -eq [IO.DriveType]::Network){throw "[SAFE1002] ネットワークドライブはTest Modeでは明示許可なしに使用できません: $full"}}catch{if($_.Exception.Message-match'^\[SAFE1002\]'){throw}}
        foreach($name in @('OneDrive','OneDriveCommercial','OneDriveConsumer')){$one=[Environment]::GetEnvironmentVariable($name);if(-not[string]::IsNullOrWhiteSpace($one)-and(Test-PathWithinRoot -Path $full -Root $one)){throw "[SAFE1003] OneDrive配下はTest Modeでは明示許可なしに使用できません: $full"}}
    }
    Assert-NoReparsePoint -Path $full
    return $full
}

function Register-TestDeniedRoot {
    param([Parameter(Mandatory=$true)][string]$Path)
    if($null-eq$script:TestExecutionContext){throw '[SAFE1010] Test Modeが初期化されていません。'}
    $full=[IO.Path]::GetFullPath($Path)
    if(-not$script:TestExecutionContext.DeniedRoots.Contains($full)){$script:TestExecutionContext.DeniedRoots.Add($full)}
    $markerPayload=[PSCustomObject]@{schemaVersion='1.0';startedUtc=$script:TestExecutionContext.StartedUtc.ToString('o');deniedRoots=@($script:TestExecutionContext.DeniedRoots)}
    [IO.File]::WriteAllText($script:TestExecutionContext.MarkerPath,($markerPayload|ConvertTo-Json -Depth 4),(New-Object Text.UTF8Encoding($false)))
}

function Test-IsAllowedTestRoot {
    param([Parameter(Mandatory=$true)][string]$Path)
    if($null-eq$script:TestExecutionContext){return $true}
    $full=[IO.Path]::GetFullPath($Path)
    foreach($denied in @($script:TestExecutionContext.DeniedRoots)){if(Test-PathWithinRoot -Path $full -Root $denied){throw "[SAFE1011] Test Modeで拒否された外部Projectです: $full"}}
    foreach($allowed in @($script:TestExecutionContext.AllowedRoots)){if(Test-PathWithinRoot -Path $full -Root $allowed){return $true}}
    $temp=[IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\','/')
    if(Test-PathWithinRoot -Path $full -Root $temp){
        $relative=$full.Substring($temp.Length).TrimStart('\','/')
        $top=($relative-split'[\\/]')[0]
        $topPath=Join-Path $temp $top
        if(($top-like'VBAUpdater*'-or$top-like'VU_*')-and(Test-Path -LiteralPath $topPath -PathType Container)){
            $created=(Get-Item -LiteralPath $topPath -Force).CreationTimeUtc
            if($created-ge$script:TestExecutionContext.StartedUtc.AddSeconds(-5)){return $true}
        }
    }
    return $false
}

function Assert-TestProjectRootSafety {
    param([Parameter(Mandatory=$true)][string]$ProjectRoot)
    if($null-eq$script:TestExecutionContext){return [IO.Path]::GetFullPath($ProjectRoot)}
    if(-not[IO.Path]::IsPathRooted($ProjectRoot)){throw "[SAFE1020] Test ModeのProject Rootは絶対パス必須です: $ProjectRoot"}
    $full=Assert-LocalTestPath -Path $ProjectRoot -AllowNetwork:(Test-ArgumentSwitch -Arguments $RemainingArgs -Name '-AllowUnsafeTestPath')
    if(-not(Test-Path -LiteralPath $full -PathType Container)){throw "[SAFE1021] Test ModeのProject Rootがありません: $full"}
    if(-not(Test-IsAllowedTestRoot -Path $full)){throw "[SAFE1022] Test Modeの許可ルート外です: $full"}
    if(-not(Test-Path -LiteralPath (Join-Path $full 'project.json') -PathType Leaf)){throw "[SAFE1023] Test ModeのProject Rootにproject.jsonがありません: $full"}
    $script:CurrentTestProjectRoot=$full
    return $full
}

function Assert-TestWorkbookTargetSafety {
    param([Parameter(Mandatory=$true)][string]$ProjectRoot,[Parameter(Mandatory=$true)][string]$TargetPath)
    if($null-eq$script:TestExecutionContext){return [IO.Path]::GetFullPath($TargetPath)}
    $project=Assert-TestProjectRootSafety -ProjectRoot $ProjectRoot
    $target=Assert-LocalTestPath -Path $TargetPath -AllowNetwork:(Test-ArgumentSwitch -Arguments $RemainingArgs -Name '-AllowUnsafeTestPath')
    if(-not(Test-PathWithinRoot -Path $target -Root $project)){throw "[SAFE1030] 対象ブックがProject Root外です: $target"}
    if(-not(Test-Path -LiteralPath $target -PathType Leaf)){throw "[SAFE1031] Test Modeの対象ブックがありません: $target"}
    $targetItem=Get-Item -LiteralPath $target -Force
    if(($targetItem.Attributes-band[IO.FileAttributes]::ReadOnly)-ne0){throw "[SAFE1033] 読み取り専用の原本はTest Modeで直接更新できません: $target"}
    $created=$targetItem.CreationTimeUtc
    if($created-lt$script:TestExecutionContext.StartedUtc.AddSeconds(-5)){throw "[SAFE1032] 対象ブックはTest Mode開始後に作成またはコピーされたfileではありません: $target"}
    return $target
}

function Invoke-TestWorkbookOpenAudit {
    param([Parameter(Mandatory=$true)][string]$Path)
    if($null-eq$script:TestExecutionContext){return}
    if([string]::IsNullOrWhiteSpace($script:CurrentTestProjectRoot)){throw "[SAFE1040] Test ModeでProject Rootが確定する前のWorkbook Openは禁止です: $Path"}
    $safe=Assert-TestWorkbookTargetSafety -ProjectRoot $script:CurrentTestProjectRoot -TargetPath $Path
    $script:TestExecutionContext.OpenedWorkbooks.Add($safe)
    $entry=[PSCustomObject]@{timestamp=[DateTime]::UtcNow.ToString('o');projectRoot=$script:CurrentTestProjectRoot;workbook=$safe}
    [IO.File]::AppendAllText($script:TestExecutionContext.OpenAuditPath,(ConvertTo-Json $entry -Compress)+[Environment]::NewLine,(New-Object Text.UTF8Encoding($false)))
}

function Get-TestPropagationArguments {
    if($null-eq$script:TestExecutionContext){return @()}
    return @('-TestMode','-TestRoot',[string]$script:TestExecutionContext.Root)
}

function Initialize-IsolatedTestExecutionContext {
    param([AllowEmptyString()][string]$CommandName,[AllowNull()][object]$Arguments)
    $recognized=Test-IsIsolatedTestCommand -CommandName $CommandName
    $explicit=Test-ArgumentSwitch -Arguments $Arguments -Name '-TestMode'
    if(-not$recognized-and-not$explicit){return}
    $requested=Get-NamedArgument -Arguments $Arguments -Name '-TestRoot'
    $owns=$false
    $markerPayload=$null
    if([string]::IsNullOrWhiteSpace($requested)){
        if($explicit-and-not$recognized){throw '[SAFE1050] -TestModeには-TestRootが必要です。'}
        $requested=Join-Path ([IO.Path]::GetTempPath()) ('VU_'+[guid]::NewGuid().ToString('N').Substring(0,8))
        New-Item -ItemType Directory -Path $requested -Force|Out-Null
        $owns=$true
        $started=[DateTime]::UtcNow
        [IO.File]::WriteAllText((Join-Path $requested 'test-context.json'),([PSCustomObject]@{schemaVersion='1.0';startedUtc=$started.ToString('o');deniedRoots=@()}|ConvertTo-Json),(New-Object Text.UTF8Encoding($false)))
    }else{
        if(-not[IO.Path]::IsPathRooted($requested)){throw '[SAFE1051] -TestRootは絶対パス必須です。'}
        $marker=Join-Path ([IO.Path]::GetFullPath($requested)) 'test-context.json'
        if(-not(Test-Path -LiteralPath $marker -PathType Leaf)){throw "[SAFE1052] 親Test Modeが作成したmarkerがありません: $marker"}
        $markerPayload=Get-Content -LiteralPath $marker -Raw -Encoding UTF8|ConvertFrom-Json
        $started=[DateTime]::Parse([string]$markerPayload.startedUtc).ToUniversalTime()
    }
    $root=Assert-LocalTestPath -Path $requested
    $previousSettings=[Environment]::GetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable,'Process')
    $settings=Join-Path $root 'settings\settings.json'
    if(-not[string]::IsNullOrWhiteSpace($previousSettings)-and[IO.Path]::IsPathRooted($previousSettings)-and(Test-PathWithinRoot -Path $previousSettings -Root $root)){$settings=[IO.Path]::GetFullPath($previousSettings)}
    $logs=Join-Path $root 'logs';$backups=Join-Path $root 'backups';$projects=Join-Path $root 'projects'
    New-Item -ItemType Directory -Path (Split-Path -Parent $settings),$logs,$backups,$projects -Force|Out-Null
    $allowed=New-Object 'System.Collections.Generic.List[string]';foreach($p in @($root,(Join-Path $script:Root 'tests'),(Join-Path $script:Root 'samples'),(Join-Path $script:Root 'test'))){if(Test-Path -LiteralPath $p -PathType Container){$allowed.Add([IO.Path]::GetFullPath($p))}}
    $denied=New-Object 'System.Collections.Generic.List[string]';if($null-ne$markerPayload-and$markerPayload.PSObject.Properties['deniedRoots']){foreach($p in @($markerPayload.deniedRoots)){$denied.Add([IO.Path]::GetFullPath([string]$p))}}
    $script:TestExecutionContext=[PSCustomObject]@{Root=$root;StartedUtc=$started;OwnsRoot=$owns;PreviousSettings=$previousSettings;AllowedRoots=$allowed;DeniedRoots=$denied;OpenedWorkbooks=(New-Object 'System.Collections.Generic.List[string]');OpenAuditPath=(Join-Path $root 'workbook-open-audit.jsonl');MarkerPath=(Join-Path $root 'test-context.json')}
    [Environment]::SetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable,$settings,'Process')
    $script:DefaultProjectRootTestOverride=$projects;$script:RuntimeLogRootOverride=$logs;$script:RuntimeBackupRootOverride=$backups
    if(Get-Command Set-WorkbookOpenAuditHook -ErrorAction SilentlyContinue){Set-WorkbookOpenAuditHook -Hook {param($path,$projectRoot) $script:CurrentTestProjectRoot=[IO.Path]::GetFullPath($projectRoot);Invoke-TestWorkbookOpenAudit -Path $path}}
}

function Complete-IsolatedTestExecutionContext {
    if($null-eq$script:TestExecutionContext){return}
    $context=$script:TestExecutionContext
    if(Get-Command Set-WorkbookOpenAuditHook -ErrorAction SilentlyContinue){Set-WorkbookOpenAuditHook -Hook $null}
    [Environment]::SetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable,$context.PreviousSettings,'Process')
    $script:TestExecutionContext=$null;$script:RuntimeLogRootOverride=$null;$script:RuntimeBackupRootOverride=$null;$script:CurrentTestProjectRoot=$null;$script:DefaultProjectRootTestOverride=$null
    if($context.OwnsRoot-and(Test-Path -LiteralPath $context.Root -PathType Container)){Remove-Item -LiteralPath $context.Root -Recurse -Force -ErrorAction SilentlyContinue}
}

function Resolve-ManifestTarget {
    param([Parameter(Mandatory=$true)]$Context)
    $m=$Context.Manifest; $projectDir=$Context.ProjectDir
    $targetDir=Resolve-ManifestPath -ProjectDir $projectDir -PathValue ([string]$m.target.directory)
    if (-not [string]::IsNullOrWhiteSpace($script:DirectProjectPathOverride)) {
        $selection=Get-DirectWorkbookSelection -TargetDirectory $targetDir -Manifest $m -WorkbookPath $script:DirectWorkbookPathOverride
        if ([string]::IsNullOrWhiteSpace([string]$selection.WorkbookPath)) {
            if ($selection.Status -eq 'Multiple') { throw ("対象ブックが複数あります。-WorkbookPathで選択してください: {0}" -f (@($selection.Candidates) -join ', ')) }
            throw $selection.Message
        }
        $resolvedTarget=[string]$selection.WorkbookPath
        if($null-ne$script:TestExecutionContext){$resolvedTarget=Assert-TestWorkbookTargetSafety -ProjectRoot $projectDir -TargetPath $resolvedTarget}
        return $resolvedTarget
    }
    $configured=$null
    if($m.target.PSObject.Properties['file'] -and -not [string]::IsNullOrWhiteSpace([string]$m.target.file)){ $configured=Join-Path $targetDir ([string]$m.target.file) }
    if($configured -and (Test-Path -LiteralPath $configured -PathType Leaf)){ $resolvedTarget=[System.IO.Path]::GetFullPath($configured);if($null-ne$script:TestExecutionContext){$resolvedTarget=Assert-TestWorkbookTargetSafety -ProjectRoot $projectDir -TargetPath $resolvedTarget};return $resolvedTarget }
    $auto=$false
    if($m.target.PSObject.Properties['autoDetectWhenMissing']){ $auto=[bool]$m.target.autoDetectWhenMissing }
    if(-not $auto){ throw "Manifest指定の対象ブックが見つかりません: $configured" }
    $resolvedTarget=Get-TargetWorkbook -TargetDir $targetDir
    if($null-ne$script:TestExecutionContext){$resolvedTarget=Assert-TestWorkbookTargetSafety -ProjectRoot $projectDir -TargetPath $resolvedTarget}
    return $resolvedTarget
}

function Import-PrepareSourceModule {
    if (-not (Test-Path -LiteralPath $script:PrepareSourceModulePath -PathType Leaf)) {
        throw "PrepareSourceモジュールが見つかりません: $script:PrepareSourceModulePath"
    }
    Import-Module -Name $script:PrepareSourceModulePath -Force -Global -DisableNameChecking -ErrorAction Stop
}

function Invoke-PrepareSourceForContext {
    param(
        [Parameter(Mandatory=$true)]$Context,
        [string]$HookName = 'prePush',
        [switch]$SkipJson
    )

    Invoke-ManifestHook -Context $Context -HookName $HookName | Out-Host
    Import-PrepareSourceModule
    try {
        $logDir = Get-RuntimeLogDirectory
        return Invoke-VbaPrepareSource -ProjectDir $Context.ProjectDir -Manifest $Context.Manifest -LogDirectory $logDir -SkipJson:$SkipJson
    }
    finally {
        Remove-Module PrepareSource -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-ManifestHook {
    param($Context,[string]$HookName)
    $m=$Context.Manifest
    if($null -eq $m.PSObject.Properties['hooks'] -or $null -eq $m.hooks.PSObject.Properties[$HookName]){ return }
    $hook=[string]$m.hooks.$HookName
    if([string]::IsNullOrWhiteSpace($hook)){ return }
    $parts=$hook.Split(' ',2,[System.StringSplitOptions]::RemoveEmptyEntries)
    $commandPath=Resolve-ManifestPath -ProjectDir $Context.ProjectDir -PathValue $parts[0]
    $args=if($parts.Count -gt 1){$parts[1]}else{''}
    Write-Info "Manifest hookを実行しています: $HookName"
    if([System.IO.Path]::GetExtension($commandPath) -ieq '.cmd'){ & $commandPath $args }
    else { & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $commandPath $args }
    if($LASTEXITCODE -ne 0){ throw "Manifest hookが失敗しました: $HookName" }
}

function Invoke-ProjectPreflight {
    param([string[]]$Arguments)
    $project=Get-NamedArgument -Arguments $Arguments -Name '-Project'
    $ctx=Read-ProjectManifest -Project $project
    [void](Test-ProjectManifest -Context $ctx)
    $target=Resolve-ManifestTarget -Context $ctx
    Write-Success "Manifest検証に成功しました。"
    Write-Host "プロジェクト: $($ctx.Manifest.projectName)"
    Write-Host "対象ブック  : $target"
    Write-Host "更新件数    : $(@($ctx.Manifest.components).Count)"
}

function Invoke-ExcelCompileGateMacro {
    param(
        [Parameter(Mandatory=$true)][string]$TargetPath,
        [Parameter(Mandatory=$true)][string]$Macro
    )
    $excel = $null
    $workbook = $null
    try {
        try { $excel = New-ExcelApplication }
        catch { $_.Exception.Data['CompileGatePhase']='CreateExcel'; throw }
        try { $excel.AutomationSecurity = 1 }
        catch { $_.Exception.Data['CompileGatePhase']='ConfigureExcel'; throw }
        Invoke-TestWorkbookOpenAudit -Path $TargetPath
        try { $workbook = $excel.Workbooks.Open($TargetPath, 0, $false) }
        catch { $_.Exception.Data['CompileGatePhase']='OpenWorkbook'; throw }

        $escapedBookName = ([string]$workbook.Name).Replace("'", "''")
        $qualifiedMacro = "'$escapedBookName'!$Macro"
        try { [void]$excel.Run($qualifiedMacro) }
        catch { $_.Exception.Data['CompileGatePhase']='RunMacro'; throw }
        try { $workbook.Save() }
        catch { $_.Exception.Data['CompileGatePhase']='SaveWorkbook'; throw }
    }
    finally {
        Close-ExcelApplication -Excel $excel -Workbook $workbook
    }
}

function Invoke-ProjectCompileGate {
    param(
        [Parameter(Mandatory=$true)]$Context,
        [Parameter(Mandatory=$true)][string]$TargetPath,
        [scriptblock]$MacroExecutor
    )
    $settings = Get-ProjectCompileGateSettings -Context $Context
    if (-not $settings.Configured) {
        $skipped = New-CompileGateResult -Macro '' -Required $settings.Required -Result 'SkippedNotConfigured' -Source $settings.Source
        Write-Host '更新後コンパイルゲート: 未設定のためスキップしました。'
        Write-CompileGateDiagnostics -Result $skipped
        return $skipped
    }

    Write-Info '更新後コンパイルゲートを実行しています...'
    try {
        if ($null -ne $MacroExecutor) {
            & $MacroExecutor $TargetPath $settings.Macro
        }
        else {
            Invoke-ExcelCompileGateMacro -TargetPath $TargetPath -Macro $settings.Macro
        }
        $success = New-CompileGateResult -Macro $settings.Macro -Required $settings.Required -Result 'Success' -Source $settings.Source
        Write-Success '更新後コンパイルゲートに成功しました。'
        Write-CompileGateDiagnostics -Result $success
        return $success
    }
    catch {
        $details = Get-CompileGateExceptionDetails -Exception $_.Exception
        if ($details.Classification -eq 'MacroUnavailable' -and -not $settings.Required) {
            $warning = New-CompileGateResult -Macro $settings.Macro -Required $false -Result 'WarningMacroUnavailable' -Source $settings.Source -Classification $details.Classification -ExceptionType $details.ExceptionType -ExceptionMessage $details.ExceptionMessage
            Write-Warn '[WARNING] 更新後コンパイルゲートを実行できませんでした。'
            Write-Host ('Macro: ' + $settings.Macro)
            Write-Host ('Reason: ' + $details.Reason)
            Write-CompileGateDiagnostics -Result $warning
            return $warning
        }

        $resultName = switch ($details.Classification) {
            'MacroUnavailable' { 'ErrorMacroUnavailableRequired' }
            'MacroRuntimeError' { 'ErrorMacroRuntime' }
            'ExcelComFailure' { 'ErrorExcelCom' }
            default { 'ErrorMacroExecution' }
        }
        $failure = New-CompileGateResult -Macro $settings.Macro -Required $settings.Required -Result $resultName -Source $settings.Source -Classification $details.Classification -ExceptionType $details.ExceptionType -ExceptionMessage $details.ExceptionMessage
        Write-Failure '[ERROR] 更新後コンパイルゲートに失敗しました。'
        Write-Host ('Macro: ' + $settings.Macro)
        Write-Host ('Reason: ' + $details.Reason)
        Write-CompileGateDiagnostics -Result $failure
        throw ("更新後コンパイルゲートに失敗しました。Macro={0} Result={1}" -f $settings.Macro,$resultName)
    }
}

function Invoke-ProjectCompile {
    param([string[]]$Arguments)
    $project=Get-NamedArgument -Arguments $Arguments -Name '-Project'
    $ctx=Read-ProjectManifest -Project $project
    [void](Test-ProjectManifest -Context $ctx)
    $target=Resolve-ManifestTarget -Context $ctx
    return Invoke-ProjectCompileGate -Context $ctx -TargetPath $target
}

function Get-DifferentialUpdatePlan {
    param([Parameter(Mandatory=$true)][object[]]$DiffItems)
    return @($DiffItems | Where-Object { $_.status -in @('changed','added') })
}

function Find-ManifestComponentByName {
    param([Parameter(Mandatory=$true)]$Context,[Parameter(Mandatory=$true)][string]$Name)
    foreach($component in @($Context.Manifest.components)) {
        if ([string]::Equals([string]$component.name,$Name,[System.StringComparison]::OrdinalIgnoreCase)) { return $component }
    }
    throw "Manifest内にコンポーネントが見つかりません: $Name"
}

function Invoke-ManifestComponentPush {
    param([Parameter(Mandatory=$true)]$Context,[Parameter(Mandatory=$true)][string]$TargetPath,[Parameter(Mandatory=$true)]$Component)
    $type=([string]$Component.type).ToLowerInvariant()
    $source=Get-ManifestComponentSourcePath -Context $Context -Component $Component
    $args=@('-WorkbookPath',$TargetPath,'-SourcePath',$source,'-ComponentName',[string]$Component.name)
    switch($type){
        'standard'{Invoke-PushStandard -Arguments $args}
        'class'{Invoke-PushClass -Arguments $args}
        'document'{Invoke-PushDocument -Arguments $args}
        'userform'{Invoke-PushUserForm -Arguments $args}
        default{throw "未対応のコンポーネント種別です: $type"}
    }
}

function Write-DifferentialPushJson {
    param(
        $Context,
        [string]$TargetPath,
        [object[]]$DiffItems,
        [object[]]$UpdatedItems,
        [object[]]$VerificationItems,
        [string]$CompileStatus,
        $CompileGateResult,
        [string]$VerificationStatus,
        [double]$ElapsedSeconds
    )
    $logDir=Get-RuntimeLogDirectory
    New-Item -ItemType Directory -Path $logDir -Force|Out-Null
    $path=Join-Path $logDir ('differential_push_'+[DateTime]::Now.ToString('yyyyMMdd_HHmmss_fff')+'.json')
    $result=[PSCustomObject]@{
        schemaVersion='1.1'
        project=[string]$Context.Manifest.projectName
        target=$TargetPath
        timestamp=[DateTime]::Now.ToString('o')
        summary=[PSCustomObject]@{
            changed=@($DiffItems|Where-Object{$_.status -eq 'changed'}).Count
            added=@($DiffItems|Where-Object{$_.status -eq 'added'}).Count
            skipped=@($DiffItems|Where-Object{$_.status -eq 'unchanged'}).Count
            updated=$UpdatedItems.Count
            compile=$CompileStatus
            verification=$VerificationStatus
            remainingDifferences=@($VerificationItems|Where-Object{$_.status -in @('changed','added','failed')}).Count
            elapsedSeconds=[Math]::Round($ElapsedSeconds,3)
        }
        diff=$DiffItems
        updated=$UpdatedItems
        verification=$VerificationItems
        compileGate=$CompileGateResult
    }
    [System.IO.File]::WriteAllText($path,($result|ConvertTo-Json -Depth 8),(New-Object System.Text.UTF8Encoding($false)))
    return $path
}

function Write-ProjectExecutionTargetSummary {
    param(
        [Parameter(Mandatory=$true)]$Context,
        [Parameter(Mandatory=$true)][string]$TargetPath,
        [int]$VbaChanges=0,
        [int]$WorkbookChanges=0,
        [bool]$WorkbookDefinitionEnabled=$false,
        [Parameter(Mandatory=$true)][string]$BackupDestination
    )
    Write-Host ''
    Write-Host '====================================='
    Write-Host 'Pre-update target confirmation'
    Write-Host '====================================='
    Write-Host ("Project       : {0}" -f [string]$Context.Manifest.projectName)
    Write-Host ("Project Root  : {0}" -f [string]$Context.ProjectDir)
    Write-Host ("Target        : {0}" -f [System.IO.Path]::GetFullPath($TargetPath))
    Write-Host ("Workbook Def  : {0}" -f $(if($WorkbookDefinitionEnabled){'Enabled'}else{'None / Disabled'}))
    Write-Host ("VBA Changes   : {0}" -f $VbaChanges)
    Write-Host ("Workbook Chg  : {0}" -f $WorkbookChanges)
    Write-Host ("Backup To     : {0}" -f [System.IO.Path]::GetFullPath($BackupDestination))
    Write-Host '====================================='
}

function Invoke-ProjectVbaPushCore {
    param([string[]]$Arguments)
    $started=[DateTime]::Now
    $project=Get-NamedArgument -Arguments $Arguments -Name '-Project'
    $ctx=Read-ProjectManifest -Project $project
    [void](Invoke-PrepareSourceForContext -Context $ctx -HookName 'prePush')
    [void](Test-ProjectManifest -Context $ctx)
    $target=Resolve-ManifestTarget -Context $ctx
    $skipRestorePoint=Test-ArgumentSwitch -Arguments $Arguments -Name '-SkipRestorePoint'
    $restorePoint=$null
    Write-ComDiagnosticLine 'P01 START Operation=InitialProjectDiff'
    $diff=@(Get-ProjectDiff -Context $ctx -TargetPath $target)
    $plan=@(Get-DifferentialUpdatePlan -DiffItems $diff)
    Write-ProjectExecutionTargetSummary -Context $ctx -TargetPath $target -VbaChanges $plan.Count -WorkbookChanges 0 -WorkbookDefinitionEnabled $false -BackupDestination (Get-ProjectRestorePointDirectory -Context $ctx)
    if(-not $skipRestorePoint){
        $restorePoint=New-ProjectRestorePoint -Context $ctx -TargetPath $target -Operation 'project-push'
        Write-Info ("復元ポイントを作成しました: {0}" -f $restorePoint.Id)
    }

    # Windows PowerShell 5.1でGeneric Listを@()に変換した際の
    # ArgumentException(0x80070057)を避けるため、通常のPowerShell配列で保持する。
    [object[]]$updatedItems=@()
    [object[]]$verificationItems=@()

    Write-Host ''
    Write-Info '差分更新計画を実行しています...'
    foreach($item in $diff) {
        if($item.status -eq 'unchanged') { Write-Host ("[SKIP] {0} ({1})" -f $item.name,$item.type) }
        else { Write-Warn ("[PLAN] {0} ({1}) - {2}" -f $item.name,$item.type,$item.status) }
    }

    foreach($item in $plan) {
        $component=Find-ManifestComponentByName -Context $ctx -Name ([string]$item.name)
        Write-Info ("[UPDATE] {0} ({1})" -f $item.name,$item.type)
        Invoke-ManifestComponentPush -Context $ctx -TargetPath $target -Component $component
        $updatedItems += [PSCustomObject]@{
            name=[string]$item.name
            type=[string]$item.type
            sourcePath=[string]$item.sourcePath
            status='updated'
        }
    }

    # 差分0件の場合もCompile Gateを呼ぶ現行順序を維持する。未設定時のスキップ判定は共通処理が行う。
    $compileGateResult=Invoke-ProjectCompile -Arguments @('-Project',$project)
    $compileStatus=[string]$compileGateResult.Result
    Invoke-ManifestHook -Context $ctx -HookName 'postPush'

    $verificationStatus='Skipped-NoChanges'
    if($plan.Count -gt 0) {
        Write-Info '更新後の差分を再確認しています...'
        Write-ComDiagnosticLine 'P02 START Operation=PostPushProjectDiff'
        $verificationItems=@(Get-ProjectDiff -Context $ctx -TargetPath $target)
        $remaining=@($verificationItems|Where-Object{$_.status -in @('changed','added','failed')})
        if($remaining.Count -gt 0) {
            $verificationStatus='Failed'
            $remainingText=($remaining|ForEach-Object{"$($_.name)[$($_.status)]"}) -join ', '
            throw "差分更新後も差分が残っています: $remainingText"
        }
        $verificationStatus='Success'
        Write-Success '更新後の再差分確認に成功しました。差分は0件です。'
    }

    $elapsed=([DateTime]::Now-$started).TotalSeconds
    $jsonPath=Write-DifferentialPushJson -Context $ctx -TargetPath $target -DiffItems $diff -UpdatedItems $updatedItems -VerificationItems $verificationItems -CompileStatus $compileStatus -CompileGateResult $compileGateResult -VerificationStatus $verificationStatus -ElapsedSeconds $elapsed
    Write-Host ''
    Write-Host '====================================='
    Write-Host 'Differential Push Summary'
    Write-Host '====================================='
    Write-Host ("Project       : {0}" -f $ctx.Manifest.projectName)
    Write-Host ("Changed       : {0}" -f @($diff|Where-Object{$_.status -eq 'changed'}).Count)
    Write-Host ("Added         : {0}" -f @($diff|Where-Object{$_.status -eq 'added'}).Count)
    Write-Host ("Skipped       : {0}" -f @($diff|Where-Object{$_.status -eq 'unchanged'}).Count)
    Write-Host ("Updated       : {0}" -f $updatedItems.Count)
    Write-Host ("Restore Point : {0}" -f $(if($null -eq $restorePoint){'<skipped>'}else{$restorePoint.Id}))
    Write-Host ("Compile       : {0}" -f $compileStatus)
    Write-Host ("Verification  : {0}" -f $verificationStatus)
    Write-Host ("Elapsed       : {0:N3} sec" -f $elapsed)
    Write-Host ("Result JSON   : {0}" -f $jsonPath)
    Write-Host '====================================='
    if($plan.Count -eq 0){Write-Success '変更対象はありません。更新をスキップしました。'}else{Write-Success '差分更新と再検証が完了しました。'}
}

function Write-IntegratedWorkbookTransactionLog {
    param($Context,[string]$TargetPath,[string]$BackupPath,[bool]$RestoreAttempted,[AllowNull()]$RestoreSucceeded,[string]$ErrorMessage)
    $logDir=Get-RuntimeLogDirectory
    New-Item -ItemType Directory -Path $logDir -Force|Out-Null
    $path=Join-Path $logDir ('workbook_transaction_'+[DateTime]::Now.ToString('yyyyMMdd_HHmmss_fff')+'.json')
    $payload=[PSCustomObject]@{
        schemaVersion='1.0';project=[string]$Context.Manifest.projectName;target=$TargetPath
        timestamp=[DateTime]::Now.ToString('o');backupPath=$BackupPath
        restoreAttempted=$RestoreAttempted;restoreSucceeded=$RestoreSucceeded
        error=$ErrorMessage
    }
    [System.IO.File]::WriteAllText($path,($payload|ConvertTo-Json -Depth 5),(New-Object System.Text.UTF8Encoding($false)))
    return $path
}

function Invoke-ProjectPush {
    param([string[]]$Arguments)
    $project=Get-NamedArgument -Arguments $Arguments -Name '-Project'
    $ctx=Read-ProjectManifest -Project $project
    $workbookContext=Get-WorkbookDefinitionContext -ProjectDir $ctx.ProjectDir -ProjectManifest $ctx.Manifest

    # Workbook定義がない既存プロジェクトは、Ver4.18.0と同じ関数・順序・出力を通す。
    if(-not $workbookContext.Enabled){
        Invoke-ProjectVbaPushCore -Arguments $Arguments
        return
    }

    [void](Test-ProjectManifest -Context $ctx)
    $target=Resolve-ManifestTarget -Context $ctx
    $logDir=Get-RuntimeLogDirectory
    $backupDir=Get-RuntimeBackupDirectory -Child 'workbook'

    Write-Info 'Workbook更新の統合Preflightと差分作成を実行しています...'
    $workbookDiff=Invoke-WorkbookUpdate -ProjectDir $ctx.ProjectDir -ProjectManifest $ctx.Manifest -TargetPath $target -Mode Diff -LogDirectory $logDir -BackupDirectory $backupDir
    Write-Host ("Workbook差分 : {0}" -f $workbookDiff.changedCount)
    $vbaDiff=@(Get-ProjectDiff -Context $ctx -TargetPath $target)
    $vbaChanges=@(Get-DifferentialUpdatePlan -DiffItems $vbaDiff).Count
    Write-ProjectExecutionTargetSummary -Context $ctx -TargetPath $target -VbaChanges $vbaChanges -WorkbookChanges ([int]$workbookDiff.changedCount) -WorkbookDefinitionEnabled $true -BackupDestination (Get-ProjectRestorePointDirectory -Context $ctx)

    # WorkbookとVBAをまとめて元に戻せる外側の復元ポイント。
    $restorePoint=New-ProjectRestorePoint -Context $ctx -TargetPath $target -Operation 'project-push-workbook-transaction'
    Write-Info ("統合復元ポイントを作成しました: {0}" -f $restorePoint.Id)
    $innerArguments=@($Arguments)
    if(-not(Test-ArgumentSwitch -Arguments $innerArguments -Name '-SkipRestorePoint')){$innerArguments+=@('-SkipRestorePoint')}

    try{
        $workbookApply=Invoke-WorkbookUpdate -ProjectDir $ctx.ProjectDir -ProjectManifest $ctx.Manifest -TargetPath $target -Mode Apply -LogDirectory $logDir -BackupDirectory $backupDir
        Invoke-ProjectVbaPushCore -Arguments $innerArguments
        $workbookVerify=Invoke-WorkbookUpdate -ProjectDir $ctx.ProjectDir -ProjectManifest $ctx.Manifest -TargetPath $target -Mode Verify -LogDirectory $logDir -BackupDirectory $backupDir
        [void](Write-IntegratedWorkbookTransactionLog -Context $ctx -TargetPath $target -BackupPath ([string]$restorePoint.backupPath) -RestoreAttempted $false -RestoreSucceeded $null -ErrorMessage '')
        Write-Success ("統合Pushが完了しました。Workbook更新={0}件 / 検証差分={1}件" -f $workbookApply.appliedCount,$workbookVerify.changedCount)
    }
    catch{
        $originalError=$_.Exception.Message
        $restoreSucceeded=$false
        $restoreError=''
        try{
            $actualBackupHash=(Get-FileHash -LiteralPath ([string]$restorePoint.backupPath) -Algorithm SHA256).Hash
            if($actualBackupHash-ne[string]$restorePoint.sha256){throw '統合復元ポイントのハッシュが一致しません。'}
            Copy-Item -LiteralPath ([string]$restorePoint.backupPath) -Destination $target -Force
            $targetHash=(Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
            if($targetHash-ne[string]$restorePoint.sha256){throw '統合復元後のハッシュが一致しません。'}
            $restoreSucceeded=$true
        }
        catch{$restoreError=$_.Exception.Message}
        $transactionLog=Write-IntegratedWorkbookTransactionLog -Context $ctx -TargetPath $target -BackupPath ([string]$restorePoint.backupPath) -RestoreAttempted $true -RestoreSucceeded $restoreSucceeded -ErrorMessage $originalError
        if($restoreSucceeded){throw "[WB3003] 統合Pushに失敗し、更新前ブックへ復元しました。Log=$transactionLog / 詳細: $originalError"}
        throw "[WB3004] 統合Pushに失敗し、復元にも失敗しました。Backup=$($restorePoint.backupPath) / Log=$transactionLog / 復元エラー=$restoreError / 詳細: $originalError"
    }
}

function Invoke-WorkbookCliCommand {
    param([string[]]$Arguments,[ValidateSet('Validate','Diff','Apply','Verify')][string]$Mode)
    $project=Get-NamedArgument -Arguments $Arguments -Name '-Project'
    $ctx=Read-ProjectManifest -Project $project
    [void](Test-ProjectManifest -Context $ctx)
    $target=Resolve-ManifestTarget -Context $ctx
    if($Mode-eq'Apply'){
        $preview=Invoke-WorkbookUpdate -ProjectDir $ctx.ProjectDir -ProjectManifest $ctx.Manifest -TargetPath $target -Mode Diff -LogDirectory (Get-RuntimeLogDirectory) -BackupDirectory (Get-RuntimeBackupDirectory -Child 'workbook')
        Write-ProjectExecutionTargetSummary -Context $ctx -TargetPath $target -VbaChanges 0 -WorkbookChanges ([int]$preview.changedCount) -WorkbookDefinitionEnabled ([bool]$preview.enabled) -BackupDestination (Get-RuntimeBackupDirectory -Child 'workbook')
    }
    $result=Invoke-WorkbookUpdate -ProjectDir $ctx.ProjectDir -ProjectManifest $ctx.Manifest -TargetPath $target -Mode $Mode -LogDirectory (Get-RuntimeLogDirectory) -BackupDirectory (Get-RuntimeBackupDirectory -Child 'workbook')
    if(Test-ArgumentSwitch -Arguments $Arguments -Name '-Json'){$result|ConvertTo-Json -Depth 10;return}
    Write-Host ''
    Write-Host '====================================='
    Write-Host ("Workbook {0} Summary" -f $Mode)
    Write-Host '====================================='
    Write-Host ("Project       : {0}" -f $ctx.Manifest.projectName)
    Write-Host ("Target        : {0}" -f $target)
    Write-Host ("Enabled       : {0}" -f $result.enabled)
    Write-Host ("Schema        : {0}" -f $(if($result.PSObject.Properties['schemaVersion']){$result.schemaVersion}else{''}))
    Write-Host ("Changed       : {0}" -f $result.changedCount)
    if($result.PSObject.Properties['appliedCount']){Write-Host ("Applied       : {0}" -f $result.appliedCount)}
    if($result.PSObject.Properties['backupPath']){Write-Host ("Backup        : {0}" -f $result.backupPath)}
    Write-Host ("Result        : {0}" -f $result.code)
    Write-Host '====================================='
    Write-Success ("Workbook $Mode に成功しました。")
}

function Invoke-WorkbookTest {
    $result=Invoke-WorkbookDefinitionTest
    Write-Success $result.message
    Write-Host ("テスト件数: {0}" -f $result.count)
}

function Invoke-WorkbookIntegrationTestCommand {
    $testRoot=if($null-ne$script:TestExecutionContext){[string]$script:TestExecutionContext.Root}else{''}
    $result=Invoke-WorkbookIntegrationTest -TestRoot $testRoot
    Write-Success $result.message
    Write-Host ("正式Project構造: {0} / 初回差分: {1} / Apply: {2} / Verify差分: {3} / 再Diff: {4}" -f $result.projectStructureVerified,$result.initialChanges,$result.appliedChanges,$result.verifyChanges,$result.secondChanges)
    Write-Host ("Backup作成: {0} / 管理対象外保全: {1} / 復元Hash一致: {2}" -f $result.backupCreated,$result.unmanagedDataPreserved,$result.rollbackHashMatched)
    Write-Host ("復元成功試験: {0} / 復元失敗の識別: {1}" -f ($result.rollbackPhases -join ', '),$result.restoreFailureDistinct)
}


function Test-ArgumentSwitch {
    param([AllowNull()][object]$Arguments,[Parameter(Mandatory=$true)][string]$Name)
    $parsed=Parse-CliArguments -Arguments $Arguments
    return Test-CliSwitch -Parsed $parsed -Name $Name
}

function Get-ProjectManagedDeletionCandidates {
    param(
        [Parameter(Mandatory=$true)]$Context,
        [Parameter(Mandatory=$true)][string]$TargetPath
    )

    [object[]]$result=@()
    if ($null -eq $Context.Manifest.PSObject.Properties['sync']) { return $result }
    if ($null -eq $Context.Manifest.sync.PSObject.Properties['managedComponents']) { return $result }

    $desired=@{}
    foreach($component in @($Context.Manifest.components)) {
        $desired[([string]$component.name).ToLowerInvariant()]=$true
    }

    $excel=$null; $workbook=$null; $vbProject=$null
    try {
        $excel=New-ExcelApplication
        $excel.AutomationSecurity=3
        $workbook=Open-WorkbookReadOnlySafe -Excel $excel -Path $TargetPath
        $vbProject=$workbook.VBProject

        foreach($managed in @($Context.Manifest.sync.managedComponents)) {
            $name=[string]$managed.name
            $type=([string]$managed.type).ToLowerInvariant()
            if ([string]::IsNullOrWhiteSpace($name)) { throw 'sync.managedComponentsにnameがない項目があります。' }
            if ($type -notin @('standard','class','document','userform')) { throw "sync.managedComponentsに未対応のtypeがあります: $type" }
            if ($desired.ContainsKey($name.ToLowerInvariant())) { continue }

            $candidate=$null
            try {
                $candidate=Find-VbComponentSafe -VbProject $vbProject -ComponentName $name
                if ($null -ne $candidate) {
                    $result += [PSCustomObject]@{
                        name=$name
                        type=$type
                        status='deleted'
                        reason='管理対象ですが、現在のcomponents定義から除外されています。'
                    }
                }
            }
            finally { Release-ComObject $candidate }
        }
    }
    finally {
        Release-ComObject $vbProject
        Close-ExcelApplication -Excel $excel -Workbook $workbook
    }
    return $result
}

function Remove-ProjectManagedComponents {
    param(
        [Parameter(Mandatory=$true)][string]$TargetPath,
        [Parameter(Mandatory=$true)][object[]]$Items
    )
    if ($Items.Count -eq 0) { return $null }

    foreach($item in $Items) {
        if ([string]$item.type -eq 'document') {
            throw "Document Moduleは安全に削除できないため自動削除対象にできません: $($item.name)"
        }
    }

    $backupDir=Get-RuntimeBackupDirectory
    New-Item -ItemType Directory -Path $backupDir -Force|Out-Null
    $backupPath=Join-Path $backupDir (([System.IO.Path]::GetFileNameWithoutExtension($TargetPath))+'_before_sync_delete_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+[System.IO.Path]::GetExtension($TargetPath))
    Copy-Item -LiteralPath $TargetPath -Destination $backupPath -Force

    $excel=$null; $workbook=$null; $vbProject=$null
    try {
        $excel=New-ExcelApplication
        $excel.AutomationSecurity=3
        Invoke-TestWorkbookOpenAudit -Path $TargetPath
        $workbook=$excel.Workbooks.Open($TargetPath,0,$false)
        $vbProject=$workbook.VBProject
        foreach($item in $Items) {
            $component=$null
            try {
                $component=Find-VbComponentSafe -VbProject $vbProject -ComponentName ([string]$item.name)
                if ($null -eq $component) { continue }
                $vbProject.VBComponents.Remove($component)
                Write-Warn ("[DELETE] {0} ({1})" -f $item.name,$item.type)
            }
            finally { Release-ComObject $component }
        }
        $workbook.Save()
    }
    catch {
        throw "管理対象コンポーネントの削除に失敗しました。バックアップ: $backupPath / 詳細: $($_.Exception.Message)"
    }
    finally {
        Release-ComObject $vbProject
        Close-ExcelApplication -Excel $excel -Workbook $workbook
    }
    return $backupPath
}

function Write-ProjectSyncJson {
    param($Context,[string]$TargetPath,[object[]]$DeleteItems,[bool]$ApplyDeletes,[string]$DeleteBackup)
    $logDir=Get-RuntimeLogDirectory
    New-Item -ItemType Directory -Path $logDir -Force|Out-Null
    $path=Join-Path $logDir ('project_sync_'+[DateTime]::Now.ToString('yyyyMMdd_HHmmss_fff')+'.json')
    $payload=[PSCustomObject]@{
        schemaVersion='1.0'
        project=[string]$Context.Manifest.projectName
        target=$TargetPath
        timestamp=[DateTime]::Now.ToString('o')
        deleteMode=if($ApplyDeletes){'applied'}else{'report-only'}
        deleteBackup=$DeleteBackup
        deletedCandidates=$DeleteItems
    }
    [System.IO.File]::WriteAllText($path,($payload|ConvertTo-Json -Depth 8),(New-Object System.Text.UTF8Encoding($false)))
    return $path
}

function Invoke-ProjectSync {
    param([string[]]$Arguments)
    $project=Get-NamedArgument -Arguments $Arguments -Name '-Project'
    $applyDeletes=Test-ArgumentSwitch -Arguments $Arguments -Name '-ApplyDeletes'
    $ctx=Read-ProjectManifest -Project $project

    [void](Invoke-PrepareSourceForContext -Context $ctx -HookName 'prePush')
    [void](Test-ProjectManifest -Context $ctx)
    $target=Resolve-ManifestTarget -Context $ctx
    [object[]]$deleteItems=@(Get-ProjectManagedDeletionCandidates -Context $ctx -TargetPath $target)
    $syncDiff=@(Get-ProjectDiff -Context $ctx -TargetPath $target)
    $syncPlan=@(Get-DifferentialUpdatePlan -DiffItems $syncDiff)
    $workbookContext=Get-WorkbookDefinitionContext -ProjectDir $ctx.ProjectDir -ProjectManifest $ctx.Manifest
    Write-ProjectExecutionTargetSummary -Context $ctx -TargetPath $target -VbaChanges $syncPlan.Count -WorkbookChanges 0 -WorkbookDefinitionEnabled ([bool]$workbookContext.Enabled) -BackupDestination (Get-ProjectRestorePointDirectory -Context $ctx)
    $restorePoint=New-ProjectRestorePoint -Context $ctx -TargetPath $target -Operation 'project-sync'
    Write-Info ("復元ポイントを作成しました: {0}" -f $restorePoint.Id)

    Write-Host ''
    Write-Info 'Project Sync計画を確認しています...'
    if($deleteItems.Count -eq 0) {
        Write-Host '[DELETE] 削除候補なし'
    } else {
        foreach($item in $deleteItems) {
            if($applyDeletes){Write-Warn ("[DELETE PLAN] {0} ({1})" -f $item.name,$item.type)}
            else{Write-Warn ("[DELETE REPORT ONLY] {0} ({1})" -f $item.name,$item.type)}
        }
    }

    $deleteBackup=$null
    if($applyDeletes -and $deleteItems.Count -gt 0) {
        $deleteBackup=Remove-ProjectManagedComponents -TargetPath $target -Items $deleteItems
    }

    # 変更・追加は既存の実績ある差分Pushエンジンに委譲する。
    $pushArguments=@($Arguments)
    if(-not(Test-ArgumentSwitch -Arguments $pushArguments -Name '-SkipRestorePoint')){$pushArguments+=@('-SkipRestorePoint')}
    Invoke-ProjectPush -Arguments $pushArguments

    $jsonPath=Write-ProjectSyncJson -Context $ctx -TargetPath $target -DeleteItems $deleteItems -ApplyDeletes $applyDeletes -DeleteBackup $deleteBackup
    Write-ProjectStateOperation -Context $ctx -Operation 'sync'
    Write-Host ''
    Write-Host '====================================='
    Write-Host 'Project Sync Summary'
    Write-Host '====================================='
    Write-Host ("Project          : {0}" -f $ctx.Manifest.projectName)
    Write-Host ("Delete Candidates: {0}" -f $deleteItems.Count)
    Write-Host ("Restore Point    : {0}" -f $restorePoint.Id)
    Write-Host ("Delete Mode      : {0}" -f $(if($applyDeletes){'Apply'}else{'Report Only'}))
    Write-Host ("Delete Backup    : {0}" -f $(if([string]::IsNullOrWhiteSpace($deleteBackup)){'<none>'}else{$deleteBackup}))
    Write-Host ("Result JSON      : {0}" -f $jsonPath)
    Write-Host '====================================='
    if(-not $applyDeletes -and $deleteItems.Count -gt 0) {
        Write-Warn '削除候補は報告のみです。削除する場合だけ -ApplyDeletes を指定してください。'
    } else {
        Write-Success 'Project Syncが完了しました。'
    }
}


function Get-ProjectStatePath {
    param([Parameter(Mandatory=$true)]$Context)
    return Join-Path $Context.ProjectDir '.vba\state.json'
}

function Read-ProjectState {
    param([Parameter(Mandatory=$true)]$Context)
    $path=Get-ProjectStatePath -Context $Context
    if(-not(Test-Path -LiteralPath $path -PathType Leaf)){return $null}
    try{return Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json}catch{return $null}
}

function Write-ProjectStateOperation {
    param([Parameter(Mandatory=$true)]$Context,[Parameter(Mandatory=$true)][ValidateSet('pull','sync')][string]$Operation)
    $path=Get-ProjectStatePath -Context $Context
    New-Item -ItemType Directory -Path (Split-Path -Parent $path) -Force|Out-Null
    $state=Read-ProjectState -Context $Context
    if($null -eq $state){
        $state=[PSCustomObject]@{schemaVersion='1.0';project=[string]$Context.Manifest.projectName;lastPull=$null;lastSync=$null;updatedAt=$null}
    }
    $now=[DateTime]::Now.ToString('o')
    if($Operation -eq 'pull'){$state.lastPull=$now}else{$state.lastSync=$now}
    $state.updatedAt=$now
    [System.IO.File]::WriteAllText($path,($state|ConvertTo-Json -Depth 5),(New-Object System.Text.UTF8Encoding($false)))
}

function Get-ProjectStateTimestamp {
    param([Parameter(Mandatory=$true)]$Context,[Parameter(Mandatory=$true)][ValidateSet('pull','sync')][string]$Operation)
    $state=Read-ProjectState -Context $Context
    if($null -eq $state){return $null}
    $property=if($Operation -eq 'pull'){'lastPull'}else{'lastSync'}
    if($state.PSObject.Properties[$property] -and -not [string]::IsNullOrWhiteSpace([string]$state.$property)){
        try{return ([DateTimeOffset]::Parse([string]$state.$property)).LocalDateTime}catch{Write-Verbose ('状態日時を解析できませんでした: '+$_.Exception.Message)}
    }
    return $null
}

function Get-ProjectStatusLogTimestamp {
    param(
        [Parameter(Mandatory=$true)][string]$ProjectName,
        [Parameter(Mandatory=$true)][string]$Prefix
    )
    $logDir=Get-RuntimeLogDirectory
    if(-not(Test-Path -LiteralPath $logDir -PathType Container)){return $null}
    $files=@(Get-ChildItem -LiteralPath $logDir -Filter ($Prefix+'*.json') -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
    foreach($file in $files){
        try{
            $payload=Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
            if($payload.PSObject.Properties['project'] -and [string]$payload.project -eq $ProjectName){
                if($payload.PSObject.Properties['timestamp'] -and -not [string]::IsNullOrWhiteSpace([string]$payload.timestamp)){
                    return ([DateTimeOffset]::Parse([string]$payload.timestamp)).LocalDateTime
                }
                return $file.LastWriteTime
            }
        }catch{Write-Verbose ('状態履歴の日時を解析できませんでした: '+$_.Exception.Message)}
    }
    return $null
}

function Write-ProjectStatusJson {
    param([Parameter(Mandatory=$true)][object[]]$Items)
    $logDir=Get-RuntimeLogDirectory
    New-Item -ItemType Directory -Path $logDir -Force|Out-Null
    $path=Join-Path $logDir ('project_status_'+[DateTime]::Now.ToString('yyyyMMdd_HHmmss_fff')+'.json')
    $payload=[PSCustomObject]@{
        schemaVersion='1.0'
        toolVersion=$script:ToolVersion
        timestamp=[DateTime]::Now.ToString('o')
        projects=$Items
    }
    [System.IO.File]::WriteAllText($path,($payload|ConvertTo-Json -Depth 10),(New-Object System.Text.UTF8Encoding($false)))
    return $path
}

function Get-OneProjectStatus {
    param([Parameter(Mandatory=$true)][string]$Project)
    $ctx=Read-ProjectManifest -Project $Project
    [void](Invoke-PrepareSourceForContext -Context $ctx -HookName 'prePush' -SkipJson)
    [void](Test-ProjectManifest -Context $ctx)
    $target=Resolve-ManifestTarget -Context $ctx
    [object[]]$diff=@(Get-ProjectDiff -Context $ctx -TargetPath $target)
    [object[]]$deletes=@(Get-ProjectManagedDeletionCandidates -Context $ctx -TargetPath $target)

    $types=@('standard','class','document','userform')
    $sourceCounts=[ordered]@{}
    $targetCounts=[ordered]@{}
    foreach($type in $types){
        $sourceCounts[$type]=@($ctx.Manifest.components|Where-Object{([string]$_.type).ToLowerInvariant() -eq $type}).Count
        $targetCounts[$type]=@($diff|Where-Object{([string]$_.type).ToLowerInvariant() -eq $type -and $_.status -ne 'added'}).Count
    }
    $changed=@($diff|Where-Object{$_.status -eq 'changed'}).Count
    $added=@($diff|Where-Object{$_.status -eq 'added'}).Count
    $unchanged=@($diff|Where-Object{$_.status -eq 'unchanged'}).Count
    $deleted=$deletes.Count
    $state=if(($changed+$added+$deleted)-eq 0){'Synchronized'}else{'Changes Pending'}
    $projectName=[string]$ctx.Manifest.projectName
    return [PSCustomObject]@{
        project=$projectName
        projectDirectory=$ctx.ProjectDir
        target=$target
        source=[PSCustomObject]$sourceCounts
        targetManaged=[PSCustomObject]$targetCounts
        diff=[PSCustomObject]@{changed=$changed;added=$added;deleted=$deleted;unchanged=$unchanged}
        lastPull=$( $statePull=Get-ProjectStateTimestamp -Context $ctx -Operation 'pull'; if($null -ne $statePull){$statePull}else{Get-ProjectStatusLogTimestamp -ProjectName $projectName -Prefix 'project_pull_'} )
        lastSync=$( $stateSync=Get-ProjectStateTimestamp -Context $ctx -Operation 'sync'; if($null -ne $stateSync){$stateSync}else{Get-ProjectStatusLogTimestamp -ProjectName $projectName -Prefix 'project_sync_'} )
        status=$state
    }
}

function Format-StatusDate {
    param($Value)
    if($null -eq $Value){return '<none>'}
    return ([DateTime]$Value).ToString('yyyy-MM-dd HH:mm:ss')
}

function Invoke-ProjectStatus {
    param([string[]]$Arguments)
    $project=Get-NamedArgument -Arguments $Arguments -Name '-Project'
    [string[]]$projectNames=@()

    if([string]::IsNullOrWhiteSpace($project) -and -not [string]::IsNullOrWhiteSpace($script:DirectProjectPathOverride)){
        $projectNames=@([string](Read-ProjectManifest -Project '').Manifest.projectName)
    }elseif(-not [string]::IsNullOrWhiteSpace($project)){
        $projectNames=@([string]$project)
    }else{
        $registered=Get-RegisteredProjectNames
        foreach($registeredName in $registered){$projectNames += [string]$registeredName}
    }

    if($projectNames.Count -eq 0){
        throw '状態確認できるプロジェクトが見つかりません。projectフォルダとproject.jsonを確認してください。'
    }

    [object[]]$itemArray=@()
    foreach($name in @($projectNames)){
        Write-Info ("プロジェクト状態を確認しています: {0}" -f $name)
        $itemArray += @(Get-OneProjectStatus -Project ([string]$name))
    }
    $itemArray=@($itemArray)
    $jsonPath=Write-ProjectStatusJson -Items $itemArray

    foreach($item in @($itemArray)){
        Write-Host ''
        Write-Host '====================================='
        Write-Host 'VBA Project Status'
        Write-Host '====================================='
        Write-Host ("Project       : {0}" -f $item.project)
        Write-Host ("Target        : {0}" -f $item.target)
        Write-Host ''
        Write-Host 'Source Components'
        Write-Host ("  Standard    : {0}" -f $item.source.standard)
        Write-Host ("  Class       : {0}" -f $item.source.class)
        Write-Host ("  Document    : {0}" -f $item.source.document)
        Write-Host ("  UserForm    : {0}" -f $item.source.userform)
        Write-Host 'Managed Target Components'
        Write-Host ("  Standard    : {0}" -f $item.targetManaged.standard)
        Write-Host ("  Class       : {0}" -f $item.targetManaged.class)
        Write-Host ("  Document    : {0}" -f $item.targetManaged.document)
        Write-Host ("  UserForm    : {0}" -f $item.targetManaged.userform)
        Write-Host ''
        Write-Host ("Changed       : {0}" -f $item.diff.changed)
        Write-Host ("Added         : {0}" -f $item.diff.added)
        Write-Host ("Deleted       : {0}" -f $item.diff.deleted)
        Write-Host ("Unchanged     : {0}" -f $item.diff.unchanged)
        Write-Host ("Last Pull     : {0}" -f (Format-StatusDate $item.lastPull))
        Write-Host ("Last Sync     : {0}" -f (Format-StatusDate $item.lastSync))
        Write-Host ("Status        : {0}" -f $item.status)
        Write-Host '====================================='
        if($item.status -eq 'Synchronized'){
            Write-Success 'SourceとTargetは同期しています。'
        }else{
            Write-Warn '未反映の差分があります。project-diffまたはproject-syncで内容を確認してください。'
        }
    }
    Write-Host ("Result JSON   : {0}" -f $jsonPath)
}

function Get-HistoryOperationFromFileName {
    param([Parameter(Mandatory=$true)][string]$Name)
    if($Name -like 'project_pull_*'){return 'Pull'}
    if($Name -like 'project_sync_*'){return 'Sync'}
    if($Name -like 'differential_push_*'){return 'Push'}
    if($Name -like 'project_diff_*'){return 'Diff'}
    if($Name -like 'project_status_*'){return 'Status'}
    return 'Other'
}

function Get-HistorySummaryText {
    param($Payload,[string]$Operation)
    if($null -eq $Payload){return ''}
    $summary=$null
    if($Payload.PSObject.Properties['summary']){$summary=$Payload.summary}
    switch($Operation){
        'Pull' {
            if($null -ne $summary -and $summary.PSObject.Properties['exported']){return ('Exported={0}' -f $summary.exported)}
        }
        'Sync' {
            if($Payload.PSObject.Properties['deletedCandidates']){return ('DeleteCandidates={0}; Mode={1}' -f @($Payload.deletedCandidates).Count,$Payload.deleteMode)}
        }
        'Push' {
            if($null -ne $summary){return ('Changed={0}; Added={1}; Updated={2}; Remaining={3}' -f $summary.changed,$summary.added,$summary.updated,$summary.remainingDifferences)}
        }
        'Diff' {
            if($null -ne $summary){return ('Changed={0}; Added={1}; Unchanged={2}' -f $summary.changed,$summary.added,$summary.unchanged)}
        }
        'Status' {
            if($Payload.PSObject.Properties['projects']){return ('Projects={0}' -f @($Payload.projects).Count)}
        }
    }
    return ''
}

function Get-ProjectHistoryItems {
    param([string]$Project)
    $logDir=Get-RuntimeLogDirectory
    if(-not(Test-Path -LiteralPath $logDir -PathType Container)){return @()}

    [object[]]$result=@()
    $files=@(Get-ChildItem -LiteralPath $logDir -Filter '*.json' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
    foreach($file in @($files)){
        try{
            $payload=Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
            $operation=Get-HistoryOperationFromFileName -Name $file.Name
            if($operation -eq 'Other'){continue}

            $payloadProject=''
            if($payload.PSObject.Properties['project']){$payloadProject=[string]$payload.project}
            if([string]::IsNullOrWhiteSpace($payloadProject) -and $payload.PSObject.Properties['projects']){
                $names=@($payload.projects | ForEach-Object { [string]$_.project } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
                $payloadProject=($names -join ',')
            }
            if(-not [string]::IsNullOrWhiteSpace($Project)){
                $matches=@($payloadProject -split ',' | ForEach-Object {$_.Trim()} | Where-Object { [string]::Equals($_,$Project,[System.StringComparison]::OrdinalIgnoreCase) })
                if($matches.Count -eq 0){continue}
            }

            $when=$file.LastWriteTime
            if($payload.PSObject.Properties['timestamp'] -and -not [string]::IsNullOrWhiteSpace([string]$payload.timestamp)){
                try{$when=([DateTimeOffset]::Parse([string]$payload.timestamp)).LocalDateTime}catch{Write-Verbose ('履歴timestampを解析できませんでした: '+$_.Exception.Message)}
            }
            $result += [PSCustomObject]@{
                timestamp=$when
                project=$(if([string]::IsNullOrWhiteSpace($payloadProject)){'<unknown>'}else{$payloadProject})
                operation=$operation
                summary=Get-HistorySummaryText -Payload $payload -Operation $operation
                file=$file.FullName
            }
        }catch{
            $result += [PSCustomObject]@{
                timestamp=$file.LastWriteTime
                project='<unreadable>'
                operation='InvalidLog'
                summary=$_.Exception.Message
                file=$file.FullName
            }
        }
    }
    return @($result | Sort-Object timestamp -Descending)
}

function Write-ProjectHistoryJson {
    param([Parameter(Mandatory=$true)][AllowEmptyCollection()][object[]]$Items,[string]$Project)
    $logDir=Get-RuntimeLogDirectory
    New-Item -ItemType Directory -Path $logDir -Force|Out-Null
    $path=Join-Path $logDir ('project_history_'+[DateTime]::Now.ToString('yyyyMMdd_HHmmss_fff')+'.json')
    $payload=[PSCustomObject]@{
        schemaVersion='1.0'
        toolVersion=$script:ToolVersion
        timestamp=[DateTime]::Now.ToString('o')
        project=$(if([string]::IsNullOrWhiteSpace($Project)){'<all>'}else{$Project})
        count=@($Items).Count
        items=@($Items)
    }
    [System.IO.File]::WriteAllText($path,($payload|ConvertTo-Json -Depth 8),(New-Object System.Text.UTF8Encoding($false)))
    return $path
}

function Invoke-ProjectHistory {
    param([string[]]$Arguments)
    $project=Get-NamedArgument -Arguments $Arguments -Name '-Project'
    $limitText=Get-NamedArgument -Arguments $Arguments -Name '-Limit'
    $limit=20
    if(-not [string]::IsNullOrWhiteSpace($limitText)){
        $parsed=0
        if(-not [int]::TryParse($limitText,[ref]$parsed) -or $parsed -lt 1 -or $parsed -gt 500){
            throw '-Limitには1～500の整数を指定してください。'
        }
        $limit=$parsed
    }

    [object[]]$allItems=@(Get-ProjectHistoryItems -Project $project)
    [object[]]$items=@($allItems | Select-Object -First $limit)
    $jsonPath=Write-ProjectHistoryJson -Items $items -Project $project

    Write-Host ''
    Write-Host '====================================='
    Write-Host 'VBA Project History'
    Write-Host '====================================='
    Write-Host ("Project       : {0}" -f $(if([string]::IsNullOrWhiteSpace($project)){'<all>'}else{$project}))
    Write-Host ("Displayed     : {0}" -f @($items).Count)
    Write-Host ("Available     : {0}" -f @($allItems).Count)
    Write-Host '====================================='

    if(@($items).Count -eq 0){
        Write-Warn '該当する操作履歴はありません。新しいパッケージへ移行した場合、旧フォルダのlogsは自動移行されません。'
    }else{
        foreach($item in @($items)){
            Write-Host ("{0}  {1,-8}  {2,-20}  {3}" -f ([DateTime]$item.timestamp).ToString('yyyy-MM-dd HH:mm:ss'),$item.operation,$item.project,$item.summary)
            Write-Host ("  Log: {0}" -f $item.file)
        }
    }
    Write-Host ("Result JSON   : {0}" -f $jsonPath)
}

function Invoke-CliCoreTest {
    Write-Info 'CLI Core回帰テストを実行しています...'
    $empty=Parse-CliArguments -Arguments $null
    if($empty.Values.Count -ne 0){throw '引数なし解析に失敗しました。'}
    $sample=Parse-CliArguments -Arguments @('-Project','PropertyManagement','-Limit=10','-ApplyDeletes')
    if((Get-CliOption -Parsed $sample -Name '-Project') -ne 'PropertyManagement'){throw '-Project解析に失敗しました。'}
    if((Get-CliOption -Parsed $sample -Name '-Limit') -ne '10'){throw '-Limit=解析に失敗しました。'}
    if(-not(Test-CliSwitch -Parsed $sample -Name '-ApplyDeletes')){throw 'スイッチ解析に失敗しました。'}
    $previousOverride=$script:ProjectRootOverride
    $fixtureName='CliCoreTest_'+[guid]::NewGuid().ToString('N')
    $fixtureDir=Join-Path (Get-DefaultProjectRoot) $fixtureName
    try{
        New-Item -ItemType Directory -Path $fixtureDir -Force|Out-Null
        [System.IO.File]::WriteAllText((Join-Path $fixtureDir 'project.json'),'{"schemaVersion":"1.0"}',(New-Object System.Text.UTF8Encoding($false)))
        $script:ProjectRootOverride=Get-DefaultProjectRoot
        $projects=Get-RegisteredProjectNames
        if(-not $projects.Contains($fixtureName)){throw '登録プロジェクト列挙に失敗しました。'}
    }finally{
        $script:ProjectRootOverride=$previousOverride
        Remove-Item -LiteralPath $fixtureDir -Recurse -Force -ErrorAction SilentlyContinue
    }
    Write-Host '  [OK] 引数なし'
    Write-Host '  [OK] 名前付き引数'
    Write-Host '  [OK] =形式引数'
    Write-Host '  [OK] スイッチ'
    Write-Host ("  [OK] 登録プロジェクト: {0}" -f ($projects -join ', '))
    Write-Success 'CLI Core回帰テストに成功しました。'
}

function Get-FileSha256ForTest {
    param([Parameter(Mandatory=$true)][string]$Path)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $stream = $null
    try {
        $stream = [System.IO.File]::OpenRead($Path)
        return ([System.BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-','').ToLowerInvariant()
    }
    finally {
        if ($null -ne $stream) { $stream.Dispose() }
        $sha.Dispose()
    }
}

function Assert-ProjectCreateFailure {
    param(
        [Parameter(Mandatory=$true)][scriptblock]$Action,
        [Parameter(Mandatory=$true)][string]$ExpectedText,
        [Parameter(Mandatory=$true)][string]$CaseName
    )
    $failed = $false
    try { & $Action | Out-Null }
    catch {
        $failed = $true
        if ($_.Exception.Message -notlike "*$ExpectedText*") {
            throw "拒否理由が一致しません。Case=$CaseName Expected=$ExpectedText Actual=$($_.Exception.Message)"
        }
    }
    if (-not $failed) { throw "安全に拒否されませんでした。Case=$CaseName" }
    Write-Host ("  [OK] {0}" -f $CaseName)
}

function Invoke-ProjectCreateTest {
    $tempRoot = Join-Path (Get-TestTempBase) ('VBAUpdaterProjectCreateTest_' + [guid]::NewGuid().ToString('N'))
    $projectRoot = Join-Path $tempRoot 'Development'
    $existingProject = 'RegistrationExisting_' + [guid]::NewGuid().ToString('N')
    $successProject = 'RegistrationTest_' + [guid]::NewGuid().ToString('N')
    $failureProject = 'RegistrationFail_' + [guid]::NewGuid().ToString('N')
    $existingProjectDir = Join-Path $projectRoot $existingProject
    $successProjectDir = Join-Path $projectRoot $successProject
    $failureProjectDir = Join-Path $projectRoot $failureProject
    $existingManifest = Join-Path $existingProjectDir 'project.json'
    $existingHashBefore = ''
    $previousOverride = $script:ProjectRootOverride
    $previousDefaultOverride = $script:DefaultProjectRootTestOverride

    try {
        $script:DefaultProjectRootTestOverride = $projectRoot
        $script:ProjectRootOverride = $projectRoot
        Write-Info 'Initial Project Registration回帰テストを実行しています...'
        New-Item -ItemType Directory -Path $projectRoot -Force | Out-Null
        New-Item -ItemType Directory -Path $existingProjectDir -Force | Out-Null
        New-Item -ItemType Directory -Path $successProjectDir -Force | Out-Null
        New-Item -ItemType Directory -Path $failureProjectDir -Force | Out-Null
        [System.IO.File]::WriteAllText((Join-Path $successProjectDir 'README.md'),'existing development files')
        [System.IO.File]::WriteAllText((Join-Path $failureProjectDir 'README.md'),'existing development files')
        [System.IO.File]::WriteAllText($existingManifest,'{"schemaVersion":"1.0","projectName":"ExistingTest"}',(New-Object System.Text.UTF8Encoding($false)))
        $existingHashBefore = Get-FileSha256ForTest -Path $existingManifest
        $xlsm = Join-Path $tempRoot 'RegistrationBook.xlsm'
        $xlsb = Join-Path $tempRoot 'RegistrationBook.xlsb'
        $xlam = Join-Path $tempRoot 'RegistrationBook.xlam'
        $xlsx = Join-Path $tempRoot 'RegistrationBook.xlsx'
        $bytes = [System.Text.Encoding]::UTF8.GetBytes('VBAUpdater project-create regression workbook placeholder')
        foreach ($path in @($xlsm,$xlsb,$xlam,$xlsx)) { [System.IO.File]::WriteAllBytes($path,$bytes) }

        [void](Test-ProjectCreateWorkbook -WorkbookPath $xlsm)
        [void](Test-ProjectCreateWorkbook -WorkbookPath $xlsb)
        [void](Test-ProjectCreateWorkbook -WorkbookPath $xlam)
        Write-Host '  [OK] .xlsm / .xlsb / .xlamを受け付けます。'

        Assert-ProjectCreateFailure -CaseName '.xlsx拒否' -ExpectedText '対応していないブック形式' -Action { Test-ProjectCreateWorkbook -WorkbookPath $xlsx }
        Assert-ProjectCreateFailure -CaseName '空のプロジェクト名を拒否' -ExpectedText 'プロジェクト内部名' -Action { Test-ProjectCreateName -Project '' }
        Assert-ProjectCreateFailure -CaseName '不正文字を含む内部名を拒否' -ExpectedText '半角英数字' -Action { Test-ProjectCreateName -Project 'Invalid/Name' }
        Assert-ProjectCreateFailure -CaseName '既存プロジェクト名の重複を拒否' -ExpectedText '既に登録' -Action { Get-ProjectCreatePlan -Project $existingProject -WorkbookPath $xlsm }
        Assert-ProjectCreateFailure -CaseName '存在しないProjectFolderを自動作成しない' -ExpectedText '自動作成は行いません' -Action {
            Get-ProjectCreatePlan -ProjectFolder (Join-Path $projectRoot 'MissingProject') -WorkbookPath $xlsm
        }

        $copyTestDir = Join-Path $tempRoot 'copy-target'
        New-Item -ItemType Directory -Path $copyTestDir -Force | Out-Null
        $copyTestTarget = Join-Path $copyTestDir 'RegistrationBook.xlsm'
        [System.IO.File]::WriteAllBytes($copyTestTarget,[byte[]]@(9,8,7))
        $copyHashBefore = Get-FileSha256ForTest -Path $copyTestTarget
        Assert-ProjectCreateFailure -CaseName 'コピー先を上書きしない' -ExpectedText '上書きしません' -Action { Copy-WorkbookToProjectTarget -SourcePath $xlsm -TargetPath $copyTestTarget }
        if ((Get-FileSha256ForTest -Path $copyTestTarget) -ne $copyHashBefore) { throw '拒否後にコピー先ファイルが変更されました。' }

        $originalHash = Get-FileSha256ForTest -Path $xlsm
        $discovery = {
            param($targetPath)
            return [PSCustomObject]@{ type='standard'; name='modRegistrationTest'; file='standard/modRegistrationTest.bas' }
        }
        $pull = {
            param($projectName)
            $sourceDir = Join-Path (Resolve-ProjectPath -Project $projectName) 'source\standard'
            New-Item -ItemType Directory -Path $sourceDir -Force | Out-Null
            [System.IO.File]::WriteAllText((Join-Path $sourceDir 'modRegistrationTest.bas'), "Attribute VB_Name = `"modRegistrationTest`"`r`nOption Explicit`r`n", (New-Object System.Text.UTF8Encoding($false)))
            $script:ProjectCreateTestPullCalled = $true
        }
        $script:ProjectCreateTestPullCalled = $false
        $result = Invoke-ProjectCreateCore -ProjectFolder $successProjectDir -WorkbookPath $xlsm -ComponentDiscovery $discovery -ProjectPullInvoker $pull
        if (-not $script:ProjectCreateTestPullCalled) { throw 'project-pull呼び出し経路が実行されませんでした。' }
        if ((Get-FileSha256ForTest -Path $xlsm) -ne $originalHash) { throw '元のExcelブックが変更されました。' }
        if (-not (Test-Path -LiteralPath $result.TargetPath -PathType Leaf)) { throw 'targetへブックがコピーされていません。' }
        if ((Get-FileSha256ForTest -Path $result.TargetPath) -ne $originalHash) { throw 'targetのコピー内容が元ブックと一致しません。' }
        $manifest = Get-Content -LiteralPath $result.ManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ([string]$manifest.schemaVersion -ne '1.0' -or [string]$manifest.target.directory -ne 'target' -or [string]$manifest.source.root -ne 'source') {
            throw '生成project.jsonが既存schemaVersion 1.0構造と互換ではありません。'
        }
        if (-not (Test-Path -LiteralPath (Join-Path $successProjectDir 'source\standard\modRegistrationTest.bas') -PathType Leaf)) {
            throw 'project-pull後の初期sourceがありません。'
        }
        Write-Host '  [OK] 元ブックを維持し、targetコピー、互換project.json、初期sourceを作成します。'
        Write-Host '  [OK] project-pull呼び出し経路を再利用します。'

        $failingPull = { param($projectName) throw '模擬project-pull失敗' }
        Assert-ProjectCreateFailure -CaseName '失敗時クリーンアップ' -ExpectedText '模擬project-pull失敗' -Action {
            Invoke-ProjectCreateCore -ProjectFolder $failureProjectDir -WorkbookPath $xlsm -ComponentDiscovery $discovery -ProjectPullInvoker $failingPull
        }
        if (-not (Test-Path -LiteralPath $failureProjectDir -PathType Container) -or
            -not (Test-Path -LiteralPath (Join-Path $failureProjectDir 'README.md') -PathType Leaf)) {
            throw '失敗時に既存の開発プロジェクトフォルダまたはREADMEが削除されました。'
        }
        if ((Test-Path -LiteralPath (Join-Path $failureProjectDir 'project.json')) -or
            (Test-Path -LiteralPath (Join-Path $failureProjectDir 'source')) -or
            (Test-Path -LiteralPath (Join-Path $failureProjectDir 'target'))) {
            throw '失敗時に今回作成した登録用ファイルが残っています。'
        }
        if (-not (Test-Path -LiteralPath $xlsm -PathType Leaf) -or (Get-FileSha256ForTest -Path $xlsm) -ne $originalHash) {
            throw '失敗時に元のExcelブックが変更されました。'
        }

        if (-not [string]::IsNullOrWhiteSpace($existingHashBefore)) {
            if (-not (Test-Path -LiteralPath $existingManifest -PathType Leaf) -or (Get-FileSha256ForTest -Path $existingManifest) -ne $existingHashBefore) {
                throw '既存のPropertyManagementプロジェクトが変更されました。'
            }
            Write-Host '  [OK] 既存のテスト用プロジェクトを変更・削除しません。'
        }

        foreach ($path in @((Join-Path $script:Root 'vba.ps1'),(Join-Path $script:Root 'gui.ps1'),$script:ProjectRegistrationModulePath)) {
            $fileBytes = [System.IO.File]::ReadAllBytes($path)
            if ($fileBytes.Length -lt 3 -or $fileBytes[0] -ne 0xEF -or $fileBytes[1] -ne 0xBB -or $fileBytes[2] -ne 0xBF) {
                throw "UTF-8 BOMが維持されていません: $path"
            }
            $tokens = $null
            $parseErrors = $null
            [void][System.Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$parseErrors)
            if (@($parseErrors).Count -gt 0) { throw "PowerShell構文解析に失敗しました: $path / $((@($parseErrors | ForEach-Object { $_.Message })) -join ' / ')" }
        }
        Write-Host '  [OK] PowerShell構文とUTF-8 BOMを維持します。'
        Write-Success 'Initial Project Registration回帰テストに成功しました。'
    }
    finally {
        Remove-Item -LiteralPath $successProjectDir -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $failureProjectDir -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $existingProjectDir -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
        $script:ProjectCreateTestPullCalled = $false
        $script:ProjectRootOverride = $previousOverride
        $script:DefaultProjectRootTestOverride = $previousDefaultOverride
    }
}

function Invoke-ProjectRegistration418Test {
    $tempRoot = Join-Path (Get-TestTempBase) ('VBAUpdaterRegistration418_' + [guid]::NewGuid().ToString('N'))
    $settingsPath = Join-Path $tempRoot 'settings\settings.json'
    $oldSettingsOverride = [Environment]::GetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable,'Process')
    $oldProjectRootOverride = $script:ProjectRootOverride
    $oldDirectProjectOverride = $script:DirectProjectPathOverride
    $migrationLogPath = $null
    $registrationLogPath = $null
    try {
        Write-Info 'Ver4.18.0 Development Project Registration回帰テストを実行しています...'
        $developmentRoot = Join-Path $tempRoot 'OneDrive - テスト\Development'
        $projectFolder = Join-Path $developmentRoot '日本語プロジェクト'
        $ignoredFolder = Join-Path $developmentRoot '未登録フォルダー'
        New-Item -ItemType Directory -Path (Join-Path $projectFolder '.git') -Force | Out-Null
        New-Item -ItemType Directory -Path $ignoredFolder -Force | Out-Null
        [System.IO.File]::WriteAllText((Join-Path $projectFolder 'README.md'),'preserve this repository file')
        $workbookPath = Join-Path $tempRoot '日本語ブック.xlsm'
        [System.IO.File]::WriteAllText($workbookPath,'Ver4.18.0 workbook placeholder')
        [Environment]::SetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable,$settingsPath,'Process')
        $script:ProjectRootOverride = $developmentRoot

        $validation = Get-ProjectRegistrationValidation -ProjectFolder $projectFolder -WorkbookPath $workbookPath -ToolRoot $script:Root
        if (-not $validation.IsValid -or $validation.ProjectName -ne '日本語プロジェクト' -or -not $validation.IsGitRepository -or -not $validation.IsOneDrive) {
            throw 'OneDrive・日本語・Git管理下の共通Validationに失敗しました。'
        }
        $missingFolder = Join-Path $developmentRoot '存在しないフォルダー'
        $missingValidation = Get-ProjectRegistrationValidation -ProjectFolder $missingFolder -WorkbookPath $workbookPath -ToolRoot $script:Root
        if ($missingValidation.IsValid -or (Test-Path -LiteralPath $missingFolder)) { throw '存在しないProjectFolderを拒否せず、自動作成しました。' }
        Write-Host '  [OK] OneDrive・日本語・Git管理下・外部Project Root・フォルダー自動作成禁止'

        $cliProbeFolder = Join-Path $developmentRoot 'CLI検証案件'
        New-Item -ItemType Directory -Path $cliProbeFolder | Out-Null
        $cliOutput = @(& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $script:Root 'vba.ps1') project-registration-validate -ProjectFolder $cliProbeFolder -WorkbookPath $workbookPath -Json @(Get-TestPropagationArguments) 2>&1)
        if ($LASTEXITCODE -ne 0) { throw ('CLI共通Validationの実行に失敗しました: ' + ($cliOutput -join ' / ')) }
        $cliValidation = ($cliOutput -join [Environment]::NewLine) | ConvertFrom-Json
        if (-not [bool]$cliValidation.IsValid -or [string]$cliValidation.ProjectName -ne 'CLI検証案件') { throw 'CLI共通Validation結果が一致しません。' }
        Write-Host '  [OK] GUI・CLI共通Validationサービスと-ProjectFolder入力'

        $discovery = { param($targetPath) [PSCustomObject]@{type='standard';name='modRegistration418';file='standard/modRegistration418.bas'} }
        $pull = {
            param($projectName)
            $sourceDir = Join-Path (Resolve-ProjectPath -Project $projectName) 'source\standard'
            New-Item -ItemType Directory -Path $sourceDir -Force | Out-Null
            [System.IO.File]::WriteAllText((Join-Path $sourceDir 'modRegistration418.bas'),"Attribute VB_Name = `"modRegistration418`"`r`nOption Explicit`r`n")
        }
        $result = Invoke-ProjectCreateCore -ProjectFolder $projectFolder -WorkbookPath $workbookPath -ComponentDiscovery $discovery -ProjectPullInvoker $pull
        [void](Add-OrUpdateRegisteredProject -ProjectFolder $result.ProjectDirectory -Name $result.Project)
        if (-not (Test-Path -LiteralPath $result.ManifestPath -PathType Leaf) -or
            -not (Test-Path -LiteralPath $result.TargetPath -PathType Leaf) -or
            -not (Test-Path -LiteralPath (Join-Path $projectFolder 'source\standard\modRegistration418.bas') -PathType Leaf)) {
            throw 'project.json、target、source、初回Pull結果が揃っていません。'
        }
        if (-not (Test-Path -LiteralPath (Join-Path $projectFolder 'README.md') -PathType Leaf) -or
            -not (Test-Path -LiteralPath (Join-Path $projectFolder '.git') -PathType Container)) {
            throw '登録時に既存READMEまたは.gitが失われました。'
        }
        $registered = Get-RegisteredProjectNames
        if (-not $registered.Contains('日本語プロジェクト') -or $registered.Contains('未登録フォルダー') -or $registered.Contains('CLI検証案件')) {
            throw 'Project Root一覧がproject.jsonのあるフォルダーだけに限定されていません。'
        }
        Write-Host '  [OK] 既存開発フォルダー正本、project.json検索、source/target生成、初回Pull、既存ファイル保持'

        $registrationLogPath = Write-ProjectRegistrationLog -Status 'Success' -ProjectFolder $projectFolder -WorkbookPath $workbookPath -Message 'Ver4.18.0 regression'
        $registrationPayload = Get-Content -LiteralPath $registrationLogPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($registrationPayload.operation -ne 'project-registration' -or $registrationPayload.status -ne 'Success') { throw '登録ログの内容が一致しません。' }
        Write-Host '  [OK] 開発プロジェクト登録JSONログ'

        $scriptText = [System.IO.File]::ReadAllText((Join-Path $script:Root 'vba.ps1'),[System.Text.Encoding]::UTF8)
        foreach ($functionName in @('Invoke-ProjectPull','Invoke-ProjectPush','Invoke-ProjectSync','Invoke-ProjectDiff')) {
            $pattern = 'function\s+' + [System.Text.RegularExpressions.Regex]::Escape($functionName) + '\b(?<Body>[\s\S]*?)(?=\r?\nfunction\s+|\z)'
            $match = [System.Text.RegularExpressions.Regex]::Match($scriptText,$pattern,[System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
            if (-not $match.Success -or $match.Groups['Body'].Value -notmatch 'Read-ProjectManifest') { throw "共通manifest解決を使用していないCLI経路があります: $functionName" }
        }
        Write-Host '  [OK] project-pull / project-push / project-sync / project-diffの既存CLI互換経路'

        $pullChildMatch = [System.Text.RegularExpressions.Regex]::Match($scriptText,'function\s+Invoke-ProjectPullChildProcess\b(?<Body>[\s\S]*?)(?=\r?\nfunction\s+|\z)',[System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
        $createCoreMatch = [System.Text.RegularExpressions.Regex]::Match($scriptText,'function\s+Invoke-ProjectCreateCore\b(?<Body>[\s\S]*?)(?=\r?\nfunction\s+|\z)',[System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
        if (-not $pullChildMatch.Success -or
            $pullChildMatch.Groups['Body'].Value -match '\$script:DirectWorkbookPathOverride' -or
            $pullChildMatch.Groups['Body'].Value -notmatch '''-WorkbookPath'',\s*\$TargetWorkbookPath' -or
            -not $createCoreMatch.Success -or
            $createCoreMatch.Groups['Body'].Value -notmatch 'Invoke-ProjectPullChildProcess[^\r\n]+-TargetWorkbookPath\s+\$plan\.TargetPath') {
            throw '初回Pullがコピー元ブックではなくtarget内のコピー先ブックを固定指定していません。'
        }
        Write-Host '  [OK] 初回Pullはtarget内のコピー先ブックを明示し、入力ブックの状態を引き継がない'

        $legacyRoot = Join-Path $tempRoot 'LegacyRoot'
        $legacyProject = Join-Path $legacyRoot '旧案件'
        New-Item -ItemType Directory -Path (Join-Path $legacyProject 'source') -Force | Out-Null
        New-Item -ItemType Directory -Path (Join-Path $legacyProject 'target') -Force | Out-Null
        [System.IO.File]::WriteAllText((Join-Path $legacyProject 'project.json'),'{"schemaVersion":"1.0","projectName":"旧案件"}')
        [System.IO.File]::WriteAllText((Join-Path $legacyProject 'README.md'),'legacy source must remain')
        $migrationDestination = Join-Path $tempRoot 'MigratedDevelopment'
        New-Item -ItemType Directory -Path $migrationDestination | Out-Null
        $migrationCheck = Get-LegacyProjectMigrationCheckResult -SourceRoot $legacyRoot
        if (-not $migrationCheck.RequiresMigration -or $migrationCheck.Projects -ne 1) { throw 'Ver4.17以前の移行対象を検出できません。' }
        $migrationLogsBefore = @(Get-ChildItem -LiteralPath (Get-RuntimeLogDirectory) -Filter 'project_migration_*.json' -File -ErrorAction SilentlyContinue | ForEach-Object {$_.FullName})
        Invoke-ProjectMigration -Arguments @('-SourceRoot',$legacyRoot,'-DestinationRoot',$migrationDestination)
        $migratedDestination = Join-Path $migrationDestination '旧案件'
        $migrationLogPath = @(Get-ChildItem -LiteralPath (Get-RuntimeLogDirectory) -Filter 'project_migration_*.json' -File -ErrorAction SilentlyContinue | Where-Object {$migrationLogsBefore -notcontains $_.FullName} | Sort-Object LastWriteTime -Descending | Select-Object -First 1 -ExpandProperty FullName)
        if (-not (Test-CompleteProjectFolder -Path $migratedDestination) -or
            -not (Test-Path -LiteralPath (Join-Path $legacyProject 'README.md') -PathType Leaf)) {
            throw '旧形式プロジェクトの安全なコピー・検証・移行元保持に失敗しました。'
        }
        if ([string]::IsNullOrWhiteSpace([string]$migrationLogPath)) { throw '移行ログが作成されていません。' }
        Write-Host '  [OK] Ver4.17以前の自動検出、安全な移行コピー、検証、移行元保持、ログ記録'

        & powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File (Join-Path $script:Root 'gui.ps1') -RegistrationHotFixSelfTest @(Get-TestPropagationArguments)
        if ($LASTEXITCODE -ne 0) { throw "GUI登録ボタン回帰テストに失敗しました。ExitCode=$LASTEXITCODE" }
        Write-Success 'Ver4.18.0 Development Project Registration回帰テストに成功しました。'
    }
    finally {
        $script:ProjectRootOverride = $oldProjectRootOverride
        $script:DirectProjectPathOverride = $oldDirectProjectOverride
        [Environment]::SetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable,$oldSettingsOverride,'Process')
        if (-not [string]::IsNullOrWhiteSpace([string]$migrationLogPath) -and (Test-Path -LiteralPath $migrationLogPath -PathType Leaf)) { Remove-Item -LiteralPath $migrationLogPath -Force -ErrorAction SilentlyContinue }
        if (-not [string]::IsNullOrWhiteSpace([string]$registrationLogPath) -and (Test-Path -LiteralPath $registrationLogPath -PathType Leaf)) { Remove-Item -LiteralPath $registrationLogPath -Force -ErrorAction SilentlyContinue }
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-SettingsPersistenceTest {
    $tempBase=if($null-ne$script:TestExecutionContext){$script:TestExecutionContext.Root}else{[System.IO.Path]::GetTempPath()}
    $tempRoot=Join-Path $tempBase ('VBAUpdater Chapter2 日本語ユーザー '+[guid]::NewGuid().ToString('N'))
    $settingsPath=Join-Path $tempRoot 'LocalAppData\VBAUpdater\settings.json'
    $developmentRoot=Join-Path $tempRoot 'OneDrive - 会社\Development'
    $oldSettings=[Environment]::GetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable,'Process')
    $oldRootOverride=$script:ProjectRootOverride
    $oldDirectOverride=$script:DirectProjectPathOverride
    try {
        Write-Info 'Ver4.18.0 Chapter2 Settings Persistence回帰テストを実行しています...'
        [Environment]::SetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable,$settingsPath,'Process')
        $script:ProjectRootOverride=$null
        $script:DirectProjectPathOverride=$null
        New-Item -ItemType Directory -Path $developmentRoot -Force|Out-Null

        $first=Get-ProjectRootInfo
        $paths=Get-ProjectRootSettingsPaths
        foreach($required in @($paths.Folder,$paths.Logs,$paths.Cache)) { if(-not(Test-Path -LiteralPath $required -PathType Container)){throw "設定フォルダーを自動生成できません: $required"} }
        foreach($required in @($paths.User,$paths.Projects)) { if(-not(Test-Path -LiteralPath $required -PathType Leaf)){throw "設定JSONを自動生成できません: $required"} }
        if($paths.Folder.StartsWith([System.IO.Path]::GetFullPath($script:Root),[System.StringComparison]::OrdinalIgnoreCase)){throw '設定フォルダーがVBAUpdater本体から独立していません。'}
        Write-Host '  [OK] 初回起動・独立設定フォルダー・settings.json・projects.json・logs・cache自動生成'

        function New-SettingsPersistenceFixture {
            param([string]$Name)
            $folder=Join-Path $developmentRoot $Name
            New-Item -ItemType Directory -Path (Join-Path $folder 'source') -Force|Out-Null
            New-Item -ItemType Directory -Path (Join-Path $folder 'target') -Force|Out-Null
            [System.IO.File]::WriteAllText((Join-Path $folder 'project.json'),([ordered]@{schemaVersion='1.0';projectName=$Name;source=[ordered]@{root='source'};target=[ordered]@{directory='target'}}|ConvertTo-Json -Depth 5),(New-Object System.Text.UTF8Encoding($false)))
            return $folder
        }
        $property=New-SettingsPersistenceFixture -Name 'PropertyManagement_日本語'
        $housing=New-SettingsPersistenceFixture -Name 'HousingERP'
        Invoke-ProjectRootSet -Arguments @('-Path',$developmentRoot)
        $registered=@(Get-RegisteredProjects)
        if($registered.Count-ne 2){throw "Project Root初回取込件数が一致しません: $($registered.Count)"}
        $restored=Get-ProjectRootInfo
        if(-not(Test-PathsEqual $restored.Path $developmentRoot)){throw 'Project Rootをsettings.jsonから復元できません。'}
        Write-Host '  [OK] Project Root復元・OneDrive・日本語ユーザー名・projects.json登録'

        $beforeUpdate=(Get-Content -LiteralPath $paths.Projects -Raw -Encoding UTF8)
        $child=@(& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $script:Root 'vba.ps1') settings -Json @(Get-TestPropagationArguments) 2>&1)
        if($LASTEXITCODE-ne 0){throw ('本体更新後相当の別プロセス読込に失敗しました: '+($child-join ' / '))}
        $childInfo=($child-join [Environment]::NewLine)|ConvertFrom-Json
        if([int]$childInfo.RegisteredProjects-ne 2-or-not(Test-PathsEqual ([string]$childInfo.ProjectRoot) $developmentRoot)){throw '別プロセスで永続設定を復元できません。'}
        if((Get-Content -LiteralPath $paths.Projects -Raw -Encoding UTF8)-ne$beforeUpdate){throw '読込だけでprojects.jsonの登録内容が変化しました。'}
        Write-Host '  [OK] VBAUpdater本体更新後相当の別プロセスでも設定保持'

        $unregisterOutput=@(& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $script:Root 'vba.ps1') project-unregister -Project 'PropertyManagement_日本語' @(Get-TestPropagationArguments) 2>&1)
        if($LASTEXITCODE-ne 0){throw ('project-unregister CLIに失敗しました: '+($unregisterOutput-join ' / '))}
        if(-not(Test-Path -LiteralPath $property -PathType Container)){throw '登録解除時にプロジェクトフォルダーが削除されました。'}
        if(@(Get-RegisteredProjects).Count-ne 1){throw 'projects.jsonから登録解除できません。'}
        Write-Host '  [OK] 登録解除はprojects.jsonだけを更新し、プロジェクトフォルダーを保持'

        $movedParent=Join-Path $tempRoot '移動後 Development'
        New-Item -ItemType Directory -Path $movedParent -Force|Out-Null
        $movedHousing=Join-Path $movedParent 'HousingERP'
        Move-Item -LiteralPath $housing -Destination $movedHousing
        $relocateOutput=@(& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $script:Root 'vba.ps1') project-relocate -Project 'HousingERP' -ProjectFolder $movedHousing @(Get-TestPropagationArguments) 2>&1)
        if($LASTEXITCODE-ne 0){throw ('project-relocate CLIに失敗しました: '+($relocateOutput-join ' / '))}
        $afterMove=@(Get-RegisteredProjects)
        if($afterMove.Count-ne 1-or-not(Test-PathsEqual -First ([string]$afterMove[0].ProjectFolder) -Second $movedHousing)){throw '移動後フォルダーへprojects.jsonを更新できません。'}
        Write-Host '  [OK] 外部でフォルダー移動後の登録先変更'

        Move-Item -LiteralPath (Join-Path $movedHousing 'project.json') -Destination (Join-Path $movedHousing 'project.json.missing')
        if(@(Get-RegisteredProjects).Count-ne 0){throw 'project.jsonがないプロジェクトを一覧から自動除外できません。'}
        $rawProjects=Get-Content -LiteralPath $paths.Projects -Raw -Encoding UTF8|ConvertFrom-Json
        if(@($rawProjects).Count-ne 0){throw 'projects.jsonから無効なプロジェクトを除外できません。'}
        Write-Host '  [OK] project.json欠落時の一覧・projects.json自動除外'

        Invoke-GuiSettingsSet -Arguments @('-Width','1280','-Height','900','-WindowState','Maximized')
        $guiReload=(Read-ProjectRootSettingsFile -Path $paths.User).Settings.gui
        if([int]$guiReload.windowWidth-ne 1280-or[int]$guiReload.windowHeight-ne 900-or[string]$guiReload.windowState-ne'Maximized'){throw 'GUIウィンドウ設定を永続化できません。'}
        $settingsText=@(& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $script:Root 'vba.ps1') settings @(Get-TestPropagationArguments) 2>&1)-join [Environment]::NewLine
        foreach($expected in @('VBAUpdater Settings','Settings Folder','Project Root','Registered Projects')){if($settingsText.IndexOf($expected,[System.StringComparison]::Ordinal)-lt 0){throw "settings表示が不足しています: $expected"}}
        Write-Host '  [OK] GUI設定・ウィンドウサイズ・settings CLI表示'

        $guiText=[System.IO.File]::ReadAllText((Join-Path $script:Root 'gui.ps1'),[System.Text.Encoding]::UTF8)
        foreach($pattern in @('Get-SettingsInfoFromCli','登録情報の保存場所','project-unregister','project-relocate','Apply-PersistedGuiSettings','Save-PersistedGuiSettings','LogsFolder')){if($guiText.IndexOf($pattern,[System.StringComparison]::Ordinal)-lt 0){throw "Chapter2 GUI要件が見つかりません: $pattern"}}
        if($guiText-match 'GetFolderPath\([^\)]*LocalApplicationData|\$env:LOCALAPPDATA'){throw 'GUIが永続設定パスを独自解決しています。CLI共通サービスを使用してください。'}
        Write-Host '  [OK] GUI保存場所表示・登録解除・登録先変更・サイズ復元・CLI共通サービス'
        Write-Success 'Ver4.18.0 Chapter2 Settings Persistence回帰テストに成功しました。'
    }
    finally {
        $script:ProjectRootOverride=$oldRootOverride
        $script:DirectProjectPathOverride=$oldDirectOverride
        [Environment]::SetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable,$oldSettings,'Process')
        if(Test-Path -LiteralPath $tempRoot -PathType Container){Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue}
    }
}

function Invoke-ProjectRootTest {
    $tempRoot = Join-Path (Get-TestTempBase) ('VBAUpdaterProjectRootTest_' + [guid]::NewGuid().ToString('N'))
    $settingsPath = Join-Path $tempRoot 'user-settings\settings.json'
    $externalRoot = Join-Path $tempRoot 'external-projects'
    $overrideRoot = Join-Path $tempRoot 'cli-override-projects'
    $testProject = 'ExternalRootTest_' + [guid]::NewGuid().ToString('N')
    $oldSettingsOverride = [Environment]::GetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable,'Process')
    $oldProjectRootOverride = $script:ProjectRootOverride
    $oldDefaultRootTestOverride = $script:DefaultProjectRootTestOverride
    $internalManifest = $null
    $internalHashBefore = ''

    try {
        Write-Info 'External Project Root回帰テストを実行しています...'
        New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null
        New-Item -ItemType Directory -Path $externalRoot -Force | Out-Null
        $script:DefaultProjectRootTestOverride = Join-Path $tempRoot 'internal-projects'
        $internalProjectDir = Join-Path (Get-DefaultProjectRoot) 'InternalPreservationTest'
        New-Item -ItemType Directory -Path $internalProjectDir -Force | Out-Null
        $internalManifest = Join-Path $internalProjectDir 'project.json'
        [System.IO.File]::WriteAllText($internalManifest,'{"schemaVersion":"1.0","projectName":"InternalPreservationTest"}',(New-Object System.Text.UTF8Encoding($false)))
        $internalHashBefore = Get-FileSha256ForTest -Path $internalManifest
        [Environment]::SetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable,$settingsPath,'Process')
        $script:ProjectRootOverride = $null

        $defaultInfo = Get-ProjectRootInfo
        if ($defaultInfo.Source -ne 'UserSettings' -or -not [string]::Equals($defaultInfo.Path,(Get-DefaultProjectRoot),[System.StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $settingsPath -PathType Leaf)) {
            throw '初回起動時に既定Developmentをsettings.jsonへ永続化できません。'
        }
        Write-Host '  [OK] 設定なし: 既定Developmentを独立settings.jsonへ自動保存'

        Assert-ProjectCreateFailure -CaseName '空パスを拒否' -ExpectedText 'パスを指定' -Action { Test-ProjectRootCandidate -Path '' -CreateIfMissing }
        Assert-ProjectCreateFailure -CaseName '相対パスを拒否' -ExpectedText '絶対パス' -Action { Test-ProjectRootCandidate -Path '.\relative-projects' -CreateIfMissing }
        Assert-ProjectCreateFailure -CaseName '本体フォルダーを拒否' -ExpectedText '本体フォルダー' -Action { Test-ProjectRootCandidate -Path $script:Root }
        Assert-ProjectCreateFailure -CaseName '本体の重要フォルダーを拒否' -ExpectedText '重要フォルダー' -Action { Test-ProjectRootCandidate -Path (Join-Path $script:Root 'tests') }
        $filePath = Join-Path $tempRoot 'not-a-directory.txt'
        [System.IO.File]::WriteAllText($filePath,'file')
        Assert-ProjectCreateFailure -CaseName 'ファイル指定を拒否' -ExpectedText 'ファイルは指定できません' -Action { Test-ProjectRootCandidate -Path $filePath }
        $probeRoot = Join-Path $tempRoot 'unwritable-probe'
        New-Item -ItemType Directory -Path $probeRoot -Force | Out-Null
        Assert-ProjectCreateFailure -CaseName '書込不可を拒否' -ExpectedText '書き込めません' -Action {
            Test-ProjectRootCandidate -Path $probeRoot -WriteProbe { param($path) throw '模擬アクセス拒否' }
        }

        Invoke-ProjectRootSet -Arguments @('-Path',$externalRoot)
        $configuredInfo = Get-ProjectRootInfo
        if ($configuredInfo.Source -ne 'UserSettings' -or -not [string]::Equals($configuredInfo.Path,$externalRoot,[System.StringComparison]::OrdinalIgnoreCase)) {
            throw "ユーザー設定を再読込できません。Source=$($configuredInfo.Source) Path=$($configuredInfo.Path)"
        }
        if (-not (Test-Path -LiteralPath $externalRoot -PathType Container)) { throw '既存の外部Project Rootを維持できませんでした。' }
        $settingBytes = [System.IO.File]::ReadAllBytes($settingsPath)
        if ($settingBytes.Length -ge 3 -and $settingBytes[0] -eq 0xEF -and $settingBytes[1] -eq 0xBB -and $settingBytes[2] -eq 0xBF) {
            throw 'ユーザー設定がUTF-8 BOMなしで保存されていません。'
        }
        $settingJson = Get-Content -LiteralPath $settingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ([string]$settingJson.schemaVersion -ne '1.0' -or -not [string]::Equals([string]$settingJson.projectRoot,$externalRoot,[System.StringComparison]::OrdinalIgnoreCase)) {
            throw 'ユーザー設定JSONの内容が一致しません。'
        }
        $jsonOutput = (Invoke-ProjectRoot -Arguments @('-Json') | Out-String) | ConvertFrom-Json
        if (-not [string]::Equals([string]$jsonOutput.Path,$externalRoot,[System.StringComparison]::OrdinalIgnoreCase)) {
            throw 'project-root -Jsonが有効な外部ルートを返しません。'
        }
        $cliOutputLines = @(& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $script:Root 'vba.ps1') project-root @(Get-TestPropagationArguments) 2>&1)
        $cliExitCode = $LASTEXITCODE
        $cliOutput = $cliOutputLines -join [Environment]::NewLine
        if ($cliExitCode -ne 0 -or $cliOutput.IndexOf($externalRoot,[System.StringComparison]::OrdinalIgnoreCase) -lt 0 -or $cliOutput.IndexOf('UserSettings',[System.StringComparison]::OrdinalIgnoreCase) -lt 0) {
            throw "project-rootコマンドが現在値と設定元を表示しません。ExitCode=$cliExitCode Output=$cliOutput"
        }
        Write-Host '  [OK] 外部ルート作成、UTF-8 BOMなし設定、保存後再読込、CLI/JSON出力'

        $corruptText = '{ "schemaVersion": '
        [System.IO.File]::WriteAllText($settingsPath,$corruptText,(New-Object System.Text.UTF8Encoding($false)))
        $fallbackInfo = Get-ProjectRootInfo
        if ($fallbackInfo.Source -ne 'DefaultFallback' -or -not [string]::Equals($fallbackInfo.Path,(Get-DefaultProjectRoot),[System.StringComparison]::OrdinalIgnoreCase)) {
            throw '破損設定時に安全な既定値へフォールバックしません。'
        }
        if (-not (Test-Path -LiteralPath $settingsPath -PathType Leaf) -or [System.IO.File]::ReadAllText($settingsPath) -ne $corruptText) {
            throw '破損設定ファイルが削除または変更されました。'
        }
        if ([string]::IsNullOrWhiteSpace([string]$fallbackInfo.Warning)) { throw '破損設定の警告情報がありません。' }
        Write-Host '  [OK] 設定破損: ファイルを残し、警告付きで既定Developmentへフォールバック'

        Invoke-ProjectRootSet -Arguments @('-Path',$externalRoot)
        New-Item -ItemType Directory -Path $overrideRoot -Force | Out-Null
        $script:ProjectRootOverride = $overrideRoot
        $overrideInfo = Get-ProjectRootInfo
        if ($overrideInfo.Source -ne 'CliArgument' -or -not [string]::Equals($overrideInfo.Path,$overrideRoot,[System.StringComparison]::OrdinalIgnoreCase)) {
            throw '-ProjectRootがユーザー設定より優先されません。'
        }
        $script:ProjectRootOverride = $null
        Write-Host '  [OK] 優先順位: -ProjectRoot > ユーザー設定 > 既定値'

        $workbookPath = Join-Path $tempRoot 'ExternalRegistration.xlsm'
        [System.IO.File]::WriteAllBytes($workbookPath,[System.Text.Encoding]::UTF8.GetBytes('external project root registration placeholder'))
        $expectedProjectDir = Join-Path $externalRoot $testProject
        New-Item -ItemType Directory -Path $expectedProjectDir -Force | Out-Null
        $discovery = { param($targetPath) [PSCustomObject]@{ type='standard'; name='modExternalRootTest'; file='standard/modExternalRootTest.bas' } }
        $pull = {
            param($projectName)
            $sourceDir = Join-Path (Resolve-ProjectPath -Project $projectName) 'source\standard'
            New-Item -ItemType Directory -Path $sourceDir -Force | Out-Null
            [System.IO.File]::WriteAllText((Join-Path $sourceDir 'modExternalRootTest.bas'),"Attribute VB_Name = `"modExternalRootTest`"`r`nOption Explicit`r`n",(New-Object System.Text.UTF8Encoding($false)))
        }
        $created = Invoke-ProjectCreateCore -ProjectFolder $expectedProjectDir -WorkbookPath $workbookPath -ComponentDiscovery $discovery -ProjectPullInvoker $pull
        [void](Add-OrUpdateRegisteredProject -ProjectFolder $created.ProjectDirectory -Name $created.Project)
        if (-not [string]::Equals($created.ProjectDirectory,$expectedProjectDir,[System.StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $created.ManifestPath -PathType Leaf)) {
            throw 'project-createが外部ルートにプロジェクトを作成しません。'
        }
        $context = Read-ProjectManifest -Project $testProject
        if (-not [string]::Equals($context.ProjectDir,$expectedProjectDir,[System.StringComparison]::OrdinalIgnoreCase)) {
            throw 'プロジェクト名から外部ルート上のproject.jsonを解決できません。'
        }
        $registeredNames = Get-RegisteredProjectNames
        if (-not $registeredNames.Contains($testProject)) { throw '外部ルートのプロジェクトを列挙できません。' }
        if (-not [string]::Equals((Get-ProjectDirectory -Project $expectedProjectDir),$expectedProjectDir,[System.StringComparison]::OrdinalIgnoreCase)) {
            throw '絶対パス指定との互換性を維持できません。'
        }

        $scriptText = [System.IO.File]::ReadAllText((Join-Path $script:Root 'vba.ps1'),[System.Text.Encoding]::UTF8)
        foreach ($functionName in @('Invoke-ProjectPull','Invoke-ProjectPush','Invoke-ProjectSync','Invoke-ProjectDiff','Invoke-ProjectRollback','Invoke-ProjectIntegrity')) {
            $pattern = 'function\s+' + [System.Text.RegularExpressions.Regex]::Escape($functionName) + '\b(?<Body>[\s\S]*?)(?=\r?\nfunction\s+|\z)'
            $match = [System.Text.RegularExpressions.Regex]::Match($scriptText,$pattern,[System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
            if (-not $match.Success -or $match.Groups['Body'].Value -notmatch 'Read-ProjectManifest') {
                throw "共通プロジェクト解決を使用していないCLI経路があります: $functionName"
            }
        }
        Write-Host '  [OK] 作成・列挙・manifest・pull/push/sync/diff/rollback/integrityの共通ルート解決'

        $guiPath = Join-Path $script:Root 'gui.ps1'
        & powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File $guiPath -ProjectRootSelfTest @(Get-TestPropagationArguments)
        if ($LASTEXITCODE -ne 0) { throw "GUI External Project Root回帰テストに失敗しました。ExitCode=$LASTEXITCODE" }
        Write-Host '  [OK] GUI保存先表示、変更/既定ボタン、外部プロジェクト一覧、CLI接続'

        Invoke-ProjectRootReset
        $resetInfo = Get-ProjectRootInfo
        if ($resetInfo.Source -ne 'UserSettings' -or -not [string]::Equals($resetInfo.Path,(Get-DefaultProjectRoot),[System.StringComparison]::OrdinalIgnoreCase)) {
            throw 'project-root-reset後に既定Developmentへ戻りません。'
        }
        if (-not (Test-Path -LiteralPath $expectedProjectDir -PathType Container)) { throw '設定リセット時に外部プロジェクトが削除されました。' }
        if (-not [string]::IsNullOrWhiteSpace($internalHashBefore)) {
            if (-not (Test-Path -LiteralPath $internalManifest -PathType Leaf) -or (Get-FileSha256ForTest -Path $internalManifest) -ne $internalHashBefore) {
                throw '従来の内部プロジェクトが変更または削除されました。'
            }
        }
        Write-Host '  [OK] 既定復帰時も既存プロジェクトを自動移動・削除しません'

        foreach ($path in @((Join-Path $script:Root 'vba.ps1'),(Join-Path $script:Root 'gui.ps1'))) {
            $fileBytes = [System.IO.File]::ReadAllBytes($path)
            if ($fileBytes.Length -lt 3 -or $fileBytes[0] -ne 0xEF -or $fileBytes[1] -ne 0xBB -or $fileBytes[2] -ne 0xBF) { throw "UTF-8 BOMが維持されていません: $path" }
            $tokens=$null; $parseErrors=$null
            [void][System.Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$parseErrors)
            if (@($parseErrors).Count -gt 0) { throw "PowerShell構文解析に失敗しました: $path" }
        }
        Write-Success 'External Project Root回帰テストに成功しました。'
    }
    finally {
        $script:ProjectRootOverride = $oldProjectRootOverride
        $script:DefaultProjectRootTestOverride = $oldDefaultRootTestOverride
        [Environment]::SetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable,$oldSettingsOverride,'Process')
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-ProjectRootMigrationTest {
    $tempRoot = Join-Path (Get-TestTempBase) ('VBAUpdaterProjectRootMigration_' + [guid]::NewGuid().ToString('N'))
    $settingsPath = Join-Path $tempRoot 'user-settings\settings.json'
    $missingRoot = Join-Path $tempRoot 'lost-project-root'
    $candidateRoot = Join-Path $tempRoot 'candidate-project-root'
    $emptyRoot = Join-Path $tempRoot 'empty-project-root'
    $oldSettingsOverride = [Environment]::GetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable,'Process')
    $oldProjectRootOverride = $script:ProjectRootOverride
    $oldDefaultRootTestOverride = $script:DefaultProjectRootTestOverride

    try {
        Write-Info 'Project Root Migration回帰テストを実行しています...'
        New-Item -ItemType Directory -Path $tempRoot,$candidateRoot,$emptyRoot -Force | Out-Null
        $script:DefaultProjectRootTestOverride = Join-Path $tempRoot 'internal-project-root'
        New-Item -ItemType Directory -Path (Get-DefaultProjectRoot) -Force | Out-Null
        [Environment]::SetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable,$settingsPath,'Process')
        $script:ProjectRootOverride = $null

        [void](Write-ProjectRootSettings -ProjectRoot $missingRoot)
        $missingInfo = Get-ProjectRootInfo
        if ($missingInfo.Exists -or -not [string]::Equals($missingInfo.Path,$missingRoot,[System.StringComparison]::OrdinalIgnoreCase)) {
            throw '存在しない設定済みプロジェクトルートを喪失状態として保持できません。'
        }
        $missingCheck = Get-ProjectRootCheckResult
        if ($missingCheck.Status -ne 'Missing' -or $missingCheck.Projects -ne 0) { throw '保存先喪失をMissingとして判定できません。' }
        Write-Host '  [OK] 設定済み保存先の喪失を検出'

        $cliScript = Join-Path $script:Root 'vba.ps1'
        $missingOutputLines = @(& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $cliScript project-root-check 2>&1)
        $missingExit = $LASTEXITCODE
        $missingOutput = $missingOutputLines -join [Environment]::NewLine
        if ($missingExit -ne 0 -or $missingOutput.IndexOf('Missing',[System.StringComparison]::Ordinal) -lt 0 -or $missingOutput.IndexOf($missingRoot,[System.StringComparison]::OrdinalIgnoreCase) -lt 0) {
            throw "project-root-checkがMissingを表示しません。ExitCode=$missingExit Output=$missingOutput"
        }
        Write-Host '  [OK] CLI project-root-check: Status=Missing'

        $guiPath = Join-Path $script:Root 'gui.ps1'
        & powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File $guiPath -ProjectRootMigrationSelfTest -ExpectedMigrationStatus Missing -ExpectedMigrationProjects 0 @(Get-TestPropagationArguments)
        if ($LASTEXITCODE -ne 0) { throw "GUI保存先喪失テストに失敗しました。ExitCode=$LASTEXITCODE" }
        Write-Host '  [OK] GUI保存先喪失表示、復旧案内、古い選択状態のクリア'

        foreach ($projectName in @('PropertyManagement','JournalConverter')) {
            $projectDir = Join-Path $candidateRoot $projectName
            New-Item -ItemType Directory -Path (Join-Path $projectDir 'source'),(Join-Path $projectDir 'target') -Force | Out-Null
            $manifest = [PSCustomObject]@{
                schemaVersion='1.0'; projectName=$projectName
                target=[PSCustomObject]@{ directory='target'; file='MigrationTest.xlsm'; autoDetectWhenMissing=$true }
                source=[PSCustomObject]@{ root='source'; encoding='utf-8' }
                components=@()
            }
            [System.IO.File]::WriteAllText((Join-Path $projectDir 'project.json'),($manifest|ConvertTo-Json -Depth 6),(New-Object System.Text.UTF8Encoding($false)))
            [System.IO.File]::WriteAllText((Join-Path $projectDir 'target\MigrationTest.xlsm'),'migration candidate')
        }
        $incompleteDir = Join-Path $candidateRoot 'ZZZ_IncompleteProject'
        New-Item -ItemType Directory -Path (Join-Path $incompleteDir 'source') -Force | Out-Null
        [System.IO.File]::WriteAllText((Join-Path $incompleteDir 'project.json'),'{}',(New-Object System.Text.UTF8Encoding($false)))

        $candidateCheck = Get-ProjectRootCheckResult -Path $candidateRoot
        if ($candidateCheck.Status -ne 'OK' -or $candidateCheck.Projects -ne 2) {
            throw "候補プロジェクト件数が一致しません。Status=$($candidateCheck.Status) Projects=$($candidateCheck.Projects)"
        }
        foreach ($name in @('PropertyManagement','JournalConverter')) {
            if (@($candidateCheck.ProjectNames) -notcontains $name) { throw "候補プロジェクトを検出できません: $name" }
        }
        if (@($candidateCheck.ProjectNames) -contains 'ZZZ_IncompleteProject') { throw 'source/targetが不足するフォルダーを候補として検出しました。' }
        $emptyCheck = Get-ProjectRootCheckResult -Path $emptyRoot
        if ($emptyCheck.Status -ne 'OK' -or $emptyCheck.Projects -ne 0) { throw 'プロジェクト0件のフォルダーをProject Rootとして許可できません。' }
        Write-Host '  [OK] project.json/source/targetを持つ候補2件を検出し、不完全候補を除外'
        Write-Host '  [OK] プロジェクト0件の保存先を許可'

        $propertyManifest = Join-Path $candidateRoot 'PropertyManagement\project.json'
        $propertyHashBefore = Get-FileSha256ForTest -Path $propertyManifest
        Invoke-ProjectRootSet -Arguments @('-Path',$candidateRoot)
        $configuredCheck = Get-ProjectRootCheckResult
        if ($configuredCheck.Status -ne 'OK' -or $configuredCheck.Projects -ne 2 -or -not [string]::Equals($configuredCheck.Path,$candidateRoot,[System.StringComparison]::OrdinalIgnoreCase)) {
            throw '保存先変更後の再確認結果が一致しません。'
        }
        $settings = Get-Content -LiteralPath $settingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ([string]$settings.schemaVersion -ne '1.0' -or -not [string]::Equals([string]$settings.projectRoot,$candidateRoot,[System.StringComparison]::OrdinalIgnoreCase)) {
            throw '既存settings.json形式との互換性を維持できません。'
        }
        if ((Get-FileSha256ForTest -Path $propertyManifest) -ne $propertyHashBefore) { throw '保存先変更時に候補プロジェクトが変更されました。' }
        Write-Host '  [OK] 保存先変更、設定再読込、schemaVersion 1.0互換、自動移動なし'

        $jsonOutputLines = @(& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $cliScript project-root-check -Json 2>&1)
        $jsonExit = $LASTEXITCODE
        if ($jsonExit -ne 0) { throw "project-root-check -Jsonに失敗しました。ExitCode=$jsonExit" }
        $jsonResult = ($jsonOutputLines -join [Environment]::NewLine) | ConvertFrom-Json
        if ($jsonResult.Status -ne 'OK' -or [int]$jsonResult.Projects -ne 2) { throw 'project-root-check -Jsonの結果が一致しません。' }
        Write-Host '  [OK] CLI project-root-check: Status=OK / Projects=2'

        & powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File $guiPath -ProjectRootMigrationSelfTest -ExpectedMigrationStatus OK -ExpectedMigrationProjects 2 @(Get-TestPropagationArguments)
        if ($LASTEXITCODE -ne 0) { throw "GUI保存先変更後テストに失敗しました。ExitCode=$LASTEXITCODE" }
        Write-Host '  [OK] GUI状態表示、候補確認、保存先変更後の一覧即時更新'

        Invoke-ProjectRootReset
        $resetCheck = Get-ProjectRootCheckResult
        if ($resetCheck.Status -ne 'OK' -or -not [string]::Equals($resetCheck.Path,(Get-DefaultProjectRoot),[System.StringComparison]::OrdinalIgnoreCase)) {
            throw '既定復帰後に既定Project Rootを認識できません。'
        }
        if (-not (Test-Path -LiteralPath $candidateRoot -PathType Container) -or -not (Test-Path -LiteralPath $propertyManifest -PathType Leaf)) {
            throw '既定復帰時に外部候補プロジェクトが削除されました。'
        }
        Write-Host '  [OK] 既定復帰後も外部プロジェクトを削除しない'

        foreach ($path in @((Join-Path $script:Root 'vba.ps1'),(Join-Path $script:Root 'gui.ps1'))) {
            $bytes = [System.IO.File]::ReadAllBytes($path)
            if ($bytes.Length -lt 3 -or $bytes[0] -ne 0xEF -or $bytes[1] -ne 0xBB -or $bytes[2] -ne 0xBF) { throw "UTF-8 BOMが維持されていません: $path" }
            $tokens=$null; $parseErrors=$null
            [void][System.Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$parseErrors)
            if (@($parseErrors).Count -gt 0) { throw "PowerShell構文解析に失敗しました: $path" }
        }
        Write-Success 'Project Root Migration回帰テストに成功しました。'
    }
    finally {
        $script:ProjectRootOverride = $oldProjectRootOverride
        $script:DefaultProjectRootTestOverride = $oldDefaultRootTestOverride
        [Environment]::SetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable,$oldSettingsOverride,'Process')
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-ManifestTest {
    $sourceRoot = Join-Path $script:Root 'tests\manifest'
    $root = $sourceRoot
    if ($null -ne $script:TestExecutionContext) {
        $root = Join-Path $script:TestExecutionContext.Root 'fixtures\manifest'
        New-Item -ItemType Directory -Path (Split-Path -Parent $root) -Force | Out-Null
        Copy-Item -LiteralPath $sourceRoot -Destination $root -Recurse -Force
        foreach ($book in @(Get-ChildItem -LiteralPath $root -File -Recurse -Include *.xlsm,*.xlam,*.xlsb -ErrorAction SilentlyContinue)) {
            $book.CreationTimeUtc = [DateTime]::UtcNow
        }
    }
    $expectationsPath = Join-Path $root 'expectations.json'

    if (-not (Test-Path -LiteralPath $expectationsPath -PathType Leaf)) {
        throw "Manifestテスト期待値ファイルが見つかりません: $expectationsPath"
    }

    try {
        $expectations = Get-Content -LiteralPath $expectationsPath -Raw -Encoding UTF8 | ConvertFrom-Json
    }
    catch {
        throw "Manifestテスト期待値ファイルを読み込めません: $($_.Exception.Message)"
    }

    Write-Info 'Manifestファイル回帰テストを実行しています...'

    $passed = 0
    foreach ($case in @($expectations.cases)) {
        $caseName = [string]$case.name
        $caseDir = Join-Path $root $caseName
        if (-not $case.PSObject.Properties['name']) {
            throw "Manifestテスト期待値にnameがありません。"
        }
        if (-not $case.PSObject.Properties['expectedSuccess']) {
            throw "Manifestテスト期待値にexpectedSuccessがありません。Case=$caseName"
        }

        $expectedSuccess = [bool]$case.expectedSuccess
        $expectedError = if ($case.PSObject.Properties['expectedErrorContains']) {
            [string]$case.expectedErrorContains
        }
        else {
            ''
        }
        $action = if ($case.PSObject.Properties['action']) { [string]$case.action } else { 'validate' }

        if (-not (Test-Path -LiteralPath $caseDir -PathType Container)) {
            throw "Manifestテストケースフォルダが見つかりません: $caseDir"
        }

        $actualSuccess = $false
        $actualError = ''
        try {
            $context = Read-ProjectManifest -Project $caseDir
            [void](Test-ProjectManifest -Context $context)
            if ($action -eq 'resolve-target') {
                [void](Resolve-ManifestTarget -Context $context)
            }
            elseif ($action -ne 'validate') {
                throw "Manifestテストのactionが不正です: $action"
            }
            $actualSuccess = $true
        }
        catch {
            $actualError = $_.Exception.Message
        }

        if ($actualSuccess -ne $expectedSuccess) {
            throw "Manifestテスト結果が一致しません。Case=$caseName / ExpectedSuccess=$expectedSuccess / ActualSuccess=$actualSuccess / Error=$actualError"
        }

        if (-not $expectedSuccess -and -not [string]::IsNullOrWhiteSpace($expectedError)) {
            if ($actualError -notlike "*$expectedError*") {
                throw "Manifestテストのエラー理由が一致しません。Case=$caseName / ExpectedContains=$expectedError / Actual=$actualError"
            }
        }

        Write-Host "  [OK] $caseName"
        $passed++
    }

    Write-Success "Manifestファイル回帰テストに成功しました。件数: $passed"
}


function Import-CodeNormalizer {
    if (-not (Test-Path -LiteralPath $script:NormalizerModulePath -PathType Leaf)) {
        throw "正規化モジュールが見つかりません: $script:NormalizerModulePath"
    }
    Import-Module -Name $script:NormalizerModulePath -Force -Global -DisableNameChecking -ErrorAction Stop
}



$script:ComDiagnosticLogPath = $null

function Get-ComDiagnosticTypeName {
    param($Object)
    if ($null -eq $Object) { return '<null>' }
    try {
        if ([System.Runtime.InteropServices.Marshal]::IsComObject($Object)) {
            return ('COM:' + $Object.GetType().FullName)
        }
        return $Object.GetType().FullName
    }
    catch { return '<type unavailable>' }
}

function Format-ComDiagnosticArguments {
    param([object[]]$Arguments = @())
    if ($null -eq $Arguments -or $Arguments.Count -eq 0) { return '<none>' }
    $parts = @()
    for ($i = 0; $i -lt $Arguments.Count; $i++) {
        $arg = $Arguments[$i]
        if ($null -eq $arg) {
            $parts += ("[{0}]=<null> (<null>)" -f $i)
        }
        else {
            $value = try { [string]$arg } catch { '<string conversion failed>' }
            $typeName = try { $arg.GetType().FullName } catch { '<type unavailable>' }
            $parts += ("[{0}]={1} ({2})" -f $i, $value, $typeName)
        }
    }
    return ($parts -join '; ')
}

function Write-ComDiagnosticLine {
    param([Parameter(Mandatory=$true)][string]$Message)
    $line = ('[{0}] {1}' -f [DateTime]::Now.ToString('yyyy-MM-dd HH:mm:ss.fff'), $Message)
    Write-Host $line
    if (-not [string]::IsNullOrWhiteSpace($script:ComDiagnosticLogPath)) {
        [System.IO.File]::AppendAllText($script:ComDiagnosticLogPath, $line + [Environment]::NewLine, (New-Object System.Text.UTF8Encoding($false)))
    }
}

function Format-HResultHex {
    param([System.Exception]$Exception)

    if ($null -eq $Exception) {
        return '<null>'
    }

    try {
        [int]$signedValue = $Exception.HResult
        $bytes = [System.BitConverter]::GetBytes($signedValue)
        [uint32]$unsignedValue = [System.BitConverter]::ToUInt32($bytes, 0)
        return ('0x{0:X8}' -f $unsignedValue)
    }
    catch {
        return ('<format-error:{0}>' -f $_.Exception.Message)
    }
}

function Invoke-ComDiagnosticOperation {
    param(
        [Parameter(Mandatory=$true)][string]$Step,
        [Parameter(Mandatory=$true)][string]$Operation,
        $Object,
        [string]$Member = '',
        [object[]]$Arguments = @(),
        [scriptblock]$Action
    )

    $objectType = Get-ComDiagnosticTypeName -Object $Object
    $argumentText = Format-ComDiagnosticArguments -Arguments $Arguments
    Write-ComDiagnosticLine ("{0} START Operation={1} Member={2} ObjectType={3} Arguments={4}" -f $Step,$Operation,$Member,$objectType,$argumentText)
    try {
        if ($null -eq $Object) {
            throw "COM呼び出し対象がnullです。Operation=$Operation Member=$Member"
        }

        # COMコレクションをPowerShellの出力パイプラインへ流すと、
        # 空コレクションは$null、複数要素はObject[]へ変換される。
        # 診断処理ではScriptBlockを実行せず、InvokeMemberでCOM戻り値を
        # 単一オブジェクトのまま取得する。
        switch ($Operation) {
            'PropertyGet' {
                $value = $Object.GetType().InvokeMember(
                    $Member,
                    [System.Reflection.BindingFlags]::GetProperty,
                    $null,
                    $Object,
                    $Arguments)
                break
            }
            'MethodCall' {
                $value = $Object.GetType().InvokeMember(
                    $Member,
                    [System.Reflection.BindingFlags]::InvokeMethod,
                    $null,
                    $Object,
                    $Arguments)
                break
            }
            default {
                throw "未対応の診断操作です。Operation=$Operation Member=$Member"
            }
        }

        Write-ComDiagnosticLine ("{0} OK Operation={1} Member={2} ResultType={3}" -f $Step,$Operation,$Member,(Get-ComDiagnosticTypeName -Object $value))
        Write-Output -NoEnumerate $value
    }
    catch {
        $ex = $_.Exception
        $hresult = Format-HResultHex -Exception $ex
        Write-ComDiagnosticLine ("{0} ERROR Operation={1} Member={2} ObjectType={3} Arguments={4} ExceptionType={5} HRESULT={6} Message={7}" -f $Step,$Operation,$Member,$objectType,$argumentText,$ex.GetType().FullName,$hresult,$ex.Message)
        throw
    }
}

function Get-ComProperty {
    param(
        $Object,
        [Parameter(Mandatory=$true)][string]$Name,
        [object[]]$Arguments = @()
    )
    if ($null -eq $Object) {
        throw "COMプロパティ取得対象がnullです。Property=$Name"
    }
    $value = $Object.GetType().InvokeMember(
        $Name,
        [System.Reflection.BindingFlags]::GetProperty,
        $null,
        $Object,
        $Arguments)

    # PowerShellはCOMコレクションを関数の出力パイプラインへ列挙し、
    # VBComponents等をSystem.Object[]へ変換する場合がある。
    # -NoEnumerateでCOMオブジェクトをそのまま呼出元へ返す。
    Write-Output -NoEnumerate $value
}

function Invoke-ComMethod {
    param(
        $Object,
        [Parameter(Mandatory=$true)][string]$Name,
        [object[]]$Arguments = @()
    )
    if ($null -eq $Object) {
        throw "COMメソッド呼出対象がnullです。Method=$Name"
    }
    $value = $Object.GetType().InvokeMember(
        $Name,
        [System.Reflection.BindingFlags]::InvokeMethod,
        $null,
        $Object,
        $Arguments)
    Write-Output -NoEnumerate $value
}

function Open-WorkbookReadOnlySafe {
    param(
        [Parameter(Mandatory=$true)]$Excel,
        [Parameter(Mandatory=$true)][string]$Path
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "差分判定対象ブックが見つかりません: $Path"
    }
    Invoke-TestWorkbookOpenAudit -Path $Path

    $workbooks = $null
    $workbook = $null
    try {
        $workbooks = Invoke-ComDiagnosticOperation -Step 'D01A' -Operation 'PropertyGet' -Object $Excel -Member 'Workbooks' -Action { param($target, $callArgs) $target.Workbooks }
        if ($null -eq $workbooks) { throw 'Excel.Workbooksを取得できませんでした。' }

        $openArgs = [object[]]@([string]$Path, [int]0, [bool]$true)
        $workbook = Invoke-ComDiagnosticOperation -Step 'D01B' -Operation 'MethodCall' -Object $workbooks -Member 'Open' -Arguments $openArgs -Action { param($target, $callArgs) $target.Open([string]$callArgs[0], [int]$callArgs[1], [bool]$callArgs[2]) }
        if ($null -eq $workbook) { throw "Excel.Workbooks.OpenがWorkbookを返しませんでした: $Path" }

        Write-Output -NoEnumerate $workbook
        $workbook = $null
    }
    finally {
        Release-ComObject $workbook
        Release-ComObject $workbooks
    }
}

function Find-VbComponentSafe {
    param(
        [Parameter(Mandatory=$true)]$VbProject,
        [Parameter(Mandatory=$true)][string]$ComponentName
    )

    $components = $null
    try {
        $components = Invoke-ComDiagnosticOperation -Step 'D03' -Operation 'PropertyGet' -Object $VbProject -Member 'VBComponents' -Action { param($target, $callArgs) $target.VBComponents }
        if ($null -eq $components) { throw 'VBProject.VBComponentsを取得できませんでした。' }

        $count = Invoke-ComDiagnosticOperation -Step 'D03C' -Operation 'PropertyGet' -Object $components -Member 'Count' -Action { param($target, $callArgs) [int]$target.Count }
        for ($index = 1; $index -le [int]$count; $index++) {
            $candidate = $null
            try {
                $itemArgs = [object[]]@([int]$index)
                $candidate = Invoke-ComDiagnosticOperation -Step 'D04' -Operation 'MethodCall' -Object $components -Member 'Item' -Arguments $itemArgs -Action { param($target, $callArgs) $target.Item([int]$callArgs[0]) }
                if ($null -eq $candidate) { continue }

                $name = Invoke-ComDiagnosticOperation -Step 'D04N' -Operation 'PropertyGet' -Object $candidate -Member 'Name' -Action { param($target, $callArgs) [string]$target.Name }
                if ([string]::Equals([string]$name, $ComponentName, [System.StringComparison]::OrdinalIgnoreCase)) {
                    Write-Output -NoEnumerate $candidate
                    $candidate = $null
                    return
                }
            }
            finally { Release-ComObject $candidate }
        }
        return $null
    }
    finally { Release-ComObject $components }
}

function Get-CodeModuleTextSafe {
    param([Parameter(Mandatory=$true)]$Component)

    $codeModule = $null
    $componentName = '<unknown>'
    try {
        try { $componentName = [string](Get-ComProperty -Object $Component -Name 'Name') } catch { Write-Verbose ('VBA Component名を取得できませんでした: ' + $_.Exception.Message) }
        $codeModule = Invoke-ComDiagnosticOperation -Step 'D05' -Operation 'PropertyGet' -Object $Component -Member 'CodeModule' -Action { param($target, $callArgs) $target.CodeModule }
        if ($null -eq $codeModule) { throw 'CodeModuleを取得できませんでした。' }

        $count = Invoke-ComDiagnosticOperation -Step 'D06' -Operation 'PropertyGet' -Object $codeModule -Member 'CountOfLines' -Action { param($target, $callArgs) [int]$target.CountOfLines }
        Write-ComDiagnosticLine ("D06V Component={0} CountOfLines={1}" -f $componentName,[int]$count)

        if ([int]$count -gt 0) {
            $lineArgs = [object[]]@([int]1, [int]$count)
            Write-ComDiagnosticLine ("D07 Lines取得開始 Invocation=ParameterizedProperty Component={0} Arguments={1}" -f $componentName,(Format-ComDiagnosticArguments -Arguments $lineArgs))
            $text = Invoke-ComDiagnosticOperation -Step 'D08' -Operation 'PropertyGet' -Object $codeModule -Member 'Lines' -Arguments $lineArgs -Action { param($target, $callArgs) [string]$target.Lines([int]$callArgs[0], [int]$callArgs[1]) }
            if (-not [string]::IsNullOrEmpty([string]$text)) { return [string]$text }
            Write-ComDiagnosticLine ("D08F Component={0} Reason=LinesReturnedEmpty ExportFallback=True" -f $componentName)
        }
        else {
            Write-ComDiagnosticLine ("D06F Component={0} Reason=CountOfLinesZero ExportFallback=True" -f $componentName)
        }

        # 一部のExcel/VBIDE環境ではCountOfLinesまたはLinesが空を返す場合がある。
        # その場合はVBComponent.Exportで一時ファイルへ書き出し、実体を読み取る。
        $componentType = 1
        try { $componentType = [int](Get-ComProperty -Object $Component -Name 'Type') } catch { Write-Verbose ('VBA Component typeを取得できませんでした: ' + $_.Exception.Message) }
        $extension = switch ($componentType) { 1 { '.bas' } 2 { '.cls' } 3 { '.frm' } 100 { '.cls' } default { '.txt' } }
        $tempPath = Join-Path ([System.IO.Path]::GetTempPath()) ('VBAUpdaterCodeRead_' + [guid]::NewGuid().ToString('N') + $extension)
        try {
            Export-VbComponentSafe -Component $Component -Path $tempPath
            if (-not (Test-Path -LiteralPath $tempPath -PathType Leaf)) { return '' }
            $fallbackText = [System.IO.File]::ReadAllText($tempPath, [System.Text.Encoding]::Default)
            Write-ComDiagnosticLine ("D08X Component={0} ExportFallbackLength={1}" -f $componentName,$fallbackText.Length)
            return [string]$fallbackText
        }
        finally {
            Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue
            $frxPath = [System.IO.Path]::ChangeExtension($tempPath,'.frx')
            Remove-Item -LiteralPath $frxPath -Force -ErrorAction SilentlyContinue
        }
    }
    finally { Release-ComObject $codeModule }
}


function Get-ProjectRestorePointDirectory {
    param([Parameter(Mandatory=$true)]$Context)
    return Join-Path (Get-RuntimeBackupDirectory -Child 'restore_points') ([string]$Context.Manifest.projectName)
}

function New-ProjectRestorePoint {
    param(
        [Parameter(Mandatory=$true)]$Context,
        [Parameter(Mandatory=$true)][string]$TargetPath,
        [Parameter(Mandatory=$true)][string]$Operation
    )
    if(-not(Test-Path -LiteralPath $TargetPath -PathType Leaf)){throw "復元ポイントの対象ブックが見つかりません: $TargetPath"}
    $dir=Get-ProjectRestorePointDirectory -Context $Context
    New-Item -ItemType Directory -Path $dir -Force|Out-Null
    $id=[DateTime]::Now.ToString('yyyyMMdd_HHmmss_fff')
    $fileName=([System.IO.Path]::GetFileNameWithoutExtension($TargetPath))+'_'+$id+[System.IO.Path]::GetExtension($TargetPath)
    $backupPath=Join-Path $dir $fileName
    Copy-Item -LiteralPath $TargetPath -Destination $backupPath -Force
    $hash=(Get-FileHash -LiteralPath $backupPath -Algorithm SHA256).Hash
    $metaPath=Join-Path $dir ($id+'.json')
    $meta=[PSCustomObject]@{
        schemaVersion='1.0'; id=$id; toolVersion=$script:ToolVersion
        project=[string]$Context.Manifest.projectName; operation=$Operation
        createdAt=[DateTime]::Now.ToString('o'); targetPath=$TargetPath
        backupPath=$backupPath; sha256=$hash; sizeBytes=(Get-Item -LiteralPath $backupPath).Length
    }
    [System.IO.File]::WriteAllText($metaPath,($meta|ConvertTo-Json -Depth 5),(New-Object System.Text.UTF8Encoding($false)))
    return $meta
}

function Get-ProjectRestorePoints {
    param([Parameter(Mandatory=$true)]$Context)
    [object[]]$items=@()
    $dir=Get-ProjectRestorePointDirectory -Context $Context
    if(-not(Test-Path -LiteralPath $dir -PathType Container)){return $items}
    foreach($file in @(Get-ChildItem -LiteralPath $dir -Filter '*.json' -File -ErrorAction SilentlyContinue|Sort-Object Name -Descending)){
        try{
            $item=Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8|ConvertFrom-Json
            if($item.PSObject.Properties['backupPath'] -and (Test-Path -LiteralPath ([string]$item.backupPath) -PathType Leaf)){$items += $item}
        }catch{Write-Warn ("復元ポイント情報を読み飛ばしました: {0}" -f $file.FullName)}
    }
    return $items
}

function Resolve-ProjectRestorePoint {
    param([Parameter(Mandatory=$true)]$Context,[AllowNull()][string]$RestorePoint)
    [object[]]$items=@(Get-ProjectRestorePoints -Context $Context)
    if($items.Count -eq 0){throw '利用可能な復元ポイントがありません。'}
    if([string]::IsNullOrWhiteSpace($RestorePoint) -or $RestorePoint -eq 'latest'){return $items[0]}
    $matched=@($items|Where-Object{[string]$_.id -eq $RestorePoint})
    if($matched.Count -eq 0){throw "指定した復元ポイントが見つかりません: $RestorePoint"}
    return $matched[0]
}

function Invoke-ProjectRollbackList {
    param([string[]]$Arguments)
    $project=Get-NamedArgument -Arguments $Arguments -Name '-Project'
    $ctx=Read-ProjectManifest -Project $project
    [object[]]$items=@(Get-ProjectRestorePoints -Context $ctx)
    Write-Host ''
    Write-Host '====================================='
    Write-Host 'VBA Project Restore Points'
    Write-Host '====================================='
    Write-Host ("Project       : {0}" -f $ctx.Manifest.projectName)
    Write-Host ("Count         : {0}" -f $items.Count)
    Write-Host '====================================='
    foreach($item in $items){
        $created=[DateTimeOffset]::Parse([string]$item.createdAt).LocalDateTime
        Write-Host ("{0}  {1,-14}  {2}" -f $created.ToString('yyyy-MM-dd HH:mm:ss'),[string]$item.operation,[string]$item.id)
        Write-Host ("  Backup: {0}" -f [string]$item.backupPath)
    }
    if($items.Count -eq 0){Write-Warn '復元ポイントはまだありません。project-pushまたはproject-syncの直前に自動作成されます。'}
}

function Invoke-ProjectRollback {
    param([string[]]$Arguments)
    $project=Get-NamedArgument -Arguments $Arguments -Name '-Project'
    $requested=Get-NamedArgument -Arguments $Arguments -Name '-RestorePoint'
    $apply=Test-ArgumentSwitch -Arguments $Arguments -Name '-Apply'
    $ctx=Read-ProjectManifest -Project $project
    [void](Test-ProjectManifest -Context $ctx)
    $target=Resolve-ManifestTarget -Context $ctx
    $point=Resolve-ProjectRestorePoint -Context $ctx -RestorePoint $requested
    $actualHash=(Get-FileHash -LiteralPath ([string]$point.backupPath) -Algorithm SHA256).Hash
    if($actualHash -ne [string]$point.sha256){throw "復元ポイントのハッシュが一致しません。ファイルが変更または破損しています: $($point.id)"}
    Write-Host ''
    Write-Host '====================================='
    Write-Host 'VBA Project Rollback'
    Write-Host '====================================='
    Write-Host ("Project       : {0}" -f $ctx.Manifest.projectName)
    Write-Host ("Restore Point : {0}" -f $point.id)
    Write-Host ("Created       : {0}" -f $point.createdAt)
    Write-Host ("Operation     : {0}" -f $point.operation)
    Write-Host ("Backup        : {0}" -f $point.backupPath)
    Write-Host ("Target        : {0}" -f $target)
    Write-Host ("Mode          : {0}" -f $(if($apply){'Apply'}else{'Preview'}))
    Write-Host '====================================='
    if(-not $apply){Write-Warn 'プレビューのみです。実際に復元する場合は -Apply を追加してください。';return}
    $safety=New-ProjectRestorePoint -Context $ctx -TargetPath $target -Operation 'pre-rollback'
    try{Copy-Item -LiteralPath ([string]$point.backupPath) -Destination $target -Force}
    catch{throw "復元に失敗しました。復元前の安全バックアップ: $($safety.id) / 詳細: $($_.Exception.Message)"}
    $restoredHash=(Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
    if($restoredHash -ne [string]$point.sha256){throw "復元後のハッシュ検証に失敗しました。復元前の安全バックアップ: $($safety.id)"}
    Write-Success ("復元しました。復元前の安全バックアップ: {0}" -f $safety.id)
}

function Invoke-RollbackTest {
    $root=Join-Path ([System.IO.Path]::GetTempPath()) ('VBAUpdaterRollbackTest_'+[guid]::NewGuid().ToString('N'))
    try{
        New-Item -ItemType Directory -Path $root -Force|Out-Null
        $target=Join-Path $root 'target.xlsm'; $backup=Join-Path $root 'backup.xlsm'
        [System.IO.File]::WriteAllText($target,'NEW');[System.IO.File]::WriteAllText($backup,'OLD')
        $expected=(Get-FileHash -LiteralPath $backup -Algorithm SHA256).Hash
        Copy-Item -LiteralPath $backup -Destination $target -Force
        $actual=(Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
        if($actual -ne $expected){throw 'ファイル置換後のハッシュが一致しません。'}
        Write-Success 'Rollback回帰テストに成功しました。'
    }finally{Remove-Item -LiteralPath $root -Recurse -Force -ErrorAction SilentlyContinue}
}

function Invoke-CodeReadTest {
    param([string[]]$Arguments)

    $project = Get-NamedArgument -Arguments $Arguments -Name '-Project'
    $ctx = Read-ProjectManifest -Project $project
    [void](Invoke-PrepareSourceForContext -Context $ctx -HookName 'prePush')
    [void](Test-ProjectManifest -Context $ctx)
    $target = Resolve-ManifestTarget -Context $ctx
    $excel=$null; $workbook=$null; $vbProject=$null
    try {
        Write-Info ("CodeModule読取テストを実行しています: {0}" -f [string]$ctx.Manifest.projectName)
        $excel = New-ExcelApplication
        $excel.AutomationSecurity = 3
        $workbook = Open-WorkbookReadOnlySafe -Excel $excel -Path $target
        $vbProject = Get-ComProperty -Object $workbook -Name 'VBProject'
        $tested = 0
        foreach($c in @($ctx.Manifest.components)) {
            $type = ([string]$c.type).ToLowerInvariant()
            if ($type -eq 'userform') { continue }
            $component=$null
            try {
                $component = Find-VbComponentSafe -VbProject $vbProject -ComponentName ([string]$c.name)
                if ($null -eq $component) {
                    Write-Warn ("  [SKIP] {0}: ブック内に存在しません。" -f [string]$c.name)
                    continue
                }
                $text = Get-CodeModuleTextSafe -Component $component
                $lineCount = if ([string]::IsNullOrEmpty([string]$text)) { 0 } else { ([string]$text -split "`r?`n").Count }
                if ([string]::IsNullOrEmpty([string]$text)) {
                    Write-Warn ("  [WARN] {0} ({1}) Lines=0 Length=0" -f [string]$c.name,$type)
                } else {
                    Write-Host ("  [OK] {0} ({1}) Lines={2} Length={3}" -f [string]$c.name,$type,$lineCount,([string]$text).Length)
                }
                $tested++
            }
            finally { Release-ComObject $component }
        }
        if ($tested -eq 0) { Write-Warn '読取対象の標準・クラス・Documentモジュールがありません。' }
        Write-Success 'CodeModule読取テストが完了しました。'
    }
    finally {
        Release-ComObject $vbProject
        Close-ExcelApplication -Excel $excel -Workbook $workbook
    }
}

function Export-VbComponentSafe {
    param(
        [Parameter(Mandatory=$true)]$Component,
        [Parameter(Mandatory=$true)][string]$Path
    )
    $args = [object[]]@([string]$Path)
    [void](Invoke-ComDiagnosticOperation -Step 'D09' -Operation 'MethodCall' -Object $Component -Member 'Export' -Arguments $args -Action { param($target, $callArgs) $target.Export([string]$callArgs[0]) })
}

function Get-ManifestComponentSourcePath {
    param($Context, $Component)
    return Resolve-ManifestPath -ProjectDir $Context.ProjectDir -PathValue (Join-Path ([string]$Context.Manifest.source.root) ([string]$Component.file))
}

function Get-ManifestUserFormBinaryPath {
    param($Context, $Component, [string]$SourcePath)
    if ($Component.PSObject.Properties['binaryFile'] -and -not [string]::IsNullOrWhiteSpace([string]$Component.binaryFile)) {
        return Resolve-ManifestPath -ProjectDir $Context.ProjectDir -PathValue (Join-Path ([string]$Context.Manifest.source.root) ([string]$Component.binaryFile))
    }
    return [System.IO.Path]::ChangeExtension($SourcePath, '.frx')
}

function Resolve-UserFormDiffResult {
    param(
        [Parameter(Mandatory=$true)][bool]$FrmSame,
        [Parameter(Mandatory=$true)][bool]$SourceFrxExists,
        [Parameter(Mandatory=$true)][bool]$ExportFrxExists,
        [Parameter(Mandatory=$true)][bool]$RawFrxSame
    )

    $effectiveFrxSame = $RawFrxSame
    $resultOverride = $false

    if (-not $SourceFrxExists -and -not $ExportFrxExists) {
        $effectiveFrxSame = $true
    }
    elseif ($SourceFrxExists -and $ExportFrxExists -and $FrmSame) {
        if (-not $RawFrxSame) { $resultOverride = $true }
        $effectiveFrxSame = $true
    }

    $status = if ($FrmSame -and $effectiveFrxSame) { 'unchanged' } else { 'changed' }
    $reasons = New-Object System.Collections.Generic.List[string]
    if (-not $FrmSame) { $reasons.Add('frm') }
    if (-not $effectiveFrxSame) { $reasons.Add('frx') }

    return [PSCustomObject]@{
        Status = $status
        EffectiveFrxSame = $effectiveFrxSame
        ResultOverride = $resultOverride
        Reason = if ($status -eq 'changed') { '差分: ' + ($reasons -join ',') } else { '' }
    }
}

function Write-ProjectDiffJson {
    param(
        [Parameter(Mandatory=$true)]$Context,
        [Parameter(Mandatory=$true)][string]$TargetPath,
        [Parameter(Mandatory=$true)][object[]]$Items
    )
    $logDir = Get-RuntimeLogDirectory
    New-Item -ItemType Directory -Path $logDir -Force | Out-Null
    $path = Join-Path $logDir ('project_diff_' + [DateTime]::Now.ToString('yyyyMMdd_HHmmss_fff') + '.json')
    $result = [PSCustomObject]@{
        schemaVersion = '1.0'
        project = [string]$Context.Manifest.projectName
        target = $TargetPath
        timestamp = [DateTime]::Now.ToString('o')
        summary = [PSCustomObject]@{
            components = @($Items).Count
            changed = @($Items | Where-Object { $_.status -eq 'changed' }).Count
            unchanged = @($Items | Where-Object { $_.status -eq 'unchanged' }).Count
            added = @($Items | Where-Object { $_.status -eq 'added' }).Count
            failed = @($Items | Where-Object { $_.status -eq 'failed' }).Count
        }
        components = @($Items)
    }
    [System.IO.File]::WriteAllText($path, ($result | ConvertTo-Json -Depth 8), (New-Object System.Text.UTF8Encoding($false)))
    return $path
}

function Get-ProjectDiff {
    param([Parameter(Mandatory=$true)]$Context, [Parameter(Mandatory=$true)][string]$TargetPath)

    Import-CodeNormalizer
    $excel=$null; $workbook=$null; $vbProject=$null
    $results = New-Object System.Collections.Generic.List[object]
    $tempRoot = Join-Path (Get-TestTempBase) ('VBAUpdaterDiff_' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null

    try {
        $logDir = Get-RuntimeLogDirectory
        New-Item -ItemType Directory -Path $logDir -Force | Out-Null
        $script:ComDiagnosticLogPath = Join-Path $logDir ('project_diff_diagnostic_' + [DateTime]::Now.ToString('yyyyMMdd_HHmmss_fff') + '.log')
        Write-ComDiagnosticLine ('Chapter5-5D Diagnostic開始 Target=' + $TargetPath)
        Write-Info '対象ブックを読み取り専用で開き、差分を判定しています...'
        $excel = New-ExcelApplication
        $excel.AutomationSecurity = 3
        $workbook = Open-WorkbookReadOnlySafe -Excel $excel -Path $TargetPath
        if ($null -eq $workbook) { throw '対象ブックを開けませんでした。' }
        Write-Host '  [OK] 対象ブックを読み取り専用で開きました。'
        $vbProject = Invoke-ComDiagnosticOperation -Step 'D02' -Operation 'PropertyGet' -Object $workbook -Member 'VBProject' -Action { param($target, $callArgs) $target.VBProject }
        if ($null -eq $vbProject) { throw 'VBProjectを取得できませんでした。Excelの「VBAプロジェクト オブジェクト モデルへのアクセスを信頼する」を確認してください。' }
        Write-Host '  [OK] VBProjectを取得しました。'

        foreach($c in @($Context.Manifest.components)) {
            $type=([string]$c.type).ToLowerInvariant()
            $name=[string]$c.name
            $sourcePath=Get-ManifestComponentSourcePath -Context $Context -Component $c
            $component=$null
            try {
                $component=Find-VbComponentSafe -VbProject $vbProject -ComponentName $name
                if ($null -eq $component) {
                    $results.Add([PSCustomObject]@{ name=$name; type=$type; status='added'; reason='ブック内にコンポーネントがありません'; sourcePath=$sourcePath })
                    continue
                }

                if ($type -eq 'userform') {
                    $exportFrm = Join-Path $tempRoot ($name + '.frm')
                    $exportFrx = Join-Path $tempRoot ($name + '.frx')
                    Export-VbComponentSafe -Component $component -Path $exportFrm

                    $sourceExists = Test-Path -LiteralPath $sourcePath -PathType Leaf
                    $exportExists = Test-Path -LiteralPath $exportFrm -PathType Leaf
                    Write-ComDiagnosticLine ("D10 FILECHECK Component={0} SourcePath={1} SourceExists={2} ExportPath={3} ExportExists={4}" -f $name,$sourcePath,$sourceExists,$exportFrm,$exportExists)

                    try {
                        Write-ComDiagnosticLine ("D11 START Operation=Get-NormalizedVbaFileContent Role=Source Path={0} PathType={1} ComponentType=userform" -f $sourcePath,$sourcePath.GetType().FullName)
                        $sourceText = Get-NormalizedVbaFileContent -Path $sourcePath -ComponentType 'userform'
                        $sourceResultType = if ($null -eq $sourceText) { '<null>' } else { $sourceText.GetType().FullName }
                        $sourceLength = if ($null -eq $sourceText) { 0 } else { ([string]$sourceText).Length }
                        Write-ComDiagnosticLine ("D11 OK ResultType={0} Length={1}" -f $sourceResultType,$sourceLength)
                    }
                    catch {
                        Write-ComDiagnosticLine ("D11 ERROR ExceptionType={0} HRESULT={1} Message={2} Position={3} Stack={4}" -f $_.Exception.GetType().FullName,(Format-HResultHex -Exception $_.Exception),$_.Exception.Message,$_.InvocationInfo.PositionMessage,$_.ScriptStackTrace)
                        throw
                    }

                    try {
                        Write-ComDiagnosticLine ("D12 START Operation=Get-NormalizedVbaFileContent Role=Export Path={0} PathType={1} ComponentType=userform" -f $exportFrm,$exportFrm.GetType().FullName)
                        $bookText = Get-NormalizedVbaFileContent -Path $exportFrm -ComponentType 'userform'
                        $bookResultType = if ($null -eq $bookText) { '<null>' } else { $bookText.GetType().FullName }
                        $bookLength = if ($null -eq $bookText) { 0 } else { ([string]$bookText).Length }
                        Write-ComDiagnosticLine ("D12 OK ResultType={0} Length={1}" -f $bookResultType,$bookLength)
                    }
                    catch {
                        Write-ComDiagnosticLine ("D12 ERROR ExceptionType={0} HRESULT={1} Message={2} Position={3} Stack={4}" -f $_.Exception.GetType().FullName,(Format-HResultHex -Exception $_.Exception),$_.Exception.Message,$_.InvocationInfo.PositionMessage,$_.ScriptStackTrace)
                        throw
                    }

                    try {
                        Write-ComDiagnosticLine ("D13 START Operation=SemanticCompare LeftType={0} LeftLength={1} RightType={2} RightLength={3}" -f $sourceResultType,$sourceLength,$bookResultType,$bookLength)
                        $frmDifference = Get-VbaSemanticDifference -Left ([string]$sourceText) -Right ([string]$bookText) -ComponentType 'userform'
                        $frmSame = [bool]$frmDifference.Same
                        Write-ComDiagnosticLine ("D13 OK Result={0} SemanticLeftLength={1} SemanticRightLength={2} FirstDifference={3}" -f $frmSame,$frmDifference.LeftLength,$frmDifference.RightLength,$frmDifference.Index)
                        if (-not $frmSame) {
                            Write-ComDiagnosticLine ("D13 DIFF LeftContext={0} RightContext={1}" -f ($frmDifference.LeftContext -replace "`r|`n",' '),($frmDifference.RightContext -replace "`r|`n",' '))
                        }
                    }
                    catch {
                        Write-ComDiagnosticLine ("D13 ERROR ExceptionType={0} HRESULT={1} Message={2} Position={3} Stack={4}" -f $_.Exception.GetType().FullName,(Format-HResultHex -Exception $_.Exception),$_.Exception.Message,$_.InvocationInfo.PositionMessage,$_.ScriptStackTrace)
                        throw
                    }

                    $sourceFrx = Get-ManifestUserFormBinaryPath -Context $Context -Component $c -SourcePath $sourcePath
                    $sourceFrxExists = Test-Path -LiteralPath $sourceFrx -PathType Leaf
                    $exportFrxExists = Test-Path -LiteralPath $exportFrx -PathType Leaf
                    Write-ComDiagnosticLine ("D14 FRXCHECK SourceFrx={0} SourceExists={1} ExportFrx={2} ExportExists={3}" -f $sourceFrx,$sourceFrxExists,$exportFrx,$exportFrxExists)
                    $frxSame = $false
                    if ($sourceFrxExists -and $exportFrxExists) {
                        try {
                            Write-ComDiagnosticLine 'D15 START Operation=Get-FileSha256'
                            $sourceHash = Get-FileSha256 -Path $sourceFrx
                            $exportHash = Get-FileSha256 -Path $exportFrx
                            $frxSame = ([string]$sourceHash -eq [string]$exportHash)
                            Write-ComDiagnosticLine ("D15 OK SourceHash={0} ExportHash={1} Result={2}" -f $sourceHash,$exportHash,$frxSame)
                        }
                        catch {
                            Write-ComDiagnosticLine ("D15 ERROR ExceptionType={0} HRESULT={1} Message={2} Position={3} Stack={4}" -f $_.Exception.GetType().FullName,(Format-HResultHex -Exception $_.Exception),$_.Exception.Message,$_.InvocationInfo.PositionMessage,$_.ScriptStackTrace)
                            throw
                        }
                    }
                    elseif (-not $sourceFrxExists -and -not $exportFrxExists) {
                        $frxSame = $true
                        Write-ComDiagnosticLine 'D15 SKIP BothFrxMissing=True Result=True'
                    }

                    # VBEが再生成するFRXは内部格納順・オフセット等が変わり、同じフォームでも
                    # SHA-256が一致しない。両方のFRXが存在し、正規化済み.frmが意味的に一致する場合は
                    # フォーム全体を同一と判定し、raw hashは診断情報としてのみ残す。
                    $userFormResult = Resolve-UserFormDiffResult -FrmSame $frmSame -SourceFrxExists $sourceFrxExists -ExportFrxExists $exportFrxExists -RawFrxSame $frxSame
                    if ($userFormResult.ResultOverride) { Write-ComDiagnosticLine 'D15 INFO RawFrxHashDifferent=True SemanticFrmMatched=True ResultOverride=True' }
                    $frxSame = [bool]$userFormResult.EffectiveFrxSame

                    Write-ComDiagnosticLine ("D16 RESULT Component={0} FrmSame={1} FrxSame={2}" -f $name,$frmSame,$frxSame)
                    $results.Add([PSCustomObject]@{ name=$name; type=$type; status=[string]$userFormResult.Status; reason=[string]$userFormResult.Reason; sourcePath=$sourcePath })
                }
                else {
                    Write-ComDiagnosticLine ("D20 START Operation=Get-NormalizedVbaFileContent Component={0} Path={1} PathType={2} ComponentType={3}" -f $name,$sourcePath,$sourcePath.GetType().FullName,$type)
                    $sourceText = Get-NormalizedVbaFileContent -Path $sourcePath -ComponentType $type
                    Write-ComDiagnosticLine ("D20 OK ResultType={0} Length={1}" -f $(if($null -eq $sourceText){'<null>'}else{$sourceText.GetType().FullName}),$(if($null -eq $sourceText){0}else{([string]$sourceText).Length}))
                    Write-ComDiagnosticLine ("D21 START Operation=Get-CodeModuleTextSafe Component={0}" -f $name)
                    $rawBookText = Get-CodeModuleTextSafe -Component $component
                    Write-ComDiagnosticLine ("D21 OK ResultType={0} Length={1}" -f $(if($null -eq $rawBookText){'<null>'}else{$rawBookText.GetType().FullName}),$(if($null -eq $rawBookText){0}else{([string]$rawBookText).Length}))
                    Write-ComDiagnosticLine ("D22 START Operation=Normalize-VbaText TextType={0} ComponentType={1}" -f $(if($null -eq $rawBookText){'<null>'}else{$rawBookText.GetType().FullName}),$type)
                    $bookText = Normalize-VbaText -Text ([string]$rawBookText) -ComponentType $type
                    Write-ComDiagnosticLine ("D22 OK ResultType={0} Length={1}" -f $(if($null -eq $bookText){'<null>'}else{$bookText.GetType().FullName}),$(if($null -eq $bookText){0}else{([string]$bookText).Length}))
                    Write-ComDiagnosticLine ("D23 START Operation=SemanticCompare LeftType={0} RightType={1}" -f $(if($null -eq $sourceText){'<null>'}else{$sourceText.GetType().FullName}),$(if($null -eq $bookText){'<null>'}else{$bookText.GetType().FullName}))
                    $codeDifference = Get-VbaSemanticDifference -Left ([string]$sourceText) -Right ([string]$bookText) -ComponentType $type
                    $status = if ([bool]$codeDifference.Same) {'unchanged'} else {'changed'}
                    Write-ComDiagnosticLine ("D23 OK Status={0} SemanticLeftLength={1} SemanticRightLength={2} FirstDifference={3}" -f $status,$codeDifference.LeftLength,$codeDifference.RightLength,$codeDifference.Index)
                    if ($status -eq 'changed') {
                        Write-ComDiagnosticLine ("D23 DIFF LeftContext={0} RightContext={1}" -f ($codeDifference.LeftContext -replace "`r|`n",' '),($codeDifference.RightContext -replace "`r|`n",' '))
                    }
                    $reason = if($status -eq 'changed'){'コード差分'}else{''}
                    $results.Add([PSCustomObject]@{ name=$name; type=$type; status=$status; reason=$reason; sourcePath=$sourcePath })
                }
            }
            catch {
                $exceptionType = $_.Exception.GetType().FullName
                $hresultText = (Format-HResultHex -Exception $_.Exception)
                $positionText = [string]$_.InvocationInfo.PositionMessage
                $stackText = [string]$_.ScriptStackTrace
                Write-ComDiagnosticLine ("DX ERROR Component={0} Type={1} ExceptionType={2} HRESULT={3} Message={4} Position={5} Stack={6}" -f $name,$type,$exceptionType,$hresultText,$_.Exception.Message,$positionText,$stackText)
                throw "差分判定に失敗しました。Component=$name / Type=$type / ExceptionType=$exceptionType / HRESULT=$hresultText / Position=$positionText / 詳細: $($_.Exception.Message)"
            }
            finally { Release-ComObject $component }
        }
    }
    finally {
        if (-not [string]::IsNullOrWhiteSpace($script:ComDiagnosticLogPath)) {
            Write-ComDiagnosticLine ('Chapter5-5D Diagnostic終了 Log=' + $script:ComDiagnosticLogPath)
        }
        Release-ComObject $vbProject
        Close-ExcelApplication -Excel $excel -Workbook $workbook
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Module CodeNormalizer -Force -ErrorAction SilentlyContinue
    }

    try {
        $resultType = if ($null -eq $results) { '<null>' } else { $results.GetType().FullName }
        $resultCount = if ($null -eq $results) { 0 } else { $results.Count }
        Write-ComDiagnosticLine ("D30 START Operation=ReturnProjectDiffCollection CollectionType={0} Count={1}" -f $resultType,$resultCount)
        for ($i = 0; $i -lt $resultCount; $i++) {
            $entry = $results[$i]
            $entryType = if ($null -eq $entry) { '<null>' } else { $entry.GetType().FullName }
            $entryName = if ($null -eq $entry) { '<null>' } else { [string]$entry.name }
            $entryStatus = if ($null -eq $entry) { '<null>' } else { [string]$entry.status }
            Write-ComDiagnosticLine ("D30 ITEM Index={0} Type={1} Name={2} Status={3}" -f $i,$entryType,$entryName,$entryStatus)
        }
        Write-ComDiagnosticLine ("D30 OK ReturnMode=IndexedPipeline ReturnCount={0}" -f $resultCount)
        for ($i = 0; $i -lt $resultCount; $i++) {
            # Generic List全体を @() で配列化すると、Windows PowerShell 5.1環境で
            # COM由来の処理後にArgumentException(0x80070057)となる場合がある。
            # 各PSCustomObjectを個別にパイプラインへ返し、呼出側で通常のObject[]として受け取る。
            Write-Output -NoEnumerate $results[$i]
        }
    }
    catch {
        Write-ComDiagnosticLine ("D30 ERROR ExceptionType={0} HRESULT={1} Message={2} Position={3} Stack={4}" -f $_.Exception.GetType().FullName,(Format-HResultHex -Exception $_.Exception),$_.Exception.Message,$_.InvocationInfo.PositionMessage,$_.ScriptStackTrace)
        throw
    }
}


function Test-ProjectManifestForPull {
    param([Parameter(Mandatory=$true)]$Context)

    $m = $Context.Manifest
    foreach($name in @('schemaVersion','projectName','target','source','components')) {
        if ($null -eq $m.PSObject.Properties[$name]) { throw "project.jsonの必須項目がありません: $name" }
    }
    if ([string]$m.schemaVersion -ne '1.0') { throw "未対応のschemaVersionです: $($m.schemaVersion)" }
    if ([string]::IsNullOrWhiteSpace([string]$m.projectName)) { throw 'projectNameが空です。' }
    if ([string]::IsNullOrWhiteSpace([string]$m.source.root)) { throw 'source.rootが空です。' }
    if ($null -eq $m.components -or @($m.components).Count -eq 0) { throw 'componentsを1件以上指定してください。' }

    $supported = @('standard','class','document','userform')
    $seen = @{}
    foreach($c in @($m.components)) {
        foreach($required in @('type','name','file')) {
            if ($null -eq $c.PSObject.Properties[$required] -or [string]::IsNullOrWhiteSpace([string]$c.$required)) {
                throw "componentの必須項目がありません: $required"
            }
        }
        $type = ([string]$c.type).ToLowerInvariant()
        if ($supported -notcontains $type) { throw "未対応のコンポーネント種別です: $($c.type)" }
        $key = $type + '|' + [string]$c.name
        if ($seen.ContainsKey($key)) { throw "コンポーネント定義が重複しています: $key" }
        $seen[$key] = $true
    }
    return $true
}

function Convert-ExportedTextToUtf8 {
    param([Parameter(Mandatory=$true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "エクスポートファイルが見つかりません: $Path" }

    # VBIDE.ExportはWindows既定コードページで出力するため、sourceの標準形式UTF-8(BOMなし)へ統一する。
    $text = [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::Default)
    [System.IO.File]::WriteAllText($Path, $text, (New-Object System.Text.UTF8Encoding($false)))
}

function Export-UserFormCodeFile {
    param(
        [Parameter(Mandatory=$true)][string]$FormPath,
        [Parameter(Mandatory=$true)][string]$CodePath
    )
    $text = [System.IO.File]::ReadAllText($FormPath, [System.Text.Encoding]::UTF8)
    $marker = 'Attribute VB_Exposed = False'
    $index = $text.IndexOf($marker, [System.StringComparison]::OrdinalIgnoreCase)
    if ($index -lt 0) { throw "UserFormコード開始位置を特定できません: $FormPath" }
    $start = $index + $marker.Length
    while ($start -lt $text.Length -and ($text[$start] -eq "`r" -or $text[$start] -eq "`n")) { $start++ }
    $code = $text.Substring($start)
    New-Item -ItemType Directory -Path (Split-Path -Parent $CodePath) -Force | Out-Null
    [System.IO.File]::WriteAllText($CodePath, $code, (New-Object System.Text.UTF8Encoding($false)))
}

function Write-ProjectPullJson {
    param(
        [Parameter(Mandatory=$true)]$Context,
        [Parameter(Mandatory=$true)][string]$TargetPath,
        [Parameter(Mandatory=$true)][string]$BackupPath,
        [Parameter(Mandatory=$true)][object[]]$Items,
        [Parameter(Mandatory=$true)][double]$ElapsedSeconds
    )
    $logDir = Get-RuntimeLogDirectory
    New-Item -ItemType Directory -Path $logDir -Force | Out-Null
    $path = Join-Path $logDir ('project_pull_' + [DateTime]::Now.ToString('yyyyMMdd_HHmmss_fff') + '.json')
    $result = [PSCustomObject]@{
        schemaVersion = '1.0'
        project = [string]$Context.Manifest.projectName
        target = $TargetPath
        sourceBackup = $BackupPath
        timestamp = [DateTime]::Now.ToString('o')
        summary = [PSCustomObject]@{
            exported = @($Items).Count
            standard = @($Items | Where-Object { $_.type -eq 'standard' }).Count
            class = @($Items | Where-Object { $_.type -eq 'class' }).Count
            document = @($Items | Where-Object { $_.type -eq 'document' }).Count
            userform = @($Items | Where-Object { $_.type -eq 'userform' }).Count
            elapsedSeconds = [Math]::Round($ElapsedSeconds, 3)
        }
        components = @($Items)
    }
    [System.IO.File]::WriteAllText($path, ($result | ConvertTo-Json -Depth 8), (New-Object System.Text.UTF8Encoding($false)))
    return $path
}

function Invoke-ProjectPull {
    param([string[]]$Arguments)

    $started = Get-Date
    $project = Get-NamedArgument -Arguments $Arguments -Name '-Project'
    $ctx = Read-ProjectManifest -Project $project
    [void](Test-ProjectManifestForPull -Context $ctx)
    $target = Resolve-ManifestTarget -Context $ctx

    $sourceRoot = Resolve-ManifestPath -ProjectDir $ctx.ProjectDir -PathValue ([string]$ctx.Manifest.source.root)
    $timestamp = [DateTime]::Now.ToString('yyyyMMdd_HHmmss')
    $backupRoot = Get-RuntimeBackupDirectory
    $backupPath = Join-Path $backupRoot (([string]$ctx.Manifest.projectName) + '_source_before_pull_' + $timestamp)
    $stagingRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('VBAUpdaterPull_' + [guid]::NewGuid().ToString('N'))

    $excel = $null; $workbook = $null; $vbProject = $null
    $items = New-Object System.Collections.Generic.List[object]

    Write-ProjectExecutionTargetSummary -Context $ctx -TargetPath $target -VbaChanges @($ctx.Manifest.components).Count -WorkbookChanges 0 -WorkbookDefinitionEnabled $false -BackupDestination $backupPath

    try {
        New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
        if (Test-Path -LiteralPath $sourceRoot -PathType Container) {
            Copy-Item -LiteralPath $sourceRoot -Destination $backupPath -Recurse -Force
        }
        else {
            New-Item -ItemType Directory -Path $backupPath -Force | Out-Null
        }
        New-Item -ItemType Directory -Path $stagingRoot -Force | Out-Null

        Write-Info '対象ブックを読み取り専用で開き、VBAコンポーネントをSourceへPullしています...'
        Write-Host "Sourceバックアップ: $backupPath"
        $excel = New-ExcelApplication
        $excel.AutomationSecurity = 3
        $workbook = Open-WorkbookReadOnlySafe -Excel $excel -Path $target
        if ($null -eq $workbook) { throw '対象ブックを開けませんでした。' }
        $vbProject = $workbook.VBProject
        if ($null -eq $vbProject) { throw 'VBProjectを取得できませんでした。Excelの「VBAプロジェクト オブジェクト モデルへのアクセスを信頼する」を確認してください。' }

        foreach($c in @($ctx.Manifest.components)) {
            $type = ([string]$c.type).ToLowerInvariant()
            $name = [string]$c.name
            $component = $null
            try {
                $component = Find-VbComponentSafe -VbProject $vbProject -ComponentName $name
                if ($null -eq $component) { throw "対象ブック内にコンポーネントが見つかりません: $name" }

                $relativeFile = [string]$c.file
                $stagedPath = Join-Path $stagingRoot $relativeFile
                $stagedDir = Split-Path -Parent $stagedPath
                New-Item -ItemType Directory -Path $stagedDir -Force | Out-Null
                Export-VbComponentSafe -Component $component -Path $stagedPath
                Convert-ExportedTextToUtf8 -Path $stagedPath

                $binaryRelative = $null
                $codeRelative = $null
                if ($type -eq 'userform') {
                    $binaryRelative = if ($c.PSObject.Properties['binaryFile'] -and -not [string]::IsNullOrWhiteSpace([string]$c.binaryFile)) { [string]$c.binaryFile } else { [System.IO.Path]::ChangeExtension($relativeFile,'.frx') }
                    $exportedFrx = [System.IO.Path]::ChangeExtension($stagedPath,'.frx')
                    $stagedFrx = Join-Path $stagingRoot $binaryRelative
                    if (-not (Test-Path -LiteralPath $exportedFrx -PathType Leaf)) { throw "UserFormの.frxが出力されませんでした: $name" }
                    if (-not [string]::Equals($exportedFrx,$stagedFrx,[System.StringComparison]::OrdinalIgnoreCase)) {
                        New-Item -ItemType Directory -Path (Split-Path -Parent $stagedFrx) -Force | Out-Null
                        Move-Item -LiteralPath $exportedFrx -Destination $stagedFrx -Force
                    }
                    if ($c.PSObject.Properties['codeFile'] -and -not [string]::IsNullOrWhiteSpace([string]$c.codeFile)) {
                        $codeRelative = [string]$c.codeFile
                        Export-UserFormCodeFile -FormPath $stagedPath -CodePath (Join-Path $stagingRoot $codeRelative)
                    }
                }

                $items.Add([PSCustomObject]@{ name=$name; type=$type; status='exported'; file=$relativeFile; binaryFile=$binaryRelative; codeFile=$codeRelative })
                Write-Host ("  [OK] {0} ({1})" -f $name,$type)
            }
            finally { Release-ComObject $component }
        }

        # 全件エクスポート成功後にだけsourceへ反映する。
        New-Item -ItemType Directory -Path $sourceRoot -Force | Out-Null
        foreach($c in @($ctx.Manifest.components)) {
            $relativeFile = [string]$c.file
            $from = Join-Path $stagingRoot $relativeFile
            $to = Join-Path $sourceRoot $relativeFile
            New-Item -ItemType Directory -Path (Split-Path -Parent $to) -Force | Out-Null
            Copy-Item -LiteralPath $from -Destination $to -Force

            if (([string]$c.type).ToLowerInvariant() -eq 'userform') {
                $binaryRelative = if ($c.PSObject.Properties['binaryFile'] -and -not [string]::IsNullOrWhiteSpace([string]$c.binaryFile)) { [string]$c.binaryFile } else { [System.IO.Path]::ChangeExtension($relativeFile,'.frx') }
                $fromFrx = Join-Path $stagingRoot $binaryRelative
                $toFrx = Join-Path $sourceRoot $binaryRelative
                New-Item -ItemType Directory -Path (Split-Path -Parent $toFrx) -Force | Out-Null
                Copy-Item -LiteralPath $fromFrx -Destination $toFrx -Force
                if ($c.PSObject.Properties['codeFile'] -and -not [string]::IsNullOrWhiteSpace([string]$c.codeFile)) {
                    $codeRelative = [string]$c.codeFile
                    $fromCode = Join-Path $stagingRoot $codeRelative
                    $toCode = Join-Path $sourceRoot $codeRelative
                    New-Item -ItemType Directory -Path (Split-Path -Parent $toCode) -Force | Out-Null
                    Copy-Item -LiteralPath $fromCode -Destination $toCode -Force
                }
            }
        }
    }
    catch {
        throw "Project Pullに失敗しました。既存Sourceはバックアップされています: $backupPath / 詳細: $($_.Exception.Message)"
    }
    finally {
        Release-ComObject $vbProject
        Close-ExcelApplication -Excel $excel -Workbook $workbook
        Remove-Item -LiteralPath $stagingRoot -Recurse -Force -ErrorAction SilentlyContinue
    }

    $elapsed = ((Get-Date) - $started).TotalSeconds
    $jsonPath = Write-ProjectPullJson -Context $ctx -TargetPath $target -BackupPath $backupPath -Items ([object[]]$items.ToArray()) -ElapsedSeconds $elapsed
    Write-ProjectStateOperation -Context $ctx -Operation 'pull'

    Write-Host ''
    Write-Host '====================================='
    Write-Host 'Differential Pull Summary'
    Write-Host '====================================='
    Write-Host ("Project       : {0}" -f $ctx.Manifest.projectName)
    Write-Host ("Exported      : {0}" -f $items.Count)
    Write-Host ("Source Backup : {0}" -f $backupPath)
    Write-Host ("Result JSON   : {0}" -f $jsonPath)
    Write-Host '====================================='
    Write-Success '対象ブックからSourceへのPullが完了しました。対象ブックは更新していません。'
}

function Invoke-ProjectDiff {
    param([string[]]$Arguments)
    try {
        Write-ComDiagnosticLine ("D31 START Operation=ResolveProjectDiffArguments ArgumentsType={0} ArgumentsCount={1}" -f $(if($null -eq $Arguments){'<null>'}else{$Arguments.GetType().FullName}),@($Arguments).Count)
        $project=Get-NamedArgument -Arguments $Arguments -Name '-Project'
        Write-ComDiagnosticLine ("D31 OK Project={0} ProjectType={1}" -f $project,$(if($null -eq $project){'<null>'}else{$project.GetType().FullName}))

        Write-ComDiagnosticLine 'D32 START Operation=ReadProjectManifest'
        $ctx=Read-ProjectManifest -Project $project
        Write-ComDiagnosticLine ("D32 OK ContextType={0}" -f $(if($null -eq $ctx){'<null>'}else{$ctx.GetType().FullName}))

        Write-ComDiagnosticLine 'D33 START Operation=PrepareAndValidate'
        [void](Invoke-PrepareSourceForContext -Context $ctx -HookName 'prePush')
        [void](Test-ProjectManifest -Context $ctx)
        $target=Resolve-ManifestTarget -Context $ctx
        Write-ComDiagnosticLine ("D33 OK Target={0} TargetType={1}" -f $target,$(if($null -eq $target){'<null>'}else{$target.GetType().FullName}))

        Write-ComDiagnosticLine 'D34 START Operation=GetProjectDiffCapture'
        $diff=@(Get-ProjectDiff -Context $ctx -TargetPath $target)
        $diffType = if ($null -eq $diff) { '<null>' } else { $diff.GetType().FullName }
        Write-ComDiagnosticLine ("D34 OK DiffType={0} DiffCount={1}" -f $diffType,@($diff).Count)
        for ($i = 0; $i -lt @($diff).Count; $i++) {
            $item = $diff[$i]
            Write-ComDiagnosticLine ("D34 ITEM Index={0} Type={1} Name={2} Status={3}" -f $i,$(if($null -eq $item){'<null>'}else{$item.GetType().FullName}),$(if($null -eq $item){'<null>'}else{[string]$item.name}),$(if($null -eq $item){'<null>'}else{[string]$item.status}))
        }

        Write-ComDiagnosticLine ("D35 START Operation=WriteProjectDiffJson ContextType={0} TargetType={1} ItemsType={2} ItemsCount={3}" -f $ctx.GetType().FullName,$target.GetType().FullName,$diff.GetType().FullName,@($diff).Count)
        $jsonPath=Write-ProjectDiffJson -Context $ctx -TargetPath $target -Items $diff
        Write-ComDiagnosticLine ("D35 OK JsonPath={0} JsonPathType={1}" -f $jsonPath,$(if($null -eq $jsonPath){'<null>'}else{$jsonPath.GetType().FullName}))

        Write-Host ''
        Write-ComDiagnosticLine ("D36 START Operation=EnumerateDiff DiffCount={0}" -f @($diff).Count)
        $displayIndex = 0
        foreach($item in $diff) {
            Write-ComDiagnosticLine ("D36 ITEM Index={0} ItemType={1} StatusType={2} NameType={3} ReasonType={4}" -f $displayIndex,$(if($null -eq $item){'<null>'}else{$item.GetType().FullName}),$(if($null -eq $item.status){'<null>'}else{$item.status.GetType().FullName}),$(if($null -eq $item.name){'<null>'}else{$item.name.GetType().FullName}),$(if($null -eq $item.reason){'<null>'}else{$item.reason.GetType().FullName}))
            switch($item.status) {
                'unchanged' { Write-Host ("変更なし : {0} ({1})" -f $item.name,$item.type) }
                'changed'   { Write-Warn ("変更あり : {0} ({1}) {2}" -f $item.name,$item.type,$item.reason) }
                'added'     { Write-Warn ("新規追加 : {0} ({1})" -f $item.name,$item.type) }
            }
            $displayIndex++
        }
        Write-ComDiagnosticLine 'D36 OK'

        Write-ComDiagnosticLine 'D37 START Operation=CalculateSummaryCounts'
        $updateCount=@($diff | Where-Object { $_.status -in @('changed','added') }).Count
        $changedCount=@($diff | Where-Object { $_.status -eq 'changed' }).Count
        $addedCount=@($diff | Where-Object { $_.status -eq 'added' }).Count
        $unchangedCount=@($diff | Where-Object { $_.status -eq 'unchanged' }).Count
        Write-ComDiagnosticLine ("D37 OK Changed={0} Added={1} Unchanged={2} UpdatePlan={3}" -f $changedCount,$addedCount,$unchangedCount,$updateCount)

        Write-Host ''
        Write-Host '====================================='
        Write-Host 'Standalone Diff Summary'
        Write-Host '====================================='
        Write-Host ("Project       : {0}" -f $ctx.Manifest.projectName)
        Write-Host ("Changed       : {0}" -f $changedCount)
        Write-Host ("Added         : {0}" -f $addedCount)
        Write-Host ("Unchanged     : {0}" -f $unchangedCount)
        Write-Host ("Update Plan   : {0}" -f $updateCount)
        Write-Host ("Result JSON   : {0}" -f $jsonPath)
        Write-Host '====================================='
        Write-Success '差分判定が完了しました。対象ブックは更新していません。'
        Write-ComDiagnosticLine 'D38 OK Operation=InvokeProjectDiffCompleted'
    }
    catch {
        $exceptionType = $_.Exception.GetType().FullName
        $hresultText = (Format-HResultHex -Exception $_.Exception)
        Write-ComDiagnosticLine ("D3X ERROR ExceptionType={0} HRESULT={1} Message={2} Position={3} Stack={4}" -f $exceptionType,$hresultText,$_.Exception.Message,$_.InvocationInfo.PositionMessage,$_.ScriptStackTrace)
        throw
    }
}

function Invoke-PrepareSourceCommand {
    param([string[]]$Arguments)
    $project = Get-NamedArgument -Arguments $Arguments -Name '-Project'
    $ctx = Read-ProjectManifest -Project $project
    $result = Invoke-PrepareSourceForContext -Context $ctx -HookName 'prePush'

    Write-Host ''
    Write-Host '====================================='
    Write-Host 'PrepareSource Summary'
    Write-Host '====================================='
    Write-Host ("Project       : {0}" -f $result.project)
    Write-Host ("Components    : {0}" -f $result.summary.components)
    Write-Host ("OK            : {0}" -f $result.summary.ok)
    Write-Host ("Failed        : {0}" -f $result.summary.failed)
    Write-Host ("Result JSON   : {0}" -f $result.resultJson)
    Write-Host '====================================='
    Write-Success 'PrepareSourceが完了しました。'
}

function Invoke-PrepareSourceTest {
    Import-PrepareSourceModule
    $tempRoot = Join-Path (Get-TestTempBase) ('VBAUpdaterPrepareSourceTest_' + [guid]::NewGuid().ToString('N'))
    try {
        Write-Info 'PrepareSource回帰テストを実行しています...'
        $sourceRoot = Join-Path $tempRoot 'source'
        New-Item -ItemType Directory -Path (Join-Path $sourceRoot 'standard') -Force | Out-Null
        New-Item -ItemType Directory -Path (Join-Path $sourceRoot 'class') -Force | Out-Null
        New-Item -ItemType Directory -Path (Join-Path $sourceRoot 'document') -Force | Out-Null
        New-Item -ItemType Directory -Path (Join-Path $sourceRoot 'userforms') -Force | Out-Null

        [System.IO.File]::WriteAllText((Join-Path $sourceRoot 'standard\modTest.bas'), "Option Explicit`r`n", (New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllText((Join-Path $sourceRoot 'class\clsTest.cls'), "Option Explicit`r`n", (New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllText((Join-Path $sourceRoot 'document\ThisWorkbook.cls'), "Option Explicit`r`n", (New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllText((Join-Path $sourceRoot 'userforms\frmTest.frm'), "VERSION 5.00`r`nBegin VB.UserForm frmTest`r`nEnd`r`n", (New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllBytes((Join-Path $sourceRoot 'userforms\frmTest.frx'), [byte[]]@(1,2,3,4))

        $manifest = [PSCustomObject]@{
            projectName = 'PrepareSourceTest'
            source = [PSCustomObject]@{ root = 'source' }
            components = @(
                [PSCustomObject]@{ type='standard'; name='modTest'; file='standard/modTest.bas' },
                [PSCustomObject]@{ type='class'; name='clsTest'; file='class/clsTest.cls' },
                [PSCustomObject]@{ type='document'; name='ThisWorkbook'; file='document/ThisWorkbook.cls' },
                [PSCustomObject]@{ type='userform'; name='frmTest'; file='userforms/frmTest.frm'; binaryFile='userforms/frmTest.frx' }
            )
        }

        $result = Invoke-VbaPrepareSource -ProjectDir $tempRoot -Manifest $manifest -LogDirectory (Join-Path $tempRoot 'logs')
        if ([int]$result.summary.components -ne 4 -or [int]$result.summary.ok -ne 4 -or [int]$result.summary.failed -ne 0) {
            throw '正常系サマリーが一致しません。'
        }
        if (-not (Test-Path -LiteralPath $result.resultJson -PathType Leaf)) {
            throw '結果JSONが作成されていません。'
        }
        Write-Host '  [OK] Standard Module'
        Write-Host '  [OK] Class Module'
        Write-Host '  [OK] Document Module'
        Write-Host '  [OK] UserForm frm/frx'
        Write-Host '  [OK] Result JSON'

        Remove-Item -LiteralPath (Join-Path $sourceRoot 'userforms\frmTest.frx') -Force
        $detected = $false
        try {
            $null = Invoke-VbaPrepareSource -ProjectDir $tempRoot -Manifest $manifest -SkipJson
        }
        catch {
            if ($_.Exception.Message -like '*UserFormの.frxが見つかりません*') { $detected = $true }
            else { throw }
        }
        if (-not $detected) { throw '不足frxを検出できませんでした。' }
        Write-Host '  [OK] Missing frx detection'

        Write-Success 'PrepareSource回帰テストに成功しました。'
    }
    finally {
        Remove-Module PrepareSource -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-StandaloneDiffTest {
    Write-Info 'Standalone Diff回帰テストを実行しています...'
    $items = @(
        [PSCustomObject]@{ name='modSame'; type='standard'; status='unchanged'; reason=''; sourcePath='same.bas' },
        [PSCustomObject]@{ name='modChanged'; type='standard'; status='changed'; reason='コード差分'; sourcePath='changed.bas' },
        [PSCustomObject]@{ name='clsAdded'; type='class'; status='added'; reason='ブック内にコンポーネントがありません'; sourcePath='added.cls' }
    )
    if (@($items | Where-Object { $_.status -eq 'unchanged' }).Count -ne 1) { throw 'unchanged集計に失敗しました。' }
    if (@($items | Where-Object { $_.status -eq 'changed' }).Count -ne 1) { throw 'changed集計に失敗しました。' }
    if (@($items | Where-Object { $_.status -eq 'added' }).Count -ne 1) { throw 'added集計に失敗しました。' }
    $updateCount = @($items | Where-Object { $_.status -in @('changed','added') }).Count
    if ($updateCount -ne 2) { throw '更新予定件数の集計に失敗しました。' }
    Write-Host '  [OK] unchanged判定'
    Write-Host '  [OK] changed判定'
    Write-Host '  [OK] added判定'
    Write-Host '  [OK] 更新予定件数'
    Write-Success 'Standalone Diff回帰テストに成功しました。'
}


function Invoke-DifferentialPushTest {
    Write-Info 'Differential Push回帰テストを実行しています...'
    $items=@(
        [PSCustomObject]@{name='modSame';type='standard';status='unchanged'},
        [PSCustomObject]@{name='modChanged';type='standard';status='changed'},
        [PSCustomObject]@{name='clsAdded';type='class';status='added'}
    )
    $plan=@(Get-DifferentialUpdatePlan -DiffItems $items)
    if($plan.Count -ne 2){throw '更新計画件数が一致しません。'}
    if(@($plan|Where-Object{$_.name -eq 'modSame'}).Count -ne 0){throw 'unchangedが更新計画に混入しました。'}
    if(@($plan|Where-Object{$_.name -eq 'modChanged'}).Count -ne 1){throw 'changedが更新計画に含まれていません。'}
    if(@($plan|Where-Object{$_.name -eq 'clsAdded'}).Count -ne 1){throw 'addedが更新計画に含まれていません。'}
    $empty=@(Get-DifferentialUpdatePlan -DiffItems @([PSCustomObject]@{name='onlySame';type='standard';status='unchanged'}))
    if($empty.Count -ne 0){throw '変更なし時の更新計画が空ではありません。'}
    Write-Host '  [OK] unchanged除外'
    Write-Host '  [OK] changed選択'
    Write-Host '  [OK] added選択'
    Write-Host '  [OK] 変更なし時の空計画'
    Write-Success 'Differential Push回帰テストに成功しました。'
}

function Invoke-NormalizeTest {
    Import-CodeNormalizer
    try {
        Write-Info 'コード正規化エンジンの回帰テストを実行しています...'
        $cases = New-Object System.Collections.Generic.List[object]
        $cases.Add([PSCustomObject]@{Name='CRLFとLF';Type='standard';Left="Option Explicit`r`nPublic Sub A()`r`nEnd Sub`r`n";Right="Option Explicit`nPublic Sub A()`nEnd Sub`n";Expected=$true})
        $cases.Add([PSCustomObject]@{Name='BOM有無';Type='standard';Left=([char]0xFEFF)+"Option Explicit`n";Right="Option Explicit`n";Expected=$true})
        $cases.Add([PSCustomObject]@{Name='末尾空白';Type='standard';Left="Option Explicit   `nPublic Sub A() `nEnd Sub";Right="Option Explicit`nPublic Sub A()`nEnd Sub";Expected=$true})
        $cases.Add([PSCustomObject]@{Name='Attribute差';Type='standard';Left="Attribute VB_Name = `"modA`"`nOption Explicit";Right="Option Explicit";Expected=$true})
        $cases.Add([PSCustomObject]@{Name='空行差';Type='standard';Left="Option Explicit`n`n`nPublic Sub A()`nEnd Sub";Right="Option Explicit`n`nPublic Sub A()`nEnd Sub";Expected=$true})
        $cases.Add([PSCustomObject]@{Name='実コード差';Type='standard';Left='Public Function A(): A=1: End Function';Right='Public Function A(): A=2: End Function';Expected=$false})
        $cases.Add([PSCustomObject]@{Name='クラスヘッダー差';Type='class';Left="VERSION 1.0 CLASS`nBEGIN`n MultiUse = -1`nEND`nAttribute VB_Name = `"C`"`nOption Explicit";Right='Option Explicit';Expected=$true})
        $cases.Add([PSCustomObject]@{Name='UserForm frx名差';Type='userform';Left='   OleObjectBlob   =   "A.frx":0000';Right='   OleObjectBlob   =   "B.frx":0000';Expected=$true})
        $cases.Add([PSCustomObject]@{Name='UserForm twip再出力差 ClientHeight';Type='userform';Left='VERSION 5.00`nBegin VB.UserForm frmTest`n   ClientHeight = 9036`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Right='VERSION 5.00`nBegin VB.UserForm frmTest`n   ClientHeight = 9036.001`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Expected=$true})
        $cases.Add([PSCustomObject]@{Name='UserForm twip再出力差 ClientWidth';Type='userform';Left='VERSION 5.00`nBegin VB.UserForm frmTest`n   ClientWidth = 9036`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Right='VERSION 5.00`nBegin VB.UserForm frmTest`n   ClientWidth = 9036.001`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Expected=$true})
        $cases.Add([PSCustomObject]@{Name='UserForm twip再出力差 ClientLeft';Type='userform';Left='VERSION 5.00`nBegin VB.UserForm frmTest`n   ClientLeft = 9036`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Right='VERSION 5.00`nBegin VB.UserForm frmTest`n   ClientLeft = 9036.001`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Expected=$true})
        $cases.Add([PSCustomObject]@{Name='UserForm twip再出力差 ClientTop';Type='userform';Left='VERSION 5.00`nBegin VB.UserForm frmTest`n   ClientTop = 9036`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Right='VERSION 5.00`nBegin VB.UserForm frmTest`n   ClientTop = 9036.001`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Expected=$true})
        $cases.Add([PSCustomObject]@{Name='UserForm twip再出力差 ScrollHeight';Type='userform';Left='VERSION 5.00`nBegin VB.UserForm frmTest`n   ScrollHeight = 9036`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Right='VERSION 5.00`nBegin VB.UserForm frmTest`n   ScrollHeight = 9036.001`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Expected=$true})
        $cases.Add([PSCustomObject]@{Name='UserForm twip再出力差 ScrollWidth';Type='userform';Left='VERSION 5.00`nBegin VB.UserForm frmTest`n   ScrollWidth = 9036`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Right='VERSION 5.00`nBegin VB.UserForm frmTest`n   ScrollWidth = 9036.001`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Expected=$true})
        $cases.Add([PSCustomObject]@{Name='UserForm twip再出力差 ScrollLeft';Type='userform';Left='VERSION 5.00`nBegin VB.UserForm frmTest`n   ScrollLeft = 9036`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Right='VERSION 5.00`nBegin VB.UserForm frmTest`n   ScrollLeft = 9036.001`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Expected=$true})
        $cases.Add([PSCustomObject]@{Name='UserForm twip再出力差 ScrollTop';Type='userform';Left='VERSION 5.00`nBegin VB.UserForm frmTest`n   ScrollTop = 9036`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Right='VERSION 5.00`nBegin VB.UserForm frmTest`n   ScrollTop = 9036.001`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Expected=$true})
        $cases.Add([PSCustomObject]@{Name='UserForm twip再出力差 Height';Type='userform';Left='VERSION 5.00`nBegin VB.UserForm frmTest`n   Height = 9036`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Right='VERSION 5.00`nBegin VB.UserForm frmTest`n   Height = 9036.001`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Expected=$true})
        $cases.Add([PSCustomObject]@{Name='UserForm twip再出力差 Width';Type='userform';Left='VERSION 5.00`nBegin VB.UserForm frmTest`n   Width = 9036`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Right='VERSION 5.00`nBegin VB.UserForm frmTest`n   Width = 9036.001`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Expected=$true})
        $cases.Add([PSCustomObject]@{Name='UserForm twip再出力差 Left';Type='userform';Left='VERSION 5.00`nBegin VB.UserForm frmTest`n   Left = 9036`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Right='VERSION 5.00`nBegin VB.UserForm frmTest`n   Left = 9036.001`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Expected=$true})
        $cases.Add([PSCustomObject]@{Name='UserForm twip再出力差 Top';Type='userform';Left='VERSION 5.00`nBegin VB.UserForm frmTest`n   Top = 9036`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Right='VERSION 5.00`nBegin VB.UserForm frmTest`n   Top = 9036.001`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Expected=$true})
        $cases.Add([PSCustomObject]@{Name='UserForm実寸法差';Type='userform';Left='VERSION 5.00`nBegin VB.UserForm frmTest`n   ClientHeight = 9036`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Right='VERSION 5.00`nBegin VB.UserForm frmTest`n   ClientHeight = 9037`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Expected=$false})
        $cases.Add([PSCustomObject]@{Name='UserForm twip非対象小数差';Type='userform';Left='VERSION 5.00`nBegin VB.UserForm frmTest`n   ClientHeight = 9036`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Right='VERSION 5.00`nBegin VB.UserForm frmTest`n   ClientHeight = 9036.01`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Expected=$false})
        $cases.Add([PSCustomObject]@{Name='UserForm VBAコード内twip類似値差';Type='userform';Left='VERSION 5.00`nBegin VB.UserForm frmTest`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit`nPrivate Sub A(): Height = 9036: End Sub';Right='VERSION 5.00`nBegin VB.UserForm frmTest`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit`nPrivate Sub A(): Height = 9036.001: End Sub';Expected=$false})
        $cases.Add([PSCustomObject]@{Name='UserForm実座標差';Type='userform';Left='VERSION 5.00`nBegin VB.UserForm frmTest`n   Left = 120`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Right='VERSION 5.00`nBegin VB.UserForm frmTest`n   Left = 121`nEnd`nAttribute VB_Name = "frmTest"`nOption Explicit';Expected=$false})
        $cases.Add([PSCustomObject]@{Name='UserFormデザイン差';Type='userform';Left='   Caption = "A"';Right='   Caption = "B"';Expected=$false})
        $cases.Add([PSCustomObject]@{Name='UserForm文字列リテラル差';Type='userform';Left='Private Sub A(): MsgBox "A": End Sub';Right='Private Sub A(): MsgBox "B": End Sub';Expected=$false})
        $cases.Add([PSCustomObject]@{Name='UserFormコード追加差';Type='userform';Left='Option Explicit';Right='Option Explicit`nPrivate Sub A(): End Sub';Expected=$false})

        foreach($case in $cases) {
            $actual=Test-VbaTextEquivalent -Left $case.Left -Right $case.Right -ComponentType $case.Type
            if($actual -ne [bool]$case.Expected){ throw "正規化テストに失敗しました。Case=$($case.Name) / Expected=$($case.Expected) / Actual=$actual" }
            Write-Host "  [OK] $($case.Name)"
        }

        $frxOverride = Resolve-UserFormDiffResult -FrmSame $true -SourceFrxExists $true -ExportFrxExists $true -RawFrxSame $false
        if ($frxOverride.Status -ne 'unchanged' -or -not $frxOverride.ResultOverride -or -not $frxOverride.EffectiveFrxSame) {
            throw 'UserForm FRX ResultOverride回帰テストに失敗しました。'
        }
        Write-Host '  [OK] UserForm FRX raw hash差 ResultOverride'

        $frxMissing = Resolve-UserFormDiffResult -FrmSame $true -SourceFrxExists $true -ExportFrxExists $false -RawFrxSame $false
        if ($frxMissing.Status -ne 'changed' -or $frxMissing.EffectiveFrxSame) {
            throw 'UserForm片側FRX欠落のchanged判定に失敗しました。'
        }
        Write-Host '  [OK] UserForm片側FRX欠落 changed'

        $frmChanged = Resolve-UserFormDiffResult -FrmSame $false -SourceFrxExists $true -ExportFrxExists $true -RawFrxSame $false
        if ($frmChanged.Status -ne 'changed') { throw 'UserForm FRM意味差のchanged判定に失敗しました。' }
        Write-Host '  [OK] UserForm FRM意味差 changed'

        $temp=Join-Path ([System.IO.Path]::GetTempPath()) ('VBAUpdaterNormalizeTest_'+[guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $temp -Force | Out-Null
        try {
            $a=Join-Path $temp 'a.frx';$b=Join-Path $temp 'b.frx';$c=Join-Path $temp 'c.frx'
            [System.IO.File]::WriteAllBytes($a,[byte[]]@(1,2,3,4));[System.IO.File]::WriteAllBytes($b,[byte[]]@(1,2,3,4));[System.IO.File]::WriteAllBytes($c,[byte[]](1,2,3,5))
            if((Get-FileSha256 $a) -ne (Get-FileSha256 $b)){throw '同一frxのハッシュが一致しません。'}
            if((Get-FileSha256 $a) -eq (Get-FileSha256 $c)){throw '異なるfrxのハッシュが一致しました。'}
            Write-Host '  [OK] .frxバイナリ差分'
        } finally { Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue }

        Write-Success 'コード正規化エンジンの回帰テストに成功しました。'
    }
    finally { Remove-Module CodeNormalizer -Force -ErrorAction SilentlyContinue }
}

function Invoke-TestRun {
    $workbookPath = Join-Path (Get-LegacyTestRoot) "VBAAddinEngineTest.xlsm"

    if (-not (Test-Path -LiteralPath $workbookPath -PathType Leaf)) {
        throw "テストブックがありません。先に test-create を実行してください。"
    }

    $excel = $null
    $workbook = $null

    try {
        Write-Info "更新結果を検証しています..."

        $excel = New-ExcelApplication
        $excel.AutomationSecurity = 1
        Invoke-TestWorkbookOpenAudit -Path $workbookPath
        $workbook = $excel.Workbooks.Open($workbookPath, 0, $true)

        $result = [string]$excel.Run("'" + $workbook.Name + "'!GetAddinEngineTestValue")

        if ($result -ne "NEW_VALUE") {
            throw "更新結果が一致しません。Expected=NEW_VALUE / Actual=$result"
        }

        Write-Success "VBAUpdater.xlamの自動テストに成功しました。"
        Write-Host "結果: $result"
    }
    finally {
        Close-ExcelApplication -Excel $excel -Workbook $workbook
    }
}


function New-IntegrityFinding {
    param([string]$Severity,[string]$Code,[string]$Message,[AllowNull()][string]$Path)
    return [PSCustomObject]@{severity=$Severity;code=$Code;message=$Message;path=$Path}
}

function Test-ExpectedComponentExtension {
    param([string]$Type,[string]$Path)
    $expected=switch($Type.ToLowerInvariant()){'standard'{'.bas'}'class'{'.cls'}'document'{'.cls'}'userform'{'.frm'}default{''}}
    return ([System.IO.Path]::GetExtension($Path) -ieq $expected)
}

function Get-ProjectIntegrityFindings {
    param([Parameter(Mandatory=$true)]$Context)
    $findings=New-Object 'System.Collections.Generic.List[object]'
    $m=$Context.Manifest
    try{[void](Test-ProjectManifest -Context $Context);$findings.Add((New-IntegrityFinding 'OK' 'MANIFEST_VALID' 'project.jsonの基本検証に成功しました。' $Context.ManifestPath))}
    catch{$findings.Add((New-IntegrityFinding 'ERROR' 'MANIFEST_INVALID' $_.Exception.Message $Context.ManifestPath));return $findings.ToArray()}

    $declared=@{}
    foreach($c in @($m.components)){
        $type=([string]$c.type).ToLowerInvariant();$name=[string]$c.name
        $sourcePath=Resolve-ManifestPath -ProjectDir $Context.ProjectDir -PathValue (Join-Path ([string]$m.source.root) ([string]$c.file))
        $key=([System.IO.Path]::GetFullPath($sourcePath)).ToLowerInvariant();$declared[$key]=$true
        if(-not(Test-ExpectedComponentExtension -Type $type -Path $sourcePath)){$findings.Add((New-IntegrityFinding 'ERROR' 'SOURCE_EXTENSION' "コンポーネント種別と拡張子が一致しません: $type/$name" $sourcePath))}
        elseif((Get-Item -LiteralPath $sourcePath).Length -eq 0){$findings.Add((New-IntegrityFinding 'ERROR' 'SOURCE_EMPTY' "ソースファイルが空です: $name" $sourcePath))}
        else{$findings.Add((New-IntegrityFinding 'OK' 'SOURCE_VALID' "ソースを確認しました: $type/$name" $sourcePath))}
        if($type -eq 'userform'){
            $binary=if($c.PSObject.Properties['binaryFile'] -and -not[string]::IsNullOrWhiteSpace([string]$c.binaryFile)){Resolve-ManifestPath -ProjectDir $Context.ProjectDir -PathValue (Join-Path ([string]$m.source.root) ([string]$c.binaryFile))}else{[System.IO.Path]::ChangeExtension($sourcePath,'.frx')}
            $declared[([System.IO.Path]::GetFullPath($binary)).ToLowerInvariant()]=$true
            if((Get-Item -LiteralPath $binary).Length -eq 0){$findings.Add((New-IntegrityFinding 'ERROR' 'FRX_EMPTY' "UserFormバイナリが空です: $name" $binary))}
            else{$findings.Add((New-IntegrityFinding 'OK' 'FRX_VALID' "UserFormバイナリを確認しました: $name" $binary))}
        }
    }
    $sourceRoot=Resolve-ManifestPath -ProjectDir $Context.ProjectDir -PathValue ([string]$m.source.root)
    foreach($file in @(Get-ChildItem -LiteralPath $sourceRoot -Recurse -File -ErrorAction SilentlyContinue|Where-Object{$_.Extension -in @('.bas','.cls','.frm','.frx')})){
        if(-not $declared.ContainsKey($file.FullName.ToLowerInvariant())){$findings.Add((New-IntegrityFinding 'WARN' 'ORPHAN_SOURCE' 'Manifestに登録されていないVBAソースです。' $file.FullName))}
    }
    try{$target=Resolve-ManifestTarget -Context $Context;$item=Get-Item -LiteralPath $target
        if($item.Length -eq 0){$findings.Add((New-IntegrityFinding 'ERROR' 'TARGET_EMPTY' '対象ブックが空です。' $target))}
        elseif($item.Extension -notin @('.xlsm','.xlsb','.xlam')){$findings.Add((New-IntegrityFinding 'ERROR' 'TARGET_EXTENSION' '対象ブックの拡張子がVBA対応形式ではありません。' $target))}
        else{[void](Get-FileHash -LiteralPath $target -Algorithm SHA256);$findings.Add((New-IntegrityFinding 'OK' 'TARGET_READABLE' '対象ブックの読取とSHA-256計算に成功しました。' $target))}
    }catch{$findings.Add((New-IntegrityFinding 'ERROR' 'TARGET_INVALID' $_.Exception.Message $null))}
    foreach($required in @($script:PackageAddinPath,$script:EngineSourcePath,$script:NormalizerModulePath,$script:PrepareSourceModulePath)){
        if(-not(Test-Path -LiteralPath $required -PathType Leaf)){$findings.Add((New-IntegrityFinding 'ERROR' 'PACKAGE_FILE_MISSING' '必須パッケージファイルがありません。' $required))}
        elseif((Get-Item -LiteralPath $required).Length -eq 0){$findings.Add((New-IntegrityFinding 'ERROR' 'PACKAGE_FILE_EMPTY' '必須パッケージファイルが空です。' $required))}
        else{$findings.Add((New-IntegrityFinding 'OK' 'PACKAGE_FILE_VALID' '必須パッケージファイルを確認しました。' $required))}
    }
    foreach($point in @(Get-ProjectRestorePoints -Context $Context)) {
        $restorePath = [string]$point.backupPath
        try {
            $actual = (Get-FileHash -LiteralPath $restorePath -Algorithm SHA256).Hash
            if ($actual -ne [string]$point.sha256) {
                $finding = New-IntegrityFinding 'ERROR' 'RESTORE_HASH_MISMATCH' "復元ポイントのハッシュが一致しません: $($point.id)" $restorePath
            }
            elseif ((Get-Item -LiteralPath $restorePath).Length -ne [long]$point.sizeBytes) {
                $finding = New-IntegrityFinding 'ERROR' 'RESTORE_SIZE_MISMATCH' "復元ポイントのサイズが一致しません: $($point.id)" $restorePath
            }
            else {
                $finding = New-IntegrityFinding 'OK' 'RESTORE_VALID' "復元ポイントを確認しました: $($point.id)" $restorePath
            }
        }
        catch {
            $finding = New-IntegrityFinding 'ERROR' 'RESTORE_INVALID' $_.Exception.Message $restorePath
        }
        [void]$findings.Add($finding)
    }
    return $findings.ToArray()
}

function Write-IntegrityResultJson {
    param($Context,[object[]]$Findings)
    $dir=Get-RuntimeLogDirectory;New-Item -ItemType Directory -Path $dir -Force|Out-Null
    $path=Join-Path $dir ('project_integrity_'+[DateTime]::Now.ToString('yyyyMMdd_HHmmss_fff')+'.json')
    $payload=[PSCustomObject]@{schemaVersion='1.0';toolVersion=$script:ToolVersion;timestamp=[DateTime]::Now.ToString('o');project=[string]$Context.Manifest.projectName;summary=[PSCustomObject]@{errors=@($Findings|Where-Object{$_.severity -eq 'ERROR'}).Count;warnings=@($Findings|Where-Object{$_.severity -eq 'WARN'}).Count;ok=@($Findings|Where-Object{$_.severity -eq 'OK'}).Count};findings=$Findings}
    [System.IO.File]::WriteAllText($path,($payload|ConvertTo-Json -Depth 10),(New-Object System.Text.UTF8Encoding($false)));return $path
}

function Invoke-ProjectIntegrity {
    param([string[]]$Arguments)
    $project=Get-NamedArgument -Arguments $Arguments -Name '-Project';$skip=Test-ArgumentSwitch -Arguments $Arguments -Name '-SkipHooks'
    $ctx=Read-ProjectManifest -Project $project
    if(-not $skip){try{[void](Invoke-PrepareSourceForContext -Context $ctx -HookName 'prePush' -SkipJson)}catch{Write-Warn ('事前生成処理で問題を検出しました: '+$_.Exception.Message)}}
    [object[]]$findings=@(Get-ProjectIntegrityFindings -Context $ctx);$json=Write-IntegrityResultJson -Context $ctx -Findings $findings
    Write-Host '';Write-Host '=====================================';Write-Host 'VBA Project Integrity Check';Write-Host '=====================================';Write-Host ('Project       : '+[string]$ctx.Manifest.projectName)
    foreach($f in $findings){$prefix=switch($f.severity){'ERROR'{'[ERROR]'}'WARN'{'[WARN]'}default{'[OK]'}};Write-Host ("  {0} {1}: {2}" -f $prefix,$f.code,$f.message);if($f.path){Write-Host ('       '+$f.path)}}
    $errors=@($findings|Where-Object{$_.severity -eq 'ERROR'}).Count;$warnings=@($findings|Where-Object{$_.severity -eq 'WARN'}).Count
    Write-Host '=====================================';Write-Host ("Errors={0} Warnings={1} OK={2}" -f $errors,$warnings,@($findings|Where-Object{$_.severity -eq 'OK'}).Count);Write-Host ('Result JSON   : '+$json)
    if($errors -gt 0){throw "整合性検証で${errors}件のエラーを検出しました。"}else{Write-Success '整合性検証に成功しました。'}
}

function Invoke-IntegrityTest {
    $root=Join-Path ([System.IO.Path]::GetTempPath()) ('VBAUpdaterIntegrityTest_'+[guid]::NewGuid().ToString('N'))
    try{New-Item -ItemType Directory -Path $root -Force|Out-Null
        $good=Join-Path $root 'modA.bas';[System.IO.File]::WriteAllText($good,'Option Explicit')
        if(-not(Test-ExpectedComponentExtension -Type 'standard' -Path $good)){throw '標準モジュール拡張子判定に失敗しました。'}
        if(Test-ExpectedComponentExtension -Type 'class' -Path $good){throw '不正拡張子を許可しました。'}
        $backup=Join-Path $root 'backup.xlsm';[System.IO.File]::WriteAllText($backup,'TEST');$hash=(Get-FileHash -LiteralPath $backup -Algorithm SHA256).Hash
        if($hash -ne (Get-FileHash -LiteralPath $backup -Algorithm SHA256).Hash){throw 'SHA-256検証に失敗しました。'}
        $f=New-IntegrityFinding 'WARN' 'TEST' 'test' $good;if($f.severity -ne 'WARN'-or$f.code -ne 'TEST'){throw 'Finding生成に失敗しました。'}
        $list=New-Object 'System.Collections.Generic.List[object]'
        [void]$list.Add((New-IntegrityFinding 'OK' 'TEST_OK_1' 'test1' $good))
        [void]$list.Add((New-IntegrityFinding 'OK' 'TEST_OK_2' 'test2' $good))
        [object[]]$flat=@($list.ToArray())
        if($flat.Count -ne 2){throw ('Finding配列の展開に失敗しました。Count='+$flat.Count)}
        if(@($flat|Where-Object{$_.severity -eq 'OK'}).Count -ne 2){throw 'Finding集計に失敗しました。'}
        if(($flat[0].code -as [string]) -ne 'TEST_OK_1'){throw 'Finding表示対象の取得に失敗しました。'}
        Write-Success 'Integrity Check回帰テストに成功しました。'
    }finally{Remove-Item -LiteralPath $root -Recurse -Force -ErrorAction SilentlyContinue}
}

function Get-CompileGateProbeDefinitions {
    $path = Join-Path $script:Root 'tests\compile-gate\cases.json'
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Compile GateテストManifestが見つかりません: $path" }
    try { $payload = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json }
    catch { throw "Compile GateテストManifestを読み込めません: $($_.Exception.Message)" }
    if ([string]$payload.schemaVersion -ne '1.0' -or $null -eq $payload.cases -or @($payload.cases).Count -eq 0) {
        throw 'Compile GateテストManifestの形式が不正です。'
    }
    return @($payload.cases)
}

function Get-CompileGateProbeDefinition {
    param([Parameter(Mandatory=$true)][string]$CaseName)
    $matched = @(Get-CompileGateProbeDefinitions | Where-Object { [string]$_.name -eq $CaseName })
    if ($matched.Count -ne 1) { throw "Compile GateテストManifestのケースが見つからないか重複しています: $CaseName" }
    return $matched[0]
}

function New-CompileGateProbeContext {
    param([Parameter(Mandatory=$true)]$Definition)
    return [PSCustomObject]@{ ProjectDir='CompileGateTest'; ManifestPath='tests\compile-gate\cases.json'; Manifest=$Definition.manifest }
}

function Invoke-CompileGateOptionalProbe {
    param([Parameter(Mandatory=$true)][string]$CaseName)
    $definition = Get-CompileGateProbeDefinition -CaseName $CaseName
    $context = New-CompileGateProbeContext -Definition $definition
    if ([string]$definition.behavior -eq 'validate') {
        [void](Test-CompileGateManifestSettings -Context $context)
        throw 'Compile Gateの不正Manifestを許可しました。'
    }

    $executor = switch ([string]$definition.behavior) {
        'success' {
            { param($targetPath,$macro) }
        }
        'missing' {
            {
                param($targetPath,$macro)
                $exception = New-Object System.Runtime.InteropServices.COMException("マクロ '$macro' を実行できません。このブックでマクロが使用できないか、またはすべてのマクロが無効になっている可能性があります。")
                $exception.Data['CompileGatePhase'] = 'RunMacro'
                throw $exception
            }
        }
        'runtime' {
            {
                param($targetPath,$macro)
                $exception = New-Object System.InvalidOperationException("実行時エラー '9': インデックスが有効範囲にありません。")
                $exception.Data['CompileGatePhase'] = 'RunMacro'
                throw $exception
            }
            break
        }
        'com-failure' {
            {
                param($targetPath,$macro)
                $exception = New-Object System.InvalidOperationException('Excelブックを開けません。')
                $exception.Data['CompileGatePhase'] = 'OpenWorkbook'
                throw $exception
            }
            break
        }
        default { throw "不明なCompile Gateテスト動作です: $($definition.behavior)" }
    }

    $result = Invoke-ProjectCompileGate -Context $context -TargetPath 'CompileGateTest.xlsm' -MacroExecutor $executor
    if ($CaseName -eq 'omitted-required' -and $result.Required) { throw 'required省略時にfalseとして扱われませんでした。' }
    Write-Host ('ProbeRequired=' + ([bool]$result.Required).ToString().ToLowerInvariant())
    Write-Host ('ProbeResult=' + [string]$result.Result)
}

function Invoke-CompileGateOptionalTest {
    param([string[]]$Arguments)
    $probeCase = Get-NamedArgument -Arguments $Arguments -Name '-ProbeCase'
    if (-not [string]::IsNullOrWhiteSpace($probeCase)) {
        Invoke-CompileGateOptionalProbe -CaseName $probeCase
        return
    }

    $cases = @(Get-CompileGateProbeDefinitions)

    $scriptPath = Join-Path $script:Root 'vba.ps1'
    foreach ($case in $cases) {
        $outputLines = @(& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $scriptPath compile-gate-optional-test -ProbeCase $case.Name @(Get-TestPropagationArguments) 2>&1)
        $actualExit = $LASTEXITCODE
        $output = $outputLines -join [Environment]::NewLine
        if ($actualExit -ne [int]$case.expectedExit) {
            throw "Compile Gateテストの終了コードが一致しません。Case=$($case.name) Expected=$($case.expectedExit) Actual=$actualExit Output=$output"
        }
        foreach ($expectedText in @($case.expected)) {
            if ($output.IndexOf([string]$expectedText, [System.StringComparison]::Ordinal) -lt 0) {
                throw "Compile Gateテストの出力が不足しています。Case=$($case.Name) Expected=$expectedText Output=$output"
            }
        }
        Write-Host ("  [OK] {0}: ExitCode={1}" -f $case.name,$actualExit)
    }

    $guiPath = Join-Path $script:Root 'gui.ps1'
    & powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File $guiPath -CompileGateWarningSelfTest @(Get-TestPropagationArguments)
    if ($LASTEXITCODE -ne 0) { throw "GUI Compile Gate警告回帰テストに失敗しました。ExitCode=$LASTEXITCODE" }
    Write-Host '  [OK] GUI Sync経路: 任意警告はExitCode=0、末尾ログ取得、GUI継続'
    Write-Success 'Compile Gate Optional回帰テストに成功しました。'
}


function Invoke-Gui {
    param([string[]]$Arguments)
    $project = Get-NamedArgument -Arguments $Arguments -Name '-Project'
    $guiPath = Join-Path $script:Root 'gui.ps1'
    if (-not (Test-Path -LiteralPath $guiPath -PathType Leaf)) { throw "GUIスクリプトが見つかりません: $guiPath" }
    $argumentList = @('-NoProfile','-STA','-ExecutionPolicy','Bypass','-File',$guiPath)
    if (-not [string]::IsNullOrWhiteSpace($project)) { $argumentList += @('-Project',$project) }
    Start-Process -FilePath 'powershell.exe' -ArgumentList $argumentList -WorkingDirectory $script:Root | Out-Null
}

function Invoke-GuiProcessTest {
    $guiPath = Join-Path $script:Root 'gui.ps1'
    if (-not (Test-Path -LiteralPath $guiPath -PathType Leaf)) { throw "GUIスクリプトが見つかりません: $guiPath" }
    & powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File $guiPath -ProcessSelfTest @(Get-TestPropagationArguments)
    if ($LASTEXITCODE -ne 0) { throw "GUI Process回帰テストに失敗しました。ExitCode=$LASTEXITCODE" }
}

function Invoke-GuiUsabilityTest {
    $guiPath = Join-Path $script:Root 'gui.ps1'
    if (-not (Test-Path -LiteralPath $guiPath -PathType Leaf)) { throw "GUIスクリプトが見つかりません: $guiPath" }

    $bytes = [System.IO.File]::ReadAllBytes($guiPath)
    if ($bytes.Length -lt 3 -or $bytes[0] -ne 0xEF -or $bytes[1] -ne 0xBB -or $bytes[2] -ne 0xBF) {
        throw 'gui.ps1がUTF-8 BOM付きではありません。'
    }
    Write-Host '  [OK] gui.ps1 UTF-8 BOM'

    $text = [System.IO.File]::ReadAllText($guiPath, [System.Text.Encoding]::UTF8)
    $requiredPatterns = [ordered]@{
        'Ver4.18.0' = 'Ver4\.18\.0'
        'ログクリア処理' = 'ログをクリア[\s\S]{0,300}\$logBox\.Clear\(\)'
        'ログコピー処理' = 'ログをコピー[\s\S]{0,700}Clipboard\]::SetText\(\$logBox\.Text\)'
        'ログフォルダーを開く処理' = 'ログフォルダーを開く[\s\S]{0,500}Get-GuiLogDirectory[\s\S]{0,500}explorer\.exe'
        '最新ログを開く処理' = '最新ログを開く[\s\S]{0,900}Sort-Object\s+LastWriteTime\s+-Descending[\s\S]{0,500}Start-Process'
        'ログ100件保持処理' = 'GuiLogRetentionCount\s*=\s*100[\s\S]*function\s+Trim-GuiLogs[\s\S]*Select-Object\s+-Skip\s+\$script:GuiLogRetentionCount[\s\S]*Remove-Item'
        '実行時間表示処理' = 'function\s+Update-ElapsedDisplay[\s\S]*commandStartedAt[\s\S]*lblElapsedValue[\s\S]*00:00:00'
        'FormClosing時の実行中確認処理' = 'Add_FormClosing[\s\S]*処理が実行中です。終了すると実行中の処理を中断します。GUIを終了しますか？[\s\S]*Clear-CliRuntime\s+\$true[\s\S]*pollTimer\.Dispose'
        '危険操作の確認処理' = 'function\s+New-DangerousOperationMessage[\s\S]*選択中プロジェクト名[\s\S]*対象ブック名[\s\S]*変更される対象[\s\S]*実行確認[\s\S]*\[GUI\] 操作をキャンセルしました。'
        '既存CLI呼出処理' = 'New-CliRunnerContent[\s\S]*powershell\.exe'
    }
    foreach ($entry in $requiredPatterns.GetEnumerator()) {
        if (-not [System.Text.RegularExpressions.Regex]::IsMatch($text, [string]$entry.Value, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
            throw ("GUI Usability要件が見つかりません: {0}" -f $entry.Key)
        }
        Write-Host ("  [OK] {0}" -f $entry.Key)
    }

    $forbiddenPatterns = @(
        'function\s+Invoke-ProjectPush\b',
        'function\s+Invoke-ProjectPull\b',
        'function\s+Invoke-ProjectSync\b',
        'function\s+Get-ProjectDiff\b',
        'function\s+Get-ProjectIntegrityFindings\b',
        'Excel\.Application',
        '\bVBProject\b',
        '\bVBComponents\b'
    )
    foreach ($pattern in $forbiddenPatterns) {
        if ([System.Text.RegularExpressions.Regex]::IsMatch($text, $pattern, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
            throw "CLI処理ロジックまたはExcel/VBAアクセスがgui.ps1へ複製されています。Pattern=$pattern"
        }
    }
    Write-Host '  [OK] CLIロジックはgui.ps1へ複製されていません。'

    $tokens = $null
    $parseErrors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($guiPath, [ref]$tokens, [ref]$parseErrors)
    if (@($parseErrors).Count -gt 0) {
        $details = @($parseErrors | ForEach-Object { $_.Message }) -join ' / '
        throw "gui.ps1のPowerShell構文解析に失敗しました: $details"
    }
    Write-Host '  [OK] gui.ps1 PowerShell構文解析'
    & powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File $guiPath -UsabilitySelfTest @(Get-TestPropagationArguments)
    if ($LASTEXITCODE -ne 0) { throw "GUI Usabilityランタイムセルフテストに失敗しました。ExitCode=$LASTEXITCODE" }
    Write-Host '  [OK] Windows PowerShell 5.1 GUIランタイム初期化'
    Write-Success 'GUI Usability回帰テストに成功しました。'
}


function Get-CodexFileSha256 {
    param([Parameter(Mandatory=$true)][string]$Path)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $stream = $null
    try {
        $stream = [System.IO.File]::OpenRead($Path)
        return ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-','')
    }
    finally {
        if ($null -ne $stream) { $stream.Dispose() }
        $sha.Dispose()
    }
}

function Get-CodexRelativePath {
    param(
        [Parameter(Mandatory=$true)][string]$Root,
        [Parameter(Mandatory=$true)][string]$Path
    )
    $rootFull = [System.IO.Path]::GetFullPath($Root).TrimEnd('\','/')
    $pathFull = [System.IO.Path]::GetFullPath($Path)
    $prefix = $rootFull + [System.IO.Path]::DirectorySeparatorChar
    if (-not $pathFull.StartsWith($prefix,[System.StringComparison]::OrdinalIgnoreCase)) {
        throw "パスが許可されたルート外です: $pathFull"
    }
    return $pathFull.Substring($prefix.Length).Replace('\','/')
}

function Test-CodexSensitiveRelativePath {
    param([Parameter(Mandatory=$true)][string]$RelativePath)
    $name = $RelativePath.Replace('\','/')
    $leaf = [System.IO.Path]::GetFileName($name)
    if ($leaf -match '^(?i:settings\.json|\.env(?:\..*)?|id_rsa|id_dsa|id_ecdsa|id_ed25519)$') { return $true }
    if ($leaf -match '(?i)(secret|credential|api[_-]?key|access[_-]?token)') { return $true }
    if ([System.IO.Path]::GetExtension($leaf) -match '^(?i:\.pem|\.pfx|\.p12|\.key)$') { return $true }
    return $false
}

function Test-CodexExcludedRelativePath {
    param([Parameter(Mandatory=$true)][string]$RelativePath)
    $name = $RelativePath.Replace('\','/').Trim('/')
    if ([string]::IsNullOrWhiteSpace($name)) { return $false }
    $segments = @($name.Split('/'))
    $excludedDirectories = @('.git','target','backups','history','logs','tmp','temp','cache','bin','obj')
    foreach ($segment in $segments) {
        if ($excludedDirectories -contains $segment.ToLowerInvariant()) { return $true }
    }
    $leaf = $segments[$segments.Count - 1]
    if ($leaf.StartsWith('~$',[System.StringComparison]::Ordinal)) { return $true }
    if ($leaf -match '^(?i:Thumbs\.db|desktop\.ini|\.DS_Store)$') { return $true }
    if ($leaf -match '(?i)\.(log|tmp|bak|old|user|suo)$') { return $true }
    if (Test-CodexSensitiveRelativePath -RelativePath $name) { return $true }
    return $false
}

function Test-CodexImportAllowedRelativePath {
    param([Parameter(Mandatory=$true)][string]$RelativePath)
    $name = $RelativePath.Replace('\','/').Trim('/')
    if ([string]::IsNullOrWhiteSpace($name) -or (Test-CodexExcludedRelativePath -RelativePath $name)) { return $false }
    if ($name.StartsWith('source/',[System.StringComparison]::OrdinalIgnoreCase)) { return $true }
    if ($name -match '^(?i:README(?:_[^/]+)?\.md)$') { return $true }
    foreach ($rootName in @('docs','tests','tools')) {
        if ($name.StartsWith(($rootName + '/'),[System.StringComparison]::OrdinalIgnoreCase)) { return $true }
    }
    return $false
}

function Get-CodexImportDisposition {
    param([Parameter(Mandatory=$true)][string]$RelativePath)
    $name = $RelativePath.Replace('\','/').Trim('/')
    if (Test-CodexSensitiveRelativePath -RelativePath $name) { return 'Dangerous' }
    if ($name -match '^(?i:vba\.ps1|vba\.cmd|gui\.ps1|gui\.cmd)$') { return 'Dangerous' }
    if (Test-CodexImportAllowedRelativePath -RelativePath $name) { return 'Allowed' }
    return 'Ignored'
}

function Get-CodexTreeFiles {
    param([Parameter(Mandatory=$true)][string]$Root)
    $result = New-Object 'System.Collections.Generic.List[System.IO.FileInfo]'
    $pending = New-Object 'System.Collections.Generic.Stack[string]'
    $pending.Push([System.IO.Path]::GetFullPath($Root))
    while ($pending.Count -gt 0) {
        $directory = $pending.Pop()
        foreach ($item in @(Get-ChildItem -LiteralPath $directory -Force -ErrorAction Stop)) {
            if (($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
                throw "再解析ポイントはCodex ZIPの処理対象にできません: $($item.FullName)"
            }
            if ($item.PSIsContainer) { $pending.Push($item.FullName) }
            else { $result.Add([System.IO.FileInfo]$item) }
        }
    }
    return $result.ToArray()
}

function Get-CodexExportSelection {
    param([Parameter(Mandatory=$true)][string]$ProjectDirectory)
    $files = New-Object 'System.Collections.Generic.List[object]'
    $directories = New-Object 'System.Collections.Generic.List[string]'
    $ignored = New-Object 'System.Collections.Generic.List[string]'
    $warnings = New-Object 'System.Collections.Generic.List[string]'
    $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)

    $topFiles = New-Object 'System.Collections.Generic.List[string]'
    $topFiles.Add((Join-Path $ProjectDirectory 'project.json'))
    foreach ($readme in @(Get-ChildItem -LiteralPath $ProjectDirectory -File -Force -ErrorAction Stop | Where-Object { $_.Name -match '^(?i:README(?:_[^/]+)?\.md)$' })) {
        $topFiles.Add($readme.FullName)
    }
    foreach ($path in $topFiles) {
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { continue }
        $relative = Get-CodexRelativePath -Root $ProjectDirectory -Path $path
        if ((Test-CodexExcludedRelativePath -RelativePath $relative) -and $relative -ne 'project.json') {
            $ignored.Add($relative)
            continue
        }
        if ($seen.Add($relative)) { $files.Add([PSCustomObject]@{ Path=$path; RelativePath=$relative }) }
    }

    foreach ($directoryName in @('source','docs','tests','tools','templates')) {
        $directoryPath = Join-Path $ProjectDirectory $directoryName
        if (-not (Test-Path -LiteralPath $directoryPath -PathType Container)) { continue }
        $directories.Add($directoryName + '/')
        $treeFiles = @(Get-CodexTreeFiles -Root $directoryPath)
        $nestedProjectRoots = New-Object 'System.Collections.Generic.List[string]'
        foreach ($candidate in $treeFiles) {
            if ($candidate.Name.Equals('project.json',[System.StringComparison]::OrdinalIgnoreCase)) {
                $nestedProjectRoots.Add($candidate.Directory.FullName.TrimEnd('\','/'))
            }
        }
        foreach ($nestedRoot in @($nestedProjectRoots.ToArray() | Sort-Object -Unique)) {
            $warnings.Add('別プロジェクトと判断したサブツリーを除外しました: ' + (Get-CodexRelativePath -Root $ProjectDirectory -Path (Join-Path $nestedRoot 'project.json')))
        }
        foreach ($file in $treeFiles) {
            $relative = Get-CodexRelativePath -Root $ProjectDirectory -Path $file.FullName
            $insideNestedProject = $false
            foreach ($nestedRoot in $nestedProjectRoots) {
                $nestedPrefix = $nestedRoot + [System.IO.Path]::DirectorySeparatorChar
                if ($file.FullName.Equals((Join-Path $nestedRoot 'project.json'),[System.StringComparison]::OrdinalIgnoreCase) -or
                    $file.FullName.StartsWith($nestedPrefix,[System.StringComparison]::OrdinalIgnoreCase)) {
                    $insideNestedProject = $true
                    break
                }
            }
            if ($insideNestedProject) { $ignored.Add($relative); continue }
            if (Test-CodexExcludedRelativePath -RelativePath $relative) {
                $ignored.Add($relative)
                continue
            }
            if ($seen.Add($relative)) { $files.Add([PSCustomObject]@{ Path=$file.FullName; RelativePath=$relative }) }
        }
    }
    return [PSCustomObject]@{
        Files=@($files.ToArray() | Sort-Object RelativePath)
        Directories=@($directories.ToArray() | Sort-Object -Unique)
        Ignored=@($ignored.ToArray() | Sort-Object -Unique)
        Warnings=@($warnings.ToArray())
    }
}

function Test-CodexZipEntryName {
    param([Parameter(Mandatory=$true)][string]$EntryName)
    if ([string]::IsNullOrWhiteSpace($EntryName) -or $EntryName.IndexOf([char]0) -ge 0) { throw 'ZIPに空または不正なエントリ名があります。' }
    if ($EntryName.StartsWith('/') -or $EntryName.StartsWith('\') -or $EntryName -match '^[A-Za-z]:' -or $EntryName.StartsWith('//') -or $EntryName.StartsWith('\\')) {
        throw "ZIPに絶対パスまたはUNCパスがあります: $EntryName"
    }
    $normalized = $EntryName.Replace('\','/').TrimEnd('/')
    if ([string]::IsNullOrWhiteSpace($normalized)) { throw "ZIPに不正なルートエントリがあります: $EntryName" }
    $invalidChars = [System.IO.Path]::GetInvalidFileNameChars()
    $reservedNames = @('CON','PRN','AUX','NUL','COM1','COM2','COM3','COM4','COM5','COM6','COM7','COM8','COM9','LPT1','LPT2','LPT3','LPT4','LPT5','LPT6','LPT7','LPT8','LPT9')
    foreach ($segment in @($normalized.Split('/'))) {
        if ([string]::IsNullOrWhiteSpace($segment) -or $segment -in @('.','..')) { throw "ZIPに不正な相対パスがあります: $EntryName" }
        if ($segment.EndsWith('.') -or $segment.EndsWith(' ')) { throw "ZIPにWindowsで不正なパス名があります: $EntryName" }
        if ($segment.IndexOf(':') -ge 0 -or $segment.IndexOfAny($invalidChars) -ge 0) { throw "ZIPにWindowsで不正な文字を含むパスがあります: $EntryName" }
        $deviceBase = ($segment.Split('.')[0]).ToUpperInvariant()
        if ($reservedNames -contains $deviceBase) { throw "ZIPにWindows予約デバイス名があります: $EntryName" }
    }
    return $normalized
}

function Expand-CodexZipSafely {
    param(
        [Parameter(Mandatory=$true)][string]$ZipPath,
        [Parameter(Mandatory=$true)][string]$Destination
    )
    if ([string]::IsNullOrWhiteSpace($ZipPath)) { throw '-ZipPath を指定してください。' }
    if (-not (Test-Path -LiteralPath $ZipPath -PathType Leaf)) { throw "Codex納品ZIPが見つかりません: $ZipPath" }
    [void](New-Item -ItemType Directory -Path $Destination -Force)
    $destinationFull = [System.IO.Path]::GetFullPath($Destination).TrimEnd('\','/')
    $destinationPrefix = $destinationFull + [System.IO.Path]::DirectorySeparatorChar
    $stream = $null
    $archive = $null
    try {
        $stream = [System.IO.File]::Open($ZipPath,[System.IO.FileMode]::Open,[System.IO.FileAccess]::Read,[System.IO.FileShare]::Read)
        try { $archive = New-Object System.IO.Compression.ZipArchive($stream,[System.IO.Compression.ZipArchiveMode]::Read,$false) }
        catch { throw "有効なZIPファイルではありません: $($_.Exception.Message)" }
        if ($archive.Entries.Count -eq 0) { throw '空のZIPファイルは取り込めません。' }
        if ($archive.Entries.Count -gt 10000) { throw 'ZIPエントリ数が安全上限（10000）を超えています。' }
        $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
        $validated = New-Object 'System.Collections.Generic.List[object]'
        [long]$totalLength = 0
        foreach ($entry in $archive.Entries) {
            $normalized = Test-CodexZipEntryName -EntryName $entry.FullName
            if (-not $seen.Add($normalized)) { throw "ZIPに重複エントリがあります: $normalized" }
            $unixType = (($entry.ExternalAttributes -shr 16) -band 0xF000)
            if ($unixType -eq 0xA000 -or (($entry.ExternalAttributes -band [int][System.IO.FileAttributes]::ReparsePoint) -ne 0)) {
                throw "ZIPにシンボリックリンクまたは再解析ポイント相当のエントリがあります: $normalized"
            }
            if ($entry.Length -gt 134217728) { throw "ZIP内の単一ファイルが安全上限（128MB）を超えています: $normalized" }
            $totalLength += [long]$entry.Length
            if ($totalLength -gt 536870912) { throw 'ZIP展開後サイズが安全上限（512MB）を超えています。' }
            $relativeWindows = $normalized.Replace('/',[System.IO.Path]::DirectorySeparatorChar)
            $target = [System.IO.Path]::GetFullPath((Join-Path $destinationFull $relativeWindows))
            if (-not $target.StartsWith($destinationPrefix,[System.StringComparison]::OrdinalIgnoreCase)) {
                throw "ZIP展開先外へ出るパスを拒否しました: $normalized"
            }
            $isDirectory = $entry.FullName.EndsWith('/') -or $entry.FullName.EndsWith('\') -or [string]::IsNullOrEmpty($entry.Name)
            $validated.Add([PSCustomObject]@{ Entry=$entry; Name=$normalized; Target=$target; IsDirectory=$isDirectory })
        }
        foreach ($item in $validated) {
            if ($item.IsDirectory) {
                [void](New-Item -ItemType Directory -Path $item.Target -Force)
                continue
            }
            $parent = Split-Path -Parent $item.Target
            [void](New-Item -ItemType Directory -Path $parent -Force)
            $input = $null
            $output = $null
            try {
                $input = $item.Entry.Open()
                $output = [System.IO.File]::Open($item.Target,[System.IO.FileMode]::CreateNew,[System.IO.FileAccess]::Write,[System.IO.FileShare]::None)
                $input.CopyTo($output)
            }
            finally {
                if ($null -ne $output) { $output.Dispose() }
                if ($null -ne $input) { $input.Dispose() }
            }
        }
        return @($validated | ForEach-Object { $_.Name })
    }
    finally {
        if ($null -ne $archive) { $archive.Dispose() }
        if ($null -ne $stream) { $stream.Dispose() }
    }
}

function New-CodexZipFromSelection {
    param(
        [Parameter(Mandatory=$true)]$Selection,
        [Parameter(Mandatory=$true)][string]$OutputPath
    )
    $outputDirectory = Split-Path -Parent $OutputPath
    if (-not (Test-Path -LiteralPath $outputDirectory -PathType Container)) { throw "ZIP出力先フォルダーが見つかりません: $outputDirectory" }
    if (Test-Path -LiteralPath $OutputPath) { throw "出力ZIPは既に存在します。別のファイル名を指定してください: $OutputPath" }
    $tempPath = $OutputPath + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
    $stream = $null
    $archive = $null
    try {
        $stream = [System.IO.File]::Open($tempPath,[System.IO.FileMode]::CreateNew,[System.IO.FileAccess]::ReadWrite,[System.IO.FileShare]::None)
        $archive = New-Object System.IO.Compression.ZipArchive($stream,[System.IO.Compression.ZipArchiveMode]::Create,$false)
        foreach ($directory in @($Selection.Directories)) { [void]$archive.CreateEntry($directory) }
        foreach ($file in @($Selection.Files)) {
            $entryName = ([string]$file.RelativePath).Replace('\','/')
            [void][System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,[string]$file.Path,$entryName,[System.IO.Compression.CompressionLevel]::Optimal)
        }
        $archive.Dispose(); $archive=$null
        $stream.Dispose(); $stream=$null
        [System.IO.File]::Move($tempPath,$OutputPath)
    }
    finally {
        if ($null -ne $archive) { $archive.Dispose() }
        if ($null -ne $stream) { $stream.Dispose() }
        if (Test-Path -LiteralPath $tempPath -PathType Leaf) { Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue }
    }
}

function Get-CodexArchiveEntryNames {
    param([Parameter(Mandatory=$true)][string]$ZipPath)
    $archive = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
    try { return @($archive.Entries | ForEach-Object { $_.FullName.Replace('\','/') }) }
    finally { $archive.Dispose() }
}

function Resolve-CodexExportPath {
    param([string]$Project,[string]$OutputDir,[string]$OutputPath)
    if (-not [string]::IsNullOrWhiteSpace($OutputPath) -and -not [string]::IsNullOrWhiteSpace($OutputDir)) {
        throw '-OutputDir と -OutputPath は同時に指定できません。'
    }
    if (-not [string]::IsNullOrWhiteSpace($OutputPath)) {
        $resolved = [System.IO.Path]::GetFullPath($OutputPath)
        if ([System.IO.Path]::GetExtension($resolved) -ne '.zip') { throw '-OutputPath は.zipファイルを指定してください。' }
        return $resolved
    }
    $directory = if ([string]::IsNullOrWhiteSpace($OutputDir)) { (Get-Location).Path } else { [System.IO.Path]::GetFullPath($OutputDir) }
    if (-not (Test-Path -LiteralPath $directory -PathType Container)) { throw "ZIP出力先フォルダーが見つかりません: $directory" }
    $base = $Project + '_Codex_' + [DateTime]::Now.ToString('yyyyMMdd_HHmmss')
    $candidate = Join-Path $directory ($base + '.zip')
    $suffix = 1
    while (Test-Path -LiteralPath $candidate) {
        $candidate = Join-Path $directory ($base + '_' + $suffix.ToString('00') + '.zip')
        $suffix++
    }
    return $candidate
}

function Get-CodexExportResult {
    param([Parameter(Mandatory=$true)][string]$Project,[string]$OutputDir,[string]$OutputPath)
    [void](Test-ProjectCreateName -Project $Project)
    $context = Read-ProjectManifest -Project $Project
    $sourcePath = Join-Path $context.ProjectDir 'source'
    if (-not (Test-Path -LiteralPath $sourcePath -PathType Container)) { throw "sourceフォルダーが見つかりません: $sourcePath" }
    if ($null -ne $context.Manifest.PSObject.Properties['projectName'] -and
        -not [string]::IsNullOrWhiteSpace([string]$context.Manifest.projectName) -and
        -not [string]::Equals([string]$context.Manifest.projectName,$Project,[System.StringComparison]::OrdinalIgnoreCase)) {
        throw "project.jsonのプロジェクト名が指定プロジェクトと一致しません: $($context.Manifest.projectName)"
    }
    $selection = Get-CodexExportSelection -ProjectDirectory $context.ProjectDir
    if (-not (@($selection.Files | Where-Object { $_.RelativePath -eq 'project.json' }).Count -eq 1)) { throw 'エクスポート対象にproject.jsonがありません。' }
    $destination = Resolve-CodexExportPath -Project $Project -OutputDir $OutputDir -OutputPath $OutputPath
    New-CodexZipFromSelection -Selection $selection -OutputPath $destination
    $entries = @(Get-CodexArchiveEntryNames -ZipPath $destination)
    if ($entries -notcontains 'project.json' -or -not (@($entries | Where-Object { $_ -eq 'source/' -or $_.StartsWith('source/') }).Count -gt 0)) {
        Remove-Item -LiteralPath $destination -Force -ErrorAction SilentlyContinue
        throw '作成したZIPの直下構成を検証できませんでした。'
    }
    foreach ($entry in $entries) {
        if ($entry -ne 'project.json' -and (Test-CodexExcludedRelativePath -RelativePath $entry)) {
            Remove-Item -LiteralPath $destination -Force -ErrorAction SilentlyContinue
            throw "作成したZIPに除外対象が含まれています: $entry"
        }
    }
    return [PSCustomObject]@{
        success=$true; project=$Project; zipPath=$destination
        added=@(); modified=@(); deleted=@(); unchanged=@()
        included=@($entries); ignored=@($selection.Ignored); dangerous=@()
        warnings=@($selection.Warnings); errors=@(); backupPath=''; applied=$false
        deletesApplied=$false; syncExecuted=$false
    }
}

function Get-CodexManagedProjectFiles {
    param([Parameter(Mandatory=$true)][string]$ProjectDirectory)
    $items = New-Object 'System.Collections.Generic.List[object]'
    foreach ($readme in @(Get-ChildItem -LiteralPath $ProjectDirectory -File -Force -ErrorAction Stop | Where-Object { $_.Name -match '^(?i:README(?:_[^/]+)?\.md)$' })) {
        $items.Add([PSCustomObject]@{ Path=$readme.FullName; RelativePath=$readme.Name })
    }
    foreach ($directoryName in @('source','docs','tests','tools')) {
        $directoryPath = Join-Path $ProjectDirectory $directoryName
        if (-not (Test-Path -LiteralPath $directoryPath -PathType Container)) { continue }
        $treeFiles = @(Get-CodexTreeFiles -Root $directoryPath)
        $nestedRoots = @($treeFiles | Where-Object { $_.Name.Equals('project.json',[System.StringComparison]::OrdinalIgnoreCase) } | ForEach-Object { $_.Directory.FullName.TrimEnd('\','/') })
        foreach ($file in $treeFiles) {
            $nested = $false
            foreach ($nestedRoot in $nestedRoots) {
                if ($file.FullName.Equals((Join-Path $nestedRoot 'project.json'),[System.StringComparison]::OrdinalIgnoreCase) -or
                    $file.FullName.StartsWith(($nestedRoot + [System.IO.Path]::DirectorySeparatorChar),[System.StringComparison]::OrdinalIgnoreCase)) { $nested=$true;break }
            }
            if ($nested) { continue }
            $relative = Get-CodexRelativePath -Root $ProjectDirectory -Path $file.FullName
            if ((Get-CodexImportDisposition -RelativePath $relative) -eq 'Allowed') {
                $items.Add([PSCustomObject]@{ Path=$file.FullName; RelativePath=$relative })
            }
        }
    }
    return $items.ToArray()
}

function Test-CodexProjectIdentity {
    param(
        [Parameter(Mandatory=$true)][string]$Project,
        [Parameter(Mandatory=$true)]$CurrentContext,
        [Parameter(Mandatory=$true)][string]$ImportedManifestPath,
        [Parameter(Mandatory=$true)]$ImportedManifest,
        [Parameter(Mandatory=$true)]$Warnings
    )
    $folderName = Split-Path -Leaf $CurrentContext.ProjectDir
    if (-not [string]::Equals($folderName,$Project,[System.StringComparison]::OrdinalIgnoreCase)) {
        throw "CLIのプロジェクト名と外部プロジェクトフォルダー名が一致しません: $Project / $folderName"
    }
    $currentName = if ($null -ne $CurrentContext.Manifest.PSObject.Properties['projectName']) { [string]$CurrentContext.Manifest.projectName } else { '' }
    $importName = if ($null -ne $ImportedManifest.PSObject.Properties['projectName']) { [string]$ImportedManifest.projectName } else { '' }
    if (-not [string]::IsNullOrWhiteSpace($currentName) -and -not [string]::Equals($currentName,$Project,[System.StringComparison]::OrdinalIgnoreCase)) {
        throw "現在のproject.jsonのprojectNameが一致しません: $currentName"
    }
    if (-not [string]::IsNullOrWhiteSpace($importName) -and -not [string]::Equals($importName,$Project,[System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Codex納品ZIPは別プロジェクトです。projectName=$importName / Expected=$Project"
    }
    $currentId = if ($null -ne $CurrentContext.Manifest.PSObject.Properties['projectId']) { [string]$CurrentContext.Manifest.projectId } else { '' }
    $importId = if ($null -ne $ImportedManifest.PSObject.Properties['projectId']) { [string]$ImportedManifest.projectId } else { '' }
    if (-not [string]::IsNullOrWhiteSpace($currentId)) {
        if ([string]::IsNullOrWhiteSpace($importId) -or -not [string]::Equals($currentId,$importId,[System.StringComparison]::OrdinalIgnoreCase)) {
            throw 'Codex納品ZIPのprojectIdが現在のプロジェクトと一致しません。'
        }
    }
    elseif (-not [string]::IsNullOrWhiteSpace($importId)) {
        $Warnings.Add('現在のproject.jsonにはprojectIdがないため、projectNameで照合しました。')
    }
    if ([string]::IsNullOrWhiteSpace($currentName) -and [string]::IsNullOrWhiteSpace($importName)) {
        $currentHash = Get-CodexFileSha256 -Path $CurrentContext.ManifestPath
        $importHash = Get-CodexFileSha256 -Path $ImportedManifestPath
        if ($currentHash -ne $importHash) { throw 'projectNameがないためproject.json全体を照合しましたが、一致しません。' }
        $Warnings.Add('projectNameがない旧形式のため、project.json全体の一致で照合しました。')
    }
    return $true
}

function New-CodexImportContext {
    param([Parameter(Mandatory=$true)][string]$Project,[AllowEmptyString()][string]$ZipPath)
    [void](Test-ProjectCreateName -Project $Project)
    if ([string]::IsNullOrWhiteSpace($ZipPath)) { throw '-ZipPath を指定してください。' }
    $zipFull = [System.IO.Path]::GetFullPath($ZipPath)
    if (-not (Test-Path -LiteralPath $zipFull -PathType Leaf)) { throw "Codex納品ZIPが見つかりません: $zipFull" }
    $current = Read-ProjectManifest -Project $Project
    $currentSource = Join-Path $current.ProjectDir 'source'
    if (-not (Test-Path -LiteralPath $currentSource -PathType Container)) { throw "現在のsourceフォルダーが見つかりません: $currentSource" }
    $tempRoot = Join-Path (Get-TestTempBase) ('VBAUpdater_CodexImport_' + [guid]::NewGuid().ToString('N'))
    $extractRoot = Join-Path $tempRoot 'extracted'
    try {
        [void](New-Item -ItemType Directory -Path $extractRoot -Force)
        $entryNames = @(Expand-CodexZipSafely -ZipPath $zipFull -Destination $extractRoot)
        $importManifestPath = Join-Path $extractRoot 'project.json'
        $importSourcePath = Join-Path $extractRoot 'source'
        if (-not (Test-Path -LiteralPath $importManifestPath -PathType Leaf)) { throw 'Codex納品ZIP直下にproject.jsonがありません。' }
        if (-not (Test-Path -LiteralPath $importSourcePath -PathType Container)) { throw 'Codex納品ZIP直下にsourceフォルダーがありません。' }
        try { $importManifest = Get-Content -LiteralPath $importManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json }
        catch { throw "Codex納品ZIPのproject.jsonを読み込めません: $($_.Exception.Message)" }
        $warnings = New-Object 'System.Collections.Generic.List[string]'
        [void](Test-CodexProjectIdentity -Project $Project -CurrentContext $current -ImportedManifestPath $importManifestPath -ImportedManifest $importManifest -Warnings $warnings)

        $incoming = New-Object 'System.Collections.Generic.Dictionary[string,string]' ([System.StringComparer]::OrdinalIgnoreCase)
        $ignored = New-Object 'System.Collections.Generic.List[string]'
        $dangerous = New-Object 'System.Collections.Generic.List[string]'
        $extractedFiles = @(Get-CodexTreeFiles -Root $extractRoot)
        $nestedProjectRoots = @($extractedFiles | Where-Object {
            $_.Name.Equals('project.json',[System.StringComparison]::OrdinalIgnoreCase) -and
            -not $_.FullName.Equals($importManifestPath,[System.StringComparison]::OrdinalIgnoreCase)
        } | ForEach-Object { $_.Directory.FullName.TrimEnd('\','/') })
        foreach ($file in $extractedFiles) {
            $relative = Get-CodexRelativePath -Root $extractRoot -Path $file.FullName
            if ($relative -eq 'project.json') { continue }
            $nestedProject = $false
            foreach ($nestedRoot in $nestedProjectRoots) {
                if ($file.FullName.Equals((Join-Path $nestedRoot 'project.json'),[System.StringComparison]::OrdinalIgnoreCase) -or
                    $file.FullName.StartsWith(($nestedRoot + [System.IO.Path]::DirectorySeparatorChar),[System.StringComparison]::OrdinalIgnoreCase)) { $nestedProject=$true;break }
            }
            $disposition = if ($nestedProject) { 'Dangerous' } else { Get-CodexImportDisposition -RelativePath $relative }
            if ($disposition -eq 'Allowed') { $incoming[$relative] = $file.FullName }
            elseif ($disposition -eq 'Dangerous') { $dangerous.Add($relative) }
            else { $ignored.Add($relative) }
        }
        if ($dangerous.Count -gt 0) { $warnings.Add('危険または個人情報の可能性があるファイルは反映対象外にしました。') }
        if ($ignored.Count -gt 0) { $warnings.Add('target、logs、未対応ファイル等は反映対象外にしました。') }

        $existing = New-Object 'System.Collections.Generic.Dictionary[string,string]' ([System.StringComparer]::OrdinalIgnoreCase)
        foreach ($file in @(Get-CodexManagedProjectFiles -ProjectDirectory $current.ProjectDir)) { $existing[$file.RelativePath] = $file.Path }
        $added = New-Object 'System.Collections.Generic.List[string]'
        $modified = New-Object 'System.Collections.Generic.List[string]'
        $unchanged = New-Object 'System.Collections.Generic.List[string]'
        $deleted = New-Object 'System.Collections.Generic.List[string]'
        foreach ($key in $incoming.Keys) {
            if (-not $existing.ContainsKey($key)) { $added.Add($key) }
            elseif ((Get-CodexFileSha256 -Path $incoming[$key]) -ne (Get-CodexFileSha256 -Path $existing[$key])) { $modified.Add($key) }
            else { $unchanged.Add($key) }
        }
        foreach ($key in $existing.Keys) { if (-not $incoming.ContainsKey($key)) { $deleted.Add($key) } }
        $result = [PSCustomObject]@{
            success=$true; project=$Project; projectMatch=$true; zipPath=$zipFull
            added=@($added.ToArray() | Sort-Object); modified=@($modified.ToArray() | Sort-Object)
            deleted=@($deleted.ToArray() | Sort-Object); unchanged=@($unchanged.ToArray() | Sort-Object)
            ignored=@($ignored.ToArray() | Sort-Object -Unique); dangerous=@($dangerous.ToArray() | Sort-Object -Unique)
            structuralErrors=@(); warnings=@($warnings.ToArray()); errors=@()
            backupPath=''; applied=$false; deletesApplied=$false; syncExecuted=$false
        }
        return [PSCustomObject]@{
            Result=$result; TempRoot=$tempRoot; ExtractRoot=$extractRoot; ProjectDirectory=$current.ProjectDir
            CurrentContext=$current; Incoming=$incoming; EntryNames=$entryNames
        }
    }
    catch {
        if (Test-Path -LiteralPath $tempRoot -PathType Container) { Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue }
        throw
    }
}

function Remove-CodexImportContext {
    param($Context)
    if ($null -ne $Context -and -not [string]::IsNullOrWhiteSpace([string]$Context.TempRoot) -and (Test-Path -LiteralPath $Context.TempRoot -PathType Container)) {
        Remove-Item -LiteralPath $Context.TempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Write-CodexResultJson {
    param([Parameter(Mandatory=$true)]$Result)
    $Result | ConvertTo-Json -Depth 12
}

function Write-CodexPreviewText {
    param([Parameter(Mandatory=$true)]$Result)
    Write-Host 'Codex Import Preview'
    Write-Host ''
    Write-Host ('Project: ' + $Result.project)
    Write-Host ('Project Match: ' + $Result.projectMatch)
    foreach ($group in @(
        [PSCustomObject]@{Name='Added';Items=@($Result.added)},
        [PSCustomObject]@{Name='Modified';Items=@($Result.modified)},
        [PSCustomObject]@{Name='Deleted candidates';Items=@($Result.deleted)},
        [PSCustomObject]@{Name='Unchanged';Items=@($Result.unchanged)},
        [PSCustomObject]@{Name='Ignored';Items=@($Result.ignored)},
        [PSCustomObject]@{Name='Dangerous';Items=@($Result.dangerous)},
        [PSCustomObject]@{Name='Warnings';Items=@($Result.warnings)},
        [PSCustomObject]@{Name='Errors';Items=@($Result.errors)})) {
        Write-Host ''
        Write-Host ($group.Name + ': ' + $group.Items.Count)
        foreach ($item in $group.Items) { Write-Host ('  ' + $item) }
    }
}

function Invoke-CodexExport {
    param([string[]]$Arguments)
    $parsed = Parse-CliArguments -Arguments $Arguments
    $project = Get-CliOption -Parsed $parsed -Name '-Project'
    if ([string]::IsNullOrWhiteSpace($project)) { throw '-Project を指定してください。' }
    $result = Get-CodexExportResult -Project $project -OutputDir (Get-CliOption -Parsed $parsed -Name '-OutputDir') -OutputPath (Get-CliOption -Parsed $parsed -Name '-OutputPath')
    if (Test-CliSwitch -Parsed $parsed -Name '-Json') { Write-CodexResultJson -Result $result; return }
    Write-Host 'Codex用ZIPを作成しました。'
    Write-Host ''
    Write-Host ('Project : ' + $result.project)
    Write-Host ('File    : ' + $result.zipPath)
    Write-Host ('Entries : ' + @($result.included).Count)
    Write-Host ('Excluded: ' + @($result.ignored).Count)
}

function Invoke-CodexImportPreview {
    param([string[]]$Arguments)
    $parsed = Parse-CliArguments -Arguments $Arguments
    $project = Get-CliOption -Parsed $parsed -Name '-Project'
    $zipPath = Get-CliOption -Parsed $parsed -Name '-ZipPath'
    if ([string]::IsNullOrWhiteSpace($project)) { throw '-Project を指定してください。' }
    $context = $null
    try {
        $context = New-CodexImportContext -Project $project -ZipPath $zipPath
        if (Test-CliSwitch -Parsed $parsed -Name '-Json') { Write-CodexResultJson -Result $context.Result }
        else { Write-CodexPreviewText -Result $context.Result }
    }
    finally { Remove-CodexImportContext -Context $context }
}

function Copy-CodexFileSafely {
    param([Parameter(Mandatory=$true)][string]$Source,[Parameter(Mandatory=$true)][string]$Destination)
    $parent = Split-Path -Parent $Destination
    if (-not (Test-Path -LiteralPath $parent -PathType Container)) { [void](New-Item -ItemType Directory -Path $parent -Force) }
    if (Test-Path -LiteralPath $Destination -PathType Leaf) {
        $existing = Get-Item -LiteralPath $Destination -Force
        if (($existing.Attributes -band [System.IO.FileAttributes]::ReadOnly) -ne 0) { $existing.IsReadOnly = $false }
    }
    [System.IO.File]::Copy($Source,$Destination,$true)
}

function Copy-CodexPathTree {
    param([Parameter(Mandatory=$true)][string]$Source,[Parameter(Mandatory=$true)][string]$Destination)
    if (Test-Path -LiteralPath $Source -PathType Leaf) {
        Copy-CodexFileSafely -Source $Source -Destination $Destination
        return
    }
    if (-not (Test-Path -LiteralPath $Source -PathType Container)) { return }
    [void](New-Item -ItemType Directory -Path $Destination -Force)
    foreach ($file in @(Get-CodexTreeFiles -Root $Source)) {
        $relative = Get-CodexRelativePath -Root $Source -Path $file.FullName
        Copy-CodexFileSafely -Source $file.FullName -Destination (Join-Path $Destination $relative.Replace('/',[System.IO.Path]::DirectorySeparatorChar))
    }
}

function Get-CodexTopLevelName {
    param([Parameter(Mandatory=$true)][string]$RelativePath)
    $name = $RelativePath.Replace('\','/').Trim('/')
    $slash = $name.IndexOf('/')
    if ($slash -ge 0) { return $name.Substring(0,$slash) }
    return $name
}

function Test-CodexManagedTopLevelName {
    param([Parameter(Mandatory=$true)][string]$Name)
    if ($Name -in @('source','docs','tests','tools')) { return $true }
    return ($Name -match '^(?i:README(?:_[^/]+)?\.md)$')
}

function New-CodexImportBackup {
    param([Parameter(Mandatory=$true)][string]$ProjectDirectory,[Parameter(Mandatory=$true)][string]$Project)
    $backupDirectory = Join-Path $ProjectDirectory 'backups\codex-import'
    [void](New-Item -ItemType Directory -Path $backupDirectory -Force)
    $baseName = $Project + '_source_before_codex_import_' + [DateTime]::Now.ToString('yyyyMMdd_HHmmss')
    $backupPath = Join-Path $backupDirectory ($baseName + '.zip')
    $suffix = 1
    while (Test-Path -LiteralPath $backupPath) {
        $backupPath = Join-Path $backupDirectory ($baseName + '_' + $suffix.ToString('00') + '.zip')
        $suffix++
    }
    $files = New-Object 'System.Collections.Generic.List[object]'
    $manifestPath = Join-Path $ProjectDirectory 'project.json'
    if (Test-Path -LiteralPath $manifestPath -PathType Leaf) { $files.Add([PSCustomObject]@{Path=$manifestPath;RelativePath='project.json'}) }
    foreach ($file in @(Get-CodexManagedProjectFiles -ProjectDirectory $ProjectDirectory)) { $files.Add($file) }
    $directories = New-Object 'System.Collections.Generic.List[string]'
    foreach ($name in @('source','docs','tests','tools')) {
        if (Test-Path -LiteralPath (Join-Path $ProjectDirectory $name) -PathType Container) { $directories.Add($name + '/') }
    }
    $selection = [PSCustomObject]@{ Files=@($files.ToArray()); Directories=@($directories.ToArray()) }
    New-CodexZipFromSelection -Selection $selection -OutputPath $backupPath
    $backupEntries = @(Get-CodexArchiveEntryNames -ZipPath $backupPath)
    if ($backupEntries -notcontains 'project.json' -or -not (@($backupEntries | Where-Object { $_ -eq 'source/' -or $_.StartsWith('source/') }).Count -gt 0)) {
        Remove-Item -LiteralPath $backupPath -Force -ErrorAction SilentlyContinue
        throw 'Codexインポート前バックアップを検証できませんでした。'
    }
    return $backupPath
}

function Invoke-CodexImportApply {
    param([Parameter(Mandatory=$true)]$Context,[switch]$ApplyDeletes)
    $result = $Context.Result
    $changePaths = New-Object 'System.Collections.Generic.List[string]'
    foreach ($item in @($result.added) + @($result.modified)) { $changePaths.Add([string]$item) }
    if ($ApplyDeletes) { foreach ($item in @($result.deleted)) { $changePaths.Add([string]$item) } }
    if ($changePaths.Count -eq 0) { return $result }

    $topNames = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($relative in $changePaths) {
        $top = Get-CodexTopLevelName -RelativePath $relative
        if (-not (Test-CodexManagedTopLevelName -Name $top)) { throw "反映対象外のトップレベルパスです: $relative" }
        [void]$topNames.Add($top)
    }
    $orderedTopNames = @($topNames | Sort-Object @{Expression={ if ($_ -eq 'source') { 0 } else { 1 } }},@{Expression={$_}})
    $transactionRoot = Join-Path $Context.ProjectDirectory ('.vbaupdater-codex-import-' + [guid]::NewGuid().ToString('N'))
    $stageRoot = Join-Path $transactionRoot 'stage'
    $rollbackRoot = Join-Path $transactionRoot 'rollback'
    $movedOriginal = New-Object 'System.Collections.Generic.List[string]'
    $applied = New-Object 'System.Collections.Generic.List[string]'
    try {
        [void](New-Item -ItemType Directory -Path $stageRoot -Force)
        [void](New-Item -ItemType Directory -Path $rollbackRoot -Force)
        foreach ($top in $orderedTopNames) {
            $currentTop = Join-Path $Context.ProjectDirectory $top
            $stagedTop = Join-Path $stageRoot $top
            if (Test-Path -LiteralPath $currentTop) { Copy-CodexPathTree -Source $currentTop -Destination $stagedTop }
        }
        foreach ($key in $Context.Incoming.Keys) {
            $top = Get-CodexTopLevelName -RelativePath $key
            if ($topNames.Contains($top)) {
                $destination = Join-Path $stageRoot $key.Replace('/',[System.IO.Path]::DirectorySeparatorChar)
                Copy-CodexFileSafely -Source $Context.Incoming[$key] -Destination $destination
            }
        }
        if ($ApplyDeletes) {
            foreach ($relative in @($result.deleted)) {
                $top = Get-CodexTopLevelName -RelativePath $relative
                if (-not $topNames.Contains($top)) { continue }
                $stagedDelete = Join-Path $stageRoot $relative.Replace('/',[System.IO.Path]::DirectorySeparatorChar)
                if (Test-Path -LiteralPath $stagedDelete -PathType Leaf) { Remove-Item -LiteralPath $stagedDelete -Force }
            }
        }
        if ($topNames.Contains('source') -and -not (Test-Path -LiteralPath (Join-Path $stageRoot 'source') -PathType Container)) {
            throw 'ステージング後のsourceフォルダーを検証できません。'
        }

        $backupPath = New-CodexImportBackup -ProjectDirectory $Context.ProjectDirectory -Project $result.project
        $result.backupPath = $backupPath
        foreach ($top in $orderedTopNames) {
            $target = Join-Path $Context.ProjectDirectory $top
            $rollback = Join-Path $rollbackRoot $top
            $stage = Join-Path $stageRoot $top
            if (Test-Path -LiteralPath $target) {
                Move-Item -LiteralPath $target -Destination $rollback
                $movedOriginal.Add($top)
            }
            if (Test-Path -LiteralPath $stage) { Move-Item -LiteralPath $stage -Destination $target }
            $applied.Add($top)
            if ($null -ne $script:CodexImportFailureTestHook) { & $script:CodexImportFailureTestHook $top }
        }
        $result.applied = $true
        $result.deletesApplied = [bool]$ApplyDeletes
        $result.syncExecuted = $false
        return $result
    }
    catch {
        $applyError = $_.Exception.Message
        foreach ($top in @($applied.ToArray() | Sort-Object -Descending)) {
            $target = Join-Path $Context.ProjectDirectory $top
            if (Test-Path -LiteralPath $target -PathType Container) { Remove-Item -LiteralPath $target -Recurse -Force -ErrorAction SilentlyContinue }
            elseif (Test-Path -LiteralPath $target -PathType Leaf) { Remove-Item -LiteralPath $target -Force -ErrorAction SilentlyContinue }
            $rollback = Join-Path $rollbackRoot $top
            if (Test-Path -LiteralPath $rollback) { Move-Item -LiteralPath $rollback -Destination $target -ErrorAction Stop }
        }
        throw "Codexインポートの反映に失敗しました。元のファイルを復元しました: $applyError"
    }
    finally {
        if (Test-Path -LiteralPath $transactionRoot -PathType Container) { Remove-Item -LiteralPath $transactionRoot -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

function Invoke-CodexImport {
    param([string[]]$Arguments)
    $parsed = Parse-CliArguments -Arguments $Arguments
    if (Test-CliSwitch -Parsed $parsed -Name '-Preview') { Invoke-CodexImportPreview -Arguments $Arguments; return }
    $project = Get-CliOption -Parsed $parsed -Name '-Project'
    $zipPath = Get-CliOption -Parsed $parsed -Name '-ZipPath'
    if ([string]::IsNullOrWhiteSpace($project)) { throw '-Project を指定してください。' }
    $json = Test-CliSwitch -Parsed $parsed -Name '-Json'
    $confirmed = Test-CliSwitch -Parsed $parsed -Name '-Confirm'
    $applyDeletes = Test-CliSwitch -Parsed $parsed -Name '-ApplyDeletes'
    $confirmDelete = Test-CliSwitch -Parsed $parsed -Name '-ConfirmDelete'
    $context = $null
    try {
        $context = New-CodexImportContext -Project $project -ZipPath $zipPath
        if (-not $confirmed) {
            if ($json) { throw '-Jsonでインポートを実行する場合は、プレビュー確認後に-Confirmを指定してください。' }
            Write-CodexPreviewText -Result $context.Result
            Write-Host ''
            $answer = Read-Host '既存sourceをバックアップして取り込みますか？ [y/N]'
            if ($answer -notmatch '^(?i:y|yes)$') { Write-Host 'Codexインポートをキャンセルしました。'; return }
        }
        if ($applyDeletes -and -not $confirmDelete) {
            throw '削除候補を反映するには-ApplyDeletesと-ConfirmDeleteの両方を明示してください。'
        }
        $result = Invoke-CodexImportApply -Context $context -ApplyDeletes:$applyDeletes
        if ($json) { Write-CodexResultJson -Result $result; return }
        if ($result.applied) {
            Write-Success 'Codex納品ZIPを取り込みました。'
            Write-Host ('Project: ' + $result.project)
            Write-Host ('Added: ' + @($result.added).Count)
            Write-Host ('Modified: ' + @($result.modified).Count)
            Write-Host ('Deleted candidates: ' + @($result.deleted).Count)
            Write-Host ('Backup: ' + $result.backupPath)
            Write-Host 'ブックを更新するには「ブックを更新する」またはproject-syncを実行してください。'
        }
        else { Write-Host '反映が必要な変更はありません。project-syncは実行していません。' }
    }
    finally { Remove-CodexImportContext -Context $context }
}

function Assert-CodexIntegrationTest {
    param([bool]$Condition,[Parameter(Mandatory=$true)][string]$Message)
    if (-not $Condition) { throw $Message }
    Write-Host ('  [OK] ' + $Message)
}

function Assert-CodexIntegrationThrows {
    param([Parameter(Mandatory=$true)][scriptblock]$Action,[Parameter(Mandatory=$true)][string]$Pattern,[Parameter(Mandatory=$true)][string]$Message)
    $thrown = $false
    try { & $Action }
    catch {
        $thrown = $true
        if ($_.Exception.Message -notmatch $Pattern) { throw "$Message / 予期しないエラー: $($_.Exception.Message)" }
    }
    if (-not $thrown) { throw "$Message / エラーが発生しませんでした。" }
    Write-Host ('  [OK] ' + $Message)
}

function New-CodexTestZipFromDirectory {
    param([Parameter(Mandatory=$true)][string]$SourceDirectory,[Parameter(Mandatory=$true)][string]$ZipPath)
    if (Test-Path -LiteralPath $ZipPath) { Remove-Item -LiteralPath $ZipPath -Force }
    $stream = [System.IO.File]::Open($ZipPath,[System.IO.FileMode]::CreateNew,[System.IO.FileAccess]::ReadWrite,[System.IO.FileShare]::None)
    $archive = New-Object System.IO.Compression.ZipArchive($stream,[System.IO.Compression.ZipArchiveMode]::Create,$false)
    try {
        foreach ($directory in @(Get-ChildItem -LiteralPath $SourceDirectory -Directory -Recurse -Force -ErrorAction Stop)) {
            $relative = (Get-CodexRelativePath -Root $SourceDirectory -Path $directory.FullName).TrimEnd('/') + '/'
            [void]$archive.CreateEntry($relative)
        }
        foreach ($file in @(Get-CodexTreeFiles -Root $SourceDirectory)) {
            $relative = Get-CodexRelativePath -Root $SourceDirectory -Path $file.FullName
            [void][System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$file.FullName,$relative,[System.IO.Compression.CompressionLevel]::Optimal)
        }
    }
    finally { $archive.Dispose(); $stream.Dispose() }
}

function New-CodexTestZipWithEntries {
    param([Parameter(Mandatory=$true)][string]$ZipPath,[hashtable]$Entries=@{})
    if (Test-Path -LiteralPath $ZipPath) { Remove-Item -LiteralPath $ZipPath -Force }
    $stream = [System.IO.File]::Open($ZipPath,[System.IO.FileMode]::CreateNew,[System.IO.FileAccess]::ReadWrite,[System.IO.FileShare]::None)
    $archive = New-Object System.IO.Compression.ZipArchive($stream,[System.IO.Compression.ZipArchiveMode]::Create,$false)
    try {
        foreach ($name in $Entries.Keys) {
            $entry = $archive.CreateEntry([string]$name)
            if ([string]$name -notmatch '[\\/]$') {
                $writer = New-Object System.IO.StreamWriter($entry.Open(),(New-Object System.Text.UTF8Encoding($false)))
                try { $writer.Write([string]$Entries[$name]) }
                finally { $writer.Dispose() }
            }
        }
    }
    finally { $archive.Dispose(); $stream.Dispose() }
}

function Get-CodexDirectoryFingerprint {
    param([Parameter(Mandatory=$true)][string]$Directory)
    $lines = New-Object 'System.Collections.Generic.List[string]'
    foreach ($file in @(Get-CodexTreeFiles -Root $Directory | Sort-Object FullName)) {
        $lines.Add((Get-CodexRelativePath -Root $Directory -Path $file.FullName) + '=' + (Get-CodexFileSha256 -Path $file.FullName))
    }
    $bytes = [System.Text.Encoding]::UTF8.GetBytes(($lines.ToArray() -join "`n"))
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','') }
    finally { $sha.Dispose() }
}

function Invoke-CodexIntegrationTest {
    $originalOverride = $script:ProjectRootOverride
    $originalSettings = [Environment]::GetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable,'Process')
    $tempName=if($null-ne$script:TestExecutionContext){'Codex_日本語'}else{'VBAUpdater Codex 日本語 ' + [guid]::NewGuid().ToString('N')}
    $tempRoot = Join-Path (Get-TestTempBase) $tempName
    $projectRoot = Join-Path $tempRoot 'OneDrive 外部 Projects'
    $projectDir = Join-Path $projectRoot 'PropertyManagement'
    $outputDir = Join-Path $tempRoot 'Codex ZIP 出力'
    $returnDir = Join-Path $tempRoot 'Codex 納品 展開'
    try {
        foreach ($directory in @(
            (Join-Path $projectDir 'source\standard'),(Join-Path $projectDir 'target'),(Join-Path $projectDir 'backups'),
            (Join-Path $projectDir 'logs'),(Join-Path $projectDir 'docs\長いパス name'),(Join-Path $projectDir 'docs\EmbeddedOther\source'),(Join-Path $projectDir 'tests'),
            (Join-Path $projectDir 'tools'),(Join-Path $projectDir 'templates'),(Join-Path $projectRoot 'OtherProject\source'),$outputDir)) {
            [void](New-Item -ItemType Directory -Path $directory -Force)
        }
        $manifest = [ordered]@{schemaVersion='1.0';projectName='PropertyManagement';projectId='codex-integration-test-id';source=[ordered]@{root='source'}} | ConvertTo-Json -Depth 5
        [System.IO.File]::WriteAllText((Join-Path $projectDir 'project.json'),$manifest,(New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllText((Join-Path $projectDir 'source\standard\modMain.bas'),'ORIGINAL',(New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllText((Join-Path $projectDir 'source\standard\modOld.bas'),'KEEP-BY-DEFAULT',(New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllText((Join-Path $projectDir 'target\PropertyManagement.xlsm'),'TARGET-UNCHANGED',(New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllText((Join-Path $projectDir 'backups\old.zip'),'BACKUP-EXCLUDED',(New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllText((Join-Path $projectDir 'logs\run.log'),'LOG-EXCLUDED',(New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllText((Join-Path $projectDir 'docs\長いパス name\guide.md'),'GUIDE',(New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllText((Join-Path $projectDir 'docs\readonly.md'),'READONLY',(New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllText((Join-Path $projectDir 'docs\EmbeddedOther\project.json'),'{"projectName":"EmbeddedOther"}',(New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllText((Join-Path $projectDir 'docs\EmbeddedOther\source\secret.bas'),'MUST-NOT-EXPORT',(New-Object System.Text.UTF8Encoding($false)))
        (Get-Item -LiteralPath (Join-Path $projectDir 'docs\readonly.md')).IsReadOnly = $true
        [System.IO.File]::WriteAllText((Join-Path $projectDir 'tests\test.txt'),'TEST',(New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllText((Join-Path $projectDir 'tools\tool.ps1'),'TOOL',(New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllText((Join-Path $projectDir 'templates\template.txt'),'TEMPLATE',(New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllText((Join-Path $projectDir 'README.md'),'README',(New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllText((Join-Path $projectRoot 'OtherProject\project.json'),'{}',(New-Object System.Text.UTF8Encoding($false)))
        $script:ProjectRootOverride = $projectRoot

        $export = Get-CodexExportResult -Project 'PropertyManagement' -OutputDir $outputDir
        Assert-CodexIntegrationTest -Condition (Test-Path -LiteralPath $export.zipPath -PathType Leaf) -Message '1. 正常なCodexエクスポート'
        $entries = @(Get-CodexArchiveEntryNames -ZipPath $export.zipPath)
        Assert-CodexIntegrationTest -Condition ($entries -contains 'project.json' -and @($entries | Where-Object { $_ -eq 'source/' -or $_.StartsWith('source/') }).Count -gt 0) -Message '2. ZIP直下にproject.jsonとsource'
        Assert-CodexIntegrationTest -Condition (@($entries | Where-Object { $_.StartsWith('target/') }).Count -eq 0) -Message '3. target除外'
        Assert-CodexIntegrationTest -Condition (@($entries | Where-Object { $_.StartsWith('backups/') }).Count -eq 0) -Message '4. backups除外'
        Assert-CodexIntegrationTest -Condition (@($entries | Where-Object { $_.StartsWith('logs/') -or $_ -match '\.log$' }).Count -eq 0) -Message '5. logs除外'
        Assert-CodexIntegrationTest -Condition (@($entries | Where-Object { $_ -match '(?i)OtherProject|EmbeddedOther' }).Count -eq 0) -Message '6. 他プロジェクト非混入'
        Assert-CodexIntegrationTest -Condition (@($entries | Where-Object { $_ -match '^(?i:vba\.ps1|gui\.ps1|vba\.cmd)$' }).Count -eq 0) -Message '7. VBAUpdater本体非混入'
        Assert-CodexIntegrationThrows -Action { Get-CodexExportResult -Project 'PropertyManagement' -OutputPath $export.zipPath | Out-Null } -Pattern '既に存在' -Message '既存OutputPathの無条件上書き拒否'

        $unchangedContext = New-CodexImportContext -Project 'PropertyManagement' -ZipPath $export.zipPath
        try { Assert-CodexIntegrationTest -Condition (@($unchangedContext.Result.added).Count -eq 0 -and @($unchangedContext.Result.modified).Count -eq 0 -and @($unchangedContext.Result.deleted).Count -eq 0) -Message '変更なしZIPのプレビュー' }
        finally { Remove-CodexImportContext -Context $unchangedContext }

        [void](New-Item -ItemType Directory -Path $returnDir -Force)
        [void](Expand-CodexZipSafely -ZipPath $export.zipPath -Destination $returnDir)
        [System.IO.File]::WriteAllText((Join-Path $returnDir 'source\standard\modMain.bas'),'CODEX-MODIFIED',(New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllText((Join-Path $returnDir 'source\standard\modNew.bas'),'CODEX-ADDED',(New-Object System.Text.UTF8Encoding($false)))
        Remove-Item -LiteralPath (Join-Path $returnDir 'source\standard\modOld.bas') -Force
        [void](New-Item -ItemType Directory -Path (Join-Path $returnDir 'target') -Force)
        [void](New-Item -ItemType Directory -Path (Join-Path $returnDir 'logs') -Force)
        [void](New-Item -ItemType Directory -Path (Join-Path $returnDir 'docs\ReturnedOther\source') -Force)
        [System.IO.File]::WriteAllText((Join-Path $returnDir 'target\foreign.xlsm'),'IGNORED',(New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllText((Join-Path $returnDir 'logs\codex.log'),'IGNORED',(New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllText((Join-Path $returnDir 'docs\ReturnedOther\project.json'),'{"projectName":"ReturnedOther"}',(New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllText((Join-Path $returnDir 'docs\ReturnedOther\source\foreign.bas'),'DANGEROUS',(New-Object System.Text.UTF8Encoding($false)))
        [System.IO.File]::WriteAllText((Join-Path $returnDir 'settings.json'),'DANGEROUS',(New-Object System.Text.UTF8Encoding($false)))
        $resultZip = Join-Path $outputDir 'PropertyManagement_Codex_Result.zip'
        New-CodexTestZipFromDirectory -SourceDirectory $returnDir -ZipPath $resultZip

        $previewContext = New-CodexImportContext -Project 'PropertyManagement' -ZipPath $resultZip
        try {
            $preview = $previewContext.Result
            Assert-CodexIntegrationTest -Condition ($preview.projectMatch -and $preview.success) -Message '8. 正常なインポートプレビュー'
            Assert-CodexIntegrationTest -Condition ($preview.added -contains 'source/standard/modNew.bas') -Message '9. 追加ファイル検出'
            Assert-CodexIntegrationTest -Condition ($preview.modified -contains 'source/standard/modMain.bas') -Message '10. 変更ファイル検出'
            Assert-CodexIntegrationTest -Condition ($preview.deleted -contains 'source/standard/modOld.bas') -Message '11. 削除候補検出'
            Assert-CodexIntegrationTest -Condition (@($preview.dangerous | Where-Object { $_ -match 'ReturnedOther' }).Count -gt 0) -Message '返却ZIP内の別プロジェクトを反映対象外として検出'
            $jsonRoundTrip = ($preview | ConvertTo-Json -Depth 12) | ConvertFrom-Json
            Assert-CodexIntegrationTest -Condition ($jsonRoundTrip.success -and $null -ne $jsonRoundTrip.added -and $null -ne $jsonRoundTrip.errors) -Message '22. GUI用JSON結果の妥当性'
        }
        finally { Remove-CodexImportContext -Context $previewContext }

        $settingsPath = Join-Path $tempRoot 'settings test.json'
        $settingsJson = [ordered]@{schemaVersion='1.0';projectRoot=$projectRoot} | ConvertTo-Json
        [System.IO.File]::WriteAllText($settingsPath,$settingsJson,(New-Object System.Text.UTF8Encoding($false)))
        [Environment]::SetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable,$settingsPath,'Process')
        $childJsonLines = @(& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $script:Root 'vba.ps1') codex-import-preview -Project PropertyManagement -ZipPath $resultZip -Json @(Get-TestPropagationArguments) 2>&1)
        if ($LASTEXITCODE -ne 0) { throw 'codex-import-preview -Json 子プロセスが失敗しました: ' + ($childJsonLines -join ' / ') }
        $childJson = ($childJsonLines -join [Environment]::NewLine) | ConvertFrom-Json
        Assert-CodexIntegrationTest -Condition ($childJson.success -and $childJson.project -eq 'PropertyManagement') -Message '-Json標準出力が有効なJSONのみ'

        $targetHashBefore = Get-CodexFileSha256 -Path (Join-Path $projectDir 'target\PropertyManagement.xlsm')
        $applyContext = New-CodexImportContext -Project 'PropertyManagement' -ZipPath $resultZip
        try { $applyResult = Invoke-CodexImportApply -Context $applyContext }
        finally { Remove-CodexImportContext -Context $applyContext }
        Assert-CodexIntegrationTest -Condition (Test-Path -LiteralPath (Join-Path $projectDir 'source\standard\modOld.bas') -PathType Leaf) -Message '12. 既定では削除されない'
        Assert-CodexIntegrationTest -Condition (-not [string]::IsNullOrWhiteSpace($applyResult.backupPath) -and (Test-Path -LiteralPath $applyResult.backupPath -PathType Leaf)) -Message '13. インポート前バックアップ作成'
        $backupEntries = @(Get-CodexArchiveEntryNames -ZipPath $applyResult.backupPath)
        Assert-CodexIntegrationTest -Condition ($backupEntries -contains 'project.json' -and @($backupEntries | Where-Object { $_.StartsWith('source/') }).Count -gt 0) -Message 'バックアップにproject.json・source・既存文書を格納'
        Assert-CodexIntegrationTest -Condition (([System.IO.File]::ReadAllText((Join-Path $projectDir 'source\standard\modMain.bas'))) -eq 'CODEX-MODIFIED' -and (Test-Path -LiteralPath (Join-Path $projectDir 'source\standard\modNew.bas'))) -Message '14. 正常なsource反映'
        Assert-CodexIntegrationTest -Condition (-not (Test-Path -LiteralPath (Join-Path $projectDir 'docs\ReturnedOther'))) -Message '別プロジェクトのサブツリーを自動反映しない'
        Assert-CodexIntegrationTest -Condition ((Get-CodexFileSha256 -Path (Join-Path $projectDir 'target\PropertyManagement.xlsm')) -eq $targetHashBefore -and -not $applyResult.syncExecuted) -Message '24. インポート後project-sync非実行'

        $correctManifest = [System.IO.File]::ReadAllText((Join-Path $returnDir 'project.json'),[System.Text.Encoding]::UTF8)
        $otherManifest = [ordered]@{schemaVersion='1.0';projectName='OtherProject';projectId='other-id';source=[ordered]@{root='source'}} | ConvertTo-Json -Depth 5
        [System.IO.File]::WriteAllText((Join-Path $returnDir 'project.json'),$otherManifest,(New-Object System.Text.UTF8Encoding($false)))
        $mismatchZip = Join-Path $outputDir 'mismatch.zip'; New-CodexTestZipFromDirectory -SourceDirectory $returnDir -ZipPath $mismatchZip
        Assert-CodexIntegrationThrows -Action { $c=New-CodexImportContext -Project 'PropertyManagement' -ZipPath $mismatchZip; Remove-CodexImportContext $c } -Pattern '別プロジェクト|projectId' -Message '15. プロジェクト不一致拒否'
        [System.IO.File]::WriteAllText((Join-Path $returnDir 'project.json'),$correctManifest,(New-Object System.Text.UTF8Encoding($false)))

        $missingManifestZip=Join-Path $outputDir 'missing-project-json.zip'; New-CodexTestZipWithEntries -ZipPath $missingManifestZip -Entries @{'source/'='';'source/mod.bas'='x'}
        Assert-CodexIntegrationThrows -Action { $c=New-CodexImportContext -Project 'PropertyManagement' -ZipPath $missingManifestZip; Remove-CodexImportContext $c } -Pattern 'project.json' -Message '16. project.json欠落拒否'
        $missingSourceZip=Join-Path $outputDir 'missing-source.zip'; New-CodexTestZipWithEntries -ZipPath $missingSourceZip -Entries @{'project.json'=$correctManifest}
        Assert-CodexIntegrationThrows -Action { $c=New-CodexImportContext -Project 'PropertyManagement' -ZipPath $missingSourceZip; Remove-CodexImportContext $c } -Pattern 'sourceフォルダー' -Message '17. source欠落拒否'
        $invalidZip=Join-Path $outputDir 'invalid.zip'; [System.IO.File]::WriteAllText($invalidZip,'not a zip',(New-Object System.Text.UTF8Encoding($false)))
        Assert-CodexIntegrationThrows -Action { $c=New-CodexImportContext -Project 'PropertyManagement' -ZipPath $invalidZip; Remove-CodexImportContext $c } -Pattern 'ZIP' -Message '18. 不正ZIP拒否'
        $slipZip=Join-Path $outputDir 'zip-slip.zip'; New-CodexTestZipWithEntries -ZipPath $slipZip -Entries @{'../evil.txt'='bad'}
        Assert-CodexIntegrationThrows -Action { $c=New-CodexImportContext -Project 'PropertyManagement' -ZipPath $slipZip; Remove-CodexImportContext $c } -Pattern '不正な相対パス|展開先外' -Message '19. Zip Slip拒否'
        $absoluteZip=Join-Path $outputDir 'absolute.zip'; New-CodexTestZipWithEntries -ZipPath $absoluteZip -Entries @{'C:/evil.txt'='bad'}
        Assert-CodexIntegrationThrows -Action { $c=New-CodexImportContext -Project 'PropertyManagement' -ZipPath $absoluteZip; Remove-CodexImportContext $c } -Pattern '絶対パス|不正' -Message '20. 絶対パス拒否'
        $emptyZip=Join-Path $outputDir 'empty.zip'; New-CodexTestZipWithEntries -ZipPath $emptyZip
        Assert-CodexIntegrationThrows -Action { $c=New-CodexImportContext -Project 'PropertyManagement' -ZipPath $emptyZip; Remove-CodexImportContext $c } -Pattern '空のZIP' -Message '21. 空ZIP拒否'
        Assert-CodexIntegrationThrows -Action { New-CodexImportContext -Project 'PropertyManagement' -ZipPath '' | Out-Null } -Pattern 'ZipPath' -Message '23. 空文字Path回帰'

        [System.IO.File]::WriteAllText((Join-Path $returnDir 'source\standard\modMain.bas'),'FAILURE-SHOULD-ROLLBACK',(New-Object System.Text.UTF8Encoding($false)))
        $failureZip=Join-Path $outputDir 'failure.zip'; New-CodexTestZipFromDirectory -SourceDirectory $returnDir -ZipPath $failureZip
        $sourceHashBefore = Get-CodexDirectoryFingerprint -Directory (Join-Path $projectDir 'source')
        $failureContext = New-CodexImportContext -Project 'PropertyManagement' -ZipPath $failureZip
        $script:CodexImportFailureTestHook = { param($top) if ($top -eq 'source') { throw '模擬反映失敗' } }
        try { Assert-CodexIntegrationThrows -Action { Invoke-CodexImportApply -Context $failureContext | Out-Null } -Pattern '元のファイルを復元' -Message '反映失敗時ロールバック実行' }
        finally { $script:CodexImportFailureTestHook=$null; Remove-CodexImportContext -Context $failureContext }
        Assert-CodexIntegrationTest -Condition ((Get-CodexDirectoryFingerprint -Directory (Join-Path $projectDir 'source')) -eq $sourceHashBefore) -Message '25. 失敗時に元source維持'

        $guiPath = Join-Path $script:Root 'gui.ps1'
        & powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File $guiPath -CodexIntegrationSelfTest @(Get-TestPropagationArguments)
        if ($LASTEXITCODE -ne 0) { throw "Codex連携GUIセルフテストに失敗しました。ExitCode=$LASTEXITCODE" }
        Assert-CodexIntegrationTest -Condition $true -Message '開発者向けGUI・イベント安全性・CLI JSON接続'
        Write-Success 'Chapter12-3 Codex Integration統合テストに成功しました。'
    }
    finally {
        $script:CodexImportFailureTestHook = $null
        $script:ProjectRootOverride = $originalOverride
        [Environment]::SetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable,$originalSettings,'Process')
        if (Test-Path -LiteralPath $tempRoot -PathType Container) { Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue }
    }
}


function Invoke-GuiRenewalTest {
    $guiPath = Join-Path $script:Root 'gui.ps1'
    if (-not (Test-Path -LiteralPath $guiPath -PathType Leaf)) { throw "GUIスクリプトが見つかりません: $guiPath" }

    $bytes = [System.IO.File]::ReadAllBytes($guiPath)
    if ($bytes.Length -lt 3 -or $bytes[0] -ne 0xEF -or $bytes[1] -ne 0xBB -or $bytes[2] -ne 0xBF) {
        throw 'gui.ps1がUTF-8 BOM付きではありません。'
    }
    Write-Host '  [OK] gui.ps1 UTF-8 BOM'

    $tokens = $null
    $parseErrors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($guiPath, [ref]$tokens, [ref]$parseErrors)
    if (@($parseErrors).Count -gt 0) {
        $details = @($parseErrors | ForEach-Object { $_.Message }) -join ' / '
        throw "gui.ps1のPowerShell構文解析に失敗しました: $details"
    }
    Write-Host '  [OK] gui.ps1 PowerShell構文解析'

    & powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File $guiPath -RenewalSelfTest @(Get-TestPropagationArguments)
    if ($LASTEXITCODE -ne 0) { throw "GUI Renewal回帰テストに失敗しました。ExitCode=$LASTEXITCODE" }
    Write-Success 'GUI Renewal回帰テストに成功しました。'
}

function Invoke-ProjectRegistrationTest {
    $guiPath = Join-Path $script:Root 'gui.ps1'
    if (-not (Test-Path -LiteralPath $guiPath -PathType Leaf)) { throw "GUIスクリプトが見つかりません: $guiPath" }

    $bytes = [System.IO.File]::ReadAllBytes($guiPath)
    if ($bytes.Length -lt 3 -or $bytes[0] -ne 0xEF -or $bytes[1] -ne 0xBB -or $bytes[2] -ne 0xBF) {
        throw 'gui.ps1がUTF-8 BOM付きではありません。'
    }
    Write-Host '  [OK] gui.ps1 UTF-8 BOM'

    $tokens = $null
    $parseErrors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($guiPath, [ref]$tokens, [ref]$parseErrors)
    if (@($parseErrors).Count -gt 0) {
        $details = @($parseErrors | ForEach-Object { $_.Message }) -join ' / '
        throw "gui.ps1のPowerShell構文解析に失敗しました: $details"
    }
    Write-Host '  [OK] gui.ps1 PowerShell構文解析'

    & powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File $guiPath -RegistrationSelfTest @(Get-TestPropagationArguments)
    if ($LASTEXITCODE -ne 0) { throw "GUI Initial Project Registration回帰テストに失敗しました。ExitCode=$LASTEXITCODE" }
    Write-Success 'GUI Initial Project Registration回帰テストに成功しました。'
}

function Invoke-ProjectRegistrationHotFixTest {
    $guiPath = Join-Path $script:Root 'gui.ps1'
    if (-not (Test-Path -LiteralPath $guiPath -PathType Leaf)) { throw "GUIスクリプトが見つかりません: $guiPath" }

    $bytes = [System.IO.File]::ReadAllBytes($guiPath)
    if ($bytes.Length -lt 3 -or $bytes[0] -ne 0xEF -or $bytes[1] -ne 0xBB -or $bytes[2] -ne 0xBF) {
        throw 'gui.ps1がUTF-8 BOM付きではありません。'
    }
    $tokens = $null
    $parseErrors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($guiPath,[ref]$tokens,[ref]$parseErrors)
    if (@($parseErrors).Count -gt 0) {
        $details = @($parseErrors | ForEach-Object { $_.Message }) -join ' / '
        throw "gui.ps1のPowerShell構文解析に失敗しました: $details"
    }

    & powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File $guiPath -RegistrationHotFixSelfTest @(Get-TestPropagationArguments)
    if ($LASTEXITCODE -ne 0) { throw "GUI Chapter12-1 HotFix回帰テストに失敗しました。ExitCode=$LASTEXITCODE" }
    Write-Success 'Chapter12-1 Registration Wizard HotFix回帰テストに成功しました。'
}

function Invoke-ProjectFolderDirectReferenceTest {
    Write-Info 'Chapter12-4 Project Folder Direct Reference回帰テストを実行しています...'
    $tempRoot=Join-Path (Get-TestTempBase) ('VBAUpdater直接参照 OneDrive (Test)_'+[guid]::NewGuid().ToString('N'))
    $oldSettings=[Environment]::GetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable)
    $oldRootOverride=$script:ProjectRootOverride
    $oldDirectOverride=$script:DirectProjectPathOverride
    $oldWorkbookOverride=$script:DirectWorkbookPathOverride
    try {
        New-Item -ItemType Directory -Path $tempRoot -Force|Out-Null
        $settingsPath=Join-Path $tempRoot 'settings\settings.json'
        [Environment]::SetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable,$settingsPath)

        function New-DirectFixture {
            param([string]$Name,[string]$ConfiguredFile='',[string[]]$WorkbookNames=@(),[switch]$Git,[switch]$NoSource,[switch]$NoTarget,[switch]$SameFolders)
            $projectPath=Join-Path $tempRoot $Name
            New-Item -ItemType Directory -Path $projectPath -Force|Out-Null
            $sourceRelative=if($SameFolders){'same'}else{'source'}
            $targetRelative=if($SameFolders){'same'}else{'target'}
            if(-not $NoSource){New-Item -ItemType Directory -Path (Join-Path $projectPath $sourceRelative) -Force|Out-Null;[System.IO.File]::WriteAllText((Join-Path $projectPath (Join-Path $sourceRelative 'modTest.bas')),"Attribute VB_Name = `"modTest`"`r`nOption Explicit`r`n")}
            if(-not $NoTarget){New-Item -ItemType Directory -Path (Join-Path $projectPath $targetRelative) -Force|Out-Null}
            if($Git){New-Item -ItemType Directory -Path (Join-Path $projectPath '.git\objects') -Force|Out-Null;[System.IO.File]::WriteAllText((Join-Path $projectPath '.git\objects\ignored.xlsm'),'must not scan')}
            foreach($workbookName in $WorkbookNames){[System.IO.File]::WriteAllText((Join-Path $projectPath (Join-Path $targetRelative $workbookName)),'workbook placeholder')}
            $target=[ordered]@{directory=$targetRelative;autoDetectWhenMissing=$true}
            if(-not [string]::IsNullOrWhiteSpace($ConfiguredFile)){$target['file']=$ConfiguredFile}
            $manifest=[ordered]@{schemaVersion='1.0';projectName=$Name;target=$target;source=[ordered]@{root=$sourceRelative};components=@([ordered]@{type='standard';name='modTest';file='modTest.bas'});validation=[ordered]@{compileAfterPush=$false}}
            [System.IO.File]::WriteAllText((Join-Path $projectPath 'project.json'),($manifest|ConvertTo-Json -Depth 8),(New-Object System.Text.UTF8Encoding($false)))
            return $projectPath
        }

        $one=New-DirectFixture -Name '日本語 Project (OneDrive)' -ConfiguredFile 'Main.xlsm' -WorkbookNames @('Main.xlsm','Fallback.xlam') -Git
        $oneResult=Get-ProjectFolderCheckResult -Path $one
        if(-not $oneResult.IsAvailable -or -not $oneResult.CanPush -or $oneResult.WorkbookSelectionStatus -ne 'Configured' -or -not $oneResult.IsGitRepository){throw 'configured workbook/Git直接判定に失敗しました。'}
        if([System.IO.Path]::GetFileName($oneResult.WorkbookPath) -ne 'Main.xlsm'){throw 'manifest targetの優先判定に失敗しました。'}
        Write-Host '  [OK] 日本語・空白・括弧・OneDrive相当パス / manifest target / Git有り'

        foreach($leafName in @('source','target')){
            $corrected=Get-ProjectFolderCheckResult -Path (Join-Path $one $leafName)
            if(-not $corrected.Corrected -or -not (Test-PathsEqual $corrected.ProjectRoot $one)){throw "$leafName選択時の親フォルダー補正に失敗しました。"}
        }
        Write-Host '  [OK] source/target誤選択を親プロジェクトへ安全に補正'

        $multi=New-DirectFixture -Name 'MultipleBooks' -WorkbookNames @('A.xlsm','B.xlsm','Lower.xlam')
        $multiResult=Get-ProjectFolderCheckResult -Path $multi
        if(-not $multiResult.IsAvailable -or $multiResult.CanPush -or $multiResult.WorkbookSelectionStatus -ne 'Multiple' -or @($multiResult.WorkbookCandidates).Count -ne 2){throw '複数ブック選択待ち判定に失敗しました。'}
        $chosen=Get-ProjectFolderCheckResult -Path $multi -WorkbookPath (Join-Path $multi 'target\B.xlsm')
        if(-not $chosen.CanPush -or $chosen.WorkbookSelectionStatus -ne 'Explicit'){throw '複数ブック明示選択に失敗しました。'}
        Write-Host '  [OK] .xlsm優先の複数候補 / 明示選択'

        $zero=New-DirectFixture -Name 'ZeroBooks' -Git:$false
        $zeroResult=Get-ProjectFolderCheckResult -Path $zero
        if(-not $zeroResult.IsAvailable -or $zeroResult.CanPush -or $zeroResult.WorkbookSelectionStatus -ne 'Missing'){throw '対象ブック0件の保存可能判定に失敗しました。'}
        Write-Host '  [OK] 対象ブック0件でもプロジェクト選択可能 / .git配下を非検出'

        $xlam=New-DirectFixture -Name 'XlamPriority' -WorkbookNames @('Addin.xlam','Binary.xlsb')
        $xlamResult=Get-ProjectFolderCheckResult -Path $xlam
        if([System.IO.Path]::GetExtension($xlamResult.WorkbookPath) -ne '.xlam'){throw '.xlam優先判定に失敗しました。'}
        Write-Host '  [OK] 拡張子優先順 .xlsm > .xlam > .xlsb'

        $missingSource=New-DirectFixture -Name 'MissingSource' -WorkbookNames @('Book.xlsm') -NoSource
        if((Get-ProjectFolderCheckResult -Path $missingSource).IsAvailable){throw 'source欠落を利用可能と判定しました。'}
        $missingTarget=New-DirectFixture -Name 'MissingTarget' -NoTarget
        if((Get-ProjectFolderCheckResult -Path $missingTarget).IsAvailable){throw 'target欠落を利用可能と判定しました。'}
        $same=New-DirectFixture -Name 'SameFolders' -WorkbookNames @('Book.xlsm') -SameFolders
        if((Get-ProjectFolderCheckResult -Path $same).IsAvailable){throw 'sourceとtargetの同一指定を許可しました。'}
        Write-Host '  [OK] source/target欠落・同一パスを安全に拒否'

        $saved=Get-ProjectFolderCheckResult -Path $one
        $parent=Split-Path -Parent $saved.ProjectRoot
        [void](Write-ProjectRootSettings -ProjectRoot $parent -LastProjectRoot $saved.ProjectRoot -LastWorkbookPath $saved.WorkbookPath)
        $script:ProjectRootOverride=$null;$script:DirectProjectPathOverride=$null
        $settingsInfo=Get-ProjectRootInfo
        if(-not (Test-PathsEqual $settingsInfo.Path $parent) -or -not (Test-PathsEqual $settingsInfo.LastProjectRoot $one) -or -not $settingsInfo.LastProjectExists){throw '最後に開いたプロジェクトの設定保存・復元に失敗しました。'}
        Write-Host '  [OK] schemaVersion 1.0互換設定へlastProjectRoot/lastWorkbookPathを追加・復元'

        $script:ProjectRootOverride=$parent;$script:DirectProjectPathOverride=$null
        if(-not (Test-PathsEqual (Resolve-ProjectPath -Project ([System.IO.Path]::GetFileName($one))) $one)){throw '旧 -ProjectRoot parent -Project name互換に失敗しました。'}
        $script:DirectProjectPathOverride=$one
        if(-not (Test-PathsEqual (Resolve-ProjectPath -Project ([System.IO.Path]::GetFileName($one))) $one)){throw '直接 -ProjectRoot解決に失敗しました。'}
        Write-Host '  [OK] 旧2方式と直接ProjectRoot方式のパス解決互換'

        $testPropagation=@(Get-TestPropagationArguments)
        $directPreflight=@(& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $script:Root 'vba.ps1') project-preflight -ProjectRoot $one @testPropagation 2>&1)
        if($LASTEXITCODE -ne 0 -or ($directPreflight -join "`n") -notmatch 'Manifest検証に成功'){throw ('直接ProjectRootだけのCLI Preflightに失敗しました: '+($directPreflight -join ' / '))}
        $legacyPreflight=@(& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $script:Root 'vba.ps1') project-preflight -Project ([System.IO.Path]::GetFileName($one)) -ProjectRoot $parent @testPropagation 2>&1)
        if($LASTEXITCODE -ne 0 -or ($legacyPreflight -join "`n") -notmatch 'Manifest検証に成功'){throw ('旧Project/ProjectRoot CLI Preflightに失敗しました: '+($legacyPreflight -join ' / '))}
        $savedPreflight=@(& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $script:Root 'vba.ps1') project-preflight @testPropagation 2>&1)
        if($LASTEXITCODE -eq 0 -or ($savedPreflight -join "`n") -notmatch 'ProjectRoot'){throw ('保存済みProjectの暗黙利用を安全停止できませんでした: '+($savedPreflight -join ' / '))}
        Write-Host '  [OK] CLI project-preflightは明示ProjectRoot/旧明示方式だけ許可し、保存済みProjectの暗黙利用を拒否'

        $guiText=[System.IO.File]::ReadAllText((Join-Path $script:Root 'gui.ps1'),[System.Text.Encoding]::UTF8)
        foreach($pattern in @('プロジェクトフォルダを開く','Get-ProjectFolderCheckFromCli','project-folder-set','WorkbookSelectionStatus','-ProjectRoot','IsGitRepository','RecoveryRequired')){
            if($guiText -notmatch [regex]::Escape($pattern)){throw "GUI直接参照要件が見つかりません: $pattern"}
        }
        if($guiText -match 'git\s+(clone|pull|push|checkout|fetch|reset)'){throw 'GUIに禁止されたGit操作が含まれています。'}
        if(-not (Test-CodexExcludedRelativePath -RelativePath '.git/config')){throw '.gitがCodex ZIP除外対象になっていません。'}
        $guiRuntime=@(& powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File (Join-Path $script:Root 'gui.ps1') -DirectReferenceSelfTest @(Get-TestPropagationArguments) 2>&1)
        if($LASTEXITCODE -ne 0){throw ('直接参照GUIランタイムテストに失敗しました: '+($guiRuntime -join ' / '))}
        Write-Host '  [OK] GUI選択・詳細表示・ブック選択・起動復元・CLI ProjectRoot引渡し'

        $toolRejected=$false
        try{[void](Get-ProjectFolderCheckResult -Path $script:Root);$toolRejected=@((Get-ProjectFolderCheckResult -Path $script:Root).Errors).Count -gt 0}catch{$toolRejected=$true}
        if(-not $toolRejected){throw 'VBAUpdater本体フォルダー指定を拒否できませんでした。'}
        Write-Host '  [OK] VBAUpdater本体フォルダーを安全に拒否'
        Write-Success 'Chapter12-4 Project Folder Direct Reference回帰テストに成功しました。'
    }
    finally {
        $script:ProjectRootOverride=$oldRootOverride
        $script:DirectProjectPathOverride=$oldDirectOverride
        $script:DirectWorkbookPathOverride=$oldWorkbookOverride
        [Environment]::SetEnvironmentVariable($script:ProjectRootSettingsEnvironmentVariable,$oldSettings)
        Remove-Item -LiteralPath $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function New-IsolatedFixtureProject {
    param([Parameter(Mandatory=$true)][string]$ProjectRoot,[string]$ProjectName='IsolationFixture',[AllowEmptyString()][string]$TargetDirectory='target')
    New-Item -ItemType Directory -Path (Join-Path $ProjectRoot 'source\standard'),(Join-Path $ProjectRoot 'target') -Force|Out-Null
    [IO.File]::WriteAllText((Join-Path $ProjectRoot 'source\standard\modFixture.bas'),"Attribute VB_Name = `"modFixture`"`r`nOption Explicit`r`n",(New-Object Text.UTF8Encoding($false)))
    $targetPath=Join-Path $ProjectRoot 'target\Fixture.xlsm'
    [IO.File]::WriteAllText($targetPath,'ISOLATION_FIXTURE_CREATED_DURING_TEST',(New-Object Text.UTF8Encoding($false)))
    $manifest=[ordered]@{schemaVersion='1.0';projectName=$ProjectName;target=[ordered]@{directory=$TargetDirectory;file='Fixture.xlsm';autoDetectWhenMissing=$false};source=[ordered]@{root='source';encoding='utf-8'};components=@([ordered]@{type='standard';name='modFixture';file='standard/modFixture.bas'});validation=[ordered]@{compileAfterPush=$false;requireBackup=$true}}
    [IO.File]::WriteAllText((Join-Path $ProjectRoot 'project.json'),($manifest|ConvertTo-Json -Depth 8),(New-Object Text.UTF8Encoding($false)))
    return [PSCustomObject]@{Root=$ProjectRoot;Target=$targetPath;Manifest=(Join-Path $ProjectRoot 'project.json')}
}

function Invoke-TestIsolationSafetyTest {
    if($null-eq$script:TestExecutionContext){throw '[SAFE1100] Test isolation testはTest Mode必須です。'}
    Write-Info 'Chapter1-9A Test Mode隔離回帰を実行しています...'
    $caseRoot=Join-Path $script:TestExecutionContext.Root ('isolation_'+[guid]::NewGuid().ToString('N'))
    $safeRoot=Join-Path $caseRoot 'safe-project';$duplicateRoot=Join-Path $caseRoot 'duplicate-project';$outsideRoot=Join-Path $caseRoot 'outside-project';$deniedRoot=Join-Path $caseRoot 'registered-business-canary'
    New-Item -ItemType Directory -Path $caseRoot,$safeRoot,$duplicateRoot,$outsideRoot,$deniedRoot -Force|Out-Null
    $safe=New-IsolatedFixtureProject -ProjectRoot $safeRoot -ProjectName 'SafeFixture'
    [void](New-IsolatedFixtureProject -ProjectRoot $duplicateRoot -ProjectName 'Duplicate')
    $denied=New-IsolatedFixtureProject -ProjectRoot $deniedRoot -ProjectName 'RegisteredBusinessCanary'
    Register-TestDeniedRoot -Path $deniedRoot
    $canaryHashBefore=(Get-FileHash -LiteralPath $denied.Target -Algorithm SHA256).Hash

    $settingsPaths=Get-ProjectRootSettingsPaths
    if(-not$settingsPaths.IsTestOverride-or-not(Test-PathWithinRoot -Path $settingsPaths.Folder -Root $script:TestExecutionContext.Root)){throw '[SAFE1101] Test ModeがLOCALAPPDATAから隔離されていません。'}
    $settingsPayload=New-PersistentSettingsPayload -ProjectRoot $caseRoot -LastProjectRoot $deniedRoot -LastWorkbookPath $denied.Target
    [void](Write-SettingsPayloadAtomic -Path $settingsPaths.User -Payload $settingsPayload)
    $registry=@(
        [PSCustomObject]@{Name='MissingDummy';ProjectFolder=(Join-Path $caseRoot 'missing-project');RegisteredAt=[DateTime]::Now.ToString('o');UpdatedAt=[DateTime]::Now.ToString('o')},
        [PSCustomObject]@{Name='RegisteredBusinessCanary';ProjectFolder=$deniedRoot;RegisteredAt=[DateTime]::Now.ToString('o');UpdatedAt=[DateTime]::Now.ToString('o')},
        [PSCustomObject]@{Name='Duplicate';ProjectFolder=$duplicateRoot;RegisteredAt=[DateTime]::Now.ToString('o');UpdatedAt=[DateTime]::Now.ToString('o')},
        [PSCustomObject]@{Name='Duplicate';ProjectFolder=$safeRoot;RegisteredAt=[DateTime]::Now.ToString('o');UpdatedAt=[DateTime]::Now.ToString('o')}
    )
    [IO.File]::WriteAllText($settingsPaths.Projects,($registry|ConvertTo-Json -Depth 5),(New-Object Text.UTF8Encoding($false)))

    $originalDirect=$script:DirectProjectPathOverride;$originalRoot=$script:ProjectRootOverride;$originalWorkbook=$script:DirectWorkbookPathOverride
    try{
        $script:DirectProjectPathOverride=$null;$script:ProjectRootOverride=$null;$script:DirectWorkbookPathOverride=$null
        Initialize-ProjectCommandContext -Arguments @() -CommandName 'project-push'
        $missingRejected=$false;try{[void](Read-ProjectManifest -Project '')}catch{if($_.Exception.Message-match'-Project.*-ProjectRoot'){$missingRejected=$true}else{throw}}
        if(-not$missingRejected){throw '[SAFE1102] -ProjectRoot未指定が拒否されませんでした。'}
        Push-Location $deniedRoot
        try{
            Initialize-ProjectCommandContext -Arguments @() -CommandName 'project-push'
            $cwdRejected=$false;try{[void](Read-ProjectManifest -Project '')}catch{if($_.Exception.Message-match'-Project.*-ProjectRoot'){$cwdRejected=$true}else{throw}}
            if(-not$cwdRejected){throw '[SAFE1102] Test Modeが現在directory外のproject.jsonを暗黙選択しました。'}
        }finally{Pop-Location}
        Write-Host '  [OK] 1/2/3/6: dummy・外部登録・前回選択を参照せず、未指定を安全停止'

        $duplicateRejected=$false;try{[void](Resolve-ProjectPath -Project 'Duplicate')}catch{if($_.Exception.Message-match'同名.*複数'){$duplicateRejected=$true}else{throw}}
        if(-not$duplicateRejected){throw '[SAFE1103] 複数Project候補が拒否されませんでした。'}
        Write-Host '  [OK] 4/5: 現在directory外候補と複数候補を推測選択しない'

        Initialize-ProjectCommandContext -Arguments @('-ProjectRoot',$safeRoot) -CommandName 'project-preflight'
        $safeContext=Read-ProjectManifest -Project ''
        $safeTarget=Resolve-ManifestTarget -Context $safeContext
        if(-not(Test-PathsEqual $safeTarget $safe.Target)){throw '[SAFE1104] 明示ProjectRootの対象解決が一致しません。'}
        Write-Host '  [OK] 7/10: 明示ProjectRootとテスト開始後に作成したFixtureだけを解決'

        $outsideManifest=Get-Content -LiteralPath $safe.Manifest -Raw -Encoding UTF8|ConvertFrom-Json
        $outsideManifest.projectName='OutsideTarget';$outsideManifest.target.directory='..\registered-business-canary\target'
        New-Item -ItemType Directory -Path (Join-Path $outsideRoot 'source\standard') -Force|Out-Null
        Copy-Item -LiteralPath (Join-Path $safeRoot 'source\standard\modFixture.bas') -Destination (Join-Path $outsideRoot 'source\standard\modFixture.bas') -Force
        [IO.File]::WriteAllText((Join-Path $outsideRoot 'project.json'),($outsideManifest|ConvertTo-Json -Depth 8),(New-Object Text.UTF8Encoding($false)))
        Initialize-ProjectCommandContext -Arguments @('-ProjectRoot',$outsideRoot) -CommandName 'project-preflight'
        $outsideContext=Read-ProjectManifest -Project ''
        $outsideRejected=$false;try{[void](Resolve-ManifestTarget -Context $outsideContext)}catch{if($_.Exception.Message-match'SAFE1011|SAFE1030'){$outsideRejected=$true}else{throw}}
        if(-not$outsideRejected){throw '[SAFE1105] Project Root外targetが拒否されませんでした。'}
        Write-Host '  [OK] 9: Project Root外targetをOpen前に拒否'

        $junction=Join-Path $caseRoot 'junction-project';$junctionSupported=$true
        try{New-Item -ItemType Junction -Path $junction -Target $deniedRoot -ErrorAction Stop|Out-Null}catch{$junctionSupported=$false;Write-Warn ('  [SKIP] Junction作成を環境が許可しません: '+$_.Exception.Message)}
        if($junctionSupported){$junctionRejected=$false;try{[void](Assert-TestProjectRootSafety -ProjectRoot $junction)}catch{if($_.Exception.Message-match'SAFE1004|SAFE1011'){$junctionRejected=$true}else{throw}};if(-not$junctionRejected){throw '[SAFE1106] Junction経由の外部Projectが拒否されませんでした。'};Write-Host '  [OK] 8: Junction経由の外部Projectを拒否'}

        $script:CurrentTestProjectRoot=$safeRoot
        Invoke-TestWorkbookOpenAudit -Path $safe.Target
        $safeItem=Get-Item -LiteralPath $safe.Target -Force;$safeItem.IsReadOnly=$true
        $readOnlyRejected=$false;try{Invoke-TestWorkbookOpenAudit -Path $safe.Target}catch{if($_.Exception.Message-match'SAFE1033'){$readOnlyRejected=$true}else{throw}}finally{(Get-Item -LiteralPath $safe.Target -Force).IsReadOnly=$false}
        if(-not$readOnlyRejected){throw '[SAFE1107] 読み取り専用原本が拒否されませんでした。'}
        $canaryOpenRejected=$false;try{Invoke-TestWorkbookOpenAudit -Path $denied.Target}catch{if($_.Exception.Message-match'SAFE1011|SAFE1030'){$canaryOpenRejected=$true}else{throw}}
        if(-not$canaryOpenRejected){throw '[SAFE1107] Canary Workbook Openが拒否されませんでした。'}
        $audit=@();if(Test-Path -LiteralPath $script:TestExecutionContext.OpenAuditPath){$audit=@(Get-Content -LiteralPath $script:TestExecutionContext.OpenAuditPath -Encoding UTF8|ForEach-Object{$_|ConvertFrom-Json})}
        if(@($audit|Where-Object{Test-PathWithinRoot -Path ([string]$_.workbook) -Root $deniedRoot}).Count-ne0){throw '[SAFE1108] Canary WorkbookがOpen auditへ記録されました。'}
        if((Get-FileHash -LiteralPath $denied.Target -Algorithm SHA256).Hash-ne$canaryHashBefore){throw '[SAFE1109] Canary SHA-256が変化しました。'}
        $logProbe=Join-Path (Get-RuntimeLogDirectory) 'write-probe-1.log';$logProbe2=Join-Path (Get-RuntimeLogDirectory) 'write-probe-2.log'
        [IO.File]::WriteAllText($logProbe,'isolated-1',(New-Object Text.UTF8Encoding($false)));[IO.File]::WriteAllText($logProbe2,'isolated-2',(New-Object Text.UTF8Encoding($false)))
        $stream=[IO.File]::Open($logProbe,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None);$stream2=[IO.File]::Open($logProbe2,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None);$stream.Dispose();$stream2.Dispose()
        [IO.File]::AppendAllText($logProbe,'-released',(New-Object Text.UTF8Encoding($false)));[IO.File]::AppendAllText($logProbe2,'-released',(New-Object Text.UTF8Encoding($false)))
        Write-Host ("  [OK] Canary SHA-256不変: {0}" -f $canaryHashBefore)
        Write-Host '  [OK] 読み取り専用原本をWorkbook Open前に拒否'
        Write-Host '  [OK] Log access回帰1/2: 隔離log 2fileへ同時排他open成功'
        Write-Host '  [OK] Log access回帰2/2: handle解放後の再書込成功'
        Write-Success 'Chapter1-9A Test Mode隔離回帰に成功しました。'
    }finally{$script:DirectProjectPathOverride=$originalDirect;$script:ProjectRootOverride=$originalRoot;$script:DirectWorkbookPathOverride=$originalWorkbook}
}

function Invoke-IsolatedRegressionTest {
    if($null-eq$script:TestExecutionContext){throw '[SAFE1120] regression-testはTest Mode必須です。'}
    $canaryRoot=Join-Path $script:TestExecutionContext.Root 'regression-canary';New-Item -ItemType Directory -Path $canaryRoot -Force|Out-Null
    $canary=Join-Path $canaryRoot 'ExternalBusinessCanary.xlsm';[IO.File]::WriteAllText($canary,'DO_NOT_OPEN_OR_CHANGE',(New-Object Text.UTF8Encoding($false)));Register-TestDeniedRoot -Path $canaryRoot;$before=(Get-FileHash $canary -Algorithm SHA256).Hash
    $commands=@('version','help','preflight-test','manifest-test','normalize-test','prepare-source-test','standalone-diff-test','differential-push-test','rollback-test','integrity-test','cli-core-test','compile-gate-optional-test','gui-process-test','gui-usability-test','gui-renewal-test','project-registration-test','project-registration-hotfix-test','project-create-test','project-registration-v418-test','settings-persistence-test','project-root-test','project-root-migration-test','codex-integration-test','project-folder-direct-reference-test','workbook-test','test-isolation-test')
    $results=New-Object 'System.Collections.Generic.List[object]';$scriptPath=Join-Path $script:Root 'vba.ps1'
    foreach($name in $commands){$childArgs=@('-NoProfile','-ExecutionPolicy','Bypass','-File',$scriptPath,$name)+@(Get-TestPropagationArguments);$output=@(& powershell.exe @childArgs 2>&1);$exitCode=$LASTEXITCODE;$results.Add([PSCustomObject]@{command=$name;exitCode=$exitCode;tail=(@($output|Select-Object -Last 1)-join' ')});if($exitCode-ne0){throw "隔離回帰に失敗しました: $name / $($output-join' / ')"};Write-Host ("  [OK] {0}" -f $name)}
    $after=(Get-FileHash $canary -Algorithm SHA256).Hash;if($after-ne$before){throw '[SAFE1121] 一括回帰でCanaryが変更されました。'}
    $audit=@();if(Test-Path -LiteralPath $script:TestExecutionContext.OpenAuditPath){$audit=@(Get-Content $script:TestExecutionContext.OpenAuditPath -Encoding UTF8|ForEach-Object{$_|ConvertFrom-Json})};if(@($audit|Where-Object{Test-PathWithinRoot -Path ([string]$_.workbook) -Root $canaryRoot}).Count){throw '[SAFE1122] 一括回帰でCanaryがOpenされました。'}
    Write-Host ("Canary SHA-256: {0}" -f $after);Write-Host ("成功: {0} / 失敗: 0" -f $results.Count);Write-Success '隔離包括回帰に成功しました。'
}

function Invoke-IsolatedExcelRegressionTest {
    if($null-eq$script:TestExecutionContext){throw '[SAFE1130] isolated-excel-regression-testはTest Mode必須です。'}
    $testRoot=$script:TestExecutionContext.Root
    $canaryRoot=Join-Path $testRoot 'excel-canary'
    New-Item -ItemType Directory -Path $canaryRoot -Force|Out-Null
    $canary=Join-Path $canaryRoot 'ExternalBusinessCanary.xlsm'
    [IO.File]::WriteAllText($canary,'DO_NOT_OPEN_OR_CHANGE',(New-Object Text.UTF8Encoding($false)))
    Register-TestDeniedRoot -Path $canaryRoot
    $canaryBefore=(Get-FileHash -LiteralPath $canary -Algorithm SHA256).Hash
    $excelBefore=@(Get-Process EXCEL -ErrorAction SilentlyContinue|Select-Object -ExpandProperty Id)
    $scriptPath=Join-Path $script:Root 'vba.ps1'

    function Invoke-IsolatedExcelChild([string]$Name,[string[]]$ChildArguments){
        $processArguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',$scriptPath,$Name)+@($ChildArguments)+@(Get-TestPropagationArguments)
        $output=@(& powershell.exe @processArguments 2>&1)
        $exitCode=$LASTEXITCODE
        if($exitCode-ne0){throw ("隔離Excel回帰に失敗しました: {0} / {1}" -f $Name,($output-join' / '))}
        Write-Host ("  [OK] {0}" -f $Name)
        return @($output)
    }

    $sourceSample=Join-Path $script:Root 'samples\workbook-minimal'
    if(-not(Test-Path -LiteralPath (Join-Path $sourceSample 'project.json') -PathType Leaf)){throw 'Workbook最小sampleがありません。'}
    $integratedRoot=Join-Path $testRoot 'fixtures\integrated-project'
    New-Item -ItemType Directory -Path (Split-Path -Parent $integratedRoot) -Force|Out-Null
    Copy-Item -LiteralPath $sourceSample -Destination $integratedRoot -Recurse -Force
    $integratedTarget=Join-Path $integratedRoot 'target\WorkbookMinimalSample.xlsm'
    (Get-Item -LiteralPath $integratedTarget -Force).CreationTimeUtc=[DateTime]::UtcNow

    $vbaOnlyRoot=Join-Path $testRoot 'fixtures\vba-only-project'
    Copy-Item -LiteralPath $integratedRoot -Destination $vbaOnlyRoot -Recurse -Force
    $vbaManifestPath=Join-Path $vbaOnlyRoot 'project.json'
    $vbaManifest=Get-Content -LiteralPath $vbaManifestPath -Raw -Encoding UTF8|ConvertFrom-Json
    $vbaManifest.projectName='WorkbookMinimalVbaOnly'
    $vbaManifest.PSObject.Properties.Remove('workbook')
    [IO.File]::WriteAllText($vbaManifestPath,($vbaManifest|ConvertTo-Json -Depth 12),(New-Object Text.UTF8Encoding($false)))
    $vbaTarget=Join-Path $vbaOnlyRoot 'target\WorkbookMinimalSample.xlsm'
    (Get-Item -LiteralPath $vbaTarget -Force).CreationTimeUtc=[DateTime]::UtcNow

    try{
        $legacyRoot=Join-Path $testRoot 'legacy-test'
        [void](Invoke-IsolatedExcelChild 'test-create' @())
        [void](Invoke-IsolatedExcelChild 'push-standard' @('-WorkbookPath',(Join-Path $legacyRoot 'VBAAddinEngineTest.xlsm'),'-SourcePath',(Join-Path $legacyRoot 'modAddinTarget.bas'),'-ComponentName','modAddinTarget'))
        [void](Invoke-IsolatedExcelChild 'test-run' @())
        [void](Invoke-IsolatedExcelChild 'class-test-create' @())
        [void](Invoke-IsolatedExcelChild 'push-class' @('-WorkbookPath',(Join-Path $legacyRoot 'VBAClassEngineTest.xlsm'),'-SourcePath',(Join-Path $legacyRoot 'clsAddinTarget.cls'),'-ComponentName','clsAddinTarget'))
        [void](Invoke-IsolatedExcelChild 'class-test-run' @())
        [void](Invoke-IsolatedExcelChild 'document-test-create' @())
        [void](Invoke-IsolatedExcelChild 'document-test-push' @())
        [void](Invoke-IsolatedExcelChild 'document-test-run' @())
        [void](Invoke-IsolatedExcelChild 'userform-test-create' @())
        [void](Invoke-IsolatedExcelChild 'userform-test-push' @())
        [void](Invoke-IsolatedExcelChild 'userform-test-run' @())
        $workbookIntegrationOutput=@(Invoke-IsolatedExcelChild 'workbook-integration-test' @())
        foreach($line in @($workbookIntegrationOutput|Where-Object{[string]$_-match'正式Project構造|Backup作成|復元成功試験'})){Write-Host ('    '+[string]$line)}
        $integratedArgs=@('-ProjectRoot',$integratedRoot,'-WorkbookPath',$integratedTarget)
        [void](Invoke-IsolatedExcelChild 'workbook-validate' $integratedArgs)
        [void](Invoke-IsolatedExcelChild 'workbook-diff' $integratedArgs)
        [void](Invoke-IsolatedExcelChild 'workbook-apply' $integratedArgs)
        [void](Invoke-IsolatedExcelChild 'workbook-verify' $integratedArgs)
        $secondWorkbookDiff=@(Invoke-IsolatedExcelChild 'workbook-diff' $integratedArgs)
        if(($secondWorkbookDiff-join"`n")-notmatch'Changed\s+:\s+0'){throw 'Workbook再Diffが0件ではありません。'}
        [void](Invoke-IsolatedExcelChild 'project-push' $integratedArgs)
        $secondIntegratedPush=@(Invoke-IsolatedExcelChild 'project-push' $integratedArgs)
        if(($secondIntegratedPush-join"`n")-notmatch'(変更対象はありません|Changed\s+:\s+0)'){throw '統合Push再実行のVBA差分が0件ではありません。'}

        $vbaArgs=@('-ProjectRoot',$vbaOnlyRoot,'-WorkbookPath',$vbaTarget)
        [void](Invoke-IsolatedExcelChild 'project-diff' $vbaArgs)
        [void](Invoke-IsolatedExcelChild 'project-push' $vbaArgs)
        [void](Invoke-IsolatedExcelChild 'project-pull' $vbaArgs)

        $canaryAfter=(Get-FileHash -LiteralPath $canary -Algorithm SHA256).Hash
        if($canaryAfter-ne$canaryBefore){throw '[SAFE1131] Excel回帰でCanaryが変更されました。'}
        $audit=@();if(Test-Path -LiteralPath $script:TestExecutionContext.OpenAuditPath){$audit=@(Get-Content -LiteralPath $script:TestExecutionContext.OpenAuditPath -Encoding UTF8|Where-Object{-not[string]::IsNullOrWhiteSpace($_)}|ForEach-Object{$_|ConvertFrom-Json})}
        if(@($audit|Where-Object{Test-PathWithinRoot -Path ([string]$_.workbook) -Root $canaryRoot}).Count){throw '[SAFE1132] Excel回帰でCanaryがOpenされました。'}
    }
    finally{
        [GC]::Collect();[GC]::WaitForPendingFinalizers();Start-Sleep -Milliseconds 500
    }
    $excelAfter=@(Get-Process EXCEL -ErrorAction SilentlyContinue|Where-Object{$excelBefore-notcontains$_.Id})
    if($excelAfter.Count){throw ("[SAFE1133] Excel processが残留しました: {0}" -f (($excelAfter|Select-Object -ExpandProperty Id)-join','))}
    Write-Host ("Canary SHA-256: {0}" -f $canaryBefore)
    Write-Host ("Workbook Open監査件数: {0}" -f @($audit).Count)
    Write-Success '隔離Excel包括回帰に成功しました。'
}

function Initialize-ProjectCommandContext {
    param([AllowNull()][object]$Arguments,[AllowEmptyString()][string]$CommandName)
    $script:ProjectRootOverride=$null
    $script:DirectProjectPathOverride=$null
    $script:DirectWorkbookPathOverride=Get-NamedArgument -Arguments $Arguments -Name '-WorkbookPath'
    $script:ProjectRootCorrectionMessage=''
    $requested=Get-NamedArgument -Arguments $Arguments -Name '-ProjectRoot'
    if ([string]::IsNullOrWhiteSpace($requested)) {
        $explicitProject=Get-NamedArgument -Arguments $Arguments -Name '-Project'
        $projectCommands=@('project-preflight','project-compile','project-push','project-pull','project-sync','project-diff','workbook-validate','workbook-diff','workbook-apply','workbook-verify','prepare-source','integrity','rollback-list','rollback','code-read-test','codex-export','codex-import-preview','codex-import')
        if ([string]::IsNullOrWhiteSpace($explicitProject) -and $CommandName.ToLowerInvariant() -in $projectCommands -and $null-eq$script:TestExecutionContext) {
            $currentProject=Find-CurrentProjectDirectory
            if(-not[string]::IsNullOrWhiteSpace($currentProject)){
                Test-DirectProjectToolSafety -Path $currentProject
                $script:DirectProjectPathOverride=$currentProject
                $script:ProjectRootOverride=Split-Path -Parent $currentProject
                Write-Info ("現在directoryのproject.jsonを使用します: {0}" -f $currentProject)
            }
        }
        return
    }
    if (Test-IsDirectProjectPath -Path $requested) {
        $resolution=Get-DirectProjectPathResolution -Path $requested
        Test-DirectProjectToolSafety -Path $resolution.Path
        $script:DirectProjectPathOverride=$resolution.Path
        $script:ProjectRootCorrectionMessage=$resolution.CorrectionMessage
        $parent=Split-Path -Parent $resolution.Path
        if ([string]::IsNullOrWhiteSpace($parent)) { $parent=[System.IO.Path]::GetPathRoot($resolution.Path) }
        $script:ProjectRootOverride=$parent
        if (-not [string]::IsNullOrWhiteSpace($resolution.CorrectionMessage)) { Write-Warn $resolution.CorrectionMessage }
        return
    }
    $script:ProjectRootOverride=$requested
}


try {
    if ([string]::IsNullOrWhiteSpace($Command)) {
        Show-Usage
        exit 1
    }

    Initialize-IsolatedTestExecutionContext -CommandName $Command -Arguments $RemainingArgs
    Initialize-ProjectCommandContext -Arguments $RemainingArgs -CommandName $Command
    $script:JsonOutputRequested = Test-CliSwitch -Parsed (Parse-CliArguments -Arguments $RemainingArgs) -Name '-Json'

    switch ($Command.ToLowerInvariant()) {
        "version"       { Write-Host "$script:ToolName Ver$script:ToolVersion" }
        "gui"           { Invoke-Gui -Arguments $RemainingArgs }
        "addin-build"   { Invoke-AddinBuild }
        "addin-doctor"  { Invoke-AddinDoctor }
        "preflight"      { Invoke-Preflight -Arguments $RemainingArgs }
        "compile-check"  { Invoke-CompileCheck -Arguments $RemainingArgs }
        "preflight-test" { Invoke-PreflightTest }
        "project-preflight" { Invoke-ProjectPreflight -Arguments $RemainingArgs }
        "project-root" { Invoke-ProjectRoot -Arguments $RemainingArgs }
        "project-root-check" { Invoke-ProjectRootCheck -Arguments $RemainingArgs }
        "project-root-set" { Invoke-ProjectRootSet -Arguments $RemainingArgs }
        "project-root-reset" { Invoke-ProjectRootReset }
        "settings" { Invoke-Settings -Arguments $RemainingArgs }
        "projects" { Invoke-Projects -Arguments $RemainingArgs }
        "project-unregister" { Invoke-ProjectUnregister -Arguments $RemainingArgs }
        "project-relocate" { Invoke-ProjectRelocate -Arguments $RemainingArgs }
        "settings-gui-set" { Invoke-GuiSettingsSet -Arguments $RemainingArgs }
        "project-migration-check" { Invoke-ProjectMigrationCheck -Arguments $RemainingArgs }
        "project-migrate" { Invoke-ProjectMigration -Arguments $RemainingArgs }
        "project-folder-check" { Invoke-ProjectFolderCheck -Arguments $RemainingArgs }
        "project-folder-set" { Invoke-ProjectFolderSet -Arguments $RemainingArgs }
        "project-registration-validate" { Invoke-ProjectRegistrationValidate -Arguments $RemainingArgs }
        "project-create" { Invoke-ProjectCreate -Arguments $RemainingArgs }
        "project-push" { Invoke-ProjectPush -Arguments $RemainingArgs }
        "workbook-validate" { Invoke-WorkbookCliCommand -Arguments $RemainingArgs -Mode Validate }
        "workbook-diff" { Invoke-WorkbookCliCommand -Arguments $RemainingArgs -Mode Diff }
        "workbook-apply" { Invoke-WorkbookCliCommand -Arguments $RemainingArgs -Mode Apply }
        "workbook-verify" { Invoke-WorkbookCliCommand -Arguments $RemainingArgs -Mode Verify }
        "workbook-test" { Invoke-WorkbookTest }
        "workbook-integration-test" { Invoke-WorkbookIntegrationTestCommand }
        "test-isolation-test" { Invoke-TestIsolationSafetyTest }
        "regression-test" { Invoke-IsolatedRegressionTest }
        "isolated-excel-regression-test" { Invoke-IsolatedExcelRegressionTest }
        "project-pull" { Invoke-ProjectPull -Arguments $RemainingArgs }
        "project-sync" { Invoke-ProjectSync -Arguments $RemainingArgs }
        "codex-export" { Invoke-CodexExport -Arguments $RemainingArgs }
        "codex-import-preview" { Invoke-CodexImportPreview -Arguments $RemainingArgs }
        "codex-import" { Invoke-CodexImport -Arguments $RemainingArgs }
        "status" { Invoke-ProjectStatus -Arguments $RemainingArgs }
        "history" { Invoke-ProjectHistory -Arguments $RemainingArgs }
        "cli-core-test" { Invoke-CliCoreTest }
        "gui-process-test" { Invoke-GuiProcessTest }
        "gui-usability-test" { Invoke-GuiUsabilityTest }
        "gui-renewal-test" { Invoke-GuiRenewalTest }
        "project-registration-test" { Invoke-ProjectRegistrationTest }
        "project-registration-hotfix-test" { Invoke-ProjectRegistrationHotFixTest }
        "project-create-test" { Invoke-ProjectCreateTest }
        "project-registration-v418-test" { Invoke-ProjectRegistration418Test }
        "settings-persistence-test" { Invoke-SettingsPersistenceTest }
        "project-root-test" { Invoke-ProjectRootTest }
        "project-root-migration-test" { Invoke-ProjectRootMigrationTest }
        "codex-integration-test" { Invoke-CodexIntegrationTest }
        "project-folder-direct-reference-test" { Invoke-ProjectFolderDirectReferenceTest }
        "compile-gate-optional-test" { Invoke-CompileGateOptionalTest -Arguments $RemainingArgs }
        "code-read-test" { Invoke-CodeReadTest -Arguments $RemainingArgs }
        "rollback-list" { Invoke-ProjectRollbackList -Arguments $RemainingArgs }
        "rollback" { Invoke-ProjectRollback -Arguments $RemainingArgs }
        "rollback-test" { Invoke-RollbackTest }
        "integrity" { Invoke-ProjectIntegrity -Arguments $RemainingArgs }
        "integrity-test" { Invoke-IntegrityTest }
        "project-compile" { Invoke-ProjectCompile -Arguments $RemainingArgs }
        "manifest-test" { Invoke-ManifestTest }
        "normalize-test" { Invoke-NormalizeTest }
        "prepare-source-test" { Invoke-PrepareSourceTest }
        "prepare-source" { Invoke-PrepareSourceCommand -Arguments $RemainingArgs }
        "project-diff" { Invoke-ProjectDiff -Arguments $RemainingArgs }
        "standalone-diff-test" { Invoke-StandaloneDiffTest }
        "differential-push-test" { Invoke-DifferentialPushTest }
        "test-create"   { Invoke-TestCreate }
        "push-standard"    { Invoke-PushStandard -Arguments $RemainingArgs }
        "push-class"       { Invoke-PushClass -Arguments $RemainingArgs }
        "push-document"    { Invoke-PushDocument -Arguments $RemainingArgs }
        "push-userform"    { Invoke-PushUserForm -Arguments $RemainingArgs }
        "class-test-create" { Invoke-ClassTestCreate }
        "class-test-run"   { Invoke-ClassTestRun }
        "document-test-create" { Invoke-DocumentTestCreate }
        "document-test-push"   { Invoke-DocumentTestPush }
        "document-test-run"    { Invoke-DocumentTestRun }
        "userform-test-create" { Invoke-UserFormTestCreate }
        "userform-test-push"   { Invoke-UserFormTestPush }
        "userform-test-run"    { Invoke-UserFormTestRun }
        "test-run"         { Invoke-TestRun }
        "help"          { Show-Usage }
        "--help"        { Show-Usage }
        "-h"            { Show-Usage }
        default {
            Write-Failure "不明なコマンドです: $Command"
            Show-Usage
            exit 1
        }
    }
    Complete-IsolatedTestExecutionContext
}
catch {
    if ($script:JsonOutputRequested -and $Command -in @('workbook-validate','workbook-diff','workbook-apply','workbook-verify')) {
        $code='WB9999'
        if($_.Exception.Message -match '\[(WB[0-9]{4})\]'){$code=$matches[1]}
        [PSCustomObject]@{success=$false;code=$code;command=$Command;project=(Get-NamedArgument -Arguments $RemainingArgs -Name '-Project');errors=@($_.Exception.Message)}|ConvertTo-Json -Depth 5
    }
    elseif ($script:JsonOutputRequested -and $Command -in @('codex-export','codex-import-preview','codex-import')) {
        $failureZipPath = if ($Command -eq 'codex-export') { Get-NamedArgument -Arguments $RemainingArgs -Name '-OutputPath' } else { Get-NamedArgument -Arguments $RemainingArgs -Name '-ZipPath' }
        [PSCustomObject]@{
            success=$false; project=(Get-NamedArgument -Arguments $RemainingArgs -Name '-Project')
            zipPath=$failureZipPath
            added=@(); modified=@(); deleted=@(); unchanged=@(); ignored=@(); dangerous=@()
            structuralErrors=@(); warnings=@(); errors=@($_.Exception.Message)
            backupPath=''; applied=$false; deletesApplied=$false; syncExecuted=$false
        } | ConvertTo-Json -Depth 12
    }
    else { Write-Failure $_.Exception.Message }
    Complete-IsolatedTestExecutionContext
    exit 1
}
