﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Resolve-PrepareSourcePath {
    param(
        [Parameter(Mandatory=$true)][string]$ProjectDir,
        [Parameter(Mandatory=$true)][string]$SourceRoot,
        [Parameter(Mandatory=$true)][string]$RelativePath
    )

    $combined = Join-Path $SourceRoot $RelativePath
    if ([System.IO.Path]::IsPathRooted($combined)) {
        return [System.IO.Path]::GetFullPath($combined)
    }
    return [System.IO.Path]::GetFullPath((Join-Path $ProjectDir $combined))
}

function Invoke-VbaPrepareSource {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$ProjectDir,
        [Parameter(Mandatory=$true)]$Manifest,
        [string]$LogDirectory,
        [switch]$SkipJson
    )

    if (-not (Test-Path -LiteralPath $ProjectDir -PathType Container)) {
        throw "プロジェクトフォルダが見つかりません: $ProjectDir"
    }
    if ($null -eq $Manifest.PSObject.Properties['projectName'] -or
        [string]::IsNullOrWhiteSpace([string]$Manifest.projectName)) {
        throw 'projectNameが空です。'
    }
    if ($null -eq $Manifest.PSObject.Properties['source'] -or
        $null -eq $Manifest.source.PSObject.Properties['root'] -or
        [string]::IsNullOrWhiteSpace([string]$Manifest.source.root)) {
        throw 'source.rootが指定されていません。'
    }
    if ($null -eq $Manifest.PSObject.Properties['components'] -or
        @($Manifest.components).Count -eq 0) {
        throw 'componentsを1件以上指定してください。'
    }

    $supported = @('standard','class','document','userform')
    $sourceRoot = [string]$Manifest.source.root
    $items = @()
    $failed = 0

    foreach ($component in @($Manifest.components)) {
        $type = ([string]$component.type).ToLowerInvariant()
        $name = [string]$component.name
        $relativeFile = [string]$component.file

        if ($supported -notcontains $type) {
            throw "未対応のコンポーネント種別です: $type"
        }
        if ([string]::IsNullOrWhiteSpace($name)) {
            throw 'component.nameが空です。'
        }
        if ([string]::IsNullOrWhiteSpace($relativeFile)) {
            throw "component.fileが空です: $name"
        }

        $sourcePath = Resolve-PrepareSourcePath -ProjectDir $ProjectDir -SourceRoot $sourceRoot -RelativePath $relativeFile
        $status = 'ok'
        $message = ''
        $binaryPath = $null

        if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf)) {
            $status = 'failed'
            $message = "ソースファイルが見つかりません: $sourcePath"
        }
        elseif ((Get-Item -LiteralPath $sourcePath).Length -eq 0) {
            $status = 'failed'
            $message = "ソースファイルが空です: $sourcePath"
        }

        if ($status -eq 'ok' -and $type -eq 'userform') {
            if ($component.PSObject.Properties['binaryFile'] -and
                -not [string]::IsNullOrWhiteSpace([string]$component.binaryFile)) {
                $binaryPath = Resolve-PrepareSourcePath -ProjectDir $ProjectDir -SourceRoot $sourceRoot -RelativePath ([string]$component.binaryFile)
            }
            else {
                $binaryPath = [System.IO.Path]::ChangeExtension($sourcePath, '.frx')
            }

            if (-not (Test-Path -LiteralPath $binaryPath -PathType Leaf)) {
                $status = 'failed'
                $message = "UserFormの.frxが見つかりません: $binaryPath"
            }
        }

        if ($status -eq 'failed') { $failed++ }
        $items += [PSCustomObject]@{
            name = $name
            type = $type
            status = $status
            sourcePath = $sourcePath
            binaryPath = $binaryPath
            message = $message
        }
    }

    $resultPath = $null
    $result = [PSCustomObject]@{
        schemaVersion = '1.0'
        project = [string]$Manifest.projectName
        timestamp = [DateTime]::Now.ToString('o')
        summary = [PSCustomObject]@{
            components = @($items).Count
            ok = @($items | Where-Object { $_.status -eq 'ok' }).Count
            failed = $failed
        }
        components = @($items)
        resultJson = $null
    }

    if (-not $SkipJson) {
        if ([string]::IsNullOrWhiteSpace($LogDirectory)) {
            $LogDirectory = Join-Path $ProjectDir 'logs'
        }
        New-Item -ItemType Directory -Path $LogDirectory -Force | Out-Null
        $resultPath = Join-Path $LogDirectory ('prepare_source_' + [DateTime]::Now.ToString('yyyyMMdd_HHmmss_fff') + '.json')
        $result.resultJson = $resultPath
        $json = $result | ConvertTo-Json -Depth 8
        [System.IO.File]::WriteAllText($resultPath, $json, (New-Object System.Text.UTF8Encoding($false)))
    }

    if ($failed -gt 0) {
        $first = @($items | Where-Object { $_.status -eq 'failed' })[0]
        throw [System.InvalidOperationException]::new([string]$first.message)
    }

    return $result
}

Export-ModuleMember -Function Invoke-VbaPrepareSource
