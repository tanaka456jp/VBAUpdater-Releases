﻿Set-StrictMode -Version 2.0

function ConvertTo-VBAUpdaterVersion {
    param([Parameter(Mandatory=$true)][string]$Version)
    $clean=($Version -replace '^[vV]','').Trim()
    try { return [version]$clean } catch { return $null }
}

function Get-VBAUpdaterUpdateManifest {
    param([Parameter(Mandatory=$true)][string]$ManifestUri)
    if([string]::IsNullOrWhiteSpace($ManifestUri)){ throw '更新情報URLが設定されていません。' }
    $response=Invoke-WebRequest -Uri $ManifestUri -UseBasicParsing -TimeoutSec 20
    $manifest=$response.Content | ConvertFrom-Json
    foreach($name in @('schemaVersion','version','downloadUrl','sha256')){
        if($null -eq $manifest.$name -or [string]::IsNullOrWhiteSpace([string]$manifest.$name)){
            throw "更新情報に必須項目がありません: $name"
        }
    }
    return $manifest
}

function Test-VBAUpdaterUpdateAvailable {
    param(
        [Parameter(Mandatory=$true)][string]$CurrentVersion,
        [Parameter(Mandatory=$true)]$Manifest
    )
    $current=ConvertTo-VBAUpdaterVersion $CurrentVersion
    $latest=ConvertTo-VBAUpdaterVersion ([string]$Manifest.version)
    if($null -eq $current -or $null -eq $latest){ throw 'バージョン番号を比較できません。' }
    return ($latest -gt $current)
}

function Test-VBAUpdaterDownloadedPackage {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$ExpectedSha256
    )
    if(-not (Test-Path -LiteralPath $Path -PathType Leaf)){ return $false }
    $actual=(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash
    return ($actual -ieq $ExpectedSha256.Trim())
}

Export-ModuleMember -Function ConvertTo-VBAUpdaterVersion,Get-VBAUpdaterUpdateManifest,Test-VBAUpdaterUpdateAvailable,Test-VBAUpdaterDownloadedPackage
