VBAUpdater Ver1.0 - Manual Guide
================================

このフォルダーには VBAUpdater Ver1.0 の利用ガイドを格納します。
現在の配布UIは Chapter4-2 FINAL Windows Standard UI を基準としています。

最初に読むもの
--------------
1. App\START_HERE.txt
2. Manual\01_SAMPLE_QUICK_START.txt
3. Manual\02_WINDOWS_STANDARD_UI.txt

問題調査が必要な場合は、GUIの「開発者」ページから「サポートZIPを作成」を利用できます。
旧Phase1／Distribution UX HotFixのファイル名は製品版Manualから除去し、用途が分かる名称へ整理しています。
