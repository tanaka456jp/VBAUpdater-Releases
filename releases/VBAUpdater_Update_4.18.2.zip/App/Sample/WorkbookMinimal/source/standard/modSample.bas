Attribute VB_Name = "modSample"
Option Explicit

Public Sub ShowManagedTitle()
    MsgBox ThisWorkbook.Worksheets("Main").Range("A1").Value
End Sub

