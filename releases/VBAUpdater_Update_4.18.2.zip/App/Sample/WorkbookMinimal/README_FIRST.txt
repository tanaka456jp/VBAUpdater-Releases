﻿WorkbookMinimal - VBAUpdater練習用サンプル
========================================
target\WorkbookMinimalSample.xlsm : 練習用Excelブック
source\ : 正本として扱うサンプルSource
project.json : プロジェクト定義

操作前に Manual\01_SAMPLE_QUICK_START.txt を読んでください。
