Attribute VB_Name = "modVBAUpdaterEngine"
Option Explicit

Private Const VBEXT_CT_STDMODULE As Long = 1
Private Const VBEXT_CT_CLASSMODULE As Long = 2
Private Const VBEXT_CT_MSFORM As Long = 3
Private Const VBEXT_CT_DOCUMENT As Long = 100

Public Function Ping() As String
    Ping = "VBA_UPDATER_ADDIN_OK"
End Function





Public Sub UpdateUserForm( _
        ByVal targetWorkbookPath As String, _
        ByVal sourceFilePath As String, _
        ByVal componentName As String, _
        ByVal resultFilePath As String)

    Dim targetBook As Workbook
    Dim vbProject As Object
    Dim existingComponent As Object
    Dim importedComponent As Object
    Dim sourceFrxPath As String
    Dim success As Boolean
    Dim createdNew As Boolean
    Dim errorNumber As Long
    Dim errorMessage As String

    On Error GoTo ErrorHandler

    ValidateInputs targetWorkbookPath, sourceFilePath, componentName, resultFilePath

    If LCase$(Right$(sourceFilePath, 4)) <> ".frm" Then
        Err.Raise vbObjectError + 4301, _
                  "UpdateUserForm", _
                  "UserForm�\�[�X�ɂ�.frm�t�@�C�����w�肵�Ă��������B"
    End If

    sourceFrxPath = Left$(sourceFilePath, Len(sourceFilePath) - 4) & ".frx"

    If Dir$(sourceFrxPath, vbNormal Or vbHidden Or vbSystem Or vbReadOnly) = vbNullString Then
        Err.Raise vbObjectError + 4302, _
                  "UpdateUserForm", _
                  "UserForm��.frx�t�@�C����������܂���: " & sourceFrxPath
    End If

    Set targetBook = Application.Workbooks.Open( _
        Filename:=targetWorkbookPath, _
        UpdateLinks:=0, _
        ReadOnly:=False, _
        IgnoreReadOnlyRecommended:=True, _
        AddToMru:=False)

    Set vbProject = targetBook.VBProject

    On Error Resume Next
    Set existingComponent = vbProject.VBComponents.Item(componentName)
    On Error GoTo ErrorHandler

    createdNew = (existingComponent Is Nothing)

    If Not existingComponent Is Nothing Then
        If CLng(existingComponent.Type) <> VBEXT_CT_MSFORM Then
            Err.Raise vbObjectError + 4303, _
                      "UpdateUserForm", _
                      "�����R���|�[�l���g��UserForm�ł͂���܂���: " & componentName
        End If

        vbProject.VBComponents.Remove existingComponent
        Set existingComponent = Nothing
    End If

    Set importedComponent = vbProject.VBComponents.Import(sourceFilePath)

    If importedComponent Is Nothing Then
        Err.Raise vbObjectError + 4304, _
                  "UpdateUserForm", _
                  "UserForm���C���|�[�g�ł��܂���ł����B"
    End If

    If CLng(importedComponent.Type) <> VBEXT_CT_MSFORM Then
        Err.Raise vbObjectError + 4305, _
                  "UpdateUserForm", _
                  "�C���|�[�g�����R���|�[�l���g��UserForm�ł͂���܂���B"
    End If

    If StrComp(importedComponent.Name, componentName, vbBinaryCompare) <> 0 Then
        Err.Raise vbObjectError + 4306, _
                  "UpdateUserForm", _
                  "UserForm������v���܂���BExpected=" & componentName & _
                  " / Actual=" & importedComponent.Name
    End If

    targetBook.Save
    success = True

CleanExit:
    On Error Resume Next

    If Not targetBook Is Nothing Then
        targetBook.Close SaveChanges:=success
    End If

    WriteResultJson _
        resultFilePath, _
        success, _
        componentName, _
        createdNew, _
        targetWorkbookPath, _
        sourceFilePath, _
        errorNumber, _
        errorMessage

    Set importedComponent = Nothing
    Set existingComponent = Nothing
    Set vbProject = Nothing
    Set targetBook = Nothing
    Exit Sub

ErrorHandler:
    success = False
    errorNumber = Err.Number
    errorMessage = Err.Description
    Resume CleanExit

End Sub

Public Sub UpdateDocumentModule( _
        ByVal targetWorkbookPath As String, _
        ByVal sourceFilePath As String, _
        ByVal componentName As String, _
        ByVal resultFilePath As String)

    Dim targetBook As Workbook
    Dim vbProject As Object
    Dim component As Object
    Dim codeModule As Object
    Dim sourceText As String
    Dim sourceCode As String
    Dim success As Boolean
    Dim createdNew As Boolean
    Dim errorNumber As Long
    Dim errorMessage As String

    On Error GoTo ErrorHandler

    ValidateInputs targetWorkbookPath, sourceFilePath, componentName, resultFilePath

    Set targetBook = Application.Workbooks.Open( _
        Filename:=targetWorkbookPath, _
        UpdateLinks:=0, _
        ReadOnly:=False, _
        IgnoreReadOnlyRecommended:=True, _
        AddToMru:=False)

    Set vbProject = targetBook.VBProject

    On Error Resume Next
    Set component = vbProject.VBComponents.Item(componentName)
    On Error GoTo ErrorHandler

    If component Is Nothing Then
        Err.Raise vbObjectError + 4201, _
                  "UpdateDocumentModule", _
                  "Document Module�͐V�K�쐬�ł��܂���B�Ώۂ�������܂���: " & componentName
    ElseIf CLng(component.Type) <> VBEXT_CT_DOCUMENT Then
        Err.Raise vbObjectError + 4202, _
                  "UpdateDocumentModule", _
                  "�w�肳�ꂽ�R���|�[�l���g��Document Module�ł͂���܂���: " & componentName
    End If

    sourceText = ReadUtf8Text(sourceFilePath)
    sourceCode = ExtractDocumentCode(sourceText)

    If Len(Trim$(sourceCode)) = 0 Then
        Err.Raise vbObjectError + 4203, _
                  "UpdateDocumentModule", _
                  "Document Module��VBA�R�[�h�𒊏o�ł��܂���ł����B"
    End If

    Set codeModule = component.CodeModule
    ReplaceAllCode codeModule, sourceCode

    If CLng(codeModule.CountOfLines) <= 0 Then
        Err.Raise vbObjectError + 4204, _
                  "UpdateDocumentModule", _
                  "Document Module�X�V��̃R�[�h�s����0�ł��B"
    End If

    targetBook.Save
    success = True

CleanExit:
    On Error Resume Next

    If Not targetBook Is Nothing Then
        targetBook.Close SaveChanges:=success
    End If

    WriteResultJson _
        resultFilePath, _
        success, _
        componentName, _
        createdNew, _
        targetWorkbookPath, _
        sourceFilePath, _
        errorNumber, _
        errorMessage

    Set codeModule = Nothing
    Set component = Nothing
    Set vbProject = Nothing
    Set targetBook = Nothing
    Exit Sub

ErrorHandler:
    success = False
    errorNumber = Err.Number
    errorMessage = Err.Description
    Resume CleanExit

End Sub

Private Function ExtractDocumentCode(ByVal sourceText As String) As String

    Dim normalized As String
    Dim lines() As String
    Dim output As String
    Dim i As Long
    Dim lineText As String
    Dim trimmed As String
    Dim codeStarted As Boolean

    normalized = Replace(sourceText, vbCrLf, vbLf)
    normalized = Replace(normalized, vbCr, vbLf)
    lines = Split(normalized, vbLf)

    For i = LBound(lines) To UBound(lines)

        lineText = lines(i)
        trimmed = Trim$(lineText)

        If Not codeStarted Then

            If Len(trimmed) = 0 Then
                '�G�N�X�|�[�g�w�b�_�[���̋�s�͓ǂݔ�΂�
            ElseIf UCase$(Left$(trimmed, 8)) = "VERSION " Then
                'VBE�Ǘ����
            ElseIf UCase$(trimmed) = "BEGIN" Then
                'VBE�Ǘ����
            ElseIf UCase$(trimmed) = "END" Then
                'VBE�Ǘ����
            ElseIf UCase$(Left$(trimmed, 10)) = "ATTRIBUTE " Then
                'VBE�Ǘ����
            ElseIf InStr(1, trimmed, "=", vbBinaryCompare) > 0 _
               And InStr(1, trimmed, "MultiUse", vbTextCompare) > 0 Then
                'VBE�Ǘ����
            Else
                codeStarted = True
                output = lineText
            End If

        Else
            If Len(output) = 0 Then
                output = lineText
            Else
                output = output & vbCrLf & lineText
            End If
        End If

    Next i

    ExtractDocumentCode = output

End Function

Public Sub UpdateClassModule( _
        ByVal targetWorkbookPath As String, _
        ByVal sourceFilePath As String, _
        ByVal componentName As String, _
        ByVal resultFilePath As String)

    Dim targetBook As Workbook
    Dim vbProject As Object
    Dim component As Object
    Dim codeModule As Object
    Dim sourceText As String
    Dim sourceCode As String
    Dim success As Boolean
    Dim createdNew As Boolean
    Dim errorNumber As Long
    Dim errorMessage As String

    On Error GoTo ErrorHandler

    ValidateInputs targetWorkbookPath, sourceFilePath, componentName, resultFilePath

    Set targetBook = Application.Workbooks.Open( _
        Filename:=targetWorkbookPath, _
        UpdateLinks:=0, _
        ReadOnly:=False, _
        IgnoreReadOnlyRecommended:=True, _
        AddToMru:=False)

    Set vbProject = targetBook.VBProject

    On Error Resume Next
    Set component = vbProject.VBComponents.Item(componentName)
    On Error GoTo ErrorHandler

    If component Is Nothing Then
        Set component = vbProject.VBComponents.Add(VBEXT_CT_CLASSMODULE)
        component.Name = componentName
        createdNew = True
    ElseIf CLng(component.Type) <> VBEXT_CT_CLASSMODULE Then
        Err.Raise vbObjectError + 4101, _
                  "UpdateClassModule", _
                  "�����R���|�[�l���g�̓N���X���W���[���ł͂���܂���: " & componentName
    End If

    sourceText = ReadUtf8Text(sourceFilePath)
    sourceCode = ExtractClassCode(sourceText)

    If Len(Trim$(sourceCode)) = 0 Then
        Err.Raise vbObjectError + 4102, _
                  "UpdateClassModule", _
                  "�N���X��VBA�R�[�h�𒊏o�ł��܂���ł����B"
    End If

    Set codeModule = component.CodeModule
    ReplaceAllCode codeModule, sourceCode

    If CLng(codeModule.CountOfLines) <= 0 Then
        Err.Raise vbObjectError + 4103, _
                  "UpdateClassModule", _
                  "�N���X���W���[���̃R�[�h�X�V��A�R�[�h�s����0�ł��B"
    End If

    targetBook.Save
    success = True

CleanExit:
    On Error Resume Next

    If Not targetBook Is Nothing Then
        targetBook.Close SaveChanges:=success
    End If

    WriteResultJson _
        resultFilePath, _
        success, _
        componentName, _
        createdNew, _
        targetWorkbookPath, _
        sourceFilePath, _
        errorNumber, _
        errorMessage

    Set codeModule = Nothing
    Set component = Nothing
    Set vbProject = Nothing
    Set targetBook = Nothing
    Exit Sub

ErrorHandler:
    success = False
    errorNumber = Err.Number
    errorMessage = Err.Description
    Resume CleanExit

End Sub

Private Function ExtractClassCode(ByVal sourceText As String) As String

    Dim normalized As String
    Dim lines() As String
    Dim output As String
    Dim i As Long
    Dim lineText As String
    Dim trimmed As String
    Dim codeStarted As Boolean

    normalized = Replace(sourceText, vbCrLf, vbLf)
    normalized = Replace(normalized, vbCr, vbLf)
    lines = Split(normalized, vbLf)

    For i = LBound(lines) To UBound(lines)

        lineText = lines(i)
        trimmed = Trim$(lineText)

        If Not codeStarted Then

            If Len(trimmed) = 0 Then
                '�w�b�_�[���̋�s�͓ǂݔ�΂�

            ElseIf UCase$(Left$(trimmed, 8)) = "VERSION " Then
                'VBE�Ǘ����

            ElseIf UCase$(trimmed) = "BEGIN" Then
                'VBE�Ǘ����

            ElseIf UCase$(trimmed) = "END" Then
                'VBE�Ǘ����

            ElseIf UCase$(Left$(trimmed, 10)) = "ATTRIBUTE " Then
                'VBE�Ǘ����

            ElseIf InStr(1, trimmed, "=", vbBinaryCompare) > 0 _
               And InStr(1, trimmed, "MultiUse", vbTextCompare) > 0 Then
                'VBE�Ǘ����

            Else
                codeStarted = True
                output = lineText
            End If

        Else

            If Len(output) = 0 Then
                output = lineText
            Else
                output = output & vbCrLf & lineText
            End If

        End If

    Next i

    ExtractClassCode = output

End Function

Public Sub UpdateStandardModule( _
        ByVal targetWorkbookPath As String, _
        ByVal sourceFilePath As String, _
        ByVal componentName As String, _
        ByVal resultFilePath As String)

    Dim targetBook As Workbook
    Dim vbProject As Object
    Dim component As Object
    Dim codeModule As Object
    Dim sourceCode As String
    Dim success As Boolean
    Dim createdNew As Boolean
    Dim errorNumber As Long
    Dim errorMessage As String

    On Error GoTo ErrorHandler

    ValidateInputs targetWorkbookPath, sourceFilePath, componentName, resultFilePath

    Set targetBook = Application.Workbooks.Open( _
        Filename:=targetWorkbookPath, _
        UpdateLinks:=0, _
        ReadOnly:=False, _
        IgnoreReadOnlyRecommended:=True, _
        AddToMru:=False)

    Set vbProject = targetBook.VBProject

    On Error Resume Next
    Set component = vbProject.VBComponents.Item(componentName)
    On Error GoTo ErrorHandler

    If component Is Nothing Then
        Set component = vbProject.VBComponents.Add(VBEXT_CT_STDMODULE)
        component.Name = componentName
        createdNew = True
    ElseIf CLng(component.Type) <> VBEXT_CT_STDMODULE Then
        Err.Raise vbObjectError + 4001, _
                  "UpdateStandardModule", _
                  "�����R���|�[�l���g�͕W�����W���[���ł͂���܂���: " & componentName
    End If

    sourceCode = ExtractStandardCode(ReadUtf8Text(sourceFilePath))

    If Len(Trim$(sourceCode)) = 0 Then
        Err.Raise vbObjectError + 4002, _
                  "UpdateStandardModule", _
                  "�W�����W���[����VBA�R�[�h�𒊏o�ł��܂���ł����B"
    End If

    Set codeModule = component.CodeModule
    ReplaceAllCode codeModule, sourceCode

    targetBook.Save
    success = True

CleanExit:
    On Error Resume Next

    If Not targetBook Is Nothing Then
        targetBook.Close SaveChanges:=success
    End If

    WriteResultJson _
        resultFilePath, _
        success, _
        componentName, _
        createdNew, _
        targetWorkbookPath, _
        sourceFilePath, _
        errorNumber, _
        errorMessage

    Set codeModule = Nothing
    Set component = Nothing
    Set vbProject = Nothing
    Set targetBook = Nothing
    Exit Sub

ErrorHandler:
    success = False
    errorNumber = Err.Number
    errorMessage = Err.Description
    Resume CleanExit

End Sub

Private Function ExtractStandardCode(ByVal sourceText As String) As String

    Dim normalized As String
    Dim lines() As String
    Dim output As String
    Dim i As Long
    Dim lineText As String
    Dim trimmed As String

    normalized = Replace(sourceText, vbCrLf, vbLf)
    normalized = Replace(normalized, vbCr, vbLf)
    lines = Split(normalized, vbLf)

    For i = LBound(lines) To UBound(lines)
        lineText = lines(i)
        trimmed = Trim$(lineText)

        'Attribute�s��VBE�̃G�N�X�|�[�g�Ǘ����ł���A
        'CodeModule.AddFromString�֓n���ƍ\���G���[�ɂȂ�B
        If UCase$(Left$(trimmed, 10)) <> "ATTRIBUTE " Then
            If Len(output) = 0 Then
                output = lineText
            Else
                output = output & vbCrLf & lineText
            End If
        End If
    Next i

    ExtractStandardCode = output

End Function

Private Sub ValidateInputs( _
        ByVal targetWorkbookPath As String, _
        ByVal sourceFilePath As String, _
        ByVal componentName As String, _
        ByVal resultFilePath As String)

    If Len(Trim$(targetWorkbookPath)) = 0 Then
        Err.Raise vbObjectError + 4010, , "�Ώۃu�b�N�̃p�X����ł��B"
    End If

    If Len(Dir$(targetWorkbookPath, vbNormal Or vbHidden Or vbSystem Or vbReadOnly)) = 0 Then
        Err.Raise vbObjectError + 4011, , "�Ώۃu�b�N��������܂���: " & targetWorkbookPath
    End If

    If Len(Trim$(sourceFilePath)) = 0 Then
        Err.Raise vbObjectError + 4012, , "�\�[�X�t�@�C���̃p�X����ł��B"
    End If

    If Len(Dir$(sourceFilePath, vbNormal Or vbHidden Or vbSystem Or vbReadOnly)) = 0 Then
        Err.Raise vbObjectError + 4013, , "�\�[�X�t�@�C����������܂���: " & sourceFilePath
    End If

    If Len(Trim$(componentName)) = 0 Then
        Err.Raise vbObjectError + 4014, , "�R���|�[�l���g������ł��B"
    End If

    If Len(Trim$(resultFilePath)) = 0 Then
        Err.Raise vbObjectError + 4015, , "���ʃt�@�C���̃p�X����ł��B"
    End If

End Sub

Private Function ReadUtf8Text(ByVal filePath As String) As String

    Dim stream As Object
    Dim value As String

    Set stream = CreateObject("ADODB.Stream")

    With stream
        .Type = 2
        .Charset = "utf-8"
        .Open
        .LoadFromFile filePath
        .Position = 0
        value = .ReadText
        .Close
    End With

    If Len(value) > 0 Then
        If AscW(Left$(value, 1)) = &HFEFF Then
            value = Mid$(value, 2)
        End If
    End If

    ReadUtf8Text = value
    Set stream = Nothing

End Function

Private Sub ReplaceAllCode(ByVal codeModule As Object, ByVal sourceCode As String)

    Dim lineCount As Long

    lineCount = CLng(codeModule.CountOfLines)

    If lineCount > 0 Then
        codeModule.DeleteLines 1, lineCount
    End If

    If Len(sourceCode) > 0 Then
        codeModule.AddFromString sourceCode
    End If

End Sub

Private Sub WriteResultJson( _
        ByVal resultFilePath As String, _
        ByVal success As Boolean, _
        ByVal componentName As String, _
        ByVal createdNew As Boolean, _
        ByVal targetWorkbookPath As String, _
        ByVal sourceFilePath As String, _
        ByVal errorNumber As Long, _
        ByVal errorMessage As String)

    Dim jsonText As String
    Dim stream As Object

    jsonText = "{" & vbCrLf & _
               "  ""success"": " & LCase$(CStr(success)) & "," & vbCrLf & _
               "  ""componentName"": """ & EscapeJson(componentName) & """," & vbCrLf & _
               "  ""createdNew"": " & LCase$(CStr(createdNew)) & "," & vbCrLf & _
               "  ""targetWorkbookPath"": """ & EscapeJson(targetWorkbookPath) & """," & vbCrLf & _
               "  ""sourceFilePath"": """ & EscapeJson(sourceFilePath) & """," & vbCrLf & _
               "  ""errorNumber"": " & CStr(errorNumber) & "," & vbCrLf & _
               "  ""errorMessage"": """ & EscapeJson(errorMessage) & """" & vbCrLf & _
               "}"

    Set stream = CreateObject("ADODB.Stream")

    With stream
        .Type = 2
        .Charset = "utf-8"
        .Open
        .WriteText jsonText
        .SaveToFile resultFilePath, 2
        .Close
    End With

    Set stream = Nothing

End Sub

Private Function EscapeJson(ByVal value As String) As String

    value = Replace(value, "\", "\\")
    value = Replace(value, """", "\""")
    value = Replace(value, vbCrLf, "\n")
    value = Replace(value, vbCr, "\n")
    value = Replace(value, vbLf, "\n")

    EscapeJson = value

End Function
