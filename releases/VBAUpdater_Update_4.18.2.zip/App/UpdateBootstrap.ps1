﻿param(
    [Parameter(Mandatory=$true)][string]$ManifestUri,
    [Parameter(Mandatory=$true)][string]$CurrentVersion
)
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSScriptRoot 'tools\ProductUpdate.psm1') -Force

$manifest=Get-VBAUpdaterUpdateManifest -ManifestUri $ManifestUri
if(-not (Test-VBAUpdaterUpdateAvailable -CurrentVersion $CurrentVersion -Manifest $manifest)){
    Write-Output 'NO_UPDATE'
    exit 0
}

$stageRoot=Join-Path $env:LOCALAPPDATA 'VBAUpdater\UpdateStage'
New-Item -ItemType Directory -Path $stageRoot -Force | Out-Null
$fileName='VBAUpdater_Update_'+([string]$manifest.version)+'.zip'
$package=Join-Path $stageRoot $fileName
Invoke-WebRequest -Uri ([string]$manifest.downloadUrl) -OutFile $package -UseBasicParsing -TimeoutSec 60
if(-not (Test-VBAUpdaterDownloadedPackage -Path $package -ExpectedSha256 ([string]$manifest.sha256))){
    Remove-Item -LiteralPath $package -Force -ErrorAction SilentlyContinue
    throw '更新パッケージのSHA-256検証に失敗しました。'
}
[PSCustomObject]@{
    Status='READY_TO_INSTALL'
    Version=[string]$manifest.version
    Package=$package
    ReleaseNotes=[string]$manifest.releaseNotes
} | ConvertTo-Json -Depth 4
